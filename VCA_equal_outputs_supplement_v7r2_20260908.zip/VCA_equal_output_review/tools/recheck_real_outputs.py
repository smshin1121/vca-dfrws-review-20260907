"""Replay the fixed real-output boundary probe in an isolated directory."""

import hashlib
import importlib.util
import json
import runpy
import shutil
import socket
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def integrity():
    entries = json.loads((ROOT / "BUNDLE_MANIFEST.json").read_bytes())["files"]
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file()
              and "_checks" not in p.relative_to(ROOT).parts and p.name != "BUNDLE_MANIFEST.json"}
    assert actual == set(entries)
    for relative, item in entries.items():
        path = ROOT / relative
        assert path.stat().st_size == item["bytes"] and sha(path) == item["sha256"], relative
    return len(entries)


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    assert sys.flags.optimize == 0 and sys.version_info[:2] == (3, 12)
    sys.dont_write_bytecode = True
    before = integrity()
    version = json.loads((ROOT / "VERSION_MANIFEST.json").read_bytes())
    checks = ROOT / "_checks"
    checks.mkdir(exist_ok=False)
    attempts = []

    def deny(*args, **kwargs):
        attempts.append("Python socket operation")
        raise RuntimeError("REAL_OUTPUT_REPLAY_NETWORK_BLOCKED")

    socket.socket.connect = deny
    socket.socket.connect_ex = deny
    socket.create_connection = deny
    socket.getaddrinfo = deny
    from vca.types import _bech32 as installed_helper
    assert sha(Path(installed_helper.__file__)) == version["frozen_bech32_sha256"]
    work = checks / "workspace"
    shutil.copytree(ROOT / "captures", work / "captures")
    shutil.copytree(ROOT / "experiments", work / "experiments",
                    ignore=shutil.ignore_patterns("evaluation.json", "independent_verification.json"))
    helper_path = work / "_workspace/replay_20260906/source/src/vca/types/_bech32.py"
    helper_path.parent.mkdir(parents=True)
    shutil.copyfile(ROOT / "frozen_support/_bech32.py", helper_path)
    assert sha(helper_path) == sha(Path(installed_helper.__file__))
    # Only rebind a pure helper to an identical-byte local copy, so the preserved
    # evaluator's relative provenance path remains valid after extraction.
    helper = load_module("review_local_bech32", helper_path)
    sys.path.insert(0, str(work / "experiments/revision_v4"))
    evaluator = load_module("review_real_output_evaluation", work / "experiments/revision_v4/evaluate_candidates.py")
    evaluator._bech32 = helper
    measured = evaluator.evaluate()
    reference = json.loads((ROOT / "experiments/revision_v4/evaluation.json").read_bytes())
    for key in ("selected", "verified", "unavailable", "rows", "controls", "totals_on_verified_groups"):
        assert measured[key] == reference[key], key
    with (work / "experiments/revision_v4/evaluation.json").open("xb") as stream:
        stream.write((json.dumps(measured, indent=2) + "\n").encode())
    runpy.run_path(str(work / "experiments/revision_v4/verify_real_outputs.py"), run_name="__main__")
    separate = json.loads((work / "experiments/revision_v4/independent_verification.json").read_bytes())
    assert separate["status"] == "PASS" and not attempts
    after = integrity()
    result = {"status": "PASS", "completed_utc": datetime.now(UTC).isoformat(),
        "files_checked_before": before, "files_checked_after": after,
        "blocks": separate["blocks"], "transaction_count": separate["counts"]["transactions"],
        "candidate_transactions": separate["candidate_transactions"], "selected": measured["selected"],
        "verified": measured["verified"], "primary_controls": len(measured["controls"]),
        "separate_controls": len(separate["controls"]), "totals": measured["totals_on_verified_groups"],
        "python_socket_attempts": len(attempts),
        "helper_provenance_binding": "Evaluator uses a byte-identical copy of the installed frozen pure-Python Bech32 helper inside the isolated replay root; no helper code or scientific result is changed.",
        "scope": "Fresh saved-data computation and separate verifier; not new acquisition, full consensus, THORChain payout coverage, or an independent-team assertion."}
    with (checks / "RESULT.json").open("xb") as stream:
        stream.write((json.dumps(result, indent=2) + "\n").encode())
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
