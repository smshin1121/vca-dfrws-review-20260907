"""Read fixed historical Bitcoin blocks; preserve every actual HTTP attempt."""

import hashlib
import json
import re
import time
import urllib.error
import urllib.request
from datetime import UTC, datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DEST = ROOT / "captures/revision_v4_equal_outputs"
HEIGHTS = tuple(range(900000, 900008))
PROVIDERS = {"blockstream": "https://blockstream.info/api", "mempool": "https://mempool.space/api"}


def now():
    return datetime.now(UTC).isoformat()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write((json.dumps(value, indent=2) + "\n").encode())


class Client:
    def __init__(self):
        DEST.mkdir(parents=True, exist_ok=True)
        (DEST / "requests").mkdir(exist_ok=True)
        (DEST / "responses").mkdir(exist_ok=True)
        self.last_start = 0.0
        self.previous_attempts = sum(len(json.loads(p.read_bytes())["attempts"])
                                     for p in (DEST / "requests").glob("*.json"))
        self.actual_attempts = 0

    def get(self, key, provider, path, maximum=2 * 1024 * 1024):
        target = DEST / "requests" / (key + ".json")
        assert not target.exists(), "Do not repeat a preserved logical request"
        assert re.fullmatch("[a-z0-9_]+", key)
        assert provider in PROVIDERS and path.startswith("/")
        url = PROVIDERS[provider] + path
        attempts = []
        result = {"key": key, "url": url, "provider": provider, "status": "unavailable", "attempts": attempts}
        for attempt in (1, 2):
            assert self.previous_attempts + self.actual_attempts < 60
            time.sleep(max(0, 0.5 - (time.monotonic() - self.last_start)))
            self.last_start = time.monotonic()
            self.actual_attempts += 1
            entry = {"attempt": attempt, "started_utc": now(), "method": "GET",
                     "authorization_sent": False, "cookie_sent": False}
            started = time.perf_counter()
            raw = None
            try:
                request = urllib.request.Request(url, headers={"User-Agent": "Academic-output-boundary-review/1.0"})
                with urllib.request.urlopen(request, timeout=25) as response:
                    assert response.geturl().startswith(PROVIDERS[provider] + "/")
                    entry["http_status"] = response.status
                    entry["final_url"] = response.geturl()
                    raw = response.read(maximum + 1)
                    assert len(raw) <= maximum, "Response exceeds declared byte bound"
                entry["status"] = "available"
            except (urllib.error.URLError, TimeoutError, AssertionError) as error:
                entry.update(status="unavailable", error_type=type(error).__name__, error=str(error))
                if isinstance(error, urllib.error.HTTPError):
                    entry["http_status"] = error.code
                    raw = error.read(maximum)
            entry["completed_utc"] = now()
            entry["elapsed_seconds"] = round(time.perf_counter() - started, 6)
            if raw is not None:
                saved = DEST / "responses" / f"{key}_attempt{attempt}.bin"
                with saved.open("xb") as stream:
                    stream.write(raw)
                entry.update(response_file=saved.relative_to(DEST).as_posix(), response_bytes=len(raw), response_sha256=sha(raw))
            attempts.append(entry)
            # A temporary journal remains distinct from the finalized request.
            write(DEST / "requests" / f"{key}_attempt{attempt}.journal", entry)
            print({"request": key, "attempt": attempt, "status": entry["status"]}, flush=True)
            if entry["status"] == "available":
                result.update(status="available", response_file=entry["response_file"], response_sha256=entry["response_sha256"])
                break
        write(target, result)
        return result


def payload(record):
    if record["status"] != "available":
        return None
    raw = (DEST / record["response_file"]).read_bytes()
    assert sha(raw) == record["response_sha256"]
    return raw


def main():
    write(HERE / "plan_lock.json", {"created_utc": now(), "heights": HEIGHTS,
        "protocol_sha256": sha((HERE / "REAL_OUTPUT_PROTOCOL.md").read_bytes()),
        "collector_sha256": sha(Path(__file__).read_bytes()), "total_attempt_budget": 60})
    client = Client()
    rows = []
    for height in HEIGHTS:
        row = {"height": height, "hash_requests": {}, "status": "hash_unavailable"}
        hashes = []
        for provider in PROVIDERS:
            record = client.get(f"height_{height}_{provider}", provider, f"/block-height/{height}")
            row["hash_requests"][provider] = record["key"]
            raw = payload(record)
            value = raw.decode().strip() if raw is not None else None
            hashes.append(value if value and re.fullmatch("[0-9a-f]{64}", value) else None)
        if all(hashes) and hashes[0] == hashes[1]:
            row["block_hash"] = hashes[0]
            block = client.get(f"block_{height}", "blockstream", f"/block/{hashes[0]}/raw", 8 * 1024 * 1024)
            row.update(block_request=block["key"], status="available" if block["status"] == "available" else "block_unavailable")
        elif all(hashes):
            row.update(status="hash_disagreement", hashes=hashes)
        rows.append(row)
    report = {"status": "CAPTURED", "completed_utc": now(), "plan_sha256": sha((HERE / "plan_lock.json").read_bytes()),
              "rows": rows, "http_attempts": client.actual_attempts, "scope": "Fixed eight-block raw-data capture; no candidate inspection in this command."}
    write(HERE / "block_capture.json", report)
    print({"available": sum(r["status"] == "available" for r in rows), "planned": len(rows), "attempts": client.actual_attempts})


if __name__ == "__main__":
    main()
