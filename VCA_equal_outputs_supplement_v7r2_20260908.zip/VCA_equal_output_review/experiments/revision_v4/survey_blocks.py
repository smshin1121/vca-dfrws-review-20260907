"""Parse the complete fixed block frame before selecting output-boundary cases."""

import copy
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

from capture_blocks import DEST, HEIGHTS, HERE, now, payload, sha, write


def double_sha(raw):
    return hashlib.sha256(hashlib.sha256(raw).digest()).digest()


class Cursor:
    def __init__(self, raw):
        self.raw, self.position = raw, 0

    def take(self, size):
        if not 0 <= size <= len(self.raw) - self.position:
            raise ValueError("truncated_serialization")
        start = self.position
        self.position += size
        return self.raw[start:self.position]

    def compact(self):
        first = self.take(1)[0]
        if first < 253:
            return first
        length = {253: 2, 254: 4, 255: 8}[first]
        value = int.from_bytes(self.take(length), "little")
        if value < {253: 253, 254: 65536, 255: 4294967296}[first]:
            raise ValueError("noncanonical_compact_size")
        return value


def parse_transaction(cursor):
    start = cursor.position
    version = cursor.take(4)
    witness = cursor.raw[cursor.position] == 0
    if witness:
        if cursor.take(2) != b"\x00\x01":
            raise ValueError("unsupported_witness_flag")
    base_start = cursor.position
    inputs = cursor.compact()
    if not 0 < inputs < len(cursor.raw):
        raise ValueError("invalid_input_count")
    for _ in range(inputs):
        cursor.take(36)
        cursor.take(cursor.compact())
        cursor.take(4)
    count = cursor.compact()
    if not 0 < count < len(cursor.raw):
        raise ValueError("invalid_output_count")
    outputs = []
    for index in range(count):
        value_offset = cursor.position
        value = int.from_bytes(cursor.take(8), "little")
        if value > 2100000000000000:
            raise ValueError("invalid_output_value")
        script = cursor.take(cursor.compact())
        outputs.append({"vout": index, "value": value, "scriptpubkey": script.hex(), "amount_offset": value_offset})
    base_end = cursor.position
    if witness:
        for _ in range(inputs):
            for _ in range(cursor.compact()):
                cursor.take(cursor.compact())
    locktime = cursor.take(4)
    stripped = version + cursor.raw[base_start:base_end] + locktime
    return {"txid": double_sha(stripped)[::-1].hex(), "inputs": inputs, "outputs": outputs,
            "start": start, "end": cursor.position, "nonwitness_sha256": sha(stripped),
            "has_witness": witness}


def script_type(hex_script):
    script = bytes.fromhex(hex_script)
    if len(script) == 25 and script[:3] == b"\x76\xa9\x14" and script[-2:] == b"\x88\xac":
        return "p2pkh"
    if len(script) == 23 and script[:2] == b"\xa9\x14" and script[-1:] == b"\x87":
        return "p2sh"
    if len(script) == 22 and script[:2] == b"\x00\x14":
        return "p2wpkh"
    if len(script) == 34 and script[:2] == b"\x00\x20":
        return "p2wsh"
    if len(script) == 34 and script[:2] == b"\x51\x20":
        return "p2tr"
    return "other"


def equal_outputs(outputs):
    groups = defaultdict(list)
    for output in outputs:
        kind = script_type(output["scriptpubkey"])
        if output["value"] > 0 and kind != "other":
            groups[(kind, output["scriptpubkey"], output["value"])].append(output["vout"])
    return [{"type": key[0], "scriptpubkey": key[1], "satoshis_each": key[2], "vout_indices": indices}
            for key, indices in sorted(groups.items()) if len(indices) > 1]


def merkle_root(txids):
    level = [bytes.fromhex(txid)[::-1] for txid in txids]
    assert level
    while len(level) > 1:
        if len(level) % 2:
            level.append(level[-1])
        level = [double_sha(level[i] + level[i + 1]) for i in range(0, len(level), 2)]
    return level[0]


def parse_block(raw, expected_hash):
    cursor = Cursor(raw)
    header = cursor.take(80)
    if double_sha(header)[::-1].hex() != expected_hash:
        raise ValueError("header_hash_mismatch")
    count = cursor.compact()
    if not 0 < count < len(raw):
        raise ValueError("invalid_transaction_count")
    transactions = [parse_transaction(cursor) for _ in range(count)]
    if cursor.position != len(raw):
        raise ValueError("trailing_block_bytes")
    if merkle_root([tx["txid"] for tx in transactions]) != header[36:68]:
        raise ValueError("merkle_root_mismatch")
    return header, transactions


def main():
    capture = json.loads((HERE / "block_capture.json").read_bytes())
    assert [r["height"] for r in capture["rows"]] == list(HEIGHTS)
    lock = json.loads((HERE / "plan_lock.json").read_bytes())
    assert lock["protocol_sha256"] == sha((HERE / "REAL_OUTPUT_PROTOCOL.md").read_bytes())
    blocks, candidates, inputs = [], [], {}
    totals = Counter()
    script_counts = Counter()
    header_by_height = {}
    first_normal = None
    for row in capture["rows"]:
        block = {"height": row["height"], "capture_status": row["status"]}
        if row["status"] != "available":
            blocks.append(block)
            continue
        request_path = DEST / "requests" / (row["block_request"] + ".json")
        record = json.loads(request_path.read_bytes())
        raw = payload(record)
        inputs[record["response_file"]] = record["response_sha256"]
        block["block_hash"] = row["block_hash"]
        try:
            header, transactions = parse_block(raw, row["block_hash"])
        except (ValueError, IndexError) as error:
            block.update(status="parse_or_identity_failure", error=str(error))
            blocks.append(block)
            continue
        block.update(status="verified_header_and_merkle", transactions=len(transactions),
                     txids=[tx["txid"] for tx in transactions], raw_bytes=len(raw),
                     timestamp=int.from_bytes(header[68:72], "little"))
        header_by_height[row["height"]] = header
        totals["transactions"] += len(transactions)
        for position, tx in enumerate(transactions):
            totals["outputs"] += len(tx["outputs"])
            totals["witness_transactions"] += tx["has_witness"]
            for output in tx["outputs"]:
                script_counts[script_type(output["scriptpubkey"])] += 1
                totals["zero_valued_outputs"] += output["value"] == 0
            groups = equal_outputs(tx["outputs"])
            if groups:
                candidates.append({"height": row["height"], "block_hash": row["block_hash"],
                    "tx_position": position, "txid": tx["txid"], "groups": groups,
                    "raw_start": tx["start"], "raw_end": tx["end"],
                    "nonwitness_sha256": tx["nonwitness_sha256"], "output_count": len(tx["outputs"])})
            if first_normal is None:
                first_normal = (raw, row["block_hash"], tx["outputs"][0]["amount_offset"])
        blocks.append(block)
    for height, header in header_by_height.items():
        if height - 1 in header_by_height:
            assert header[4:36] == double_sha(header_by_height[height - 1]), "consecutive_header_mismatch"
    control_outputs = [{"vout": i, "value": 1000, "scriptpubkey": "0014" + "01" * 20} for i in range(2)]
    assert equal_outputs(control_outputs)[0]["vout_indices"] == [0, 1]
    changed = copy.deepcopy(control_outputs)
    changed[1]["value"] = 1001
    assert not equal_outputs(changed)
    normal_control = "not_run_no_usable_block"
    if first_normal is not None:
        raw, identifier, offset = first_normal
        parse_block(raw, identifier)
        altered = bytearray(raw)
        altered[offset] ^= 1
        try:
            parse_block(bytes(altered), identifier)
        except ValueError as error:
            assert str(error) == "merkle_root_mismatch", str(error)
        else:
            raise AssertionError("Output mutation was not rejected")
        normal_control = "unchanged_block_passes_output_change_breaks_merkle_root"
    assert len({row["txid"] for row in candidates}) == len(candidates)
    result = {"status": "MEASURED", "created_utc": now(), "blocks": blocks,
        "totals": dict(totals), "script_type_counts": dict(script_counts), "candidates": candidates,
        "candidate_transactions": len(candidates), "candidate_groups": sum(len(r["groups"]) for r in candidates),
        "controls": ["constructed_equal_pair_detected", "different_amount_pair_not_equal", normal_control],
        "input_response_sha256": inputs, "capture_sha256": sha((HERE / "block_capture.json").read_bytes()),
        "plan_sha256": sha((HERE / "plan_lock.json").read_bytes()), "survey_source_sha256": sha(Path(__file__).read_bytes()),
        "scope": "Fixed eight-block convenience frame; actual output boundaries, not THORChain linkage or network-wide prevalence."}
    write(HERE / "survey.json", result)
    ranked = sorted(candidates, key=lambda r: (sha(("VCA-REAL-OUTPUT-20260908|" + r["txid"]).encode()), r["txid"]))
    selection = {"created_utc": now(), "survey_sha256": sha((HERE / "survey.json").read_bytes()),
        "selected": [{**row, "rank_sha256": sha(("VCA-REAL-OUTPUT-20260908|" + row["txid"]).encode())} for row in ranked[:3]],
        "eligible_candidates": len(candidates), "unavailable_not_replaced": True}
    write(HERE / "selection.json", selection)
    print(json.dumps({"blocks_verified": len(header_by_height), "totals": dict(totals),
                      "candidates": len(candidates), "selected": len(selection["selected"])}))


if __name__ == "__main__":
    main()
