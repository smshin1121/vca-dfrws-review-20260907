"""Apply the unchanged supplemental audit to rows derived from real BTC outputs."""

import copy
import json
import sys
from pathlib import Path

from capture_blocks import DEST, HERE, ROOT, now, payload, sha, write
from survey_blocks import double_sha, parse_block

sys.path.insert(0, str(HERE.parent / "revision_v1"))
from output_audit import audit_outputs, frozen_four_field_total
from vca.types import _bech32


def proof_ok(identifier, proof, header, height, position):
    if proof.get("block_height") != height or proof.get("pos") != position:
        return False
    digest = bytes.fromhex(identifier)[::-1]
    index = position
    for sibling_hex in proof["merkle"]:
        sibling = bytes.fromhex(sibling_hex)[::-1]
        if len(sibling) != 32:
            return False
        digest = double_sha(sibling + digest if index & 1 else digest + sibling)
        index >>= 1
    return index == 0 and digest == header[36:68]


def address_script(address):
    normalized = _bech32.normalize_btc_address(address)
    decoded = _bech32._decode_bech32(normalized)
    assert decoded is not None and decoded[0] == "bc"
    version = decoded[1][0]
    program = _bech32._convert_bits(decoded[1][1:], 5, 8, pad=False)
    assert program is not None
    return bytes([0 if version == 0 else 0x50 + version, len(program)]) + bytes(program)


def evaluate():
    selection = json.loads((HERE / "selection.json").read_bytes())
    captured = json.loads((HERE / "candidate_capture.json").read_bytes())
    assert captured["selection_sha256"] == sha((HERE / "selection.json").read_bytes())
    assert [r["txid"] for r in captured["rows"]] == [r["txid"] for r in selection["selected"]]
    rows, controls, input_hashes = [], [], {}

    def response(key):
        path = DEST / "requests" / (key + ".json")
        input_hashes[path.relative_to(ROOT).as_posix()] = sha(path.read_bytes())
        record = json.loads(path.read_bytes())
        raw = payload(record)
        if raw is not None:
            input_hashes[(DEST / record["response_file"]).relative_to(ROOT).as_posix()] = record["response_sha256"]
        return raw

    def check(name, observed, expected, rank):
        controls.append({"name": name, "rank": rank, "observed": observed, "expected": expected, "passed": observed == expected})
        assert observed == expected, (rank, name, observed, expected)

    for rank, (selected, capture) in enumerate(zip(selection["selected"], captured["rows"], strict=True), 1):
        row = {"rank": rank, "txid": selected["txid"], "height": selected["height"]}
        raw_json, raw_proof = response(capture["transaction_request"]), response(capture["proof_request"])
        raw_block = response(f"block_{selected['height']}")
        if any(item is None for item in (raw_json, raw_proof, raw_block)):
            rows.append({**row, "status": "evidence_unavailable", "verified_satoshis": None})
            continue
        tx, proof = json.loads(raw_json), json.loads(raw_proof)
        header, parsed = parse_block(raw_block, selected["block_hash"])
        actual = parsed[selected["tx_position"]]
        assert actual["txid"] == tx["txid"] == selected["txid"]
        assert tx["status"]["confirmed"] is True
        assert tx["status"]["block_hash"] == selected["block_hash"] and tx["status"]["block_height"] == selected["height"]
        assert [{"scriptpubkey": o["scriptpubkey"], "value": o["value"]} for o in tx["vout"]] == [
            {"scriptpubkey": o["scriptpubkey"], "value": o["value"]} for o in actual["outputs"]]
        assert proof_ok(tx["txid"], proof, header, selected["height"], selected["tx_position"])
        legs, groups = [], []
        for group in selected["groups"]:
            addresses = {tx["vout"][index]["scriptpubkey_address"] for index in group["vout_indices"]}
            assert len(addresses) == 1
            recipient = addresses.pop()
            assert address_script(recipient).hex() == group["scriptpubkey"]
            for index in group["vout_indices"]:
                assert tx["vout"][index]["value"] == group["satoshis_each"]
                legs.append({"txID": tx["txid"], "address": recipient, "vout": index,
                             "coins": [{"asset": "BTC.BTC", "amount": str(group["satoshis_each"])}]})
            groups.append({**group, "recipient": recipient})
        derived = [{"type": "derived_bitcoin_output_rows", "out": legs}]
        transactions = {tx["txid"]: tx}
        indexed = audit_outputs(derived, transactions)
        actual_sum = sum(tx["vout"][index]["value"] for group in selected["groups"] for index in group["vout_indices"])
        projected = frozen_four_field_total(derived)
        check("unchanged_indexed_outputs", indexed["verified_total_satoshis"], actual_sum, rank)
        check("repeated_references_preserve_total", audit_outputs(derived + copy.deepcopy(derived), transactions)["verified_total_satoshis"], actual_sum, rank)
        no_indices = copy.deepcopy(derived)
        for leg in no_indices[0]["out"]:
            del leg["vout"]
        ambiguous = audit_outputs(no_indices, transactions)
        check("without_indices_no_verified_total", ambiguous["verified_total_satoshis"], None, rank)
        check("without_indices_ambiguous", set(ambiguous["claim_status_counts"]) == {"ambiguous_output_assignment"}, True, rank)
        changed = copy.deepcopy(derived)
        changed[0]["out"][0]["coins"][0]["amount"] = str(int(changed[0]["out"][0]["coins"][0]["amount"]) + 1)
        altered = audit_outputs(changed, transactions)
        check("changed_claim_amount_has_no_total", altered["verified_total_satoshis"], None, rank)
        check("changed_claim_reason", altered["claims"][0]["status"], "output_content_mismatch", rank)
        check("missing_transaction_not_zero", audit_outputs(derived, {})["verified_total_satoshis"], None, rank)
        wrong_proof = copy.deepcopy(proof)
        sibling = bytearray.fromhex(wrong_proof["merkle"][0])
        sibling[0] ^= 1
        wrong_proof["merkle"][0] = sibling.hex()
        check("changed_merkle_branch_rejected", proof_ok(tx["txid"], wrong_proof, header, selected["height"], selected["tx_position"]), False, rank)
        assert projected < actual_sum
        rows.append({**row, "status": "verified_real_output_boundary", "block_hash": selected["block_hash"],
            "groups": groups, "secondary_json_outputs_match_raw": True, "secondary_merkle_proof_matches": True,
            "derived_records": derived, "derived_record_scope": "Projection from real Bitcoin vout rows, not observed Midgard actions",
            "indexed_audit": indexed, "without_indices_audit": ambiguous,
            "verified_satoshis": actual_sum, "four_field_projection_satoshis": projected,
            "projection_loss_satoshis": actual_sum - projected})
    verified = [r for r in rows if r["status"] == "verified_real_output_boundary"]
    return {"status": "MEASURED", "created_utc": now(), "selected": len(rows), "verified": len(verified),
        "unavailable": len(rows) - len(verified), "rows": rows, "controls": controls,
        "totals_on_verified_groups": {"indexed_satoshis": sum(r["verified_satoshis"] for r in verified),
            "four_field_projection_satoshis": sum(r["four_field_projection_satoshis"] for r in verified),
            "projection_loss_satoshis": sum(r["projection_loss_satoshis"] for r in verified)},
        "input_sha256": input_hashes, "selection_sha256": sha((HERE / "selection.json").read_bytes()),
        "code_sha256": {p.relative_to(ROOT).as_posix(): sha(p.read_bytes()) for p in
                       (Path(__file__), HERE / "survey_blocks.py", HERE.parent / "revision_v1/output_audit.py", Path(_bech32.__file__))},
        "scope": "Actual Bitcoin equal-output boundary demonstration using derived records; not a THORChain payout sample, an observed original-VCA accounting error, or a network-wide rate."}


if __name__ == "__main__":
    result = evaluate()
    write(HERE / "evaluation.json", result)
    print(json.dumps({"selected": result["selected"], "verified": result["verified"],
                      "controls": len(result["controls"]), "totals": result["totals_on_verified_groups"]}))
