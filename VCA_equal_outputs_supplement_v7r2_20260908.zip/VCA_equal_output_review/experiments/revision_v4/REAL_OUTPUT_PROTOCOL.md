# Prospective bounded search for actual equal-valued distinct Bitcoin outputs

Recorded before acquisition on 2026-09-08. The prior saved-record census found
no such case among 610 unique transactions. This new probe is a targeted
boundary-case investigation, not a held-out THORChain accuracy evaluation.

1. Fix Bitcoin mainnet block heights 900000 through 900007 inclusive. They are
   eight consecutive historical blocks selected by a round-number anchor,
   without inspecting their transactions. Do not replace a block, extend the
   range after seeing results, or stop early when a candidate is found.
2. Request each height's block hash from Blockstream and mempool.space. Download
   Blockstream's raw block only when both hashes are available and agree.
   Save failures, response bytes, URL, UTC times, status and SHA256. One request
   at a time; at least 0.5 seconds between starts; 25-second timeout; at most
   two attempts per request and 60 total attempts including candidate checks.
   Raw blocks are limited to 8 MiB and other responses to 2 MiB. No API keys.
3. Parse every transaction in each obtained raw block, including legacy and
   SegWit forms. Recompute non-witness transaction identifiers, the full txid
   Merkle root and block-header hash; record parse/identity failures rather
   than treating them as no candidates. Check consecutive header links for
   adjacent obtained heights. This is content binding, not a full-node
   consensus, signature, witness or longest-chain validation.
4. Count all parsed transactions and outputs. A candidate transaction has
   two distinct vout indices with the same positive satoshi value and exactly
   the same P2PKH, P2SH, P2WPKH, P2WSH or P2TR locking script. Zero-valued,
   OP_RETURN and other script templates are outside the candidate predicate;
   keep their counts in the survey. Report all candidate IDs, output indices,
   scripts and amounts. This candidate definition concerns receiving scripts,
   not an assertion of who owns them or why the transfers occurred.
5. After completing all eight blocks, rank candidate transactions by
   SHA256("VCA-REAL-OUTPUT-20260908|" + lowercase_txid), then txid. Select up to
   the first three distinct transactions for secondary-provider JSON and
   Merkle-proof collection. Preserve unavailable selected candidates; do not
   replace them. If no candidates are found, record that result and end.
6. Bind selected transaction JSON to the raw transaction's complete output
   list and recomputed txid. Verify the secondary Merkle branch against the
   downloaded header. Obtain recipient display addresses from those bound
   outputs and record agreement with the locking scripts. Run the unchanged
   supplemental output audit with explicit vout, omitted vout, duplicate
   references, altered amount and absent transaction controls.
7. Compare the distinct output sum with its projection to
   (txid, recipient, asset, amount). The projected rows are derived from actual
   Bitcoin outputs; they are not observed Midgard actions. A projection loss
   demonstrates a representational limitation, not an error in the original
   153 THORChain sums, criminal proceeds, or a real multi-payout THORChain swap.

Preserve first survey, selection, capture and evaluation outputs. Keep the
decoder, original 40 and 96 predictions, v5/v6 archives and prior returns
unchanged. A separate verifier must re-read raw data without importing the
survey/parser/evaluation. Include positive and deliberately altered controls.
Only validated results can enter the manuscripts or a new supplement.

Primary format references consulted before acquisition:

- https://developer.bitcoin.org/reference/block_chain.html (80-byte header,
  transaction order and txid Merkle tree; its legacy size prose is not used).
- https://github.com/bitcoin/bips/blob/master/bip-0141.mediawiki (witness and
  non-witness serialization; current block-weight rule).
- https://github.com/Blockstream/esplora/blob/master/API.md (public raw block,
  transaction and Merkle-proof endpoints; values are integer satoshis).

Consecutive blocks are a clustered convenience frame. Neither occurrence
counts nor selected examples estimate network-wide prevalence or error rates.
No transaction is signed, broadcast, or sent to an address in this work.
