"""Separate raw-byte verification; imports none of the study's computation code.

Bitcoin serialization, txid Merkle commitments and BIP350 address checks are
implemented here directly. This is another implementation in the same study,
not an independent research team's execution.
"""

import hashlib
import io
import json
import re
import struct
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CAPTURES = ROOT / "captures/revision_v4_equal_outputs"


def read(path):
    return json.loads(path.read_bytes())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def h256(raw):
    return hashlib.sha256(hashlib.sha256(raw).digest()).digest()


def take(stream, length):
    raw = stream.read(length)
    if len(raw) != length:
        raise ValueError("TRUNCATED_BLOCK")
    return raw


def size(stream):
    leading = take(stream, 1)[0]
    if leading <= 252:
        return leading
    value = struct.unpack({253: "<H", 254: "<I", 255: "<Q"}[leading], take(stream, {253: 2, 254: 4, 255: 8}[leading]))[0]
    assert value >= {253: 253, 254: 65536, 255: 4294967296}[leading]
    return value


def put_size(number):
    if number < 253:
        return struct.pack("<B", number)
    if number < 65536:
        return b"\xfd" + struct.pack("<H", number)
    if number < 4294967296:
        return b"\xfe" + struct.pack("<I", number)
    return b"\xff" + struct.pack("<Q", number)


def read_transaction(stream):
    version = take(stream, 4)
    marker_position = stream.tell()
    marker = take(stream, 1)
    segwit = marker == b"\x00"
    if segwit:
        assert take(stream, 1) == b"\x01"
    else:
        stream.seek(marker_position)
    count = size(stream)
    assert count > 0
    encoded = [version, put_size(count)]
    for _ in range(count):
        outpoint = take(stream, 36)
        script_length = size(stream)
        script = take(stream, script_length)
        encoded.extend((outpoint, put_size(script_length), script, take(stream, 4)))
    nout = size(stream)
    assert nout > 0
    encoded.append(put_size(nout))
    outputs = []
    for index in range(nout):
        amount = take(stream, 8)
        length = size(stream)
        script = take(stream, length)
        encoded.extend((amount, put_size(length), script))
        value = struct.unpack("<Q", amount)[0]
        assert value <= 2100000000000000
        outputs.append((index, value, script.hex()))
    if segwit:
        for _ in range(count):
            items = size(stream)
            for _ in range(items):
                take(stream, size(stream))
    encoded.append(take(stream, 4))
    stripped = b"".join(encoded)
    return h256(stripped)[::-1].hex(), outputs, segwit


def tree_root(identifiers):
    values = [bytes.fromhex(identifier)[::-1] for identifier in identifiers]
    while len(values) > 1:
        nxt = []
        for i in range(0, len(values), 2):
            right = values[i + 1] if i + 1 < len(values) else values[i]
            nxt.append(h256(values[i] + right))
        values = nxt
    return values[0]


TEMPLATES = {
    "p2pkh": r"76a914[0-9a-f]{40}88ac", "p2sh": r"a914[0-9a-f]{40}87",
    "p2wpkh": r"0014[0-9a-f]{40}", "p2wsh": r"0020[0-9a-f]{64}",
    "p2tr": r"5120[0-9a-f]{64}",
}


def kind(script):
    return next((name for name, pattern in TEMPLATES.items() if re.fullmatch(pattern, script)), "other")


def duplicate_groups(outputs):
    counts = Counter((kind(script), script, value) for _, value, script in outputs if value > 0 and kind(script) != "other")
    return [{"type": script_kind, "scriptpubkey": script, "satoshis_each": value,
             "vout_indices": [i for i, val, scr in outputs if (val, scr) == (value, script)]}
            for (script_kind, script, value), count in sorted(counts.items()) if count > 1]


def json_transaction_id(tx):
    chunks = [struct.pack("<i", tx["version"]), put_size(len(tx["vin"]))]
    for incoming in tx["vin"]:
        script = bytes.fromhex(incoming["scriptsig"])
        chunks.extend((bytes.fromhex(incoming["txid"])[::-1], struct.pack("<I", incoming["vout"]),
                       put_size(len(script)), script, struct.pack("<I", incoming["sequence"])))
    chunks.append(put_size(len(tx["vout"])))
    for outgoing in tx["vout"]:
        script = bytes.fromhex(outgoing["scriptpubkey"])
        assert type(outgoing["value"]) is int
        chunks.extend((struct.pack("<Q", outgoing["value"]), put_size(len(script)), script))
    chunks.append(struct.pack("<I", tx["locktime"]))
    return h256(b"".join(chunks))[::-1].hex()


def decode_script(address):
    # BIP173/BIP350: validate the address independently of the VCA helper.
    assert address == address.lower() or address == address.upper()
    hrp, body = address.lower().rsplit("1", 1)
    assert hrp == "bc" and 6 < len(body) and len(address) <= 90
    alphabet = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
    values = [alphabet.index(char) for char in body]
    polymod = 1
    for value in [ord(c) >> 5 for c in hrp] + [0] + [ord(c) & 31 for c in hrp] + values:
        top = polymod >> 25
        polymod = ((polymod & 0x1ffffff) << 5) ^ value
        for bit, coefficient in enumerate((0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3)):
            if top & (1 << bit):
                polymod ^= coefficient
    version = values[0]
    assert 0 <= version <= 16 and polymod == (1 if version == 0 else 0x2bc830a3)
    bits = "".join(format(value, "05b") for value in values[1:-6])
    remaining = len(bits) % 8
    assert remaining < 5 and (not remaining or int(bits[-remaining:], 2) == 0)
    program = bytes(int(bits[i:i + 8], 2) for i in range(0, len(bits) - remaining, 8))
    assert 2 <= len(program) <= 40
    return bytes([0 if version == 0 else 0x50 + version, len(program)]) + program


def proof_root(identifier, siblings, position):
    digest = bytes.fromhex(identifier)[::-1]
    for sibling in siblings:
        value = bytes.fromhex(sibling)[::-1]
        digest = h256(value + digest) if position % 2 else h256(digest + value)
        position //= 2
    assert position == 0
    return digest


def main():
    baseline_hashes = {p.relative_to(ROOT).as_posix(): sha(p.read_bytes()) for p in sorted(CAPTURES.rglob("*")) if p.is_file()}
    requests = {p.stem: read(p) for p in (CAPTURES / "requests").glob("*.json")}
    attempts = [attempt for request in requests.values() for attempt in request["attempts"]]
    assert len(attempts) == 30 <= 60
    for request in requests.values():
        assert 0 < len(request["attempts"]) <= 2
        for attempt in request["attempts"]:
            assert attempt["method"] == "GET" and not attempt["authorization_sent"] and not attempt["cookie_sent"]
            if "response_file" in attempt:
                raw = (CAPTURES / attempt["response_file"]).read_bytes()
                assert len(raw) == attempt["response_bytes"] and sha(raw) == attempt["response_sha256"]
        assert request["status"] == "available"

    def response(key):
        request = requests[key]
        raw = (CAPTURES / request["response_file"]).read_bytes()
        assert sha(raw) == request["response_sha256"]
        return raw

    lock = read(HERE / "plan_lock.json")
    assert lock["protocol_sha256"] == sha((HERE / "REAL_OUTPUT_PROTOCOL.md").read_bytes())
    assert lock["collector_sha256"] == sha((HERE / "capture_blocks.py").read_bytes())
    assert lock["created_utc"] < min(a["started_utc"] for a in attempts)
    survey = read(HERE / "survey.json")
    selection = read(HERE / "selection.json")
    assert selection["survey_sha256"] == sha((HERE / "survey.json").read_bytes())
    start = read(HERE / "candidate_capture_start.json")
    assert start["selection_sha256"] == sha((HERE / "selection.json").read_bytes())
    assert selection["created_utc"] <= start["started_utc"]
    candidates, transactions, headers = {}, {}, {}
    counts, script_counts = Counter(), Counter()
    for height in range(900000, 900008):
        block_id = response(f"height_{height}_blockstream").decode().strip()
        assert response(f"height_{height}_mempool").decode().strip() == block_id
        raw = response(f"block_{height}")
        stream = io.BytesIO(raw)
        header = take(stream, 80)
        assert h256(header)[::-1].hex() == block_id
        headers[height] = header
        n = size(stream)
        identifiers = []
        for position in range(n):
            identifier, outputs, segwit = read_transaction(stream)
            assert identifier not in transactions
            identifiers.append(identifier)
            transactions[identifier] = (height, position, outputs)
            counts["transactions"] += 1
            counts["outputs"] += len(outputs)
            counts["witness_transactions"] += segwit
            for _, value, script in outputs:
                counts["zero_valued_outputs"] += value == 0
                script_counts[kind(script)] += 1
            groups = duplicate_groups(outputs)
            if groups:
                candidates[identifier] = {"height": height, "block_hash": block_id, "tx_position": position, "groups": groups}
        assert stream.tell() == len(raw)
        assert tree_root(identifiers) == header[36:68]
        original = next(b for b in survey["blocks"] if b["height"] == height)
        assert identifiers == original["txids"] and n == original["transactions"]
        if height > 900000:
            assert header[4:36] == h256(headers[height - 1])
    assert dict(counts) == survey["totals"] and dict(script_counts) == survey["script_type_counts"]
    assert len(candidates) == survey["candidate_transactions"]
    assert set(candidates) == {row["txid"] for row in survey["candidates"]}
    for row in survey["candidates"]:
        assert candidates[row["txid"]] == {key: row[key] for key in ("height", "block_hash", "tx_position", "groups")}
    chosen = sorted(candidates, key=lambda txid: (sha(("VCA-REAL-OUTPUT-20260908|" + txid).encode()), txid))[:3]
    assert chosen == [row["txid"] for row in selection["selected"]]
    evaluation = read(HERE / "evaluation.json")
    evidence_rows = []
    negative_controls = []
    for rank, identifier in enumerate(chosen, 1):
        tx = json.loads(response(f"candidate_{rank}_transaction"))
        proof = json.loads(response(f"candidate_{rank}_proof"))
        assert json_transaction_id(tx) == identifier
        height, position, outputs = transactions[identifier]
        assert tx["status"]["confirmed"] is True and tx["status"]["block_height"] == height
        assert tx["status"]["block_hash"] == candidates[identifier]["block_hash"]
        assert [(i, o["value"], o["scriptpubkey"]) for i, o in enumerate(tx["vout"])] == outputs
        assert (proof["block_height"], proof["pos"]) == (height, position)
        assert proof_root(identifier, proof["merkle"], position) == headers[height][36:68]
        selected_outputs = []
        for group in candidates[identifier]["groups"]:
            recipients = set()
            for index in group["vout_indices"]:
                out = tx["vout"][index]
                address = out["scriptpubkey_address"]
                assert decode_script(address).hex() == out["scriptpubkey"] == group["scriptpubkey"]
                assert out["value"] == group["satoshis_each"]
                selected_outputs.append((index, address, out["value"]))
                recipients.add(address)
            assert len(recipients) == 1
        indexed = sum(value for _, _, value in selected_outputs)
        projected = sum(value for _, value in {(address, value) for _, address, value in selected_outputs})
        first = next(r for r in evaluation["rows"] if r["txid"] == identifier)
        assert first["verified_satoshis"] == indexed and first["four_field_projection_satoshis"] == projected
        assert first["projection_loss_satoshis"] == indexed - projected
        assert first["indexed_audit"]["verified_total_satoshis"] == indexed
        assert first["without_indices_audit"]["verified_total_satoshis"] is None
        evidence_rows.append({"txid": identifier, "height": height, "outputs": selected_outputs,
                              "indexed_satoshis": indexed, "projected_satoshis": projected})
        # A changed value cannot retain the captured txid or its Merkle binding.
        altered = json.loads(json.dumps(tx))
        altered["vout"][selected_outputs[0][0]]["value"] += 1
        assert json_transaction_id(altered) != identifier
        modified_proof = list(proof["merkle"])
        modified_proof[0] = format(int(modified_proof[0], 16) ^ 1, "064x")
        assert proof_root(identifier, modified_proof, position) != headers[height][36:68]
        negative_controls.extend([f"case{rank}_one_satoshi_changes_txid", f"case{rank}_changed_branch_breaks_root"])
    assert len(evidence_rows) == evaluation["verified"] == evaluation["selected"] == 3
    assert len(evaluation["controls"]) == 24 and all(c["passed"] for c in evaluation["controls"])
    assert all(sha((ROOT / path).read_bytes()) == digest for path, digest in evaluation["input_sha256"].items())
    assert all(sha((ROOT / path).read_bytes()) == digest for path, digest in evaluation["code_sha256"].items())
    assert {p: sha((ROOT / p).read_bytes()) for p in baseline_hashes} == baseline_hashes
    result = {"status": "PASS", "completed_utc": datetime.now(UTC).isoformat(),
        "blocks": len(headers), "counts": dict(counts), "candidate_transactions": len(candidates),
        "selected": chosen, "rows": evidence_rows, "secondary_json_txids_recomputed": len(evidence_rows),
        "secondary_merkle_branches_checked": len(evidence_rows), "address_scripts_independently_decoded": 6,
        "controls": negative_controls, "request_attempts": len(attempts), "captured_files_unchanged": len(baseline_hashes),
        "evaluation_sha256": sha((HERE / "evaluation.json").read_bytes()),
        "verifier_sha256": sha(Path(__file__).read_bytes()),
        "scope": "Separate implementation in the same workflow; raw frame and selected output identities verified. Not full consensus, THORChain payout coverage, independent-team reproduction, or a population error rate."}
    with (HERE / "independent_verification.json").open("xb") as stream:
        stream.write((json.dumps(result, indent=2) + "\n").encode())
    print(json.dumps({k: result[k] for k in ("status", "blocks", "counts", "candidate_transactions", "request_attempts", "captured_files_unchanged")}, indent=2))


if __name__ == "__main__":
    main()
