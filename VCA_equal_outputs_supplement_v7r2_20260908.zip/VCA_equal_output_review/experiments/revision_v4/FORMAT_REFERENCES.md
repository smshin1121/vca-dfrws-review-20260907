# Serialization and address-format references

The pre-collection protocol lists the Bitcoin header, transaction and Esplora
references actually consulted before collecting the fixed eight-block frame.
The older developer block page's pre-SegWit size description was not used.

After selection showed three P2TR examples, the separate address verifier also
consulted [BIP350](https://github.com/bitcoin/bips/blob/master/bip-0350.mediawiki)
on 2026-09-08. BIP350 is by Pieter Wuille and is marked BSD-2-Clause; it defines
the Bech32m checksum constant and version-dependent decoding checks. The
verifier implements the normative arithmetic directly and does not import
the VCA decoder. This later consultation did not change the block frame,
candidate definition or selected transactions.

The primary evaluator uses the unchanged VCA `_bech32.py` helper. Its exact
SHA256 is recorded in `evaluation.json`; that helper cites the public-domain
reference implementation from https://github.com/sipa/bech32.

The post-run interpreter observations report Python3.12.13 for both command
families with assertions enabled. These are observations made after execution,
not telemetry fabricated for earlier process start times. Capture request
start/end times were recorded by the collector itself.
