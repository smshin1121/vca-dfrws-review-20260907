"""Fetch only the three prespecified-ranked boundary transactions and proofs."""

import json
from pathlib import Path

from capture_blocks import Client, HERE, now, sha, write


def main():
    selection = json.loads((HERE / "selection.json").read_bytes())
    write(HERE / "candidate_capture_start.json", {"started_utc": now(),
        "selection_sha256": sha((HERE / "selection.json").read_bytes()),
        "collector_sha256": sha(Path(__file__).read_bytes())})
    client = Client()
    rows = []
    for rank, row in enumerate(selection["selected"], 1):
        identifier = row["txid"]
        transaction = client.get(f"candidate_{rank}_transaction", "mempool", f"/tx/{identifier}")
        proof = client.get(f"candidate_{rank}_proof", "mempool", f"/tx/{identifier}/merkle-proof")
        rows.append({"rank": rank, "txid": identifier,
            "transaction_request": transaction["key"], "proof_request": proof["key"],
            "status": "available" if transaction["status"] == proof["status"] == "available" else "unavailable"})
    result = {"status": "CAPTURED", "completed_utc": now(),
        "selection_sha256": sha((HERE / "selection.json").read_bytes()),
        "rows": rows, "http_attempts_this_phase": client.actual_attempts,
        "total_http_attempts": client.previous_attempts + client.actual_attempts}
    write(HERE / "candidate_capture.json", result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
