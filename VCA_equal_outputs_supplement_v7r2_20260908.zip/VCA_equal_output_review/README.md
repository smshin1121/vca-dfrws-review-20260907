# Actual equal-valued Bitcoin output boundaries

This separate supplement preserves a fixed-block boundary investigation. It
does not replace the revision-5 base, revision-6 refund data, or any first
predictions. Extract it into a new directory, separate from the other packages.

Use the Python 3.12 environment installed from the revision-5 locked source:

```powershell
C:/vca-review/source/.venv/Scripts/python.exe -X utf8 -B tools/recheck_real_outputs.py
```

Run from this supplement's root. Change the Python path to the actual base
extraction. The checker verifies every supplied file, creates a new `_checks`
workspace, recalculates the selected real-output cases, runs 24 primary controls,
and executes a separate raw-block/selection/output verifier with 6 additional
controls. It checks original files again and blocks Python socket operations.
`_checks/RESULT.json` must report `PASS`. An existing `_checks` directory is
refused; retain it and use a new extraction for another attempt.

The preserved evaluator used a Bech32 helper under the original snapshot root.
For portable provenance, the wrapper loads a byte-identical copy of the
installed frozen helper at that relative path inside the isolated workspace.
The copied helper and the installed helper must have the same pinned hash.
This changes the helper's file location only; its code and the evaluated rows
are unchanged. The supplemental output audit is also preserved byte for byte.

## Recorded findings

Heights 900000--900007 were fixed before capture. Both Blockstream and
mempool.space returned the same hash for every height. All 8 raw blocks were
parsed: 18,401 transactions and 46,058 outputs. There were 215 transactions with 255
groups of distinct positive outputs sharing one of the five specified receiving
script templates and the same value. These are counts in a clustered convenience
frame, not network-wide prevalence.

The first 3 candidate transactions in a prospectively specified salted-SHA256
ordering were checked using mempool.space JSON and Merkle proofs. Each contains
two distinct 600-satoshi P2TR outputs to the same recipient. For the equal-output
group, indexed accounting retains 1,200 satoshi, while a projection onto
`(txid, recipient, asset, amount)` retains 600. Without indices the existing
supplemental audit reports ambiguity and no verified total. The other outputs
of each transaction are not part of this quoted group total.

The input rows for this comparison are derived from real Bitcoin outputs.
They are not observed Midgard actions. This does not establish an error in
the original 153 THORChain sums or a real multiple-payout THORChain swap. It
provides real boundary cases for a representation previously tested only with
constructed equal outputs. No owner identity or transaction purpose is inferred.

The separate verifier re-parses all blocks without importing the survey,
selector, evaluator or VCA. It recomputes txids and Merkle roots, checks the
selection, reconstructs secondary transaction identifiers, decodes the address
scripts, and checks inclusion branches. Header/Merkle consistency does not
validate signatures, witnesses, every consensus rule or longest-chain status.
Another implementation in this workflow is not an independent research team.

## Evidence map

- `experiments/revision_v4/`: local prospective protocol, plan lock, capture
  summaries, complete survey and candidate list, selection, first evaluation,
  first separate check, exact executed scripts, and format references.
- `captures/revision_v4_equal_outputs/`: every raw response and request record,
  including attempt journals. The 30 GET attempts all succeeded without replacement.
- `experiments/revision_v1/output_audit.py`: unchanged supplemental identity check.
- `frozen_support/_bech32.py`: unchanged helper; its source header identifies
  the public-domain reference implementation.
- `VERSION_MANIFEST.json`: relation to the base, evidence hashes and command.
- `BUNDLE_MANIFEST.json`: individual file hashes. Keep the complete ZIP's
  separately supplied checksum; this manifest cannot authenticate itself.

Do not run the `capture_*.py` scripts during review. They are preserved
acquisition code. The review command uses saved bytes and makes no new chain
requests. Preserve failures and the actual operator/assistance record.
