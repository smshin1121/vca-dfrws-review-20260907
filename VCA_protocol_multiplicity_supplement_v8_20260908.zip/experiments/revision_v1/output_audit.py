"""Supplemental output-identity audit; the frozen VCA projection stays unchanged.

Amounts validate identified outputs; they do not identify an output if two
outputs have equal recipient and value. Missing and ambiguous evidence cannot
produce a verified total. This audit does not authenticate protocol ownership.
"""
from collections import Counter


def bitcoin_claims(actions):
    claims = []
    for action_index, action in enumerate(actions):
        for leg_index, leg in enumerate(action.get("out", [])):
            for coin in leg.get("coins", []):
                if coin.get("asset") == "BTC.BTC":
                    claims.append({"txid": leg.get("txID", "").lower(),
                        "recipient": leg.get("address"), "satoshis": int(coin["amount"]),
                        "vout": leg.get("vout"), "action": action_index, "leg": leg_index})
    return claims


def frozen_four_field_total(actions):
    return sum(x[3] for x in {(c["txid"], c["recipient"], "BTC.BTC", c["satoshis"]) for c in bitcoin_claims(actions)})


def audit_outputs(actions, transactions):
    claims = bitcoin_claims(actions)
    results = []
    resolved = {}
    for claim in claims:
        row = {**claim, "status": "transaction_unavailable", "output_id": None}
        transaction = transactions.get(claim["txid"])
        if transaction is not None:
            if transaction.get("txid", "").lower() != claim["txid"]:
                row["status"] = "transaction_identity_mismatch"
            elif transaction.get("status", {}).get("confirmed") is not True:
                row["status"] = "transaction_unconfirmed"
            else:
                outputs = transaction.get("vout", [])
                explicit = claim["vout"]
                if explicit is not None and (type(explicit) is not int or explicit < 0 or explicit >= len(outputs)):
                    row["status"] = "invalid_output_index"
                else:
                    candidates = [explicit] if explicit is not None else list(range(len(outputs)))
                    matches = [index for index in candidates if
                        outputs[index].get("scriptpubkey_address") == claim["recipient"]
                        and type(outputs[index].get("value")) is int
                        and outputs[index]["value"] == claim["satoshis"]]
                    if not matches:
                        row["status"] = "output_content_mismatch"
                    elif len(matches) > 1:
                        row["status"] = "ambiguous_output_assignment"
                    else:
                        output_id = ("BTC", claim["txid"], matches[0])
                        row["status"] = "resolved"
                        row["output_id"] = list(output_id)
                        resolved[output_id] = outputs[matches[0]]["value"]
        results.append(row)
    complete = bool(results) and all(row["status"] == "resolved" for row in results)
    return {"status": "resolved" if complete else "unresolved", "claims": results,
        "claim_status_counts": dict(Counter(row["status"] for row in results)),
        "resolved_outputs": [{"output_id": list(key), "satoshis": value} for key, value in sorted(resolved.items())],
        "verified_total_satoshis": sum(resolved.values()) if complete else None}


def payer_status(input_addresses, historical_vault_addresses):
    if historical_vault_addresses is None or not input_addresses:
        return "payer_unverified"
    return "payer_consistent" if set(input_addresses) <= set(historical_vault_addresses) else "payer_mismatch"
