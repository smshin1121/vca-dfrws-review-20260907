"""Preserve the fixed Thor25M frame without selecting or evaluating swaps."""
import base64
import hashlib
import http.client
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
DEST = ROOT / "captures/revision_v5_multi"
TREE_PATH = ROOT / "_workspace/streaming_scope_20260908/pinned_tree.json"
PROTOCOL = HERE / "MULTI_OUTPUT_PROTOCOL.md"
SOURCE_METADATA = ROOT / "experiments/metadata/thor25_schema_sources.json"
EXCLUSION_FILES = (
    "experiments/holdout/selection_20260907/exclusions.json",
    "experiments/revision_v1/selection/exclusions.json",
    "experiments/revision_v1/selection/sealed_labels.json",
    "experiments/revision_v2/selection.json",
)


def now():
    return datetime.now(UTC).isoformat()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write_new(path, value):
    raw = (json.dumps(value, indent=2) + "\n").encode()
    with path.open("xb") as stream:
        stream.write(raw)


class Requests:
    def __init__(self):
        self.logical = 0
        self.last_started = 0.0
        self.opener = urllib.request.build_opener(NoRedirects())

    def get(self, key, url):
        assert re.fullmatch(r"[a-z0-9_]+", key)
        parsed = urllib.parse.urlsplit(url)
        if (parsed.scheme != "https" or parsed.hostname not in {
                "api.github.com", "media.githubusercontent.com"
            } or parsed.username or parsed.password or parsed.port not in (None, 443)):
            raise ValueError("request_outside_https_host_boundary")
        self.logical += 1
        assert self.logical <= 120
        attempts = []
        data = None
        for attempt in (1, 2):
            pause = 0.5 - (time.monotonic() - self.last_started)
            if pause > 0:
                time.sleep(pause)
            self.last_started = time.monotonic()
            prefix = f"{key}_attempt{attempt}"
            request_record = {
                "started_utc": now(), "method": "GET", "url": url,
                "authorization_sent": False, "cookie_sent": False,
                "tls_verification": True, "timeout_seconds": 25,
            }
            request_file = prefix + ".request.json"
            write_new(DEST / request_file, request_record)
            observation = {"request_file": request_file,
                           "request_sha256": sha((DEST / request_file).read_bytes())}
            request = urllib.request.Request(url, headers={
                "User-Agent": "VCA-multiplicity-probe/1.0",
                "Accept": "application/vnd.github+json" if "api.github.com" in url else "*/*",
            })
            try:
                with self.opener.open(request, timeout=25) as response:
                    raw = response.read(10_000_001)
                    observation.update({"http_status": response.status,
                                        "final_url": response.geturl()})
                if len(raw) > 10_000_000:
                    response_file = prefix + ".truncated.bin"
                    (DEST / response_file).write_bytes(raw[:10_000_000])
                    observation.update({"status": "unavailable", "reason": "response_limit",
                                        "response_file": response_file, "body_truncated": True,
                                        "response_sha256": sha(raw[:10_000_000]), "bytes": 10_000_000})
                else:
                    response_file = prefix + ".response.bin"
                    (DEST / response_file).write_bytes(raw)
                    observation.update({"status": "available", "response_file": response_file,
                                        "response_sha256": sha(raw), "bytes": len(raw)})
                    data = raw
            except urllib.error.HTTPError as error:
                observation.update({"status": "unavailable", "reason": "HTTPError",
                                    "http_status": error.code})
                try:
                    raw = error.read(10_000_001)
                    kept = raw[:10_000_000]
                    response_file = prefix + ".error.bin"
                    (DEST / response_file).write_bytes(kept)
                    observation.update({"response_file": response_file, "body_truncated": len(raw) > len(kept),
                                        "response_sha256": sha(kept), "bytes": len(kept)})
                except (OSError, TimeoutError, http.client.HTTPException) as body_error:
                    observation.update({"error_body_unavailable": True,
                                        "body_error_type": type(body_error).__name__,
                                        "body_error_message": str(body_error)})
                finally:
                    error.close()
            except (OSError, TimeoutError, http.client.HTTPException) as error:
                observation.update({"status": "unavailable", "reason": type(error).__name__,
                                    "message": str(error)})
            observation["ended_utc"] = now()
            attempts.append(observation)
            write_new(DEST / (prefix + ".metadata.json"), observation)
            if data is not None:
                break
        result = {"key": key, "url": url, "status": "available" if data is not None else "unavailable",
                  "attempts": attempts}
        write_new(DEST / (key + ".json"), result)
        return data, result


class NoRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def run():
    assert not (HERE / "frame_capture.json").exists()
    assert not DEST.exists(), "Preserve prior attempts; never overwrite an execution"
    source = json.loads(SOURCE_METADATA.read_bytes())
    tree = json.loads(TREE_PATH.read_bytes())
    assert tree["sha"] == source["tree_sha"] and tree["truncated"] is False
    paths = sorted((row for row in tree["tree"] if row["type"] == "blob"
                    and row["path"].startswith("data/thorchain-2025-multi/")
                    and row["path"].endswith(".ndjson")), key=lambda row: row["path"])
    assert len(paths) == 9
    lock = {"locked_utc": now(), "protocol_sha256": sha(PROTOCOL.read_bytes()),
            "collector_sha256": sha(Path(__file__).read_bytes()),
            "census_sha256": sha((HERE / "census_frame.py").read_bytes()),
            "tree_sha256": sha(TREE_PATH.read_bytes()),
            "exclusions_sha256": {path: sha((ROOT / path).read_bytes()) for path in EXCLUSION_FILES},
            "unchanged_output_audit_sha256": sha((ROOT / "experiments/revision_v1/output_audit.py").read_bytes()),
            "request_order": "Frame paths in lexicographic order, pointer then payload. After fixed selection: native ETH stratum then other, hash order within each; all Midgard pages then inbound THORNode then sorted union BTC IDs (Bitcoin then outbound THORNode) per selected case. Budget-unattempted checks remain unavailable.",
            "source_commit": source["source_commit"], "files": paths,
            "scope": "All nine fixed frame files; no transaction payload inspected before this lock."}
    write_new(HERE / "frame_lock.json", lock)
    DEST.mkdir(parents=True)
    client = Requests()
    rows = []
    for index, entry in enumerate(paths, 1):
        row = {"path": entry["path"], "git_blob_sha": entry["sha"], "index": index}
        pointer_raw, pointer_request = client.get(f"pointer_{index:02}", entry["url"])
        row["pointer_request"] = pointer_request["key"]
        if pointer_raw is None:
            row.update({"status": "unavailable", "reason": "pointer_unavailable"})
            rows.append(row)
            continue
        try:
            blob = json.loads(pointer_raw)
            assert blob["encoding"] == "base64" and blob["sha"] == entry["sha"]
            pointer = base64.b64decode(blob["content"], validate=False)
            assert len(pointer) == entry["size"] == blob["size"]
            git_bytes = b"blob " + str(len(pointer)).encode() + b"\x00" + pointer
            assert hashlib.sha1(git_bytes).hexdigest() == entry["sha"]
            match = re.fullmatch(rb"version https://git-lfs.github.com/spec/v1\noid sha256:([0-9a-f]{64})\nsize ([0-9]+)\n", pointer)
            assert match is not None
            expected_sha, expected_bytes = match[1].decode(), int(match[2])
            assert expected_bytes <= 10_000_000
        except (ValueError, KeyError, TypeError, AssertionError) as error:
            row.update({"status": "unavailable", "reason": "invalid_pointer", "error_type": type(error).__name__})
            rows.append(row)
            continue
        pointer_file = f"frame_{index:02}.lfs.txt"
        (DEST / pointer_file).write_bytes(pointer)
        payload_url = ("https://media.githubusercontent.com/media/" + source["repository"] + "/"
                       + source["source_commit"] + "/" + urllib.parse.quote(entry["path"], safe="/"))
        raw, payload_request = client.get(f"payload_{index:02}", payload_url)
        row.update({"pointer_file": pointer_file, "pointer_sha256": sha(pointer),
                    "expected_sha256": expected_sha, "expected_bytes": expected_bytes,
                    "payload_request": payload_request["key"]})
        if raw is None:
            row.update({"status": "unavailable", "reason": "payload_unavailable"})
        elif sha(raw) != expected_sha or len(raw) != expected_bytes:
            row.update({"status": "unavailable", "reason": "payload_identity_mismatch"})
        else:
            # The source filename may contain Windows-reserved '|'. Keep the
            # exact remote path in the manifest and a numeric local filename.
            filename = f"frame_{index:02}.ndjson"
            (DEST / filename).write_bytes(raw)
            row.update({"status": "available", "file": filename,
                        "sha256": sha(raw), "bytes": len(raw)})
        rows.append(row)
        print(json.dumps({"index": index, "status": row["status"], "bytes": row.get("bytes")}), flush=True)
    assert sha(PROTOCOL.read_bytes()) == lock["protocol_sha256"]
    report = {"completed_utc": now(), "protocol_sha256": lock["protocol_sha256"],
              "lock_sha256": sha((HERE / "frame_lock.json").read_bytes()),
              "logical_requests": client.logical, "rows": rows,
              "files_available": sum(row["status"] == "available" for row in rows),
              "files_expected": 9, "scope": "Frame collection only; no swap selection or evaluation."}
    write_new(HERE / "frame_capture.json", report)
    print(json.dumps({"files_available": report["files_available"], "files_expected": 9,
                      "logical_requests": client.logical}))


if __name__ == "__main__":
    run()
