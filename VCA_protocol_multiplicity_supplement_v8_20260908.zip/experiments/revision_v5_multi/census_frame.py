"""Measure fixed-frame claim multiplicity without inferring Bitcoin vouts."""
import copy
import hashlib
import json
import re
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
DEST = ROOT / "captures/revision_v5_multi"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identifier(value):
    if not isinstance(value, str):
        raise ValueError("invalid_identifier")
    value = value.lower().removeprefix("0x")
    if not re.fullmatch(r"[0-9a-f]{64}", value):
        raise ValueError("invalid_identifier")
    return value


def amount(value):
    if type(value) is int and value >= 0:
        return value
    if type(value) is str and re.fullmatch(r"[0-9]+", value):
        return int(value)
    raise ValueError("invalid_amount")


def claim_key(claim):
    return claim["txid"], claim["recipient"], "BTC", claim["amount"]


def inspect(record, origin):
    row = {**origin, "issues": [], "inbound": None, "btc_claims": [],
           "participants": [], "asset_pairs": [], "raw_btc_rows": 0,
           "invalid_btc_rows": 0}
    if not isinstance(record, dict):
        row["issues"].append("record_not_object")
        row["classification"] = "unresolved"
        return row
    row["record_status"] = record.get("status")
    row["record_type"] = record.get("type")
    inputs, outputs = record.get("in"), record.get("out")
    if not isinstance(inputs, list) or len(inputs) != 1:
        row["issues"].append("inbound_cardinality")
    elif not isinstance(inputs[0], dict):
        row["issues"].append("inbound_not_object")
    else:
        leg = inputs[0]
        try:
            chain, asset = leg["chain"], leg["asset"]
            if not isinstance(chain, str) or not chain.strip() or not isinstance(asset, str) or not asset.strip():
                raise ValueError("inbound_chain_or_asset")
            row["inbound"] = {"chain": chain.upper(), "asset": asset.upper(),
                              "txid": identifier(leg["txID"])}
        except (KeyError, ValueError, TypeError) as error:
            row["issues"].append(str(error))
    if isinstance(inputs, list):
        row["participants"].extend(leg["address"] for leg in inputs
            if isinstance(leg, dict) and isinstance(leg.get("address"), str) and leg["address"])
    if not isinstance(outputs, list):
        row["issues"].append("outputs_not_array")
        row["classification"] = "unresolved"
        return row
    row["raw_output_rows"] = len(outputs)
    for index, leg in enumerate(outputs):
        if not isinstance(leg, dict):
            row["issues"].append(f"output_{index}_not_object")
            continue
        chain, asset = leg.get("chain"), leg.get("asset")
        if not isinstance(chain, str) or not chain.strip() or not isinstance(asset, str) or not asset.strip():
            row["issues"].append(f"output_{index}_chain_or_asset")
            continue
        chain, asset = chain.upper(), asset.upper()
        row["asset_pairs"].append([chain, asset])
        recipient = leg.get("address")
        if isinstance(recipient, str) and recipient:
            row["participants"].append(recipient)
        is_btc = (chain, asset) == ("BTC", "BTC")
        if is_btc:
            row["raw_btc_rows"] += 1
        try:
            if not isinstance(recipient, str) or not recipient.strip():
                raise ValueError("missing_recipient")
            txid, units = identifier(leg["txID"]), amount(leg["amount"])
            if is_btc:
                row["btc_claims"].append({"txid": txid,
                    "recipient": recipient, "amount": units, "row_index": index})
        except (KeyError, ValueError, TypeError) as error:
            if is_btc:
                row["invalid_btc_rows"] += 1
            row["issues"].append(f"output_{index}_{error}")
    unique = {claim_key(claim) for claim in row["btc_claims"]}
    row["distinct_btc_claims"] = len(unique)
    row["distinct_btc_transactions"] = len({claim[0] for claim in unique})
    row["repeated_btc_claim_rows"] = len(row["btc_claims"]) - len(unique)
    if row["issues"]:
        row["classification"] = "unresolved"
    elif not unique:
        row["classification"] = "no_btc_claim"
    elif len(unique) > 1:
        row["classification"] = "multiple_distinct_btc_claims"
    elif any(pair != ["BTC", "BTC"] for pair in row["asset_pairs"]):
        row["classification"] = "one_btc_claim_with_other_assets"
    else:
        row["classification"] = "one_btc_claim_only"
    row["possible_multiple_btc"] = len(unique) > 1 or row["raw_btc_rows"] >= 2
    return row


def predicate_controls():
    # Explicit synthetic identifiers/addresses; these are never case evidence.
    base = {"type": "swap", "status": "success",
            "in": [{"chain": "ETH", "asset": "ETH", "txID": "a" * 64, "address": "control-payer"}],
            "out": [{"chain": "BTC", "asset": "BTC", "txID": "b" * 64,
                     "address": "control-recipient", "amount": "600"}]}
    controls = []
    observed = inspect(base, {})
    assert observed["classification"] == "one_btc_claim_only" and not observed["possible_multiple_btc"]
    controls.append("single_btc_claim_not_multiple")
    duplicate = copy.deepcopy(base)
    duplicate["out"] *= 2
    observed = inspect(duplicate, {})
    assert observed["distinct_btc_claims"] == 1 and observed["possible_multiple_btc"]
    controls.append("identical_rows_retained_for_equal_output_boundary")
    distinct = copy.deepcopy(duplicate)
    distinct["out"][1] = {**distinct["out"][1], "txID": "c" * 64}
    assert inspect(distinct, {})["distinct_btc_transactions"] == 2
    controls.append("two_btc_transactions")
    within = copy.deepcopy(duplicate)
    within["out"][1] = {**within["out"][1], "amount": "700"}
    observed = inspect(within, {})
    assert observed["distinct_btc_transactions"] == 1 and observed["distinct_btc_claims"] == 2
    controls.append("different_claims_within_one_transaction")
    mixed = copy.deepcopy(base)
    mixed["out"].append({"chain": "ETH", "asset": "ETH", "txID": "d" * 64,
                         "address": "control-payer", "amount": "50"})
    observed = inspect(mixed, {})
    assert observed["classification"] == "one_btc_claim_with_other_assets" and not observed["possible_multiple_btc"]
    controls.append("cross_asset_is_not_multiple_btc")
    for invalid in (None, True, -1, "0.5"):
        bad = copy.deepcopy(base)
        bad["out"][0]["amount"] = invalid
        observed = inspect(bad, {})
        assert observed["classification"] == "unresolved" and observed["invalid_btc_rows"] == 1
        controls.append("invalid_amount_" + repr(invalid))
    missing = copy.deepcopy(base)
    del missing["out"]
    assert inspect(missing, {})["classification"] == "unresolved"
    controls.append("missing_outputs_not_zero")
    for field in ("chain", "asset"):
        for invalid in ("", " ", None, 1):
            malformed = copy.deepcopy(base)
            malformed["out"][0][field] = invalid
            assert inspect(malformed, {})["classification"] == "unresolved"
            controls.append("invalid_output_" + field + "_" + repr(invalid))
    for field, invalid in (("txID", "unknown"), ("amount", None), ("address", " ")):
        malformed = copy.deepcopy(mixed)
        malformed["out"][1][field] = invalid
        assert inspect(malformed, {})["classification"] == "unresolved"
        controls.append("invalid_non_btc_output_" + field)
    return controls


def exclusion_sets(lock):
    data = {}
    for name, expected in lock["exclusions_sha256"].items():
        raw = (ROOT / name).read_bytes()
        assert sha(raw) == expected
        data[name] = json.loads(raw)
    baseline = data["experiments/revision_v1/selection/exclusions.json"]
    ids = {identifier(value) for value in baseline["identifiers"]}
    senders = {value.lower() for value in baseline["evm_senders"]}
    recipients = set(baseline["btc_recipients"])
    for selected in data["experiments/revision_v1/selection/sealed_labels.json"]:
        ids.add(identifier(selected["txid"]))
        senders.update(leg["address"].lower() for leg in selected["record"]["in"])
        recipients.update(leg["address"] for leg in selected["record"]["out"])
    for selected in data["experiments/revision_v2/selection.json"]["selected"]:
        ids.add(identifier(selected["txid"]))
        senders.add(selected["sender"].lower())
        recipients.add(selected["memo_recipient"])
    return ids, senders, recipients


def run():
    target = HERE / "census.json"
    assert not target.exists() and not (HERE / "selection.json").exists()
    controls = predicate_controls()
    capture = json.loads((HERE / "frame_capture.json").read_bytes())
    lock = json.loads((HERE / "frame_lock.json").read_bytes())
    assert sha((HERE / "frame_lock.json").read_bytes()) == capture["lock_sha256"]
    assert sha((HERE / "MULTI_OUTPUT_PROTOCOL.md").read_bytes()) == lock["protocol_sha256"]
    assert sha(Path(__file__).read_bytes()) == lock["census_sha256"]
    ids, senders, recipients = exclusion_sets(lock)
    rows, files, hashes = [], [], {}
    for entry in capture["rows"]:
        files.append({"path": entry["path"], "status": entry["status"]})
        if entry["status"] != "available":
            continue
        path = DEST / entry["file"]
        raw = path.read_bytes()
        assert sha(raw) == entry["sha256"] and len(raw) == entry["bytes"]
        hashes[path.relative_to(ROOT).as_posix()] = sha(raw)
        count = 0
        for line_number, line in enumerate(raw.splitlines(), 1):
            if not line.strip():
                continue
            origin = {"file": path.relative_to(ROOT).as_posix(), "line": line_number,
                      "line_sha256": sha(line), "source_path": entry["path"]}
            try:
                record = json.loads(line)
                row = inspect(record, origin)
            except (UnicodeDecodeError, json.JSONDecodeError):
                row = {**origin, "classification": "unresolved", "issues": ["invalid_json"],
                       "inbound": None, "btc_claims": [], "participants": [], "raw_btc_rows": 0}
            rows.append(row)
            count += 1
        files[-1]["nonempty_lines"] = count
    groups = {}
    for index, row in enumerate(rows):
        inbound = row["inbound"]
        if inbound is None:
            continue
        key = (inbound["chain"], inbound["txid"])
        group = groups.setdefault(key, {"source_chain": key[0], "inbound_txid": key[1],
            "input_assets": set(), "row_indices": [], "claims": [], "participants": set(),
            "max_btc_rows_in_one_record": 0, "issues": []})
        group["input_assets"].add(inbound["asset"])
        group["row_indices"].append(index)
        group["claims"].extend(row["btc_claims"])
        group["participants"].update(row["participants"])
        group["max_btc_rows_in_one_record"] = max(group["max_btc_rows_in_one_record"], row["raw_btc_rows"])
        group["issues"].extend(row["issues"])
    grouped, eligible, excluded = [], [], []
    for key, group in sorted(groups.items()):
        tuples = sorted({claim_key(claim) for claim in group["claims"]})
        group["input_assets"] = sorted(group["input_assets"])
        group["participants"] = sorted(group["participants"])
        group["distinct_claim_tuples"] = [list(value) for value in tuples]
        group["distinct_btc_transaction_ids"] = sorted({value[0] for value in tuples})
        group["repeated_claim_rows"] = len(group["claims"]) - len(tuples)
        group["candidate"] = len(tuples) > 1 or group["max_btc_rows_in_one_record"] >= 2
        grouped.append(group)
        if not group["candidate"]:
            continue
        reasons = []
        if key[1] in ids:
            reasons.append("prior_identifier")
        if any(address.lower() in senders for address in group["participants"]):
            reasons.append("prior_evm_participant")
        if any(address in recipients for address in group["participants"]):
            reasons.append("prior_btc_participant")
        if reasons:
            excluded.append({"source_chain": key[0], "inbound_txid": key[1], "reasons": reasons})
            continue
        stratum = "native_ETH" if key[0] == "ETH" and group["input_assets"] == ["ETH"] else "other_input"
        candidate = {**group, "stratum": stratum,
            "rank_sha256": sha(("VCA-MULTI5-20260908|" + key[0] + "|" + key[1]).encode())}
        eligible.append(candidate)
    selected = []
    for stratum in ("native_ETH", "other_input"):
        selected.extend(sorted((row for row in eligible if row["stratum"] == stratum),
            key=lambda row: (row["rank_sha256"], row["source_chain"], row["inbound_txid"]))[:5])
    counts = {"frame_files_expected": 9, "frame_files_available": capture["files_available"],
        "records": len(rows), "record_classifications": dict(Counter(row["classification"] for row in rows)),
        "record_statuses": dict(Counter(str(row.get("record_status")) for row in rows)),
        "record_types": dict(Counter(str(row.get("record_type")) for row in rows)),
        "bound_inbounds": len(grouped), "inbounds_in_multiple_records": sum(len(g["row_indices"]) > 1 for g in grouped),
        "candidate_inbounds": sum(g["candidate"] for g in grouped), "excluded_candidates": len(excluded),
        "eligible_candidates": len(eligible), "selected": len(selected),
        "selected_strata": dict(Counter(row["stratum"] for row in selected)), "predicate_controls": len(controls)}
    evidence_complete = capture["files_available"] == 9 and all(not row["issues"] for row in rows)
    report = {"status": "MEASURED", "created_utc": datetime.now(UTC).isoformat(),
        "protocol_sha256": lock["protocol_sha256"], "source_sha256": sha(Path(__file__).read_bytes()),
        "frame_capture_sha256": sha((HERE / "frame_capture.json").read_bytes()),
        "inputs_sha256": hashes, "counts": counts, "files": files, "rows": rows, "grouped": grouped,
        "eligible": eligible, "excluded": excluded, "controls": controls,
        "scope": "Curated protocol-record multiplicity; no verified Bitcoin payouts or decoder outcomes."}
    with target.open("xb") as stream:
        stream.write((json.dumps(report, indent=2) + "\n").encode())
    selection = {"status": "SELECTED_NOT_VERIFIED", "created_utc": datetime.now(UTC).isoformat(),
                 "census_sha256": sha(target.read_bytes()), "protocol_sha256": lock["protocol_sha256"],
                 "exclusions_sha256": lock["exclusions_sha256"], "selected": selected,
                 "n": len(selected), "fresh_transaction_requests_before_selection": 0,
                 "frame_and_schema_complete": evidence_complete,
                 "next_action": "capture_selected" if selected else (
                     "stop_no_eligible_candidate_complete_frame" if evidence_complete
                     else "stop_no_eligible_candidate_incomplete_evidence"),
                 "exclusion_scope": "Use the prior base participant sets with their infrastructure removals already applied; add the selected96 and selected11 participants, following the preserved earlier selector policy."}
    with (HERE / "selection.json").open("xb") as stream:
        stream.write((json.dumps(selection, indent=2) + "\n").encode())
    print(json.dumps(counts, indent=2))


if __name__ == "__main__":
    run()
