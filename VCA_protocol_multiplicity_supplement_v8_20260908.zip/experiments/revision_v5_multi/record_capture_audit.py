"""Record request counts and a disclosed frame-throttle measurement limit."""
import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FRAME = ROOT / "captures/revision_v5_multi"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def minimum_gap(stamps):
    values = [datetime.fromisoformat(value) for value in stamps]
    return min((right - left).total_seconds() for left, right in zip(values, values[1:])) if len(values) > 1 else None


def run():
    target = HERE / "capture_audit.json"
    assert not target.exists()
    frame, selected = read(HERE / "frame_capture.json"), read(HERE / "selected_capture.json")
    frame_requests = []
    for row in frame["rows"]:
        for kind in ("pointer_request", "payload_request"):
            if kind in row:
                frame_requests.append(read(FRAME / (row[kind] + ".json")))
    assert len(frame_requests) == frame["logical_requests"]
    all_observations, hashes = [], {}
    frame_stamps, selected_stamps = [], []
    for root, requests, stamps, is_frame in (
        (FRAME, frame_requests, frame_stamps, True),
        (FRAME / "selected", selected["requests"], selected_stamps, False),
    ):
        for request in requests:
            assert len(request["attempts"]) <= 2
            for attempt in request["attempts"]:
                for prefix in ("request", "response"):
                    if prefix + "_file" in attempt:
                        path = root / attempt[prefix + "_file"]
                        digest = sha(path)
                        assert digest == attempt[prefix + "_sha256"]
                        hashes[path.relative_to(ROOT).as_posix()] = digest
                registered = read(root / attempt["request_file"])
                assert registered["method"] == "GET" and registered["tls_verification"] is True
                assert registered["authorization_sent"] is False and registered["cookie_sent"] is False
                stamps.append(registered["started_utc"] if is_frame else attempt["call_started_utc"])
                all_observations.append(attempt)
    assert selected["total_logical_requests"] == len(frame_requests) + len(selected["requests"])
    report = {"created_utc": datetime.now(UTC).isoformat(), "status": "AUDITED_WITH_DISCLOSED_LIMIT",
        "frame_logical_requests": len(frame_requests), "selected_logical_requests": len(selected["requests"]),
        "total_logical_requests": selected["total_logical_requests"], "http_attempts": len(all_observations),
        "available_attempts": sum(row["status"] == "available" for row in all_observations),
        "http_429_observed": sum(row.get("http_status") == 429 for row in all_observations),
        "frame_minimum_record_preparation_gap_seconds": minimum_gap(frame_stamps),
        "frame_minimum_actual_call_gap_seconds": None,
        "selected_minimum_recorded_call_gap_seconds": minimum_gap(selected_stamps),
        "disclosed_limit": "The frozen frame collector gates record preparation before variable file I/O. Its saved timestamps do not prove at least 0.5 seconds between actual opener calls. A later mock counterexample exposed this gap; no actual frame-call spacing measurement exists. The frame bytes and original collector are preserved. The selected-candidate collector gates the next call 0.5 seconds after the previous request/body operation finishes, and passed the delayed-I/O control before real requests.",
        "interpretation": "This timing limitation does not alter the fixed frame, its Git/LFS byte checks or candidate selection. It is not evidence that the actual frame calls violated an endpoint limit; no claim of measured frame transport spacing is made.",
        "inputs_sha256": {str(path.relative_to(ROOT).as_posix()): sha(path) for path in (
            HERE / "frame_capture.json", HERE / "selected_capture.json", HERE / "capture_frame.py",
            HERE / "capture_selected.py", Path(__file__))},
        "captured_files_sha256": hashes}
    with target.open("xb") as stream:
        stream.write((json.dumps(report, indent=2) + "\n").encode())
    print(json.dumps({key: value for key, value in report.items() if key not in {"inputs_sha256", "captured_files_sha256"}}, indent=2))


if __name__ == "__main__":
    run()
