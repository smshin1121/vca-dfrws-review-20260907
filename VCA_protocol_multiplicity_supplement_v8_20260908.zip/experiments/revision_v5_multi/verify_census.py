"""Separate offline recount of Thor25M frame evidence and fixed selection.

No producer, VCA, capture runner, or output-audit module is imported/executed.
The reported producer results were known to the reviewer; this is an
implementation cross-check, not a blinded or independent-team experiment.
"""
import argparse
import base64
import copy
import hashlib
import json
import re
import socket
from collections import Counter, defaultdict
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath
from urllib.parse import quote, urlsplit

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CAPTURE = ROOT / "captures/revision_v5_multi"
READS = {}
SOCKET_ATTEMPTS = []


def blocked_socket(*args, **kwargs):
    SOCKET_ATTEMPTS.append("blocked")
    raise RuntimeError("offline_verifier_network_attempt")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def demand(condition, label):
    if not condition:
        raise AssertionError(label)


def same(label, expected, observed):
    # JSON encodings distinguish bool/int/float; ordinary Python == does not.
    encode = lambda value: json.dumps(value, sort_keys=True, ensure_ascii=False,
                                      separators=(",", ":"))
    demand(encode(expected) == encode(observed), label)


def read(path):
    path = Path(path).resolve()
    key = path.relative_to(ROOT).as_posix()
    data = path.read_bytes()
    measured = digest(data)
    if key in READS:
        demand(READS[key] == measured, "input_changed_while_reading:" + key)
    READS[key] = measured
    return data


def document(path):
    return json.loads(read(path))


def checked_digest(data, expected, label):
    demand(digest(data) == expected, label)


def git_id(kind, data):
    return hashlib.sha1(kind.encode() + b" " + str(len(data)).encode()
                        + b"\0" + data).hexdigest()


def transaction_id(value):
    if type(value) is not str:
        raise ValueError("transaction_id_type")
    value = value.lower()
    if value.startswith("0x"):
        value = value[2:]
    if len(value) != 64 or any(char not in "0123456789abcdef" for char in value):
        raise ValueError("transaction_id_text")
    return value


def units(value):
    if type(value) is int and value >= 0:
        return value
    if type(value) is str and value and value.isascii() and value.isdecimal():
        return int(value)
    raise ValueError("amount_format")


def label(value):
    if type(value) is not str or not value.strip():
        raise ValueError("empty_label")
    return value.upper()


def describe(record):
    """Independent row representation; errors stay separate from empty claims."""
    result = {"inbound": None, "claims": [], "participants": set(),
              "assets": [], "btc_occurrences": 0, "invalid_btc": 0,
              "errors": [], "output_count": None, "status": None, "type": None}
    if type(record) is not dict:
        result["errors"].append("not_object")
        result["category"] = "unresolved"
        return result
    result["status"], result["type"] = record.get("status"), record.get("type")
    inbound = record.get("in")
    if type(inbound) is list:
        for item in inbound:
            if type(item) is dict and type(item.get("address")) is str and item["address"]:
                result["participants"].add(item["address"])
    try:
        if type(inbound) is not list or len(inbound) != 1 or type(inbound[0]) is not dict:
            raise ValueError("inbound_shape")
        item = inbound[0]
        result["inbound"] = (label(item["chain"]), transaction_id(item["txID"]),
                             label(item["asset"]))
    except (KeyError, ValueError, TypeError) as error:
        result["errors"].append(str(error))
    outbound = record.get("out")
    if type(outbound) is not list:
        result["errors"].append("missing_output_array")
    else:
        result["output_count"] = len(outbound)
        for position, item in enumerate(outbound):
            if type(item) is not dict:
                result["errors"].append("invalid_output_object")
                continue
            try:
                chain_asset = (label(item.get("chain")), label(item.get("asset")))
            except ValueError:
                result["errors"].append("invalid_output_label")
                continue
            result["assets"].append(chain_asset)
            address = item.get("address")
            if type(address) is str and address:
                result["participants"].add(address)
            native_btc = chain_asset == ("BTC", "BTC")
            result["btc_occurrences"] += int(native_btc)
            try:
                if type(address) is not str or not address.strip():
                    raise ValueError("recipient_missing")
                tx = transaction_id(item["txID"])
                amount = units(item["amount"])
            except (KeyError, ValueError, TypeError) as error:
                result["errors"].append(str(error))
                result["invalid_btc"] += int(native_btc)
                continue
            if native_btc:
                result["claims"].append((tx, address, amount, position))
    distinct = {(tx, address, amount) for tx, address, amount, _ in result["claims"]}
    if result["errors"]:
        category = "unresolved"
    elif len(distinct) == 0:
        category = "no_btc_claim"
    elif len(distinct) >= 2:
        category = "multiple_distinct_btc_claims"
    elif any(asset != ("BTC", "BTC") for asset in result["assets"]):
        category = "one_btc_claim_with_other_assets"
    else:
        category = "one_btc_claim_only"
    result["category"] = category
    return result


def collect_groups(descriptions):
    locations = defaultdict(list)
    for index, row in enumerate(descriptions):
        if row["inbound"] is not None:
            locations[row["inbound"][:2]].append(index)
    result = []
    for (chain, tx), indices in sorted(locations.items()):
        records = [descriptions[index] for index in indices]
        claims = [claim for row in records for claim in row["claims"]]
        unique = sorted({(item[0], item[1], "BTC", item[2]) for item in claims})
        maximum = max(row["btc_occurrences"] for row in records)
        result.append({"source_chain": chain, "inbound_txid": tx,
            "input_assets": sorted({row["inbound"][2] for row in records}),
            "row_indices": indices,
            "claims": [{"txid": a, "recipient": b, "amount": c, "row_index": d}
                       for a, b, c, d in claims],
            "participants": sorted(set().union(*(row["participants"] for row in records))),
            "max_btc_rows_in_one_record": maximum,
            "distinct_claim_tuples": [list(item) for item in unique],
            "distinct_btc_transaction_ids": sorted({item[0] for item in unique}),
            "repeated_claim_rows": len(claims) - len(unique),
            "candidate": len(unique) >= 2 or maximum >= 2,
            "has_issues": any(row["errors"] for row in records)})
    return result


def choose(groups, prior):
    ids, senders, recipients = prior
    available, excluded = [], []
    for item in groups:
        if not item["candidate"]:
            continue
        reasons = []
        if item["inbound_txid"] in ids:
            reasons.append("prior_identifier")
        if set(address.lower() for address in item["participants"]) & senders:
            reasons.append("prior_evm_participant")
        if set(item["participants"]) & recipients:
            reasons.append("prior_btc_participant")
        if reasons:
            excluded.append({"source_chain": item["source_chain"],
                "inbound_txid": item["inbound_txid"], "reasons": reasons})
            continue
        stratum = "other_input"
        if (item["source_chain"], item["input_assets"]) == ("ETH", ["ETH"]):
            stratum = "native_ETH"
        rank = digest(("VCA-MULTI5-20260908|" + item["source_chain"]
                       + "|" + item["inbound_txid"]).encode())
        available.append({**item, "stratum": stratum, "rank_sha256": rank})
    selected = []
    for stratum in ("native_ETH", "other_input"):
        ordered = sorted((item for item in available if item["stratum"] == stratum),
                         key=lambda item: (item["rank_sha256"], item["source_chain"],
                                           item["inbound_txid"]))
        selected += ordered[:5]
    return available, excluded, selected


def own_controls():
    done = []
    base = {"status": "success", "type": "swap",
            "in": [{"chain": "ETH", "asset": "ETH", "txID": "1" * 64,
                    "address": "synthetic-payer"}],
            "out": [{"chain": "BTC", "asset": "BTC", "txID": "2" * 64,
                     "address": "synthetic-recipient", "amount": "600"}]}
    def confirm(name, condition):
        demand(condition, "synthetic:" + name)
        done.append(name)
    def grouped(records):
        return collect_groups([describe(item) for item in records])
    confirm("normal_single", describe(base)["category"] == "one_btc_claim_only"
            and not grouped([base])[0]["candidate"])
    repeated = copy.deepcopy(base)
    repeated["out"] += copy.deepcopy(repeated["out"])
    confirm("identical_rows_preserved", grouped([repeated])[0]["candidate"]
            and len(grouped([repeated])[0]["distinct_claim_tuples"]) == 1)
    confirm("identical_single_rows_across_records", not grouped([base, base])[0]["candidate"])
    second = copy.deepcopy(base)
    second["out"][0]["txID"] = "3" * 64
    confirm("different_claims_across_records", grouped([base, second])[0]["candidate"])
    within = copy.deepcopy(repeated)
    within["out"][1]["amount"] = "700"
    confirm("two_claims_one_transaction", grouped([within])[0]["candidate"]
            and len(grouped([within])[0]["distinct_btc_transaction_ids"]) == 1)
    mixed = copy.deepcopy(base)
    mixed["out"].append({"chain": "ETH", "asset": "ETH", "txID": "4" * 64,
                         "address": "synthetic-payer", "amount": "100"})
    confirm("cross_asset_distinction", describe(mixed)["category"] == "one_btc_claim_with_other_assets"
            and not grouped([mixed])[0]["candidate"])
    other_only = copy.deepcopy(mixed)
    other_only["out"] = other_only["out"][1:]
    confirm("valid_no_btc", describe(other_only)["category"] == "no_btc_claim")
    for name, change in (
        ("missing_outputs", lambda item: item.pop("out")),
        ("blank_asset", lambda item: item["out"][0].update(asset=" ")),
        ("invalid_amount_bool", lambda item: item["out"][0].update(amount=True)),
        ("invalid_amount_float", lambda item: item["out"][0].update(amount=1.0)),
        ("invalid_non_btc_amount", lambda item: item["out"][1].update(amount=None)),
        ("invalid_non_btc_recipient", lambda item: item["out"][1].update(address="")),
    ):
        bad = copy.deepcopy(mixed)
        change(bad)
        confirm(name, describe(bad)["category"] == "unresolved")
    zero = copy.deepcopy(base)
    zero["out"][0]["amount"] = 0
    confirm("zero_is_claim_not_absence", describe(zero)["claims"][0][2] == 0
            and describe(zero)["category"] == "one_btc_claim_only")
    malformed_duplicate = copy.deepcopy(repeated)
    for output in malformed_duplicate["out"]:
        output["amount"] = None
    confirm("malformed_multiple_still_candidate", grouped([malformed_duplicate])[0]["candidate"]
            and grouped([malformed_duplicate])[0]["has_issues"])
    for name, prior in (
        ("exclude_id", ({"1" * 64}, set(), set())),
        ("exclude_sender", (set(), {"synthetic-payer"}, set())),
        ("exclude_recipient", (set(), set(), {"synthetic-recipient"})),
    ):
        available, excluded, selected = choose(grouped([repeated]), prior)
        confirm(name, not available and not selected and len(excluded) == 1)
    candidates = []
    for number in range(14):
        item = copy.deepcopy(repeated)
        item["in"][0]["txID"] = format(100 + number, "064x")
        if number >= 7:
            item["in"][0].update(chain="LTC", asset="LTC")
        candidates.append(item)
    selection = choose(grouped(candidates), (set(), set(), set()))[2]
    reverse = choose(grouped(list(reversed(candidates))), (set(), set(), set()))[2]
    signature = lambda items: [(row["source_chain"], row["inbound_txid"]) for row in items]
    confirm("ranking_order_and_stratum_caps", signature(selection) == signature(reverse)
            and Counter(row["stratum"] for row in selection) == {"native_ETH": 5, "other_input": 5})
    token = copy.deepcopy(repeated)
    token["in"][0]["asset"] = "TOKEN"
    confirm("eth_token_not_native_stratum", choose(grouped([token]), (set(), set(), set()))[2][0]["stratum"] == "other_input")
    for name, operation in (
        ("content_hash_mutation_rejected", lambda: checked_digest(b"changed", digest(b"original"), "digest_control")),
        ("strict_count_mutation_rejected", lambda: same("count_control", {"count": 1}, {"count": 2})),
        ("false_is_not_zero", lambda: same("type_control", {"count": 0}, {"count": False})),
    ):
        try:
            operation()
        except AssertionError:
            done.append(name)
        else:
            raise AssertionError("negative_control_failed:" + name)
    return done


def tree_check(tree):
    demand(tree["truncated"] is False, "tree_incomplete")
    by_path = {item["path"]: item for item in tree["tree"]}
    demand(len(by_path) == len(tree["tree"]), "duplicate_tree_path")
    children = defaultdict(list)
    for item in tree["tree"]:
        parent = str(PurePosixPath(item["path"]).parent)
        children["" if parent == "." else parent].append(item)
    checked = 0
    for folder, entries in children.items():
        entries = sorted(entries, key=lambda item: PurePosixPath(item["path"]).name.encode()
                         + (b"/" if item["type"] == "tree" else b""))
        parts = []
        for item in entries:
            mode = item["mode"].lstrip("0")
            name = PurePosixPath(item["path"]).name
            parts.append(mode.encode() + b" " + name.encode() + b"\0" + bytes.fromhex(item["sha"]))
        expected = tree["sha"] if folder == "" else by_path[folder]["sha"]
        demand(git_id("tree", b"".join(parts)) == expected, "git_tree_identity:" + folder)
        checked += 1
    return by_path, checked


def archived_request(key, expected_url):
    report = document(CAPTURE / (key + ".json"))
    same("request_url:" + key, expected_url, report["url"])
    demand(report["key"] == key and 1 <= len(report["attempts"]) <= 2, "attempt_cardinality:" + key)
    available = []
    starts = []
    for index, attempt in enumerate(report["attempts"], 1):
        request = document(CAPTURE / attempt["request_file"])
        checked_digest(read(CAPTURE / attempt["request_file"]), attempt["request_sha256"], "request_hash:" + key)
        same("attempt_metadata:" + key, attempt, document(CAPTURE / f"{key}_attempt{index}.metadata.json"))
        demand(request["method"] == "GET" and request["url"] == expected_url, "recorded_request:" + key)
        demand(request["authorization_sent"] is False and request["cookie_sent"] is False
               and request["tls_verification"] is True, "recorded_request_options:" + key)
        parsed = urlsplit(request["url"])
        demand(parsed.scheme == "https" and parsed.hostname in {"api.github.com", "media.githubusercontent.com"},
               "recorded_request_boundary:" + key)
        starts.append(request["started_utc"])
        if "response_file" in attempt:
            body = read(CAPTURE / attempt["response_file"])
            checked_digest(body, attempt["response_sha256"], "response_hash:" + key)
            demand(len(body) == attempt["bytes"] and len(body) <= 10_000_000, "response_size:" + key)
            if attempt["status"] == "available":
                demand(attempt["http_status"] == 200 and attempt["final_url"] == expected_url, "response_status:" + key)
                available.append(body)
    demand((report["status"] == "available") == bool(available), "request_availability:" + key)
    demand(len(available) <= 1, "multiple_success_attempts:" + key)
    return available[0] if available else None, starts


def exclusion_policy(lock):
    values = {}
    for relative, expected in lock["exclusions_sha256"].items():
        raw = read(ROOT / relative)
        checked_digest(raw, expected, "locked_exclusion:" + relative)
        values[relative] = json.loads(raw)
    original_name = "experiments/holdout/selection_20260907/exclusions.json"
    original = values[original_name]
    inherited = values["experiments/revision_v1/selection/exclusions.json"]
    checked_digest(read(ROOT / original_name), inherited["source_exclusions_sha256"], "original_exclusion_lineage")
    old_labels_path = ROOT / "experiments/holdout/selection_20260907/sealed_labels.json"
    checked_digest(read(old_labels_path), inherited["earlier_sample_sha256"], "original_40_lineage")
    old_labels = document(old_labels_path)
    ids = {transaction_id(item) for item in original["identifiers"]}
    evm = set(address.lower() for address in original["evm_senders"])
    btc = set(original["btc_recipients"])
    for item in old_labels:
        ids.add(transaction_id(item["txid"]))
        evm.update(leg["address"].lower() for leg in item["record"]["in"])
        btc.update(leg["address"] for leg in item["record"]["out"])
    same("rederived_base_identifiers", sorted(ids), sorted(transaction_id(item) for item in inherited["identifiers"]))
    same("rederived_base_evm", sorted(evm), sorted(inherited["evm_senders"]))
    same("rederived_base_btc", sorted(btc), sorted(inherited["btc_recipients"]))
    removed = set(original["shared_infrastructure_removed_from_senders"])
    demand(not removed.intersection(original["evm_senders"]), "infrastructure_original_exceptions")
    recent_labels = values["experiments/revision_v1/selection/sealed_labels.json"]
    refund_labels = values["experiments/revision_v2/selection.json"]["selected"]
    for item in recent_labels:
        ids.add(transaction_id(item["txid"]))
        evm.update(leg["address"].lower() for leg in item["record"]["in"])
        btc.update(leg["address"] for leg in item["record"]["out"])
    for item in refund_labels:
        ids.add(transaction_id(item["txid"]))
        evm.add(item["sender"].lower())
        btc.add(item["memo_recipient"])
    return (ids, evm, btc), {"original_40_labels": len(old_labels), "additional_96_labels": len(recent_labels),
                            "refund_labels": len(refund_labels), "identifiers": len(ids),
                            "evm_participants": len(evm), "btc_participants": len(btc),
                            "original_infrastructure_exceptions": len(removed)}


def projection(row):
    unique = {(a, b, c) for a, b, c, _ in row["claims"]}
    inbound = row["inbound"]
    return {"classification": row["category"],
        "inbound": None if inbound is None else {"chain": inbound[0], "txid": inbound[1], "asset": inbound[2]},
        "btc_claims": [{"txid": a, "recipient": b, "amount": c, "row_index": d} for a, b, c, d in row["claims"]],
        "participants": sorted(row["participants"]), "asset_pairs": [list(item) for item in row["assets"]],
        "raw_btc_rows": row["btc_occurrences"], "invalid_btc_rows": row["invalid_btc"],
        "raw_output_rows": row["output_count"], "distinct_btc_claims": len(unique),
        "distinct_btc_transactions": len({item[0] for item in unique}),
        "repeated_btc_claim_rows": len(row["claims"]) - len(unique),
        "record_status": row["status"], "record_type": row["type"],
        "possible_multiple_btc": len(unique) >= 2 or row["btc_occurrences"] >= 2,
        "has_issues": bool(row["errors"])}


def comparable_group(row):
    return {**{key: value for key, value in row.items() if key != "issues"},
            "has_issues": bool(row.get("issues"))}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=HERE / "census_verification.json")
    args = parser.parse_args()
    output = args.output.resolve()
    output.relative_to(ROOT)
    demand(not output.exists(), "verification_output_already_exists")
    socket.create_connection = blocked_socket
    socket.socket.connect = blocked_socket
    socket.socket.connect_ex = blocked_socket
    started = datetime.now(UTC).isoformat()
    own_source = read(Path(__file__))
    controls = own_controls()
    lock = document(HERE / "frame_lock.json")
    capture = document(HERE / "frame_capture.json")
    checked_digest(read(HERE / "frame_lock.json"), capture["lock_sha256"], "capture_lock_binding")
    for file, key in (("MULTI_OUTPUT_PROTOCOL.md", "protocol_sha256"),
                      ("capture_frame.py", "collector_sha256"), ("census_frame.py", "census_sha256")):
        checked_digest(read(HERE / file), lock[key], "frozen_source:" + file)
    checked_digest(read(ROOT / "experiments/revision_v1/output_audit.py"),
                   lock["unchanged_output_audit_sha256"], "frozen_output_audit")
    tree_path = ROOT / "_workspace/streaming_scope_20260908/pinned_tree.json"
    checked_digest(read(tree_path), lock["tree_sha256"], "locked_tree")
    tree = document(tree_path)
    by_path, trees_verified = tree_check(tree)
    source = document(ROOT / "experiments/metadata/thor25_schema_sources.json")
    demand(source["tree_sha"] == tree["sha"] and source["source_commit"] == lock["source_commit"], "source_tree_binding")
    candidates = [item for path, item in sorted(by_path.items())
                  if path.startswith("data/thorchain-2025-multi/") and path.endswith(".ndjson")
                  and item["type"] == "blob"]
    same("fixed_nine_tree_entries", candidates, lock["files"])
    demand(len(candidates) == 9, "fixed_frame_cardinality")
    capture_rows = {item["path"]: item for item in capture["rows"]}
    demand(len(capture_rows) == 9 and set(capture_rows) == {item["path"] for item in candidates}, "capture_frame_paths")
    rows, origins, file_results, frame_hashes, request_starts = [], [], [], {}, []
    logical_requests = 0
    for ordinal, entry in enumerate(candidates, 1):
        stored = capture_rows[entry["path"]]
        demand(stored["index"] == ordinal and stored["git_blob_sha"] == entry["sha"], "frame_blob_binding")
        pointer_response, starts = archived_request(f"pointer_{ordinal:02d}", entry["url"])
        logical_requests += 1
        request_starts += starts
        if pointer_response is None:
            demand(stored["status"] == "unavailable", "missing_pointer_status")
            file_results.append({"path": entry["path"], "status": "unavailable"})
            continue
        blob = json.loads(pointer_response)
        demand(blob["encoding"] == "base64", "pointer_encoding")
        pointer = base64.b64decode("".join(blob["content"].split()), validate=True)
        demand(git_id("blob", pointer) == entry["sha"] == blob["sha"], "pointer_git_identity")
        demand(len(pointer) == entry["size"] == blob["size"], "pointer_git_size")
        same("saved_pointer_bytes", pointer.decode("ascii"), read(CAPTURE / stored["pointer_file"]).decode("ascii"))
        checked_digest(pointer, stored["pointer_sha256"], "pointer_sha256")
        lines = pointer.decode("ascii").splitlines()
        demand(len(lines) == 3 and lines[0] == "version https://git-lfs.github.com/spec/v1", "lfs_version")
        demand(lines[1].startswith("oid sha256:") and lines[2].startswith("size "), "lfs_fields")
        expected_hash, expected_size = lines[1].split(":", 1)[1], int(lines[2][5:])
        demand(expected_hash == stored["expected_sha256"] and expected_size == stored["expected_bytes"], "lfs_manifest_binding")
        url = ("https://media.githubusercontent.com/media/" + source["repository"] + "/"
               + source["source_commit"] + "/" + quote(entry["path"], safe="/"))
        response, starts = archived_request(f"payload_{ordinal:02d}", url)
        logical_requests += 1
        request_starts += starts
        if response is None:
            demand(stored["status"] == "unavailable", "missing_payload_status")
            file_results.append({"path": entry["path"], "status": "unavailable"})
            continue
        checked_digest(response, expected_hash, "lfs_payload_identity")
        demand(len(response) == expected_size, "lfs_payload_size")
        raw = read(CAPTURE / stored["file"])
        demand(raw == response and stored["status"] == "available", "saved_payload_identity")
        checked_digest(raw, stored["sha256"], "capture_payload_hash")
        demand(len(raw) == stored["bytes"], "capture_payload_size")
        relative = (CAPTURE / stored["file"]).relative_to(ROOT).as_posix()
        frame_hashes[relative] = digest(raw)
        count = 0
        for line_number, line in enumerate(raw.split(b"\n"), 1):
            line = line.removesuffix(b"\r")
            if not line.strip():
                continue
            try:
                decoded = json.loads(line)
                row = describe(decoded)
            except (json.JSONDecodeError, UnicodeDecodeError):
                row = describe(None)
            rows.append(row)
            origins.append({"file": relative, "line": line_number,
                            "line_sha256": digest(line), "source_path": entry["path"]})
            count += 1
        file_results.append({"path": entry["path"], "status": "available", "nonempty_lines": count})
    demand(logical_requests == capture["logical_requests"], "logical_request_count")
    same("lexicographic_request_time_order", sorted(request_starts), request_starts)
    available_files = sum(item["status"] == "available" for item in file_results)
    demand(available_files == capture["files_available"], "file_availability_count")
    groups = collect_groups(rows)
    prior, prior_counts = exclusion_policy(lock)
    eligible, excluded, selected = choose(groups, prior)
    counts = {"frame_files_expected": 9, "frame_files_available": available_files,
        "records": len(rows), "record_classifications": dict(Counter(item["category"] for item in rows)),
        "record_statuses": dict(Counter(str(item["status"]) for item in rows)),
        "record_types": dict(Counter(str(item["type"]) for item in rows)),
        "bound_inbounds": len(groups), "inbounds_in_multiple_records": sum(len(item["row_indices"]) > 1 for item in groups),
        "candidate_inbounds": sum(item["candidate"] for item in groups), "excluded_candidates": len(excluded),
        "eligible_candidates": len(eligible), "selected": len(selected),
        "selected_strata": dict(Counter(item["stratum"] for item in selected))}
    # Load producer results only after the separate source-based recount/selection.
    producer = document(HERE / "census.json")
    selection = document(HERE / "selection.json")
    checked_digest(read(HERE / "census.json"), selection["census_sha256"], "selection_census_binding")
    checked_digest(read(HERE / "frame_capture.json"), producer["frame_capture_sha256"], "census_capture_binding")
    demand(producer["source_sha256"] == lock["census_sha256"], "producer_source_binding")
    demand(producer["protocol_sha256"] == selection["protocol_sha256"] == lock["protocol_sha256"], "protocol_result_binding")
    same("producer_count_comparison", counts, {key: value for key, value in producer["counts"].items() if key != "predicate_controls"})
    same("producer_control_record_count", len(producer["controls"]), producer["counts"]["predicate_controls"])
    same("producer_file_comparison", file_results, producer["files"])
    same("producer_input_hashes", frame_hashes, producer["inputs_sha256"])
    demand(len(producer["rows"]) == len(rows), "producer_row_count")
    for number, (ours, theirs, origin) in enumerate(zip(rows, producer["rows"], origins)):
        expected = projection(ours)
        reported = {key: theirs.get(key) for key in expected}
        reported["participants"] = sorted(set(theirs["participants"]))
        reported["has_issues"] = bool(theirs["issues"])
        same("producer_row_projection:" + str(number), expected, reported)
        same("producer_row_origin:" + str(number), origin, {key: theirs[key] for key in origin})
    same("producer_group_comparison", groups, [comparable_group(item) for item in producer["grouped"]])
    same("producer_eligible_comparison", eligible, [comparable_group(item) for item in producer["eligible"]])
    same("producer_exclusion_comparison", excluded, producer["excluded"])
    same("selected_candidates", selected, [comparable_group(item) for item in selection["selected"]])
    same("selection_exclusion_pins", lock["exclusions_sha256"], selection["exclusions_sha256"])
    demand(selection["n"] == len(selected), "selection_size")
    complete = available_files == 9 and not any(item["errors"] for item in rows)
    demand(selection["frame_and_schema_complete"] is complete, "completeness_status")
    action = "capture_selected" if selected else ("stop_no_eligible_candidate_complete_frame" if complete
               else "stop_no_eligible_candidate_incomplete_evidence")
    demand(selection["next_action"] == action, "selection_next_action")
    readme_entry = next(item for item in source["records"] if item["path"] == "README.md")
    readme = read(ROOT / readme_entry["local_review_copy"])
    checked_digest(readme, readme_entry["sha256"], "readme_hash")
    demand(git_id("blob", readme) == by_path["README.md"]["sha"] == readme_entry["git_blob_sha"], "readme_git_identity")
    matches = re.findall(r"\(Thor25M\):[^\n]*?\((\d+) records", readme.decode("utf-8"))
    demand(len(matches) == 1, "readme_count_anchor")
    advertised = int(matches[0])
    demand(not SOCKET_ATTEMPTS, "offline_socket_attempts")
    for relative, expected in READS.items():
        checked_digest((ROOT / relative).read_bytes(), expected, "changed_input_at_exit:" + relative)
    report = {"status": "PASS", "started_utc": started, "completed_utc": datetime.now(UTC).isoformat(),
        "verifier_sha256": digest(own_source), "counts": counts, "files": file_results,
        "git_tree_objects_reconstructed": trees_verified, "root_tree_sha": tree["sha"],
        "source_commit": source["source_commit"], "archived_logical_requests": logical_requests,
        "archived_attempts": len(request_starts), "prior_exclusion_counts": prior_counts,
        "readme_comparison": {"advertised_records": advertised, "measured_records": len(rows),
            "difference": len(rows) - advertised, "same_pinned_repository_tree": True,
            "interpretation": "README description differs from the nine measured files; cause not established."},
        "selected": selected, "producer_row_projections_checked": len(rows),
        "producer_groups_checked": len(groups), "producer_comparison_mismatches": 0,
        "own_controls": controls, "own_control_count": len(controls),
        "input_files_sha256": READS, "input_hashes_unchanged_at_exit": True,
        "outbound_socket_attempts": 0, "producer_modules_imported_or_executed": False,
        "scope": "Separate implementation of archived-frame classification, exclusions and selection. Reported results were known to this same research workflow. No Bitcoin payout, THORNode dispatch, historical protocol guarantee, population rate or independent-team reproduction is established."}
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(report, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    print(json.dumps({"status": report["status"], "counts": counts,
                      "own_controls": len(controls), "input_files": len(READS),
                      "readme_difference": report["readme_comparison"]["difference"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
