"""Compare saved multiple-payment claims with individually identified outputs.

The recipient-output reference does not filter by claimed amount. The frozen
output audit does use amounts; its result is reported separately. Historical
dispatch checks remain protocol-source corroboration, not consensus validation.
"""
import copy
import hashlib
import importlib.util
import json
import re
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CAPTURE = ROOT / "captures/revision_v5_multi/selected"
AUDIT_PATH = ROOT / "experiments/revision_v1/output_audit.py"
BECH32_PATH = ROOT / "_workspace/replay_20260906/source/src/vca/types/_bech32.py"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(path, value):
    with path.open("xb") as stream:
        stream.write((json.dumps(value, indent=2) + "\n").encode())


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def identifier(value):
    if not isinstance(value, str):
        return None
    value = value.lower().removeprefix("0x")
    return value if re.fullmatch(r"[0-9a-f]{64}", value) else None


def valid_action(action, inbound):
    if not isinstance(action, dict) or not isinstance(action.get("in"), list) or not action["in"]:
        return False
    if any(not isinstance(leg, dict) or identifier(leg.get("txID")) != inbound for leg in action["in"]):
        return False
    if not isinstance(action.get("out"), list):
        return False
    for leg in action["out"]:
        if not isinstance(leg, dict) or not isinstance(leg.get("coins"), list) or not leg["coins"]:
            return False
        for coin in leg["coins"]:
            if not isinstance(coin, dict) or not isinstance(coin.get("asset"), str) or not coin["asset"].strip():
                return False
            units = coin.get("amount")
            integer = (type(units) is int and units >= 0) or (type(units) is str and re.fullmatch(r"[0-9]+", units))
            if not integer:
                return False
            if coin["asset"] == "BTC.BTC":
                recipient = leg.get("address")
                if identifier(leg.get("txID")) is None or not isinstance(recipient, str) or not recipient.strip():
                    return False
    return True


def normalized_action_copy(action):
    normalized = copy.deepcopy(action)
    for leg in normalized["out"]:
        if any(coin["asset"] == "BTC.BTC" for coin in leg["coins"]):
            leg["txID"] = identifier(leg["txID"])
    return normalized


def compact_size(size):
    if type(size) is not int or not 0 <= size < 2**64:
        raise ValueError("invalid_compact_size")
    if size < 253:
        return bytes([size])
    for ceiling, prefix, width in ((2**16, b"\xfd", 2), (2**32, b"\xfe", 4), (2**64, b"\xff", 8)):
        if size < ceiling:
            return prefix + size.to_bytes(width, "little")
    raise ValueError("invalid_compact_size")


def calculated_txid(transaction):
    version = transaction["version"]
    if type(version) is not int or not -(2**31) <= version < 2**31:
        raise ValueError("invalid_version")
    raw = version.to_bytes(4, "little", signed=True) + compact_size(len(transaction["vin"]))
    for vin in transaction["vin"]:
        prev = identifier(vin["txid"])
        if prev is None:
            raise ValueError("invalid_previous_txid")
        script = bytes.fromhex(vin["scriptsig"])
        raw += bytes.fromhex(prev)[::-1] + vin["vout"].to_bytes(4, "little")
        raw += compact_size(len(script)) + script + vin["sequence"].to_bytes(4, "little")
    raw += compact_size(len(transaction["vout"]))
    for output in transaction["vout"]:
        value = output["value"]
        if type(value) is not int or not 0 <= value <= 21_000_000 * 10**8:
            raise ValueError("invalid_output_value")
        script = bytes.fromhex(output["scriptpubkey"])
        raw += value.to_bytes(8, "little") + compact_size(len(script)) + script
    raw += transaction["locktime"].to_bytes(4, "little")
    return hashlib.sha256(hashlib.sha256(raw).digest()).digest()[::-1].hex()


def transaction_check(expected, transaction):
    if transaction is None:
        return "transaction_unavailable"
    try:
        if transaction.get("txid") != expected or calculated_txid(transaction) != expected:
            return "transaction_identity_mismatch"
        status = transaction.get("status")
        if not isinstance(status, dict) or type(status.get("confirmed")) is not bool:
            return "transaction_fields_unavailable"
        if status["confirmed"] is False:
            return "transaction_unconfirmed"
    except (KeyError, ValueError, TypeError, OverflowError, AttributeError):
        return "transaction_fields_unavailable"
    return "content_consistent"


def recipient_script(address, bech32):
    decoded = bech32._decode_segwit(address)
    if decoded is not None:
        hrp, version, program = decoded
        if hrp != "bc":
            raise ValueError("non_mainnet_recipient")
        opcode = 0 if version == 0 else 0x50 + version
        return bytes([opcode, len(program)]).hex() + bytes(program).hex()
    decoded = bech32._b58_decode_check(address)
    if decoded is not None and len(decoded) == 21:
        if decoded[0] == 0:
            return "76a914" + decoded[1:].hex() + "88ac"
        if decoded[0] == 5:
            return "a914" + decoded[1:].hex() + "87"
    raise ValueError("recipient_encoding_unsupported")


def recipient_reference(claims, transactions, bech32):
    # The amount field is deliberately never read in this function.
    outputs, issues = {}, []
    pairs = sorted({(claim["txid"], claim["recipient"]) for claim in claims})
    for txid, recipient in pairs:
        try:
            locking_script = recipient_script(recipient, bech32)
        except ValueError:
            issues.append({"txid": txid, "recipient": recipient, "reason": "recipient_encoding_unsupported"})
            continue
        transaction = transactions.get(txid)
        status = transaction_check(txid, transaction)
        if status != "content_consistent":
            issues.append({"txid": txid, "recipient": recipient, "reason": status})
            continue
        matches = [(index, out) for index, out in enumerate(transaction["vout"])
                   if out.get("scriptpubkey") == locking_script]
        if not matches:
            issues.append({"txid": txid, "recipient": recipient, "reason": "recipient_not_found"})
        for index, out in matches:
            outputs[("BTC", txid, index)] = {"output_id": ["BTC", txid, index],
                "recipient": recipient, "satoshis": out["value"], "scriptpubkey": out["scriptpubkey"]}
    complete = bool(pairs) and not issues
    return {"status": "enumerated" if complete else "unresolved", "issues": issues,
        "outputs": [outputs[key] for key in sorted(outputs)],
        "total_satoshis": sum(row["satoshis"] for row in outputs.values()) if complete else None,
        "scope": "All outputs to claimed recipients in claimed transactions, without an amount filter; not an allocation between claims."}


def op_return_text(script_hex):
    raw = bytes.fromhex(script_hex)
    if not raw or raw[0] != 0x6A or len(raw) < 2:
        return None
    code, offset = raw[1], 2
    if code <= 75:
        size = code
    elif code == 76 and len(raw) >= 3:
        size, offset = raw[2], 3
    elif code == 77 and len(raw) >= 4:
        size, offset = int.from_bytes(raw[2:4], "little"), 4
    else:
        return None
    if len(raw) != offset + size:
        return None
    try:
        return raw[offset:].decode("ascii", errors="strict")
    except UnicodeDecodeError:
        return None


def payer_check(source_id, source_chain, claim, inbound, outbound, bitcoin, bech32):
    if inbound is None or outbound is None or bitcoin is None:
        return {"status": "evidence_unavailable", "checks": {}}
    checks = {}
    try:
        observed, historical = outbound["tx"], inbound["tx"]
        payout = observed["tx"]
        output_id, recipient, units = claim["txid"], claim["recipient"], claim["satoshis"]
        planned = [row for row in inbound["actions"] if row.get("chain") == "BTC"
            and row.get("to_address") == recipient and identifier(row.get("in_hash")) == source_id]
        emitted = [row for row in inbound["out_txs"] if identifier(row.get("id")) == output_id]
        if transaction_check(output_id, bitcoin) == "transaction_fields_unavailable":
            return {"status": "fields_unavailable", "checks": checks, "reason": "bitcoin_fields_unavailable"}
        if not isinstance(bitcoin.get("vin"), list) or not bitcoin["vin"]:
            return {"status": "fields_unavailable", "checks": checks, "reason": "bitcoin_inputs_unavailable"}
        for vin in bitcoin["vin"]:
            previous = vin.get("prevout") if isinstance(vin, dict) else None
            if not isinstance(previous, dict) or any(not isinstance(previous.get(field), str) or not previous[field].strip()
                    for field in ("scriptpubkey", "scriptpubkey_address")):
                return {"status": "fields_unavailable", "checks": checks, "reason": "previous_output_fields_unavailable"}
        if not isinstance(observed.get("observed_pub_key"), str) or not observed["observed_pub_key"].strip():
            return {"status": "fields_unavailable", "checks": checks, "reason": "observed_vault_key_unavailable"}
        if any(not isinstance(row.get("vault_pub_key"), str) or not row["vault_pub_key"].strip() for row in planned):
            return {"status": "fields_unavailable", "checks": checks, "reason": "planned_vault_key_unavailable"}
        decoded = bech32._decode_bech32(observed["observed_pub_key"])
        if decoded is None or decoded[0] != "thorpub" or decoded[2] != 1:
            return {"status": "historical_key_unsupported", "checks": checks}
        converted = bech32._convert_bits(decoded[1], 5, 8, pad=False)
        key = bytes(converted) if converted is not None else b""
        if len(key) != 38 or key[:5].hex() != "eb5ae98721" or key[5] not in (2, 3):
            return {"status": "historical_key_unsupported", "checks": checks}
        expected_script = "0014" + hashlib.new("ripemd160", hashlib.sha256(key[5:]).digest()).hexdigest()
        references = [op_return_text(row["scriptpubkey"]) for row in bitcoin["vout"]]
        checks = {
            "inbound_identity": identifier(inbound["tx_id"]) == identifier(historical["tx"]["id"]) == source_id,
            "source_chain": historical["tx"]["chain"] == source_chain,
            "outbound_identity": identifier(outbound["tx_id"]) == identifier(payout["id"]) == output_id,
            "bitcoin_content": transaction_check(output_id, bitcoin) == "content_consistent",
            "protocol_chain": payout["chain"] == "BTC",
            "inbound_out_hash": output_id in {identifier(value) for value in historical["out_hashes"]},
            "dispatch_record": len(emitted) == 1 and emitted[0] == payout,
            "recipient": payout["to_address"] == recipient,
            "protocol_amount": sum(int(coin["amount"]) for coin in payout["coins"] if coin["asset"] == "BTC.BTC") == units,
            "historical_vault": any(row.get("vault_pub_key") == observed["observed_pub_key"] for row in planned),
            "protocol_memo_reference": payout["memo"].upper() == "OUT:" + source_id.upper(),
            "bitcoin_memo_reference": any(value is not None and value.upper() == "OUT:" + source_id.upper() for value in references),
            "nonempty_inputs": bool(bitcoin["vin"]),
            "all_input_addresses": bool(bitcoin["vin"]) and all(vin.get("prevout", {}).get("scriptpubkey_address") == payout["from_address"] for vin in bitcoin["vin"]),
            "all_input_scripts": bool(bitcoin["vin"]) and all(vin.get("prevout", {}).get("scriptpubkey") == expected_script for vin in bitcoin["vin"]),
            "one_recipient_output": [row["value"] for row in bitcoin["vout"] if row.get("scriptpubkey_address") == recipient] == [units],
            "recipient_script_outputs": [row["value"] for row in bitcoin["vout"] if row.get("scriptpubkey") == recipient_script(recipient, bech32)] == [units],
        }
    except (KeyError, TypeError, ValueError, AttributeError, OverflowError) as error:
        return {"status": "fields_unavailable", "checks": checks, "error_type": type(error).__name__}
    return {"status": "corroborated" if all(checks.values()) else "mismatch", "checks": checks}


def run():
    target = HERE / "selected_results.json"
    assert not target.exists()
    tracked = [Path(__file__), AUDIT_PATH, BECH32_PATH, HERE / "MULTI_OUTPUT_PROTOCOL.md",
        HERE / "selection.json", HERE / "selected_capture.json", HERE / "selected_capture_lock.json",
        HERE / "capture_selected.py", HERE / "frame_capture.json"]
    before = {path.relative_to(ROOT).as_posix(): sha(path.read_bytes()) for path in tracked}
    selection = json.loads((HERE / "selection.json").read_bytes())
    capture = json.loads((HERE / "selected_capture.json").read_bytes())
    lock = json.loads((HERE / "selected_capture_lock.json").read_bytes())
    assert capture["selection_sha256"] == lock["selection_sha256"] == sha((HERE / "selection.json").read_bytes())
    assert capture["lock_sha256"] == sha((HERE / "selected_capture_lock.json").read_bytes())
    assert lock["source_sha256"] == sha((HERE / "capture_selected.py").read_bytes())
    assert lock["protocol_sha256"] == selection["protocol_sha256"] == sha((HERE / "MULTI_OUTPUT_PROTOCOL.md").read_bytes())
    assert lock["frame_capture_sha256"] == sha((HERE / "frame_capture.json").read_bytes())
    assert lock["output_audit_sha256"] == sha(AUDIT_PATH.read_bytes())
    write(HERE / "evaluation_lock.json", {"created_utc": datetime.now(UTC).isoformat(),
        "inputs_and_sources_sha256": before, "scope": "Analysis code and saved inputs before evaluation; selection was fixed before fresh capture."})
    audit, bech32 = module(AUDIT_PATH, "frozen_output_audit"), module(BECH32_PATH, "frozen_bech32")
    requests = {row["key"]: row for row in capture["requests"]}
    hashes = {}
    for request in requests.values():
        for attempt in request["attempts"]:
            for field in ("request", "response"):
                if field + "_file" in attempt:
                    path = CAPTURE / attempt[field + "_file"]
                    digest = sha(path.read_bytes())
                    assert digest == attempt[field + "_sha256"]
                    hashes[path.relative_to(ROOT).as_posix()] = digest

    def response(key):
        request = requests.get(key)
        if request is None:
            return None
        if request["status"] != "available":
            return None
        raw = (CAPTURE / request["response_file"]).read_bytes()
        assert sha(raw) == request["response_sha256"]
        return json.loads(raw)

    rows, controls = [], []
    for selected, captured in zip(selection["selected"], capture["rows"], strict=True):
        source_id = selected["inbound_txid"]
        assert captured["inbound_txid"] == source_id
        transactions = {txid: response(key) for txid, key in captured["btc"].items()}
        frame_actions = [{"out": [{"txID": claim["txid"], "address": claim["recipient"],
            "coins": [{"asset": "BTC.BTC", "amount": str(claim["amount"])}]}
            for claim in selected["claims"]]}]
        actions, malformed = [], []
        for page_key in captured["action_pages"]:
            page = response(page_key)
            if page is None or not isinstance(page.get("actions"), list):
                continue
            for action in page["actions"]:
                try:
                    if not valid_action(action, source_id):
                        malformed.append("malformed_or_unbound_action")
                        continue
                    normalized = normalized_action_copy(action)
                    audit.bitcoin_claims([normalized])
                    actions.append(normalized)
                except (KeyError, TypeError, ValueError, AttributeError):
                    malformed.append("malformed_action")
        claims_by_source = {"curated_frame": audit.bitcoin_claims(frame_actions), "fresh_midgard": audit.bitcoin_claims(actions)}
        methods = {}
        for source, source_actions in (("curated_frame", frame_actions), ("fresh_midgard", actions)):
            claims = claims_by_source[source]
            valid_transactions = {txid: tx for txid, tx in transactions.items() if transaction_check(txid, tx) == "content_consistent"}
            methods[source] = {"raw_claim_count": len(claims), "naive_total_satoshis": sum(c["satoshis"] for c in claims),
                "four_field_total_satoshis": audit.frozen_four_field_total(source_actions),
                "indexed_audit": audit.audit_outputs(source_actions, valid_transactions),
                "recipient_reference": recipient_reference(claims, transactions, bech32)}
        all_claims = {(c["txid"], c["recipient"], c["satoshis"]): c for source in claims_by_source.values() for c in source}
        payer_rows = []
        for key, claim in sorted(all_claims.items()):
            args = (source_id, selected["source_chain"], claim, response(captured["thor"][source_id]),
                response(captured["thor"].get(claim["txid"])), transactions.get(claim["txid"]), bech32)
            payer_rows.append({"txid": key[0], "recipient": key[1], "satoshis": key[2], **payer_check(*args)})
            if payer_rows[-1]["status"] == "corroborated":
                normal = [copy.deepcopy(value) for value in args[:-1]] + [bech32]
                actual = payer_check(*normal)
                assert actual["status"] == "corroborated"
                controls.append({"name": "unchanged_payer_" + key[0], "status": "PASS"})
                changed = list(args)
                changed[5] = copy.deepcopy(args[5])
                changed[5]["vin"][0]["prevout"]["scriptpubkey"] = "0014" + "00" * 20
                assert payer_check(*changed)["status"] == "mismatch"
                controls.append({"name": "altered_payer_script_" + key[0], "status": "PASS"})
        canonical = lambda claims: sorted({(c["txid"], c["recipient"], c["satoshis"]) for c in claims})
        rows.append({"source_chain": selected["source_chain"], "inbound_txid": source_id,
            "action_stop": captured["action_stop"], "malformed_or_unbound_actions": malformed,
            "fresh_action_collection_complete": captured["action_stop"] == "short_final_page_without_token" and not malformed and not captured["invalid_btc_identifiers"],
            "fresh_action_types": dict(Counter(str(action.get("type")) for action in actions)),
            "fresh_action_statuses": dict(Counter(str(action.get("status")) for action in actions)),
            "frame_and_fresh_claims_agree": canonical(claims_by_source["curated_frame"]) == canonical(claims_by_source["fresh_midgard"]),
            "transaction_checks": {txid: transaction_check(txid, tx) for txid, tx in transactions.items()},
            "methods": methods, "historical_payer_checks": payer_rows})
        claims = claims_by_source["curated_frame"]
        reference = recipient_reference(claims, transactions, bech32)
        if reference["status"] == "enumerated":
            changed = copy.deepcopy(claims)
            for claim in changed:
                claim["satoshis"] += 1
            assert recipient_reference(changed, transactions, bech32) == reference
            controls.append({"name": "amount_independent_reference", "status": "PASS"})
            duplicated = copy.deepcopy(frame_actions)
            duplicated[0]["out"] *= 2
            base_audit = audit.audit_outputs(frame_actions, transactions)
            repeated_audit = audit.audit_outputs(duplicated, transactions)
            assert repeated_audit["verified_total_satoshis"] == base_audit["verified_total_satoshis"]
            assert repeated_audit["resolved_outputs"] == base_audit["resolved_outputs"]
            assert len(repeated_audit["claims"]) == 2 * len(base_audit["claims"])
            assert audit.frozen_four_field_total(duplicated) == audit.frozen_four_field_total(frame_actions)
            controls.append({"name": "repeated_records_retain_indexed_total", "status": "PASS"})
            missing = dict(transactions)
            missing[claims[0]["txid"]] = None
            assert recipient_reference(claims, missing, bech32)["total_satoshis"] is None
            assert audit.audit_outputs(frame_actions, missing)["verified_total_satoshis"] is None
            controls.append({"name": "missing_transaction_not_zero", "status": "PASS"})
    assert before == {path.relative_to(ROOT).as_posix(): sha(path.read_bytes()) for path in tracked}
    assert hashes == {name: sha((ROOT / name).read_bytes()) for name in hashes}
    report = {"status": "MEASURED", "created_utc": datetime.now(UTC).isoformat(), "rows": rows,
        "inputs_and_sources_sha256": before, "captured_files_sha256": hashes, "controls": controls,
        "captured_input_hashes_unchanged_at_exit": True,
        "fresh_action_normalization": "A deep copy canonicalizes only BTC txID case and optional 0x prefix before the unchanged audit; raw captured bytes are preserved.",
        "scope": "Fixed-frame output accounting and historical protocol corroboration. Non-ETH input, no VCA decoder or inbound-LTC amount validation, no block inclusion or independent consensus claim."}
    write(target, report)
    print(json.dumps({"cases": len(rows), "transaction_checks": [row["transaction_checks"] for row in rows],
        "claim_agreement": [row["frame_and_fresh_claims_agree"] for row in rows],
        "payer_checks": dict(Counter(check["status"] for row in rows for check in row["historical_payer_checks"])),
        "controls": len(controls)}, indent=2))


if __name__ == "__main__":
    run()
