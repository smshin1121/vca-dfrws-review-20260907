# Protocol-record multiplicity probe

Recorded on 2026-09-08 before downloading any Thor25M transaction payload or
running its census. This is a locally prospective procedure informed by the
published dataset README and pinned repository paths. It is not public
preregistration, a decoder extension, or an independent-team experiment.

## Question

Does the separate public multi-output frame contain multiple BTC payment
claims for one inbound, distinct from a BTC payment plus source-asset refund
and from repeated references to one BTC payment? If so, do the unchanged
four-field calculation and supplemental output-index audit account for the
available actual outputs? A protocol claim is not an independently verified
payment. Internal streaming sub-swaps are not counted as outbound payments.

## Fixed candidate frame

Use all nine NDJSON files under `data/thorchain-2025-multi/` at the already
preserved public dataset commit `6ae096a4138c7016642e8bc82d1ebb5cae294d5d`,
tree `822d8ba67c89f1e7069c62b727c9238c8f58ef43` in
`xhyumiracle/thorchain-crosschain-data`. The README advertises 156 records;
the actual count is to be measured, not assumed. The observed pinned tree is
saved at `_workspace/streaming_scope_20260908/pinned_tree.json`.

Read each Git LFS pointer by its tree-pinned blob SHA, verify Git blob identity,
and fetch its referenced payload at the same commit. Verify SHA-256 and size
against the pointer before parsing. Preserve response bytes and metadata.
Unavailable or malformed files remain in the nine-file denominator; do not
replace them from a different commit or expand the frame after seeing results.
Read public transform/source documentation separately if needed to interpret
the schema; do not assume this curated frame includes all network activity.

## Census and candidate classification

Parse every nonempty line with its source file and line number. Retain malformed
or unsupported rows. Native Bitcoin output rows are identified by chain BTC
and asset BTC in this dataset schema. Require a single inbound row with a
nonempty chain and valid 64-hex transaction identifier for a linked candidate.
Keep all source chains and distinguish ETH from other inputs; non-ETH cases
test output accounting only and cannot establish VCA decoder support.

For each record retain output-row multiplicity and four separate groupings:

1. Assets present in all outputs, including source-asset refund candidates.
2. Distinct BTC transaction identifiers.
3. Distinct BTC claim tuples `(txid, recipient, asset, integer amount)` and
   exact repeated tuples. These are record groupings, not identified vouts.
4. Potential ambiguity when a Bitcoin transaction has more than one claim
   to the same recipient. Resolve this only with acquired Bitcoin outputs.

Describe rows with zero BTC claims, one distinct BTC claim and non-BTC outputs,
one distinct BTC claim only, and more than one distinct BTC claim separately.
Report malformed identifiers/amounts without silently treating them as zero.
Also report repeated inbound identifiers and distinct claims across all valid
rows for the same `(source chain, inbound txid)`. Identical records or repeated
inbounds are not extra independent cases. Do not infer that an ETH output is
a refund solely from the asset pair or dataset filename.

## Selection before fresh protocol checks

Candidates have more than one distinct BTC claim for one inbound across the
saved rows, whether in the same or different Bitcoin transactions, or contain
two or more BTC rows within one source record even when their tuples are
identical. The latter preserves the possibility of separate equal-valued
outputs; it must not be silently classified as harmless repetition. Exclude
inbound identifiers and participant addresses documented in the original
development/40/96 exclusion and label files, plus the 11 external refund cases.
Keep the prior exclusion policy's public-infrastructure exceptions; record
the exact exclusion files, hashes and matching reasons. Exclusion does not
establish the absence of every economic relationship or undocumented prior use.

Create two descriptive source strata: native ETH input and other input.
Within each, sort by SHA-256 of
`VCA-MULTI5-20260908|<uppercase-source-chain>|<lowercase-inbound-txid-without-0x>`.
Select the first five in each stratum, at most ten; do not replace a later
unavailable, ambiguous, inconsistent or unsupported case. If there are no
candidates, stop before transaction-API collection and report the frame-limited
zero with positive predicate controls. Do not fetch until a desired example
is found.

## Checks on selected candidates

Preserve selection before fresh requests. For each selected inbound, request
bound Midgard actions with at most four pages of 50; query THORNode transaction
details for the inbound and every BTC outbound identified by the frame or new
actions. Fetch Bitcoin transaction JSON for the union of the two sources'
claimed BTC transaction IDs. Retain disagreement between sources. Enforce
inbound binding and distinguish requested pages from unavailable pages; no
partial response is a complete action history.

For all observed BTC claims, enumerate actual transaction outputs to the
claimed recipients without using the claimed amount to choose an output.
Apply the frozen `experiments/revision_v1/output_audit.py` unchanged, separately
report its conservative unresolved conditions and compare the unchanged
four-field calculation. A missing transaction is unknown, not zero. The
reference calculation must retain individual output indices. Record hashes
of the source module and inputs before and after evaluation.

Check protocol dispatch and historical payer where the existing evidence
requirements can be met. Do not turn a lack of historical protocol evidence
into a validated payout. Every Bitcoin input and non-witness transaction ID
can be checked from acquired JSON; block inclusion or independent chain
consensus is not implied. For non-ETH inputs no decoder or inbound-value
reconciliation is claimed. No statement of endpoint-to-endpoint precision,
population coverage, or cross-tool superiority follows from this probe.

Use a separately implemented census/recount and controls that exercise:
repeated same payment; two different BTC transaction claims; different outputs
within one transaction; BTC plus another asset; malformed and missing data.
Normal unmodified evidence must pass the same path that rejects corrupted
records. Only then decide whether a measured result belongs in the manuscript.

## Request budget and preservation

All requests are unauthenticated HTTPS GETs, with verified TLS, at most two
attempts per logical request, 25-second timeout, one in flight, and at least
0.5 seconds between starts. Dataset/source files have a 10 MB limit each;
transaction/API responses also have a 10 MB limit. Maximum 120 logical requests
including frame/source retrieval and transaction checks. Preserve each attempt
and its status; stop rather than exceeding the limit or bypassing TLS.

Allowed hosts: api.github.com, raw.githubusercontent.com,
media.githubusercontent.com, gitlab.com, dev.thorchain.org,
gateway.liquify.com, blockstream.info and mempool.space. No accounts, API keys,
asset transfers or contact with other persons. This collection is within the
user's prior authorization for additional public research data. All writes
remain under Codex. Existing decoder, predictions, returned results and v5/v6/v7
archives remain immutable. A new published supplement, if warranted, must
include its own review and actual extracted-package replay.

## Interpretation sources already read

- Preserved Thor25 README at the above commit: standard single-in/single-out
  data and the separate Thor25M directory are distinct curated frames.
- https://dev.thorchain.org/swap-guide/streaming-swaps.html describes delivery
  after internal swap completion and possible source-asset refund.
- Current Midgard OpenAPI permits multiple outbound transaction records, not
  individual Bitcoin output indices. Current documentation is not proof of
  every historical version's behavior. The separate source review is
  `_workspace/streaming_scope_20260908/qa_primary_sources.md`.
