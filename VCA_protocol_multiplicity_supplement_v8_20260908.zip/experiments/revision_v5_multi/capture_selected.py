"""Capture the locked multiple-BTC candidates without replacing failed cases."""
import hashlib
import http.client
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
DEST = ROOT / "captures/revision_v5_multi/selected"
MIDGARD = "https://gateway.liquify.com/chain/thorchain_midgard"
THOR = "https://gateway.liquify.com/chain/thorchain_api"


def now():
    return datetime.now(UTC).isoformat()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(path, value):
    with path.open("xb") as stream:
        stream.write((json.dumps(value, indent=2) + "\n").encode())


def identifier(value):
    if not isinstance(value, str):
        return None
    value = value.lower().removeprefix("0x")
    return value if re.fullmatch(r"[0-9a-f]{64}", value) else None


class NoRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Capture:
    def __init__(self, logical):
        self.logical = logical
        self.last_finished = 0.0
        self.opener = urllib.request.build_opener(NoRedirects())
        self.results = {}

    def get(self, key, urls):
        if key in self.results:
            return self.results[key]
        assert re.fullmatch(r"[a-z0-9_]+", key) and len(urls) == 2
        for url in urls:
            parsed = urllib.parse.urlsplit(url)
            if (parsed.scheme != "https" or parsed.hostname not in {
                    "gateway.liquify.com", "blockstream.info", "mempool.space"
                } or parsed.username or parsed.password or parsed.port not in (None, 443)):
                raise ValueError("request_outside_https_host_boundary")
        result = {"key": key, "urls": urls, "attempts": [], "status": "unavailable"}
        data = None
        if self.logical >= 120:
            result["reason"] = "budget_unattempted"
        else:
            self.logical += 1
            result["logical_request_number"] = self.logical
            for attempt, url in enumerate(urls, 1):
                prefix = f"{key}_attempt{attempt}"
                request_name = prefix + ".request.json"
                write(DEST / request_name, {"started_utc": now(), "method": "GET", "url": url,
                    "authorization_sent": False, "cookie_sent": False,
                    "tls_verification": True, "timeout_seconds": 25})
                observation = {"request_file": request_name,
                    "request_sha256": sha((DEST / request_name).read_bytes())}
                try:
                    request = urllib.request.Request(url, headers={"User-Agent": "VCA-multiplicity-probe/1.0"})
                    pause = 0.5 - (time.monotonic() - self.last_finished)
                    if pause > 0:
                        time.sleep(pause)
                    observation["call_started_utc"] = now()
                    with self.opener.open(request, timeout=25) as response:
                        raw = response.read(10_000_001)
                        observation.update({"http_status": response.status, "final_url": response.geturl()})
                    kept = raw[:10_000_000]
                    response_name = prefix + (".truncated.bin" if len(raw) > len(kept) else ".response.bin")
                    (DEST / response_name).write_bytes(kept)
                    observation.update({"response_file": response_name, "response_sha256": sha(kept),
                        "bytes": len(kept), "body_truncated": len(raw) > len(kept),
                        "status": "unavailable" if len(raw) > len(kept) else "available"})
                    if len(raw) > len(kept):
                        observation["reason"] = "response_limit"
                    else:
                        try:
                            data = json.loads(raw)
                            if not isinstance(data, dict):
                                data = None
                                observation.update({"status": "unavailable", "reason": "json_not_object"})
                        except (ValueError, UnicodeDecodeError):
                            observation.update({"status": "unavailable", "reason": "invalid_json"})
                except urllib.error.HTTPError as error:
                    observation.update({"status": "unavailable", "reason": "HTTPError", "http_status": error.code})
                    try:
                        raw = error.read(10_000_001)
                        kept = raw[:10_000_000]
                        response_name = prefix + ".error.bin"
                        (DEST / response_name).write_bytes(kept)
                        observation.update({"response_file": response_name, "response_sha256": sha(kept),
                            "bytes": len(kept), "body_truncated": len(raw) > len(kept)})
                    except (OSError, http.client.HTTPException) as body_error:
                        observation.update({"error_body_unavailable": True,
                            "body_error_type": type(body_error).__name__, "body_error_message": str(body_error)})
                    finally:
                        error.close()
                except (OSError, http.client.HTTPException) as error:
                    observation.update({"status": "unavailable", "reason": type(error).__name__, "message": str(error)})
                finally:
                    self.last_finished = time.monotonic()
                observation["ended_utc"] = now()
                write(DEST / (prefix + ".metadata.json"), observation)
                result["attempts"].append(observation)
                if data is not None:
                    result.update({"status": "available", "response_file": observation["response_file"],
                        "response_sha256": observation["response_sha256"]})
                    break
        write(DEST / (key + ".json"), result)
        self.results[key] = (data, result)
        return data, result


def bound_action(action, inbound):
    if not isinstance(action, dict) or not isinstance(action.get("in"), list) or not action["in"]:
        return False
    return all(isinstance(leg, dict) and identifier(leg.get("txID")) == inbound for leg in action["in"])


def run():
    assert not DEST.exists() and not (HERE / "selected_capture.json").exists()
    selection_path = HERE / "selection.json"
    selected = json.loads(selection_path.read_bytes())
    frame = json.loads((HERE / "frame_capture.json").read_bytes())
    lock = json.loads((HERE / "frame_lock.json").read_bytes())
    assert selected["protocol_sha256"] == lock["protocol_sha256"] == sha((HERE / "MULTI_OUTPUT_PROTOCOL.md").read_bytes())
    assert selected["census_sha256"] == sha((HERE / "census.json").read_bytes())
    assert 0 < selected["n"] == len(selected["selected"]) <= 10
    check_lock = {"locked_utc": now(), "selection_sha256": sha(selection_path.read_bytes()),
        "source_sha256": sha(Path(__file__).read_bytes()), "protocol_sha256": lock["protocol_sha256"],
        "frame_capture_sha256": sha((HERE / "frame_capture.json").read_bytes()),
        "output_audit_sha256": sha((ROOT / "experiments/revision_v1/output_audit.py").read_bytes()),
        "prior_logical_requests": frame["logical_requests"], "maximum_total_logical_requests": 120,
        "request_order": lock["request_order"], "bitcoin_attempt_order": ["blockstream.info", "mempool.space"],
        "selection_unchanged": True, "fresh_transaction_requests_before_this_lock": 0,
        "scope": "Fresh protocol/Bitcoin checks after a fixed frame-based selection; no decoder extension."}
    write(HERE / "selected_capture_lock.json", check_lock)
    DEST.mkdir(parents=True)
    client = Capture(frame["logical_requests"])
    rows = []
    for index, item in enumerate(selected["selected"], 1):
        inbound = identifier(item["inbound_txid"])
        assert inbound
        row = {"index": index, "inbound_txid": inbound, "source_chain": item["source_chain"],
            "started_utc": now(), "action_pages": [], "action_stop": "page_ceiling",
            "btc": {}, "thor": {}, "invalid_btc_identifiers": []}
        actions, token, seen = [], None, set()
        for page in range(4):
            params = {"txid": inbound, "limit": 50}
            if token:
                params["nextPageToken"] = token
            key = f"selected_{index:02}_actions_{page + 1}"
            url = MIDGARD + "/v2/actions?" + urllib.parse.urlencode(params)
            data, result = client.get(key, [url, url])
            row["action_pages"].append(key)
            if data is None or not isinstance(data.get("actions"), list):
                row["action_stop"] = result.get("reason", "unavailable_or_invalid_page")
                break
            actions.extend(data["actions"])
            metadata = data.get("meta", {})
            token = metadata.get("nextPageToken") if isinstance(metadata, dict) else None
            if token:
                if not isinstance(token, str) or token in seen:
                    row["action_stop"] = "invalid_or_repeated_token"
                    break
                seen.add(token)
            elif len(data["actions"]) < 50:
                row["action_stop"] = "short_final_page_without_token"
                break
            else:
                row["action_stop"] = "missing_pagination_token"
                break
        bound = [action for action in actions if bound_action(action, inbound)]
        row["bound_actions"] = len(bound)
        row["other_or_malformed_actions"] = len(actions) - len(bound)
        outputs = set(item["distinct_btc_transaction_ids"])
        for action in bound:
            legs = action.get("out")
            if not isinstance(legs, list):
                row["invalid_btc_identifiers"].append({"reason": "outputs_not_array"})
                continue
            for leg in legs:
                if not isinstance(leg, dict) or not isinstance(leg.get("coins"), list):
                    row["invalid_btc_identifiers"].append({"reason": "malformed_output"})
                    continue
                if any(isinstance(coin, dict) and coin.get("asset") == "BTC.BTC" for coin in leg["coins"]):
                    output = identifier(leg.get("txID"))
                    if output:
                        outputs.add(output)
                    else:
                        row["invalid_btc_identifiers"].append(leg)
        key = "thor_" + inbound
        url = THOR + "/thorchain/tx/details/" + inbound.upper()
        client.get(key, [url, url])
        row["thor"][inbound] = key
        row["union_btc_identifiers"] = sorted(outputs)
        for output in sorted(outputs):
            key = "btc_" + output
            client.get(key, ["https://blockstream.info/api/tx/" + output, "https://mempool.space/api/tx/" + output])
            row["btc"][output] = key
            key = "thor_" + output
            url = THOR + "/thorchain/tx/details/" + output.upper()
            client.get(key, [url, url])
            row["thor"][output] = key
        row["ended_utc"] = now()
        write(HERE / f"selected_{index:02}_capture.json", row)
        rows.append(row)
        print(json.dumps({"selected_case": index, "bound_actions": len(bound),
            "btc_identifiers": len(outputs), "action_stop": row["action_stop"]}), flush=True)
    assert sha(selection_path.read_bytes()) == check_lock["selection_sha256"]
    write(HERE / "selected_capture.json", {"completed_utc": now(),
        "selection_sha256": check_lock["selection_sha256"], "lock_sha256": sha((HERE / "selected_capture_lock.json").read_bytes()),
        "total_logical_requests": client.logical, "rows": rows,
        "requests": [result for _, result in client.results.values()],
        "scope": "Saved responses, not yet verified payouts."})
    print(json.dumps({"cases": len(rows), "total_logical_requests": client.logical,
        "available_requests": sum(result["status"] == "available" for _, result in client.results.values())}))


if __name__ == "__main__":
    run()
