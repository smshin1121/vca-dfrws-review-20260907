# VCA protocol-payment multiplicity supplement v8

This self-contained supplement preserves a fixed-frame accounting probe dated
8 September 2026. It includes the inputs needed to rerun the separate census,
the frozen payment evaluator, and a separately implemented raw-record recount.
No VCA application installation, account, API key, or network request is needed.

The nine pinned Thor25M files contain 166 records: 143 with one BTC claim and
other assets, 22 without a BTC claim, and one with two distinct BTC claims.
The one eligible selected case is a Litecoin input. Its two Bitcoin transactions
each have one output to the recipient, of 10,326 and 16,752 satoshi. The total
is 27,078 satoshi. The four-field calculation and output-index calculation
both retain that total; no four-field collision is observed in this case.

## Offline replay

Use Python 3.11 or newer with standard-library RIPEMD-160 support through
`hashlib`. The builders tested Python 3.12 on Windows. No dependency download
is performed. Keep the extracted package unchanged and use a new work directory
outside it. From the extracted package root:

```text
python -B reproducibility/protocol_multiplicity_20260908/verify_package.py
python -B reproducibility/protocol_multiplicity_20260908/replay_offline.py --work-dir ../v8-replay
```

The second command refuses an existing work directory. For another run, choose
a different new directory. Do not launch the archived capture scripts; they
are preserved as provenance and are not needed for replay.

The wrapper verifies the manifest and checksums, makes an exact scratch copy
of required files, and runs these original scripts in separate Python
subprocesses with socket/DNS audit guards:

1. `experiments/revision_v5_multi/verify_census.py` independently reclassifies
   all source rows, re-applies the fixed exclusion and selection rules, verifies
   Git/LFS evidence and the pinned README, and compares the archived census.
2. `experiments/revision_v5_multi/evaluate_selected.py` runs the frozen evaluator
   with the unchanged `output_audit.py` and the archived address codec.
3. `_workspace/streaming_scope_20260908/recount_selected_raw.py` recomputes
   transaction identifiers, recipient outputs and saved payer-script agreement
   without importing the evaluator or its output-audit code.

Preserved reports stay in their original package paths. The scratch copy omits
only prior output files that those scripts exclusively create. New results,
logs and execution receipts are kept under the work directory. The wrapper
compares all report content with the preserved reports, excluding only
top-level execution timestamps and normalizing path separators in JSON keys.
It checks the preserved package and copied input hashes again after execution.

Successful completion creates `REPLAY_RESULT.json` with:

- 9 frame files, 166 records, and 1 selected `other_input` case;
- 23 census controls, 7 frozen-evaluator controls, and 24 separate raw-recount
  controls, reported separately;
- 2 recipient payments, totaling 27,078 satoshi under both calculations;
- four report comparisons, unchanged source/input hashes, and zero network
  events during the three calculations.

The worker also tests its socket guard using a synthetic audit event before
each calculation. That self-test makes no socket operation. Python audit guards
are not an operating-system sandbox for arbitrary hostile code. The documented
commands execute the included reviewed scripts only.

## Preserved evidence and interpretation

The manifest enumerates all package files and their SHA-256 digests. Its own
digest appears in `SHA256SUMS`, together with the payload digests. The original
source-relative layout is retained, including the codec and the raw recount
script; `_workspace` here denotes archived dependencies, not a missing download.
The archive includes nine NDJSON files, Git LFS pointers, raw responses,
request/response metadata, selection and exclusion evidence, original results,
review notes, and the dataset README and transformation-source copies.

The third-party dataset repository is
`xhyumiracle/thorchain-crosschain-data`, commit
`6ae096a4138c7016642e8bc82d1ebb5cae294d5d`. Third-party author and repository
attribution is retained. The README at that same pinned tree advertises
**156** Thor25M records, while the nine verified files contain **166**. This
ten-record discrepancy is preserved; its cause is not established. The
curated frame is not all THORChain activity, and this is not a population-rate
or decoder-coverage experiment.

`capture_audit.json` records 18 frame requests and 7 later selected-case
requests, all with saved responses. The frozen frame collector gated record
preparation before variable file I/O. Its timestamps therefore do not prove
a minimum 0.5-second interval between actual HTTP calls; the recorded minimum
preparation gap is 0.490512 seconds and no actual-call timing measurement exists.
An offline counterexample later exposed that limitation. The original frame
bytes and collector are unchanged. Before the selected-case capture, a revised
collector passed the delayed-I/O control; its recorded minimum call-start gap
was 0.660142 seconds. This does not retroactively validate frame timing or
establish that an endpoint limit was violated.

This **LTC-input** case tests saved payment accounting. It does not establish
VCA support for decoding Litecoin inputs, an independently authenticated
Litecoin deposit, or complete end-to-end tracing. Midgard labels the action as
a streaming swap. The observed two transactions do not establish why this
historical action produced two payments or how frequently that occurs.

THORNode's saved inbound `out_txs` and outbound records identify both BTC
payments. The recorded historical payout key yields the same P2WPKH script as
all 1 and 10 `vin.prevout` scripts in the two Bitcoin responses. This is
corroboration between saved records. Recomputing a non-witness Bitcoin
transaction ID binds its input outpoints and outputs; it does **not**
authenticate explorer-supplied prevout annotations, witness signatures or
block-status fields. Previous-transaction authentication, cryptographic
signature checks, block inclusion and independent chain consensus are outside
this supplement's verified scope.

The original calculations and packaging replay belong to the same research
workflow. Running this archive does not by itself establish reproduction by
an independent author or team. A separate operator should record their role,
environment, commands, package digest, assistance received and actual scope
completed. File hashes establish byte identity, not the truth or collection
time of the underlying records.

The package verifier also rejects unsafe/duplicate paths. Build-time author
checks used private known-account patterns; those identifying patterns are
not distributed in this archive. If needed, pass an external local text file
to `verify_package.py --author-pattern-file PATH`, one pattern per line. The
default run reports zero configured author patterns and performs byte/path
checks. A clean configured scan is a limited check, not a claim that every
possible author identifier has been excluded.
