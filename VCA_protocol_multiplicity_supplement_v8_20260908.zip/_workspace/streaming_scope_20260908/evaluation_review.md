# Selected-candidate evaluation QA

Decision: **REVISE** before calling `evaluate_selected.run()`.

Reviewed source SHA-256:
`fbf16bf252af68f7520822b95fa7f2757341c9b1774c0f39a52d5b7f8cc6c70a`.
Protocol SHA-256:
`65ac10fe486eacade040c132bd9417e762dc53b91e461036546bbe518118cb0d`.
Frozen output audit SHA-256:
`b15fa052fcb4d39a5236c15d7f9cf7b53e2887b54f6f12c9564c511e6e756c93`.

This was source review and synthetic helper execution only. No evaluation
`run()`, capture `run()`, HTTP request, saved transaction response, or real
claim outcome was used. Neither reviewed source nor any frozen evidence was
edited. The reviewer is a separate AI process within the same project, not an
independent research team or a blind evaluation author.

## Blocking corrections

1. **Missing evidence must remain unknown.** In `payer_check`, a missing
   `prevout.scriptpubkey` or `prevout.scriptpubkey_address` becomes a false
   Boolean through `.get(...)`, and the overall result is `mismatch`. A missing
   `vault_pub_key` on the matching historical dispatch row does the same.
   Synthetic evidence that otherwise passes reproduced all three cases.
   Separately, a missing confirmation-status object is labelled
   `transaction_unconfirmed`, although no explicit unconfirmed observation
   exists. Check availability and field types before computing content
   comparisons; use an unavailable/unknown result when a necessary field is
   absent. Preserve `mismatch` for present contradictory evidence and explicit
   `confirmed: false` for an observed unconfirmed transaction. This does not
   require extra requests or changes to the frozen audit.

2. **Accepted fresh-action schemas must agree with claim extraction and
   request-key lookup.** An output coin with `asset: null`, an empty asset, or
   a non-string asset passes `valid_action`, becomes no BTC claim in the frozen
   extractor, and gives a four-field sum of zero. It should be retained as
   malformed/unknown asset evidence. Validate the asset discriminator before
   deciding that an output is non-BTC. Empty observed lists can be described as
   such without claiming a completed payment history; an unavailable or
   partial fresh response must not be presented as a complete zero total.
   Also, `valid_action` accepts a `0x`-prefixed BTC txID because `identifier`
   strips the prefix; capture keys are prefix-free, while the frozen extractor
   preserves the prefix. A subsequently accepted claim then misses the
   `captured['thor'][claim['txid']]` lookup and can abort the run. The separate
   synthetic prefix example reproduces this interface disagreement. Normalize
   a copy before the frozen extractor or reject the unsupported form
   explicitly and retain it in the unresolved denominator. Do not edit the
   frozen audit.

3. **Recheck captured input bytes at the end.** The protocol expressly calls
   for source and input hashes before and after evaluation. `hashes` verifies
   captured request/response bytes initially, but the final assertion only
   covers `tracked`, which excludes those bytes. Rehash the recorded capture
   paths at exit and require equality, then record that this comparison was
   performed. This is a preservation check, not a reason to collect new data.

## Confirmed behavior

- Curated-frame claims and fresh Midgard actions are calculated separately;
  selected rows are not removed for failed requests. Claim agreement is
  separately reported from collection completeness. The collector marks
  unavailable, invalid, token-limited and page-limited retrievals, so the
  evaluator must retain that distinction when naming totals.
- `recipient_reference` reads transaction ID and recipient only. A mapping that
  raises if the claimed amount is accessed still passes. Two equal-value
  outputs to the same recipient retain distinct vout indices and sum to 1,200
  synthetic satoshis; repeating the claim does not duplicate those outputs.
  The unchanged audit separately returns ambiguous assignment on that same
  fixture. Neither result allocates individual protocol claims to those vouts.
- An independently serialized synthetic transaction agrees with the computed
  non-witness txID. Witness-only changes preserve that ID; changing an output
  value produces an identity mismatch. This checks content serialization, not
  block inclusion, signatures, input ancestry, or independent consensus.
- A normal synthetic payer passes the same path on which a different present
  input script fails. The code derives a P2WPKH input script from a decoded
  historical `thorpub`, checks the planned key and dispatch records, and parses
  the actual transaction's OP_RETURN. These remain protocol-source
  corroboration plus explorer-provided previous-output fields. The previous
  transaction bodies are not independently fetched or cryptographically
  reconstructed by this procedure.
- Unsupported key encodings and absent whole responses remain unresolved.
  The one-recipient-output check is conservative: output enumeration can
  succeed while a specific claim-to-output assignment cannot. It must not be
  described as general multiple-output support or general payer authentication.
- The code imports a frozen address-codec file under `_workspace/`. Its hash
  is recorded, but an eventual extracted supplement must include that exact
  dependency and preserve or deliberately remap its path. This is a packaging
  requirement, not a request to modify the frozen helper.

## Execution evidence

`check_evaluation_r1.py` ran once with `python -B`. Its
`evaluation_synthetic_r1.json` records 26 successful QA assertions, of which
seven deliberately reproduce the blocking missing-field/asset behavior.
These are **not 26 successful payment evaluations**. The network guard
recorded zero attempts, and all four loaded source/protocol files retained
their before hashes. `evaluation_prefix_r1.json` adds the accepted-prefix
lookup disagreement. No corpus tests or actual evaluation was run.

Fix the three interface/preservation issues above, then review only the
changed paths. No sampling-frame, decoder, protocol, request-budget, or
historical-guarantee expansion is required by this review.
