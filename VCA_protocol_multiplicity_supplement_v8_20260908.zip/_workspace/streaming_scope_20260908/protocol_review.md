# Pre-collection review: multiple-output probe

Decision: **READY — no blocking methodological ambiguity identified for the stated bounded, descriptive probe.** This approves the design for collection, not the unreviewed collector, selection implementation, future measurements, or publication.

Reviewed 2026-09-08 before this reviewer inspected or requested any Thor25M transaction payload. No tests or transaction requests were run; the protocol and frozen evidence were not edited.

## Exact reviewed state

- Protocol: `experiments/revision_v5_multi/MULTI_OUTPUT_PROTOCOL.md`, SHA-256 `65ac10fe486eacade040c132bd9417e762dc53b91e461036546bbe518118cb0d`.
- Pinned tree: `_workspace/streaming_scope_20260908/pinned_tree.json`, SHA-256 `418a2cd34812b0e4a1f859779abd82c17ef40aba08f2e58a473fca55f8ec657b`; root tree `822d8ba67c89f1e7069c62b727c9238c8f58ef43`; `truncated=false`.
- Preserved README: `_workspace/thor25_metadata/README.md.txt`, SHA-256 `ed056b42640a321561e8219f5fad53f95ba59409d6cf492eb987542699333b30`.
- Frozen supplemental audit: `experiments/revision_v1/output_audit.py`, SHA-256 `b15fa052fcb4d39a5236c15d7f9cf7b53e2887b54f6f12c9564c511e6e756c93`.
- Primary-source interpretation: `qa_primary_sources.md` in this directory. The current documentation does not establish historical protocol invariants.

## Verified design points

The actual pinned tree contains exactly nine blob paths below `data/thorchain-2025-multi/`: BTC→BTC|DOGE, BTC→BTC|ETH, BTC→BTC|LTC, BTC→ETH, ETH→BTC|ETH, ETH→ETH|LTC, LTC→BTC, LTC→DOGE|LTC, and LTC→ETH. All use the `-multi-out.ndjson` suffix. The tree fixes pointer blobs, not yet verified transaction payloads; their advertised sizes are 128–130 bytes. The procedure appropriately requires blob identity, then LFS payload digest and size checks. The README's 156-record description is an expectation to recount, not a result.

The candidate predicate retains both distinct BTC tuples and two-or-more BTC occurrences within a single record, including identical tuples. Consequently it does not exclude the specific equal-recipient/equal-amount vout boundary by deduplicating it before selection. It also groups repeated inbounds, which avoids treating cross-record occurrences as independent cases.

Selection has an explicit hash ordering, separate native-ETH/other strata, a five-case cap per stratum, prior-sample exclusions, no outcome-dependent replacement, and a zero-candidate stopping rule. Missing/malformed files and selected failures remain visible. Reading a curated multi-output frame before choosing multiplicity candidates is part of this locally prospective probe; it is not a decoder holdout evaluation.

Asset mixtures, repeated references and actual Bitcoin output identities are separated. Fresh actions are bound to the inbound, and source disagreement is retained. The protocol's separate payment-reference and historical-payer checks avoid declaring every available Bitcoin output a proven THORChain payment.

## Remaining limits to preserve during implementation and reporting

1. The README describes native-asset, `type=swap`, `status=success` curation and removal of THOR.* affiliate outputs. Frame counts therefore do not estimate network-wide multiplicity or failed-swap coverage. An ETH+BTC mixture alone does not authenticate a refund. Native-ETH stratum membership should check the input asset as well as its chain.
2. The unchanged `audit_outputs` function uses claimed amount when matching a recipient's candidate outputs. Only the separately specified enumeration is amount-independent. Preserve this distinction in reports; do not describe the whole frozen audit as amount-blind. Multiple matching outputs must remain unresolved unless an index is actually bound by the evidence. A sum over all matching recipient outputs can be reported as a transaction-level observation, but cannot automatically be attributed to this inbound.
3. The 120-request cap can censor later checks when a selected record exposes many outbound identifiers. Fix the request traversal order in the collector before payload inspection and retain unattempted checks as budget-unavailable. Do not preferentially finish apparently successful candidates. Freeze the concrete exclusion-file list and hashes before applying the selector; the semantic policy is already fixed in the protocol.
4. Fresh protocol responses may differ from archived claims. Preserve both. JSON transaction-identity and input-field checks do not independently establish block inclusion, historical dispatch correctness, or chain consensus. Non-ETH examples remain accounting probes. A frame-limited zero does not show multiple BTC payouts are impossible.

These are existing scope limits and implementation obligations, not reasons to expand the experiment or change its fixed frame. Before relying on results, separately review the collector/selector and verify the required positive, negative, missing-data and ambiguity controls.
