# 선정 표본 원시 응답 별도 대조 — 2026-09-08

판정: **저장 기록 대조 PASS.** 선정된 Litecoin 입금 1건에 연결된 서로 다른
Bitcoin 거래 2건에서 수신자 출력 2개, 합계 **27,078 satoshi
(0.00027078 BTC)**를 확인했다. 두 거래의 비증인 직렬화에서 계산한 거래 ID가
기록된 ID와 같고, THORNode가 기록한 지급 금고의 키에서 계산한 스크립트가
Bitcoin 응답에 포함된 모든 입력의 이전 출력 스크립트와 일치한다.

이 판정은 같은 프로젝트 안에서 새 평가기와 별도로 계산한 결과다. 작성자 독립,
Bitcoin/Litecoin 합의 검증, 이전 거래 및 서명 인증을 뜻하지 않는다.
`evaluate_selected.py`는 읽거나 import하거나 실행하지 않았다.

## 1. 읽은 자료와 선정 결속

- `experiments/revision_v5_multi/selection.json`의 SHA-256은
  `7f367f51c241cd3ca06e18264fc8fd4a9162cb83ebe7a1c646a9b26c0e360445`이며,
  수집 잠금과 완료 요약의 선정 해시와 같다.
- 선정된 입금은 LTC 거래
  `66d4ec13ef7713f9cdeea5c03579e7bd2c24d7ce80bf6cd3d45621e861b17f48`이다.
  선정 과정이나 166행 census를 이 작업에서 다시 실행하지 않았다.
- 완료 수집 요약에 결속된 원시 JSON 7개를 직접 읽고 각각의 SHA-256을
  검증했다. Midgard 2페이지, THORNode 입금 1개·출금 2개, Bitcoin 거래 2개다.
  첫 Midgard 페이지에는 action 1개와 다음 토큰이 있고, 그 토큰으로 요청한
  둘째 페이지에는 action 0개와 빈 다음 토큰이 있다.
- 입금 action의 `txID`, `LTC.LTC`, 송신 주소 및 금액 53,000,000 단위
  (0.53 LTC)는 THORNode 입금 `tx.tx`와 일치한다. THORNode 입금의 바깥
  `tx_id`와 내부 `tx.tx.id`도 선정 ID와 같다. 별도의 Litecoin 원장 자료로
  입금 자체를 인증한 것은 아니다.
- 수집기의 신규 논리 요청은 7개이며 이전 frame 요청 18개를 포함하면
  25개다. 이 별도 대조 작업은 신규 요청을 보내지 않았다.

원시 파일은 모두 `captures/revision_v5_multi/selected/` 아래에 있다.
구체적인 파일명과 해시는 `selected_raw_recount.json`의
`input_hashes_before_and_after_identical`에 기록했다.

## 2. 두 지급의 실제 출력

공통 수신 주소는 `bc1qpeuftnmh9krh50ny9v7xrnydxn39x5puu5ymtf`다.
이 주소를 Bech32로 해독해 얻은 스크립트
`00140e7895cf772d877a3e642b3c61cc8d34e253503c`와 일치하는 출력을 전수 선택했다.
선택 과정에서는 Midgard가 주장한 지급액을 사용하지 않고, 선택 후 금액을
대조했다.

| Bitcoin 거래 ID | 수신 출력 index | 실제 출력액 | 비증인 직렬화 길이 | ID 재계산 |
|---|---:|---:|---:|---|
| `4a9ef67c8f5da085454755ee1fb813488d4c6eaaa783c935f6c6e5a1ca2387d9` | 0 | 10,326 sat | 192 bytes | 일치 |
| `e2027c08485533fff4c10d8cb3c92bc358876dc4ee27aa858891d56e7327e811` | 0 | 16,752 sat | 561 bytes | 일치 |

각 거래에는 수신 출력 외에 지급자 주소로 가는 출력(index 1)과
`OUT:<선정된 LTC 입금 ID>`를 담은 OP_RETURN(index 2)이 있다. OP_RETURN은
익스플로러의 해석 문자열이 아닌 원시 `scriptpubkey`의 바이트를 읽었다.

거래 ID는 version, 입력 outpoint·scriptSig·sequence, 모든 출력의 금액·스크립트,
locktime을 비증인 형식으로 직렬화한 뒤 double-SHA256을 적용해 계산했다.
두 계산 결과는 각각 요청한 ID 및 JSON의 `txid`와 일치한다. 직렬화한 바이트의
전체 hex도 결과 JSON에 보존했다.

Midgard action에는 위 두 BTC 지급과 별도의 `THOR.RUNE` 행이 있으며,
그 행에는 `affiliate: true`가 명시돼 있다. 따라서 이 사례의 두 BTC 주장은
동일 지급의 반복 행이나 BTC 지급 하나와 LTC 환불을 센 결과가 아니다.
다만 저장된 목록에 없는 다른 원장 활동의 부재까지 확인한 것은 아니다.

네 필드 `(txid, recipient, asset, amount)`로 별도 계산한 합계와 출력 index를
보존한 합계는 모두 **27,078 sat**이다. 이 사례에서는 두 거래 ID가 달라
네 필드 방식도 두 지급을 유지한다. 같은 거래의 같은 수신자에게 같은 금액의
출력 두 개가 존재하는 경계 조건을 실제로 관찰한 사례는 아니다.
이 계산은 해당 규칙을 별도로 재계산한 것이며, 보존된 `output_audit.py`를
실행했다는 뜻이 아니다.

## 3. THORNode 출금 연결과 지급자 대조

입금 THORNode 응답의 실제 `out_txs`에는 두 BTC ID가 모두 있으며,
각 항목은 그 ID로 조회한 outbound THORNode의 `tx.tx`와 일치한다.
ID·체인·송수신 주소·BTC 지급액·OUT 메모를 함께 비교했다.

입금 응답의 `actions`에는 해당 수신자·금액·입금 참조에 맞는 출금 지시가
각각 하나씩 있다. 이 지시의 `vault_pub_key`가 각 outbound 응답의
`tx.observed_pub_key` 및 추가 관측 항목의 키와 같다. 지시의 키만으로 지급을
확정하지 않고, 별도로 기록된 실제 출금 ID와 Bitcoin 출력까지 대조했다.

- 저장된 BTC 금고 키:
  `thorpub1addwnpepqgey08clv9gu47fsdllv93w9dxjeeeghj0nfspuj230uqkzwvxtx292sun0`
- Bech32 체크섬·형식 확인 후 얻은 압축 공개키:
  `0232479f1f6151caf9306ffec2c5c569a59ce51793e6980792545fc0584e619665`
- 공개키의 SHA-256 및 RIPEMD-160에서 계산한 P2WPKH 스크립트:
  `0014e0dc9c226094639e916f238bba31c0ee140d9a14`
- THORNode의 지급 주소:
  `bc1qurwfcgnqj33eayt0yw9m5vwqac2qmxs55up6nq`

위 스크립트는 첫 BTC 거래의 입력 **1/1**, 둘째 거래의 입력 **10/10**의
`vin.prevout.scriptpubkey`와 모두 같다. 각 입력의 witness에 실린 공개키
문자열도 이 압축 공개키와 일치한다. 서명 자체를 검증하지는 않았다.

관측 정보에서 첫 출금의 THORNode finalised height는 21,075,166,
둘째는 21,075,898이다. Bitcoin 응답은 각각 block 896,441 및 896,455에
확정됐다고 보고한다. 이 높이는 저장 응답의 필드이며 블록 헤더·Merkle 증명이나
별도 노드 합의로 인증한 높이가 아니다.

**중요한 결속 범위:** 비증인 거래 ID는 각 입력이 참조하는 이전 거래 ID와 출력
index를 포함하지만, 익스플로러가 덧붙인 `prevout`의 스크립트·금액을 직접
포함하지 않는다. witness와 블록 상태 필드도 비증인 ID에 포함되지 않는다.
따라서 이 작업은 저장 응답 사이에서 지급자 근거가 일치함을 보였다. 이전 거래
본문이나 서명·블록 합의까지 인증했다고 쓰면 안 된다.

## 4. 실행한 정상·오류 대조

명령:

```text
python -X utf8 -B _workspace/streaming_scope_20260908/recount_selected_raw.py
```

결과: **24/24 조건 PASS, 종료 코드 0.** 두 실제 거래 각각에 다음 12개 조건을
적용했다. 이 횟수는 독립 거래 표본 24건이나 일반 오류 탐지율이 아니다.

1. 변경하지 않은 지급 자료의 일치.
2. 변경하지 않은 모든 입력의 지급자 스크립트 일치.
3. 거래 자료가 없으면 `unavailable`, 금액 0으로 처리하지 않음.
4. 지급 주장 금액에 1 sat를 더하면 금액 불일치.
5. 실제 출력 금액에 1 sat를 더하면 재계산 거래 ID 불일치.
6. 같은 출력 변형이 지급 주장과도 불일치.
7. 수신 출력을 제거하면 수신 출력 미확보.
8. **마지막 입력**의 prevout 스크립트를 바꾸면 지급자 불일치.
9. 그 prevout 주석 변형만으로는 비증인 거래 ID가 바뀌지 않음.
10. 마지막 입력의 prevout을 제거하면 지급자 대조 `unavailable`.
11. 다른 유효한 금고 키를 쓰면 지급자 스크립트 불일치.
12. OP_RETURN의 입금 ID를 바꾸면 입금 메모 불일치.

정상과 변형은 같은 별도 대조 함수로 처리했다. 원시 파일은 바꾸지 않고
메모리 복사본만 변형했다. 읽은 10개 파일(선정·수집 요약·수집 잠금 및 원시
응답 7개)의 해시는 실행 전후 모두 같았다. 소켓 연결 및 DNS 감사 이벤트는
0건이었다.

- 별도 대조 스크립트 SHA-256:
  `ec95c5dcbe71e3295a3923567fb2e657ffb21f19ce9ce512f94798bc53275640`
- 결과 JSON SHA-256:
  `4a601f54bfea512dbbc2b59b4509c8f14bd69d207c35b43cd3d4da5c9dc2798b`

## 5. 원고에 사용할 수 있는 범위

허용 가능한 서술:

> 별도로 선정한 LTC 입금 1건에서 Midgard가 주장한 두 BTC 지급은 각각
> 다른 Bitcoin 거래의 수신 출력과 일치했다. 출력 index를 보존한 합계와
> 네 필드 합산은 모두 27,078 sat였다. THORNode가 기록한 출금 연결과 당시
> 지급 키도 저장 Bitcoin 응답의 모든 입력 스크립트와 일치했다.

다음 내용은 이 자료로 확정하지 않는다.

- VCA가 Litecoin 입력을 해석하거나 전체 거래 추적을 완료했다는 주장.
- 스트리밍 스왑은 항상 여러 BTC 지급을 만든다는 일반화. 이 action의
  `isStreamingSwap: true`는 확인했지만 왜 두 거래가 발생했는지는 분석하지 않았다.
- 같은 거래·수신자·금액의 별개 출력 때문에 네 필드 방식이 실제로 누락했다는 주장.
- 다른 작성자·연구팀의 재현 또는 외부 합의에 의한 인증.
- Litecoin 입금 및 Bitcoin의 이전 출력·witness 서명·블록 포함의 독립 인증.

기존 선정·census·수집 원본·평가 코드·원고·배포 자료는 수정하지 않았고,
새 외부 HTTP 요청이나 커밋도 수행하지 않았다.
