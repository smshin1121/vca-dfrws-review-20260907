"""Recount selected raw records without importing either collection/evaluation code."""

import hashlib
import json
import sys
from copy import deepcopy
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
RAW = ROOT / "captures/revision_v5_multi/selected"
EXPERIMENT = ROOT / "experiments/revision_v5_multi"
SOCKET_EVENTS = []
HASHES = {}


def no_network(event, args):
    if event in {"socket.connect", "socket.connect_ex", "socket.getaddrinfo"}:
        SOCKET_EVENTS.append(event)
        raise RuntimeError("Raw QA permits no network")


sys.addaudithook(no_network)


def load(path):
    raw = path.read_bytes()
    HASHES[str(path.relative_to(ROOT))] = hashlib.sha256(raw).hexdigest()
    return json.loads(raw)


def compact(value):
    assert type(value) is int and value >= 0
    if value < 253:
        return bytes([value])
    if value <= 65535:
        return b"\xfd" + value.to_bytes(2, "little")
    if value <= 4294967295:
        return b"\xfe" + value.to_bytes(4, "little")
    return b"\xff" + value.to_bytes(8, "little")


def uint(value, size):
    assert type(value) is int and 0 <= value < (1 << (8 * size))
    return value.to_bytes(size, "little")


def nonwitness(tx):
    parts = [uint(tx["version"], 4), compact(len(tx["vin"]))]
    for leg in tx["vin"]:
        previous = bytes.fromhex(leg["txid"])
        assert len(previous) == 32 and not leg["is_coinbase"]
        script = bytes.fromhex(leg["scriptsig"])
        parts.extend([previous[::-1], uint(leg["vout"], 4), compact(len(script)), script, uint(leg["sequence"], 4)])
    parts.append(compact(len(tx["vout"])))
    for output in tx["vout"]:
        script = bytes.fromhex(output["scriptpubkey"])
        parts.extend([uint(output["value"], 8), compact(len(script)), script])
    parts.append(uint(tx["locktime"], 4))
    return b"".join(parts)


def txid_from_json(tx):
    encoded = nonwitness(tx)
    return hashlib.sha256(hashlib.sha256(encoded).digest()).digest()[::-1].hex()


CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"


def bech32_words(text):
    assert text == text.lower() or text == text.upper()
    hrp, data = text.lower().rsplit("1", 1)
    words = [CHARSET.index(char) for char in data]
    assert len(words) >= 6
    expanded = [ord(char) >> 5 for char in hrp] + [0] + [ord(char) & 31 for char in hrp]
    checksum = 1
    generators = [0x3B6A57B2, 0x26508E6D, 0x1EA119FA, 0x3D4233DD, 0x2A1462B3]
    for value in expanded + words:
        top = checksum >> 25
        checksum = ((checksum & 0x1FFFFFF) << 5) ^ value
        for bit, generator in enumerate(generators):
            if (top >> bit) & 1:
                checksum ^= generator
    assert checksum == 1, "Bech32 checksum mismatch"
    return hrp, words[:-6]


def five_to_eight(words):
    acc = 0
    bits = 0
    out = []
    for word in words:
        assert 0 <= word < 32
        acc = (acc << 5) | word
        bits += 5
        while bits >= 8:
            bits -= 8
            out.append((acc >> bits) & 255)
    assert bits < 5 and ((acc << (8 - bits)) & 255) == 0
    return bytes(out)


def address_script(address, hrp="bc"):
    actual_hrp, words = bech32_words(address)
    assert actual_hrp == hrp and words[0] == 0
    program = five_to_eight(words[1:])
    assert len(program) == 20
    return b"\x00\x14" + program


def vault_script(encoded):
    hrp, words = bech32_words(encoded)
    assert hrp == "thorpub"
    decoded = five_to_eight(words)
    assert len(decoded) == 38 and decoded[:5].hex() == "eb5ae98721"
    pubkey = decoded[5:]
    assert pubkey[0] in {2, 3}
    key_hash = hashlib.new("ripemd160", hashlib.sha256(pubkey).digest()).digest()
    return b"\x00\x14" + key_hash, pubkey


def output_check(claim, tx):
    if tx is None:
        return {"status": "unavailable", "indices": [], "satoshis": None}
    target_script = address_script(claim["recipient"]).hex()
    matches = [(index, output["value"]) for index, output in enumerate(tx["vout"]) if output["scriptpubkey"] == target_script]
    if not matches:
        return {"status": "recipient_output_missing", "indices": [], "satoshis": None}
    total = sum(amount for _, amount in matches)
    return {"status": "consistent" if total == claim["amount"] else "amount_mismatch", "indices": [index for index, _ in matches], "satoshis": total}


def payer_check(tx, key):
    expected, pubkey = vault_script(key)
    if not tx["vin"] or any(not isinstance(leg.get("prevout"), dict) or not isinstance(leg["prevout"].get("scriptpubkey"), str) for leg in tx["vin"]):
        return {"status": "unavailable", "matched": None, "inputs": len(tx["vin"])}
    matches = [leg["prevout"]["scriptpubkey"] == expected.hex() for leg in tx["vin"]]
    return {"status": "consistent" if all(matches) else "payer_script_mismatch", "matched": sum(matches), "inputs": len(matches), "expected_script": expected.hex(), "compressed_public_key": pubkey.hex(), "witness_keys_agree": all(leg.get("witness", [None])[-1] == pubkey.hex() for leg in tx["vin"])}


def memo_payloads(tx):
    payloads = []
    for output in tx["vout"]:
        script = bytes.fromhex(output["scriptpubkey"])
        if len(script) >= 2 and script[0] == 0x6A and 1 <= script[1] <= 75 and len(script) == script[1] + 2:
            payloads.append(script[2:].decode("ascii"))
    return payloads


selection = load(EXPERIMENT / "selection.json")
capture = load(EXPERIMENT / "selected_capture.json")
lock = load(EXPERIMENT / "selected_capture_lock.json")
assert len(selection["selected"]) == selection["n"] == 1
assert capture["selection_sha256"] == HASHES[str((EXPERIMENT / "selection.json").relative_to(ROOT))]
assert capture["lock_sha256"] == HASHES[str((EXPERIMENT / "selected_capture_lock.json").relative_to(ROOT))]
selected = selection["selected"][0]
inbound = selected["inbound_txid"]
assert selected["source_chain"] == "LTC"
responses = {}
for request in capture["requests"]:
    assert request["status"] == "available" and len(request["attempts"]) == 1
    path = RAW / request["response_file"]
    responses[request["key"]] = load(path)
    assert HASHES[str(path.relative_to(ROOT))] == request["response_sha256"]
assert len(responses) == 7 and capture["total_logical_requests"] == lock["prior_logical_requests"] + 7 == 25

first_page = responses["selected_01_actions_1"]
last_page = responses["selected_01_actions_2"]
assert len(first_page["actions"]) == 1 and last_page["actions"] == []
assert last_page["meta"]["nextPageToken"] == ""
action = first_page["actions"][0]
assert action["type"] == "swap" and action["status"] == "success"
assert len(action["in"]) == 1
assert action["in"][0]["txID"].lower() == inbound
assert action["in"][0]["coins"] == [{"amount": "53000000", "asset": "LTC.LTC"}]
claims = []
other_outputs = []
for leg in action["out"]:
    for coin in leg["coins"]:
        if coin["asset"] == "BTC.BTC":
            claims.append({"txid": leg["txID"].lower(), "recipient": leg["address"], "amount": int(coin["amount"])})
        else:
            other_outputs.append(deepcopy(leg))
assert sorted(claims, key=lambda claim: claim["txid"]) == sorted([{key: value for key, value in claim.items() if key != "row_index"} for claim in selected["claims"]], key=lambda claim: claim["txid"])

inbound_details = responses["thor_" + inbound]
core = inbound_details["tx"]["tx"]
assert inbound_details["tx_id"].lower() == core["id"].lower() == inbound
assert core["chain"] == "LTC" and core["coins"] == action["in"][0]["coins"]
assert core["from_address"] == action["in"][0]["address"]
assert core["memo"] == action["metadata"]["swap"]["memo"]
inbound_script, inbound_pubkey = vault_script(inbound_details["tx"]["observed_pub_key"])
assert inbound_script == address_script(core["to_address"], "ltc")

rows = []
controls = []
memo = "OUT:" + inbound.upper()
for claim in sorted(claims, key=lambda value: value["txid"]):
    txid = claim["txid"]
    bitcoin = responses["btc_" + txid]
    outgoing = responses["thor_" + txid]
    dispatches = [item for item in inbound_details["out_txs"] if item["chain"] == "BTC" and item["id"].lower() == txid]
    assert len(dispatches) == 1
    dispatch = dispatches[0]
    out_core = outgoing["tx"]["tx"]
    assert outgoing["tx_id"].lower() == out_core["id"].lower() == bitcoin["txid"] == txid
    assert outgoing["tx"]["status"] == "done" and out_core["chain"] == "BTC"
    assert dispatch == out_core
    assert dispatch["memo"] == memo and dispatch["to_address"] == claim["recipient"]
    assert dispatch["coins"] == [{"asset": "BTC.BTC", "amount": str(claim["amount"])}]
    planned = [item for item in inbound_details["actions"] if item["chain"] == "BTC" and item["to_address"] == claim["recipient"] and item["coin"] == dispatch["coins"][0]]
    assert len(planned) == 1 and planned[0]["in_hash"].lower() == inbound and planned[0]["memo"] == memo
    vault_key = planned[0]["vault_pub_key"]
    assert vault_key == outgoing["tx"]["observed_pub_key"]
    assert all(item["observed_pub_key"] == vault_key and item["tx"]["id"].lower() == txid for item in outgoing["txs"])
    calculated_txid = txid_from_json(bitcoin)
    assert calculated_txid == txid
    checked_output = output_check(claim, bitcoin)
    checked_payer = payer_check(bitcoin, vault_key)
    assert checked_output["status"] == checked_payer["status"] == "consistent"
    assert address_script(dispatch["from_address"]).hex() == checked_payer["expected_script"]
    assert memo_payloads(bitcoin) == [memo]
    observed_fee = sum(item["prevout"]["value"] for item in bitcoin["vin"]) - sum(item["value"] for item in bitcoin["vout"])
    assert observed_fee == bitcoin["fee"] == int(dispatch["gas"][0]["amount"])
    rows.append({"txid": txid, "calculated_nonwitness_txid": calculated_txid, "nonwitness_bytes": len(nonwitness(bitcoin)), "nonwitness_hex": nonwitness(bitcoin).hex(), "recipient": claim["recipient"], "claim_satoshis": claim["amount"], "output_check": checked_output, "payer_check": checked_payer, "op_return_payloads": memo_payloads(bitcoin), "historical_vault_key": vault_key, "thor_finalised_height": outgoing["finalised_height"], "btc_status_as_reported": bitcoin["status"], "btc_fee_as_reported_and_recomputed": observed_fee, "scope": "Consistency of saved API records; prevout annotations, witnesses and block status are not authenticated by non-witness txid recomputation."})

    control_cases = []
    control_cases.append(("unchanged_output", output_check(deepcopy(claim), deepcopy(bitcoin))["status"], "consistent"))
    control_cases.append(("unchanged_payer", payer_check(deepcopy(bitcoin), vault_key)["status"], "consistent"))
    control_cases.append(("missing_transaction", output_check(claim, None)["status"], "unavailable"))
    changed_claim = deepcopy(claim)
    changed_claim["amount"] += 1
    control_cases.append(("claim_amount_plus_one", output_check(changed_claim, bitcoin)["status"], "amount_mismatch"))
    changed_tx = deepcopy(bitcoin)
    changed_tx["vout"][0]["value"] += 1
    control_cases.append(("output_amount_changes_txid", txid_from_json(changed_tx) != txid, True))
    control_cases.append(("output_amount_mismatch", output_check(claim, changed_tx)["status"], "amount_mismatch"))
    missing_output = deepcopy(bitcoin)
    missing_output["vout"].pop(0)
    control_cases.append(("recipient_output_missing", output_check(claim, missing_output)["status"], "recipient_output_missing"))
    changed_payer = deepcopy(bitcoin)
    changed_payer["vin"][-1]["prevout"]["scriptpubkey"] = "0014" + "00" * 20
    control_cases.append(("last_input_payer_script_mismatch", payer_check(changed_payer, vault_key)["status"], "payer_script_mismatch"))
    control_cases.append(("prevout_annotation_not_committed_by_txid", txid_from_json(changed_payer), txid))
    missing_prevout = deepcopy(bitcoin)
    del missing_prevout["vin"][-1]["prevout"]
    control_cases.append(("missing_prevout_unknown", payer_check(missing_prevout, vault_key)["status"], "unavailable"))
    control_cases.append(("wrong_valid_historical_key", payer_check(bitcoin, inbound_details["tx"]["observed_pub_key"])["status"], "payer_script_mismatch"))
    changed_tag = deepcopy(bitcoin)
    changed_tag["vout"][-1]["scriptpubkey"] = "6a44" + ("OUT:" + "0" * 64).encode().hex()
    control_cases.append(("wrong_inbound_memo", memo_payloads(changed_tag) == [memo], False))
    for name, observed, expected in control_cases:
        assert observed == expected, (name, observed, expected)
        controls.append({"txid": txid, "name": name, "status": "PASS", "observed": observed, "expected": expected})

four_field_total = sum(item[3] for item in {(claim["txid"], claim["recipient"], "BTC.BTC", claim["amount"]) for claim in claims})
index_total = sum(row["output_check"]["satoshis"] for row in rows)
assert four_field_total == index_total == 27078
assert HASHES == {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for path in HASHES}
assert SOCKET_EVENTS == []
result = {"status": "PASS", "scope": "Separate raw-record recount in the same project/team; no evaluate_selected import or execution, no network, no chain consensus or independent-author verification.", "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "input_hashes_before_and_after_identical": HASHES, "socket_events": SOCKET_EVENTS, "inbound": {"chain": "LTC", "txid": inbound, "amount_as_reported_1e8": 53000000, "midgard_height": action["height"], "streaming_flag_as_reported": action["metadata"]["swap"]["isStreamingSwap"], "thor_consensus_height": inbound_details["consensus_height"], "thor_finalised_height": inbound_details["finalised_height"], "ltc_status_source": "Midgard and THORNode only; no Litecoin transaction or block independently fetched"}, "midgard_action_count": 1, "btc_payment_claims": len(claims), "other_action_outputs": other_outputs, "rows": rows, "four_field_total_independently_calculated": four_field_total, "output_index_total_satoshis": index_total, "controls": controls, "unassessed": ["Cryptographic witness/signature validation", "Prior transactions authenticating each prevout annotation", "Bitcoin or Litecoin block inclusion/chain consensus", "Reason this streaming-labelled swap used two BTC transactions", "VCA Litecoin decoder support", "Network-wide or all-streaming-swap frequency"]}
with (BASE / "selected_raw_recount.json").open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps({"status": result["status"], "input_files": len(HASHES), "source_sha256": result["source_sha256"], "payments": len(rows), "recipient_outputs": [row["output_check"] for row in rows], "payer_checks": [row["payer_check"] for row in rows], "four_field_total": four_field_total, "output_index_total": index_total, "controls": len(controls), "socket_events": SOCKET_EVENTS}, indent=2))
