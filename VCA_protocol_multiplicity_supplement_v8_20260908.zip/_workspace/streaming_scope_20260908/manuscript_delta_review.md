# Manuscript multiplicity addition: evidence review

Decision: **READY on evidence and scope.** The one wording refinement identified
below has been applied in both languages and reread. No result correction,
new experiment, or expanded claim is needed.

This review reads the six changed TeX files against the preserved pre-change
archive and saved census, selection, evaluation, and separate raw-recount
reports. It does not rerun an experiment, compile the manuscript, edit TeX,
or make HTTP requests. Section 5.3's forthcoming v8-package access statement
is intentionally outside this decision.

## Evidence matches

| New statement | Saved evidence and review conclusion |
| --- | --- |
| Nine files fixed before downloading the multi-output payloads | `MULTI_OUTPUT_PROTOCOL.md`, frame lock, and the preserved Git-tree/LFS verification establish the locally prospective frame. The text does not call it public preregistration. |
| 166 records rather than README's 156 | `census.json` and `census_verification.json` agree: nine available files, 166 records, 166 distinct bound inbounds, no row/group comparison mismatch. README comparison records a difference of 10 from the same pinned tree; the manuscript does not invent its cause. |
| 143 records with one BTC claim plus other assets; 22 with no BTC claim; one with two distinct BTC claims | Exact match to both census implementations. The text describes recorded claims and does not classify every other-asset output as a refund. |
| One selected LTC input, saved before fresh protocol checks, without replacement | `selection.json` has one candidate, no prior-overlap exclusion, one eligible selection in `other_input`, and zero fresh transaction requests before selection. No ETH decoder result is inferred. |
| Two separate BTC transactions, output index 0, 10,326 and 16,752 satoshi | Both `selected_results.json` and `selected_raw_recount.json` identify these two outputs and amounts. The sum is 27,078 satoshi. |
| Recipient-script reference, four-field sum and indexed audit retain 27,078 satoshi | Both frame and fresh-Midgard branches of the saved evaluator agree. The separately written raw checker confirms the reference and four-field totals without importing the evaluator. Distinct txIDs make this a case where four-field accounting succeeds. |
| Non-witness transaction IDs recompute | The evaluator reports `content_consistent` for both, and the separate checker records matching IDs plus serialized bytes of lengths 192 and 561. The manuscript does not infer block inclusion or signature validity. |
| Fresh Midgard claims agree with the frame and THORNode links both actual outbounds | The action history ends with a saved empty final page, is marked complete, has one successful swap action, and both historical payer checks corroborate. The separate raw checker agrees. |
| Historical payer evidence matches 11 previous-output script fields | The separate checker records 1/1 and 10/10 script matches. These are explorer `prevout` annotations compared with scripts derived from the historical key. They are not authenticated previous-transaction bodies. |
| Separate code confirms census, selection and output comparison | `verify_census.py` supplies the first two checks; `recount_selected_raw.py` supplies the last. Neither claim requires that one checker did all three. The text says separate code, not independent authors or an independent research team. |

## Separation from existing results

- The two development incidents' 153 hops and 132 covered outputs are unchanged.
  The new LTC case is not added to their totals, error rates, or rediscovery
  denominator.
- The frozen-decoder evaluations remain 9/40 and 46/96. Section 4.11 expressly
  does not evaluate Litecoin decoding, and Figure 1 retains a separate ETH
  decoder-evaluation path.
- The 11 external refund cases, including three partial refunds and their
  duplicate-counting result, remain separate. The Korean clarification at the
  end of Section 4.10 correctly limits the absence of multiple BTC payouts to
  that refund sample; the English wording already has that scope.
- The three same-recipient/same-amount Bitcoin boundary cases remain separate
  from THORChain actions. The LTC case uses two different BTC transactions;
  it is not presented as an observed equal-vout failure of the four-field key.
- The added limitation paragraph excludes a claim about why the swap split,
  general multiple-payment support, previous-transaction authentication, and
  signatures. Existing related-source and full-incident limits remain intact.
- Figure 1's changed payment-accounting labels and Section 4.11 reference fit
  the added case. No connection makes this case part of the label-withheld
  payout search or an expanded decoder experiment.

## Wording precision corrected

The initial Section 4.11 versions described a public key as matching an input
script. The observed match is between the **script derived from that key** and
the response's script field. The parent applied this correction in both
languages, and the corrected text was reread. The requested meaning was:

English:

> Fresh Midgard claims agree with the frame. THORNode records both actual
> outbounds; scripts derived from the recorded historical vault key match all
> 11 previous-output script fields in the Bitcoin responses.

Korean:

> 새로 조회한 Midgard의 지급 항목은 표본 기록과 같았다. THORNode에는 두
> 실제 출금의 연결이 남아 있으며, 당시 금고 키에서 계산한 스크립트는
> Bitcoin 응답에 기록된 입력 11개의 이전 출력 스크립트와 모두 일치했다.

The English now says "the script derived from its historical vault key" and
the Korean now says "당시 금고 키에서 계산한 스크립트". This corrects the matching
operation without changing the result. The limitation paragraph continues
to prevent an authentication claim. The hashes below include this edit;
the other four reviewed TeX files retained their initial review hashes.

## Review snapshot and preservation

The archive manifest lists 34 saved files and four prior ZIP hashes. All 34
saved file hashes matched the manifest. Exactly the following six current
files differ from that archive; the ZIP files were not rehashed in this review.
Each language has 11 result subsections.

| Reviewed TeX file | SHA-256 |
| --- | --- |
| `manuscript/3. methodology.tex` | `13a82c05281060165bc85d571a71368b5bdd3db03bddb58fa371c68a1bcce6f3` |
| `manuscript/4. results.tex` | `d1aa15a22883bd4a5e2824b6f86fc36dc9bb66a2f460c02151b5e07818d40774` |
| `manuscript/5. conclusion.tex` | `1fe1cafb9906fa252d314baf9e4ac3f15312d283b38ec422a6a4e3bf3cc9c380` |
| `manuscript_ko/3. methodology.tex` | `8d5dde9e0c277352f997c61a03fa29671afe070309afa50750ad77b98097aad4` |
| `manuscript_ko/4. results.tex` | `9dd047d72e5117a60d07802de5c69dd1ed3c0e766cb8668a97f7519b5c4fd0b6` |
| `manuscript_ko/5. conclusion.tex` | `e3dc8abd1f38b0d53609572feb3d95762e3c0f3b72463fbe5566649f7ff64af5` |

Evidence hashes:

- Census: `7a42eee1f691a0ca28e691747964add9b9f86bb5ae01700fd77b864e4282a65f`.
- Census verification: `9914bbb859a8f5f1e50177fb44e93cb596befe6d82f62a8600dca77818ffd7d5`.
- Selection: `7f367f51c241cd3ca06e18264fc8fd4a9162cb83ebe7a1c646a9b26c0e360445`.
- Evaluator result: `5e454cc8d7d59898283e9699fa39b284193da733058b87680dd0961c3ff108d7`.
- Separate raw recount: `4a601f54bfea512dbbc2b59b4509c8f14bd69d207c35b43cd3d4da5c9dc2798b`.

Only this review document was written. Any subsequent wording, package-access,
or layout change should preserve the above factual distinctions.
