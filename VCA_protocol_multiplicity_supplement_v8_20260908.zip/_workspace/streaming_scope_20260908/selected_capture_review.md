# Selected-candidate capture review — 2026-09-08

Current decision: **READY — no remaining collection blocker identified.**
This is readiness for the locked bounded capture, not validation of protocol
payouts or permission to change the selected case.

Final reviewed `capture_selected.py` SHA-256:
`d21a99d055cca10b0569a41db831cc6178462a519ba7055d6b3b8eecdb59869e`.

## Round 2 closure

The parent moved the rate gate after request-file preservation, immediately
before the opener call. It now waits at least 0.5 seconds after the preceding
transfer/body-handling completion, which is more conservative than spacing
the call starts alone. `call_started_utc` is recorded separately from the
request record's preparation timestamp. The `finally` block records completion
after both success and caught transport/body failures.

The same nine offline controls were rerun unchanged except for their new
output directory: **9/9 PASS, exit 0, zero socket/DNS audit events**. With the
same synthetic 0.4-second delay in the first request-file write, opener starts
were now 10.4 and 10.9: **0.5 seconds apart**. The revised source hash was equal
before and after the mock run. The real collector runner was not invoked.

Reversing exactly the timing-state/gate changes and added call-start metadata
reconstructed the previous reviewed source SHA-256, establishing that no other
source bytes changed. See `selected_capture_delta_r2.json` and
`selected_capture_mock_r2/RESULT.json`. The protocol, selection, frame and
output-audit identities listed below are unchanged; only the capture source
entry is superseded by the final source hash above.

Recheck command:

```text
python -X utf8 -B _workspace/streaming_scope_20260908/check_selected_capture_r2.py
```

The earlier frame collector was already executed and frozen before this
review. This correction does not retroactively demonstrate its actual opener
spacing. Any report of that earlier collection must distinguish its
record-preparation spacing from independently demonstrated transport-call
spacing; the preserved frame evidence should not be rewritten.

## Round 1 findings, preserved

Original decision: **REVISE — one collection blocker.** This decision applied to the
reviewed source hash below. It does not change the selected case or interpret
any new protocol or Bitcoin response. The runner and actual HTTP requests were
not executed.

## Blocker: rate gate precedes variable file I/O

`experiments/revision_v5_multi/capture_selected.py:70–83` updates
`last_started`, writes and hashes the request file, constructs the request, and
only then calls `opener.open`. The protocol requires at least 0.5 seconds
between request starts. Variable pre-open file I/O can therefore make actual
`opener.open` starts less than 0.5 seconds apart even though the earlier gate
timestamps meet the configured interval.

A socket-blocked mock delayed only the first request-file write by 0.4 seconds.
The two opener call times were 10.4 and 10.5 seconds: **0.1 seconds apart**.
The same mock path with no injected I/O delay passes the 0.5-second condition.
This is a controlled counterexample, not a measurement of any real server
requests or previously captured evidence.

Required correction: retain the pre-attempt request record, then enforce the
minimum interval and update `last_started` immediately before the actual opener
call. If start timestamps are exposed, distinguish record preparation from
the transport-call start. Preserve the two-attempt and logical-request limits.
Re-run the I/O-delay control against the revised source before capture. No
selection, protocol scope, decoder support, or accounting-rule change is needed.

## Reviewed identities

| File relative to Codex | SHA-256 |
|---|---|
| `experiments/revision_v5_multi/capture_selected.py` | `885689cf7ca242be85156e8990b39acf8d198fade9a2ac1efaaed83ffc1b4713` |
| `experiments/revision_v5_multi/MULTI_OUTPUT_PROTOCOL.md` | `65ac10fe486eacade040c132bd9417e762dc53b91e461036546bbe518118cb0d` |
| `experiments/revision_v5_multi/selection.json` | `7f367f51c241cd3ca06e18264fc8fd4a9162cb83ebe7a1c646a9b26c0e360445` |
| `experiments/revision_v5_multi/frame_lock.json` | `9f9fea9c1efc403c46035caac678d57d38a92d62616577ccebb1e3da3bd36356` |
| `experiments/revision_v5_multi/frame_capture.json` | `fb1c7e43f0d5343faae6f12106b1ce2c4cd0ebd432cd7663f326d6dd95dbfef7` |
| `experiments/revision_v5_multi/census.json` | `7a42eee1f691a0ca28e691747964add9b9f86bb5ae01700fd77b864e4282a65f` |
| `experiments/revision_v1/output_audit.py` | `b15fa052fcb4d39a5236c15d7f9cf7b53e2887b54f6f12c9564c511e6e756c93` |

The current protocol hash agrees across the selection and frame lock. The
selection's census digest matches the current census, whose frame-capture
digest matches the current frame-capture file. The frame-capture lock digest
matches `frame_lock.json`; the output-audit hash matches the frame lock's
unchanged-module digest. This comparison does not independently recompute the
166-row census or validate the historical truth of the source dataset.

## Static review that did not identify another collection blocker

- The saved selection contains one `other_input` case with source chain `LTC`
  and inbound ID `66d4ec13ef7713f9cdeea5c03579e7bd2c24d7ce80bf6cd3d45621e861b17f48`.
  It has two distinct frame BTC transaction IDs. The collector does not replace
  unavailable cases, expand the frame, or invoke a decoder. This remains an
  output-accounting probe, not a test of VCA's Litecoin-input support.
- `frame_capture.json` reports 18 logical requests. The client starts at that
  total and stops opening new logical requests at 120. An unavailable check
  remains recorded as `budget_unattempted`; repeated keys use the saved result.
- Per selected case, source order is: at most four Midgard pages requested with
  limit 50; inbound THORNode details; lexicographically sorted union of valid
  frame/BTC action IDs, with Bitcoin then outbound THORNode for each ID. This
  agrees with the locked order. Bitcoin attempts use Blockstream then mempool;
  the other endpoint retries use the same permitted URL.
- Only actions with nonempty inbound legs all matching the selected inbound
  contribute newly identified BTC IDs. Other/malformed actions remain counted
  and their raw pages remain preserved. This identifier filter does not itself
  validate source-chain semantics or protocol dispatch; the evaluator must do
  that using the saved evidence.
- Page ceilings, repeated/invalid tokens, missing tokens on full pages, and
  unavailable/malformed pages get separate stop reasons. No complete-history
  assertion is emitted merely because the collector stopped.
- The host/scheme/user-info/port guard, no-redirect handler, default TLS-verified
  urllib transport, GET-only construction, 25-second timeout, two attempts,
  10,000,000-byte retained-body cap, and explicit error/truncation records are
  present. The no-redirect/TLS properties were read statically in this review;
  no real connection was used to test them.
- The real destination and completed summary did not exist at review time.
  The runner refuses those pre-existing destinations, creates its pre-capture
  lock before requests, and verifies the selection digest again after capture.
  Request records and JSON metadata are created exclusively. The collector
  stores response dictionaries but does not label them verified payouts.

## Offline checks actually executed

Command, with Codex as the working directory:

```text
python -X utf8 -B _workspace/streaming_scope_20260908/check_selected_capture_r1.py
```

Result: **8 checks PASS, 1 rate-spacing check FAIL**, exit 1. Tests covered:
normal response/digest/cache; invalid JSON then successful retry; non-object
JSON; logical-budget exhaustion; oversized bodies; HTTP-error/read-failure
preservation; forbidden URL rejection; inbound binding; and actual opener
spacing under request-file I/O delay. Both the unchanged normal path and
corrupted/failing paths were exercised.

The harness imports the module without its main guard, never calls `run()`,
replaces only its in-memory destination/opener/clock for the mock cases, and
raises on socket-connect or DNS audit events. It recorded **zero such events**.
Source bytes before and after the run have the identical SHA-256 above.

Detailed result: `selected_capture_mock_r1/RESULT.json`. All mock request,
response and metadata files are confined to that new directory. The existing
source, selection, frame, original 40/96 predictions, manuscript and research
archives were not edited. No commit, new real capture, corpus census runner,
golden test or payout evaluation was performed by this reviewer.
