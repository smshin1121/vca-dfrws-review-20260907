# Selected-candidate evaluation QA, revision 2

Decision: **READY** to execute the bounded saved-input evaluation.

This decision concerns the three corrections requested in
`evaluation_review.md`. It is not a finding about the selected transaction,
an independent-team reproduction, or approval to expand the sampling frame.
No new blocking discrepancy was found in the changed paths.

## Reviewed hashes

| File | SHA-256 |
| --- | --- |
| `experiments/revision_v5_multi/evaluate_selected.py` | `ab0cf874b1f95e58bb94c6ce220349509a8b9654b5a2fb9f31cafc0277846235` |
| `experiments/revision_v1/output_audit.py` | `b15fa052fcb4d39a5236c15d7f9cf7b53e2887b54f6f12c9564c511e6e756c93` |
| `experiments/revision_v5_multi/MULTI_OUTPUT_PROTOCOL.md` | `65ac10fe486eacade040c132bd9417e762dc53b91e461036546bbe518118cb0d` |

All four loaded source/protocol files, including the frozen address codec,
retained their before hashes. The full set is in
`evaluation_synthetic_r2.json`.

## Corrections verified

1. Missing or incorrectly typed confirmation evidence now returns
   `transaction_fields_unavailable`; explicit Boolean false remains
   `transaction_unconfirmed`. Missing, blank, or wrongly typed previous-output
   script/address fields and unavailable historical key fields return an
   unavailable state in `payer_check`. A normal fixture still corroborates;
   a present different script or planned key still produces a mismatch.

2. Fresh-action validation rejects missing/blank/non-string asset labels,
   invalid amounts, and empty coin vectors. A deep copy canonicalizes BTC
   txID case and an optional `0x` prefix before the unchanged extractor. The
   original action and non-BTC transaction ID remain unchanged, and extracted
   IDs match capture lookup keys. The missing outbound-request-key path uses
   `.get(...)` and `response(None)` returns unavailable. This last lookup
   guard was inspected statically; the evaluation `run()` was not executed.

3. A final assertion now rehashes every recorded captured request/response
   path and compares the entire mapping. The report records
   `captured_input_hashes_unchanged_at_exit`. The exact final guard AST was
   executed only against a new synthetic file under this review directory:
   unchanged bytes pass; changed bytes fail. No real capture was read or
   altered for this check.

## Synthetic execution evidence

Command: `python -B _workspace/streaming_scope_20260908/check_evaluation_r2.py`

Result: **55 QA assertions passed, zero network attempts, no production
evaluation run, and loaded inputs unchanged**. The original r1 driver and
result remain preserved. The r2 wrapper makes exact, checked substitutions
to update the seven former failure reproductions, then adds 29 controls for
the corrected interfaces and input-preservation guard.

The retained controls also confirm that recipient-output enumeration never
reads a claimed amount, equal-valued vouts remain distinct, repeated claims
do not duplicate outputs, missing transaction evidence does not yield a
verified zero, and the frozen amount-assisted audit remains conservative on
ambiguous output assignment. The synthetic non-witness serialization check
and normal-versus-altered payer control still pass.

## Limits retained for result reporting

- Curated-frame claims and fresh Midgard claims remain separate. Retrieval
  completeness is distinct from agreement among available claims. Naive and
  four-field sums on incomplete evidence describe observed valid claims;
  they must not be described as complete payment-history totals.
- Recipient-based enumeration is not an allocation of each protocol claim
  to one output. The unchanged audit's unresolved cases must remain visible.
- Historical THORNode records plus explorer previous-output fields support
  protocol-source corroboration. They do not independently validate previous
  transaction bodies, signatures, block inclusion, or chain consensus.
- This probe cannot establish ETH decoder support for the selected non-ETH
  input, population coverage, or independent-team reproducibility. The
  `_workspace` address-codec dependency still has to be included in any later
  extracted research package.

Actual saved-input results should be generated once by the parent workflow
and then compared with the separate raw-data checker. Those steps are outside
this code/synthetic review and have not been performed here.
