# Pre-collection code review, round 2

Decision: **READY.** The four previously identified discrepancies are resolved for the fixed, bounded collection and descriptive census. No remaining collection-blocking discrepancy was identified in the reviewed changes. This is not a result of the planned corpus experiment or approval to claim verified protocol payouts.

Final reviewed SHA-256:

- `experiments/revision_v5_multi/capture_frame.py`: `5849ef2d6fdf8ede8cf4a3da49214bf38ddc4831edf05e7cbafb4334fef2a982`.
- `experiments/revision_v5_multi/census_frame.py`: `487c6881354d7995ac2f7febc90c77678dfe422f591a23ce22eca925db1ce563`.
- `experiments/revision_v5_multi/MULTI_OUTPUT_PROTOCOL.md`: `65ac10fe486eacade040c132bd9417e762dc53b91e461036546bbe518118cb0d`, unchanged from the approved protocol review.

## Closure evidence

1. Blank chain/asset labels and malformed non-BTC identifiers, amounts and recipients now add issues and yield `unresolved`. The synthetic predicate suite passed **21/21**, including the new malformed cases. Repeated identical BTC rows remain candidates, and the ETH stratum still requires its native asset.
2. HTTP-error body reading now catches read failures, records their details, and retains at most 10,000,000 bytes with an explicit truncation flag. Mocked timeout, oversized error/success bodies and `HTTPException` cases preserved both attempts and their result metadata. A normal response passed the same recording path.
3. Scheme, host, user-info and port restrictions are enforced before opening a request. The no-redirect handler passed checks through the opener's local error-handler chain for external-host and HTTP-downgrade redirects. No transport was used.
4. `frame_and_schema_complete` separates complete evidence from unavailable files or unresolved rows. The final no-selection states explicitly say **no eligible candidate**, preserving the distinction between no candidate and candidates removed by the prior-exclusion policy. Status/type distributions are also retained. These completeness and state-label branches were checked statically; the real census runner was not executed.

The pre-download lock additionally pins the census source hash, and the census checks that hash before reading the frame. Protocol, sample caps, exclusion policy and candidate frame were not expanded.

## Bounded execution record

`check_code_r2b.py` ran with `python -B`; it loads the two modules using `runpy.run_path` without invoking their `run()` functions. Result: **21 synthetic predicate controls + 11 mock request checks PASS, exit 0, zero outbound socket attempts**. Result file: `mock_io_r2b/RESULT.json` in this directory. All mock files are confined to this directory; no frame payload was read or requested.

The measured census hash at that run was `0c0480109803e5dd57cff8c0c45b1b3b18ab3c2e24c4eac5a498beac327018e9`. Afterwards the parent changed only the two no-selection strings. Reversing exactly those two unique byte replacements reproduced that measured hash, establishing an exact label-only delta to the final hash above. No additional algorithm or predicate change occurred.

The first mock attempt (`check_code_r2.py`, preserved `mock_io_r2/`) stopped because the review harness incorrectly expected a redirect handler by itself to raise. The corrected harness exercises the complete opener error-handler chain; this was a harness correction, not an additional collector defect. The corrected complete run passed.

No actual corpus/HTTP capture, broad VCA test, golden test, or manuscript edit was performed. The independently implemented recount and output verification remain future checks after collection.
