# Pre-collection code review

Decision: **REVISE before collection.** The fixed-frame design remains suitable, but the implementation has four bounded discrepancies below. No transaction payload or capture runner was executed during review; neither reviewed source file was edited.

Reviewed SHA-256:

- `experiments/revision_v5_multi/capture_frame.py`: `de7e91547d21a6c82f8b56e480aa311f62da96ef8a70037180dc0598bb3c68e0`.
- `experiments/revision_v5_multi/census_frame.py`: `c1ac19628f4ad23116595965e132ba77249a3fa09eeb59f3a303be6bc74b516b`.
- Protocol remains the previously reviewed `65ac10fe486eacade040c132bd9417e762dc53b91e461036546bbe518118cb0d`.

## Required corrections

1. **Malformed output labels can become a zero-BTC classification.** In `census_frame.py` lines 77–87, output chain and asset need only be strings; empty or whitespace-only labels pass, are treated as non-BTC, and add no issue. With an otherwise valid inbound and `out=[{"chain":"","asset":""}]`, the implementation reaches `no_btc_claim`, although the output's asset is unknown. Validate nonempty labels and retain this case as unresolved. Also preserve malformed non-BTC row fields as issues rather than allowing an invalid source-asset row to appear fully classified; at present non-BTC rows skip identifier/amount validation altogether. Add these cases to the same synthetic predicate controls. Do not weaken the existing retention of malformed BTC candidates.

2. **Error-response reading can escape attempt recording.** In `capture_frame.py` lines 87–93, `error.read(10_000_001)` runs inside the `HTTPError` handler, outside the sibling timeout/OSError handler. A read failure there exits `get()` before its attempt metadata and logical-result file are written, and prevents the remaining nine-file census from receiving its unavailable entries. The error branch also writes 10,000,001 bytes without applying the specified 10,000,000-byte retention limit. Guard the error-body read, retain a bounded body/prefix with an explicit incomplete/oversized flag, and always finish attempt metadata for such failures. This is a static failure path; no real request was made to demonstrate it.

3. **The recorded HTTPS/host guarantee does not cover redirects.** `Requests.get()` checks only the initial hostname, not its scheme, and default `urlopen` follows redirects before `final_url` is recorded. The resulting request record still declares verified TLS unconditionally. Enforce HTTPS and the allowlist on every followed hop, or disable redirects and record them as unavailable responses. Checking only the final URL after following it would not enforce the collection boundary. The pinned initial URLs are HTTPS; this finding concerns the unconditional guarantee made for the complete request path, not a claim that an actual source redirected improperly.

4. **An incomplete frame can receive an unqualified zero-candidate stop reason.** The selector currently assigns `next_action=stop_no_candidate` whenever its selected list is empty, even if all nine files were unavailable. The per-file denominator is retained, which is good, but this machine-readable outcome should distinguish a complete census from no observed candidate in an incomplete frame. Record completeness and a separate stop reason; likewise keep malformed/unbound rows visible when interpreting a zero. This point was also independently raised by the parent reviewer before the review ended.

## Checks that passed

The permitted synthetic `predicate_controls()` was run with `python -B` via `runpy.run_path` (not as `__main__`): **10 controls passed, exit 0**. They cover single BTC, repeated identical rows, distinct BTC transactions, different claims in one transaction, BTC plus another asset, four invalid BTC amounts, and absent output arrays. They do not cover the four paths above.

Static review confirmed the nine-path frame is fixed; pointer Git identity and payload SHA-256/size are checked; Windows-reserved source names map to numeric local files; existing execution outputs use existence guards; raw repeated BTC rows remain candidates; native ETH requires both chain ETH and the sole input asset ETH; selected cases are hash-ordered with no replacement. The four exclusion files are locked before payload collection. The earlier exclusion hash carried by the revision-v1 exclusion file matches the actual original exclusion file (`8298477199c136b4f706552f2ce3da609ae5a27cbf16c42e3f4aa5a6a8a95038`), so the original file's indirect use is not an identified exclusion-policy defect.

Zero-valued BTC claims are retained as claims rather than dropped; their amounts are not proof of settlement. `record_status` and `record_type` are preserved, so non-success rows can remain descriptive observations instead of being silently excluded to match the README. Keep that behavior and report their distribution; actual source status is not validated merely by the published curation description.

No broader VCA, corpus, or golden tests were run. Collection may proceed after these localized corrections and their bounded review; the findings do not justify changing the frame, sample caps, or scientific claims.
