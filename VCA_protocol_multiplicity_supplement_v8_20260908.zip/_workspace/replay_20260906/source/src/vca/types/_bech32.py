"""In-house BIP-173 (bech32) and base58check normalisation for Bitcoin.

Public domain reference port — see
``https://github.com/sipa/bech32/blob/master/ref/python/segwit_addr.py``
for the canonical implementation we adapted.

The module exposes a single high-level helper, :func:`normalize_btc_address`,
which decides between bech32, bech32m and base58check, validates the
checksum, and returns a canonical string (lowercase for bech32, original
casing for base58). It rejects anything else with :class:`ValueError`.

Why in-house? P1-001 forbids new external dependencies (DoD-14). The
algorithms are stable and small (~80 LoC together), so we ship them
ourselves and revisit if BTC scope grows.
"""

from __future__ import annotations

import hashlib
from collections.abc import Mapping
from types import MappingProxyType
from typing import Final

_BECH32_CHARSET: Final[str] = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
_BECH32_CHARSET_REV: Final[Mapping[str, int]] = MappingProxyType(
    {c: i for i, c in enumerate(_BECH32_CHARSET)}
)
_BECH32_CONST: Final[int] = 1
_BECH32M_CONST: Final[int] = 0x2BC830A3
_B58_ALPHABET: Final[str] = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
_B58_REV: Final[Mapping[str, int]] = MappingProxyType({c: i for i, c in enumerate(_B58_ALPHABET)})


def _bech32_polymod(values: list[int]) -> int:
    gen = [0x3B6A57B2, 0x26508E6D, 0x1EA119FA, 0x3D4233DD, 0x2A1462B3]
    chk = 1
    for v in values:
        b = chk >> 25
        chk = ((chk & 0x1FFFFFF) << 5) ^ v
        for i in range(5):
            if (b >> i) & 1:
                chk ^= gen[i]
    return chk


def _bech32_hrp_expand(hrp: str) -> list[int]:
    return [ord(c) >> 5 for c in hrp] + [0] + [ord(c) & 31 for c in hrp]


def _bech32_verify_checksum(hrp: str, data: list[int]) -> int | None:
    """Return the bech32 constant used (1 or 0x2BC830A3) or None on failure."""
    polymod = _bech32_polymod(_bech32_hrp_expand(hrp) + data)
    if polymod == _BECH32_CONST:
        return _BECH32_CONST
    if polymod == _BECH32M_CONST:
        return _BECH32M_CONST
    return None


def _decode_bech32(addr: str) -> tuple[str, list[int], int] | None:
    """Decode a bech32/bech32m string. Return (hrp, data, variant) or None.

    ``variant`` is :data:`_BECH32_CONST` for BIP-173 (bech32) or
    :data:`_BECH32M_CONST` for BIP-350 (bech32m). Callers use it to enforce
    the version-specific encoding rule (v0 → bech32, v≥1 → bech32m).
    """
    if any(ord(c) < 33 or ord(c) > 126 for c in addr):
        return None
    lower, upper = addr.lower(), addr.upper()
    if addr != lower and addr != upper:
        return None  # mixed case forbidden by BIP-173
    addr = lower
    pos = addr.rfind("1")
    if pos < 1 or pos + 7 > len(addr) or len(addr) > 90:
        return None
    hrp = addr[:pos]
    if any(c not in _BECH32_CHARSET_REV for c in addr[pos + 1 :]):
        return None
    data = [_BECH32_CHARSET_REV[c] for c in addr[pos + 1 :]]
    variant = _bech32_verify_checksum(hrp, data)
    if variant is None:
        return None
    return hrp, data[:-6], variant


def _convert_bits(data: list[int], frombits: int, tobits: int, *, pad: bool) -> list[int] | None:
    """General power-of-2 base conversion (BIP-173 reference)."""
    acc = 0
    bits = 0
    ret: list[int] = []
    maxv = (1 << tobits) - 1
    max_acc = (1 << (frombits + tobits - 1)) - 1
    for value in data:
        if value < 0 or (value >> frombits):
            return None
        acc = ((acc << frombits) | value) & max_acc
        bits += frombits
        while bits >= tobits:
            bits -= tobits
            ret.append((acc >> bits) & maxv)
    if pad:
        if bits:
            ret.append((acc << (tobits - bits)) & maxv)
    elif bits >= frombits or ((acc << (tobits - bits)) & maxv):
        return None
    return ret


def _decode_segwit(addr: str) -> tuple[str, int, list[int]] | None:
    """Decode a SegWit address: (hrp, witness_version, witness_program) or None.

    Enforces BIP-141 / BIP-350 program rules:
      * witness version in [0, 16]
      * v=0 → bech32 variant, program length 20 (P2WPKH) or 32 (P2WSH)
      * v≥1 → bech32m variant, program length in [2, 40]
    """
    decoded = _decode_bech32(addr)
    if decoded is None:
        return None
    hrp, data, variant = decoded
    if not data:
        return None
    witver = data[0]
    if witver < 0 or witver > 16:
        return None
    program = _convert_bits(data[1:], 5, 8, pad=False)
    if program is None or len(program) < 2 or len(program) > 40:
        return None
    if witver == 0:
        if len(program) not in (20, 32):
            return None
        if variant != _BECH32_CONST:
            return None
    else:
        if variant != _BECH32M_CONST:
            return None
    return hrp, witver, program


def _b58_decode_check(s: str) -> bytes | None:
    """Decode base58check; return payload (incl. version byte) or None."""
    if not s or any(c not in _B58_REV for c in s):
        return None
    num = 0
    for c in s:
        num = num * 58 + _B58_REV[c]
    full = num.to_bytes((num.bit_length() + 7) // 8, "big") if num else b""
    # Restore leading zero bytes corresponding to leading "1" characters.
    pad = len(s) - len(s.lstrip("1"))
    full = b"\x00" * pad + full
    if len(full) < 5:
        return None
    payload, checksum = full[:-4], full[-4:]
    digest = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
    if digest != checksum:
        return None
    return payload


def normalize_btc_address(raw: str) -> str:
    """Validate and canonicalize a Bitcoin address (mainnet only).

    Accepts bech32/bech32m (``bc1...``) and base58check (``1...``/``3...``)
    mainnet addresses. Returns the canonical form: bech32 lowercased,
    base58 in its original (case-sensitive) representation.

    Raises ``ValueError`` on any malformed input.
    """
    s = raw.strip()
    if not s:
        raise ValueError("empty BTC address")
    if s.lower().startswith("bc1"):
        decoded = _decode_segwit(s)
        if decoded is None:
            raise ValueError(f"invalid bech32 BTC address: {raw!r}")
        hrp, _witver, _program = decoded
        if hrp != "bc":
            raise ValueError(f"non-mainnet bech32 hrp: {hrp!r}")
        return s.lower()
    if s[0] in {"1", "3"}:
        payload = _b58_decode_check(s)
        if payload is None or len(payload) != 21:
            raise ValueError(f"invalid base58check BTC address: {raw!r}")
        version = payload[0]
        if version not in {0x00, 0x05}:  # mainnet P2PKH / P2SH only
            raise ValueError(f"non-mainnet base58 version: {version:#x}")
        return s
    raise ValueError(f"unrecognised BTC address format: {raw!r}")


__all__ = ["normalize_btc_address"]
