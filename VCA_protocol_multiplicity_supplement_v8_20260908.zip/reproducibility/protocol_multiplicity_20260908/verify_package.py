"""Verify v8 identities/paths and optionally scan externally supplied patterns."""

import argparse
import hashlib
import json
import re
import stat
import sys
import zipfile
from pathlib import Path, PurePosixPath, PureWindowsPath

sys.dont_write_bytecode = True
PACKAGE = Path(__file__).resolve().parents[2]


def demand(condition, message):
    if not condition:
        raise ValueError(message)


def safe_name(name):
    demand(type(name) is str and bool(name), "unsafe_package_path")
    path = PurePosixPath(name)
    demand("\\" not in name and "\x00" not in name and not path.is_absolute(), "unsafe_package_path")
    demand(not PureWindowsPath(name).drive and path.as_posix() == name, "unsafe_package_path")
    demand(all(part not in {"", ".", ".."} and ":" not in part and not part.endswith((" ", ".")) for part in path.parts), "unsafe_package_path")
    reserved = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}
    demand(all(part.split(".", 1)[0].upper() not in reserved for part in path.parts), "unsafe_package_path")
    return path


def file_digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def author_hits(data, tokens=()):
    lowered = data.lower()
    return [f"supplied_pattern_{index + 1}" for index, token in enumerate(tokens) if token.lower() in lowered]


def inspect_zip(path):
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        demand(0 < len(infos) <= 2000, "zip_entry_count")
        seen = set()
        total = 0
        for entry in infos:
            safe_name(entry.filename)
            demand(not entry.is_dir(), "unexpected_zip_directory_entry")
            demand(entry.filename.casefold() not in seen, "duplicate_zip_entry")
            seen.add(entry.filename.casefold())
            demand(not stat.S_ISLNK(entry.external_attr >> 16), "zip_symlink")
            demand(not (entry.flag_bits & 1), "encrypted_zip_entry")
            demand(entry.file_size <= 128 * 1024 * 1024, "zip_member_size")
            total += entry.file_size
        demand(total <= 512 * 1024 * 1024, "zip_total_size")
        demand({"manifest.json", "sha256sums"}.issubset(seen), "zip_missing_identity_records")
        return {"entries": len(infos), "uncompressed_bytes": total, "sha256": file_digest(path)}


def verify(root, known_tokens=()):
    root = Path(root).resolve()
    manifest_path = root / "MANIFEST.json"
    manifest = json.loads(manifest_path.read_bytes())
    demand(manifest.get("format") == "VCA-protocol-multiplicity-v8", "manifest_format")
    entries = manifest["files"]
    demand(type(entries) is list and bool(entries), "manifest_files")
    expected = {}
    seen = set()
    failures = []
    scan_hits = []
    for entry in entries:
        name = entry["path"]
        safe_name(name)
        demand(name.casefold() not in seen and name not in {"MANIFEST.json", "SHA256SUMS"}, "duplicate_manifest_entry")
        seen.add(name.casefold())
        demand(type(entry["bytes"]) is int and entry["bytes"] >= 0, "manifest_size")
        demand(type(entry["sha256"]) is str and re.fullmatch(r"[0-9a-f]{64}", entry["sha256"]) is not None, "manifest_digest")
        target = root / name
        demand(not target.is_symlink(), "package_symlink")
        demand(target.resolve().is_relative_to(root), "package_path_escape")
        if not target.is_file():
            failures.append({"path": name, "reason": "missing_file"})
            continue
        data = target.read_bytes()
        if len(data) != entry["bytes"] or hashlib.sha256(data).hexdigest() != entry["sha256"]:
            failures.append({"path": name, "reason": "file_identity_mismatch"})
        for hit in author_hits(data, known_tokens):
            scan_hits.append({"path": name, "reason": hit})
        expected[name] = entry["sha256"]
    actual = {item.relative_to(root).as_posix() for item in root.rglob("*") if item.is_file()}
    named = {entry["path"] for entry in entries} | {"MANIFEST.json", "SHA256SUMS"}
    demand(actual == named, "package_file_set_mismatch")
    demand(not failures, "package_file_identity_failure:" + json.dumps(failures))
    for identity_file in (manifest_path, root / "SHA256SUMS"):
        demand(not identity_file.is_symlink(), "package_symlink")
        for hit in author_hits(identity_file.read_bytes(), known_tokens):
            scan_hits.append({"path": identity_file.name, "reason": hit})
    demand(not scan_hits, "known_author_string:" + json.dumps(scan_hits))
    sums = {}
    for line in (root / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        safe_name(name)
        demand(name not in sums, "duplicate_sum_entry")
        sums[name] = digest
    expected["MANIFEST.json"] = file_digest(manifest_path)
    demand(sums == expected, "checksum_list_mismatch")
    return {"status": "PASS", "files_checked": len(entries), "manifest_sha256": expected["MANIFEST.json"], "configured_author_patterns": len(known_tokens), "known_author_string_hits": scan_hits, "scope": "File-byte/path verification and any explicitly supplied patterns; not proof of source truth, complete anonymization or author independence."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", type=Path, default=PACKAGE)
    parser.add_argument("--zip", type=Path)
    parser.add_argument("--json-out", type=Path)
    parser.add_argument("--author-pattern-file", type=Path)
    args = parser.parse_args()
    tokens = tuple(line for line in args.author_pattern_file.read_bytes().splitlines() if line) if args.author_pattern_file else ()
    result = verify(args.package_root, tokens)
    if args.zip:
        result["zip"] = inspect_zip(args.zip)
    if args.json_out:
        with args.json_out.open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(result, stream, indent=2)
            stream.write("\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
