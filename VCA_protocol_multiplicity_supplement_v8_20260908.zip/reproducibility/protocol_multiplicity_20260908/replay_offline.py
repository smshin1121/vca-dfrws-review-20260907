"""Replay the three frozen v8 calculations in a new scratch copy."""

import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from verify_package import file_digest, safe_name, verify

PACKAGE = Path(__file__).resolve().parents[2]
PREFIX = "experiments/revision_v5_multi/"
RAW_PREFIX = "_workspace/streaming_scope_20260908/"
OMIT_FROM_SCRATCH = {
    PREFIX + "selected_results.json",
    PREFIX + "evaluation_lock.json",
    PREFIX + "census_verification.json",
    RAW_PREFIX + "selected_raw_recount.json",
}


def write_json(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def normalized(value):
    if isinstance(value, dict):
        return {key.replace("\\", "/"): normalized(item) for key, item in value.items()}
    if isinstance(value, list):
        return [normalized(item) for item in value]
    return value


def scientific_comparison(expected, fresh):
    # Only new execution timestamps and platform path separators may vary.
    timestamps = {"created_utc", "started_utc", "completed_utc"}
    expected = normalized({key: value for key, value in expected.items() if key not in timestamps})
    fresh = normalized({key: value for key, value in fresh.items() if key not in timestamps})
    encode = lambda value: json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return encode(expected) == encode(fresh)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", type=Path, default=PACKAGE)
    parser.add_argument("--work-dir", type=Path, required=True)
    args = parser.parse_args()
    package = args.package_root.resolve()
    work = args.work_dir.resolve()
    if work.exists() or work.is_relative_to(package) or package.is_relative_to(work):
        raise ValueError("work_directory_must_be_new_and_outside_package")
    if sys.version_info < (3, 11):
        raise RuntimeError("Python 3.11 or newer is required")
    hashlib.new("ripemd160", b"dependency-check")
    verified_before = verify(package)
    manifest = json.loads((package / "MANIFEST.json").read_bytes())
    started = datetime.now(UTC).isoformat()
    work.mkdir(parents=True)
    scratch = work / "scratch"
    scratch.mkdir()
    copied = {}
    for entry in manifest["files"]:
        name = entry["path"]
        safe_name(name)
        if name in OMIT_FROM_SCRATCH:
            continue
        target = scratch / name
        target.parent.mkdir(parents=True, exist_ok=True)
        data = (package / name).read_bytes()
        with target.open("xb") as stream:
            stream.write(data)
        if file_digest(target) != entry["sha256"]:
            raise AssertionError("scratch_copy_identity:" + name)
        copied[name] = entry["sha256"]
    worker = package / "reproducibility/protocol_multiplicity_20260908/offline_worker.py"
    stages = [
        ("census", PREFIX + "verify_census.py", ["--output", "_fresh/census_verification.json"]),
        ("evaluation", PREFIX + "evaluate_selected.py", []),
        ("raw_recount", RAW_PREFIX + "recount_selected_raw.py", []),
    ]
    receipts = []
    for label, script, tail in stages:
        print("Running frozen " + label, flush=True)
        receipt = work / (label + "_execution.json")
        command = [sys.executable, "-I", "-B", str(worker), "--scratch", str(scratch), "--script", script, "--receipt", str(receipt)]
        if tail:
            command.extend(["--", *tail])
        with (work / (label + ".log")).open("xb") as log:
            completed = subprocess.run(command, cwd=work, stdout=log, stderr=subprocess.STDOUT, timeout=180, check=False, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if completed.returncode != 0:
            raise RuntimeError("frozen_stage_failed:" + label + "; see " + label + ".log")
        observed = json.loads(receipt.read_bytes())
        if observed["status"] != "PASS" or observed["network_events"] or observed["forbidden_writes"]:
            raise AssertionError("execution_receipt_failed:" + label)
        receipts.append(observed)
    comparisons = []
    report_paths = [
        ("census", PREFIX + "census_verification.json", "_fresh/census_verification.json"),
        ("evaluation", PREFIX + "selected_results.json", PREFIX + "selected_results.json"),
        ("evaluation_lock", PREFIX + "evaluation_lock.json", PREFIX + "evaluation_lock.json"),
        ("raw_recount", RAW_PREFIX + "selected_raw_recount.json", RAW_PREFIX + "selected_raw_recount.json"),
    ]
    loaded = {}
    for label, preserved, fresh in report_paths:
        expected_data = json.loads((package / preserved).read_bytes())
        actual_data = json.loads((scratch / fresh).read_bytes())
        agree = scientific_comparison(expected_data, actual_data)
        comparisons.append({"name": label, "status": "PASS" if agree else "FAIL", "expected_path": preserved, "fresh_path_in_scratch": fresh, "expected_sha256": file_digest(package / preserved), "fresh_sha256": file_digest(scratch / fresh), "comparison": "All JSON content after removing only top-level execution timestamps and normalizing object-key path separators."})
        loaded[label] = actual_data
        if not agree:
            write_json(work / "failed_comparisons.json", comparisons)
            raise AssertionError("preserved_result_disagreement:" + label)
    unchanged = {name: file_digest(scratch / name) for name in copied}
    if copied != unchanged:
        raise AssertionError("scratch_input_changed")
    verified_after = verify(package)
    if verified_after != verified_before:
        raise AssertionError("package_changed_during_replay")
    census = loaded["census"]
    evaluation = loaded["evaluation"]
    raw = loaded["raw_recount"]
    result = {"status": "PASS", "started_utc": started, "completed_utc": datetime.now(UTC).isoformat(), "python": platform.python_version(), "platform": platform.platform(), "package_manifest_sha256": verified_before["manifest_sha256"], "package_files_checked": verified_before["files_checked"], "scratch_input_files_unchanged": len(copied), "executions": receipts, "comparisons": comparisons, "observations": {"frame_files": census["counts"]["frame_files_available"], "frame_records": census["counts"]["records"], "selected_cases": census["counts"]["selected"], "selected_strata": census["counts"]["selected_strata"], "census_controls": census["own_control_count"], "evaluation_controls": len(evaluation["controls"]), "raw_recount_controls": len(raw["controls"]), "raw_payment_count": len(raw["rows"]), "raw_index_total_satoshis": raw["output_index_total_satoshis"], "raw_four_field_total_satoshis": raw["four_field_total_independently_calculated"]}, "network_events": sum(len(receipt["network_events"]) for receipt in receipts), "scope": "Local replay of packaged preserved inputs with separate implementations and frozen evaluation. Operator/team independence, source truth, signatures and chain consensus are not established."}
    write_json(work / "REPLAY_RESULT.json", result)
    print(json.dumps({"status": "PASS", "files_checked": result["package_files_checked"], "comparisons": len(comparisons), "observations": result["observations"], "network_events": result["network_events"]}, indent=2))


if __name__ == "__main__":
    main()
