"""Execute one frozen script with socket, nested-process and write boundaries."""

import argparse
import hashlib
import json
import os
import runpy
import sys
import traceback
from datetime import UTC, datetime
from pathlib import Path

sys.dont_write_bytecode = True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scratch", type=Path, required=True)
    parser.add_argument("--script", required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("script_arguments", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    scratch = args.scratch.resolve()
    receipt = args.receipt.resolve()
    script = (scratch / args.script).resolve()
    if not script.is_relative_to(scratch) or receipt.exists():
        raise ValueError("unsafe_worker_paths")
    source_before = hashlib.sha256(script.read_bytes()).hexdigest()
    network_events = []
    forbidden_writes = []
    nested_processes = []
    self_testing = False

    def guard(event, values):
        if event in {"socket.connect", "socket.connect_ex", "socket.getaddrinfo"}:
            if not self_testing:
                network_events.append(event)
            raise RuntimeError("offline_network_denied")
        if event in {"subprocess.Popen", "os.system", "os.exec", "os.posix_spawn"}:
            nested_processes.append(event)
            raise RuntimeError("nested_process_denied")
        if event == "open":
            name, mode, flags = values
            writing = (isinstance(mode, str) and any(char in mode for char in "wax+")) or (type(flags) is int and bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_APPEND | os.O_CREAT | os.O_TRUNC)))
            if writing and isinstance(name, (str, bytes, os.PathLike)):
                path = Path(os.fsdecode(name)).resolve()
                if not (path.is_relative_to(scratch) or path == receipt):
                    forbidden_writes.append(str(path))
                    raise RuntimeError("write_outside_scratch_denied")

    sys.addaudithook(guard)
    self_testing = True
    try:
        sys.audit("socket.connect", None, ("offline-self-test.invalid", 443))
    except RuntimeError as error:
        assert str(error) == "offline_network_denied"
    else:
        raise AssertionError("socket_guard_self_test_failed")
    self_testing = False
    started = datetime.now(UTC).isoformat()
    exit_code = 0
    error_text = None
    os.chdir(scratch)
    tail = args.script_arguments
    if tail[:1] == ["--"]:
        tail = tail[1:]
    sys.argv = [str(script), *tail]
    try:
        runpy.run_path(str(script), run_name="__main__")
    except SystemExit as error:
        exit_code = error.code if type(error.code) is int else int(error.code is not None)
        if exit_code:
            error_text = repr(error)
    except BaseException as error:
        exit_code = 1
        error_text = repr(error)
        traceback.print_exc()
    source_after = hashlib.sha256(script.read_bytes()).hexdigest()
    clean = source_after == source_before and not network_events and not forbidden_writes and not nested_processes
    if not clean:
        exit_code = 1
    result = {"status": "PASS" if exit_code == 0 else "FAIL", "started_utc": started, "completed_utc": datetime.now(UTC).isoformat(), "script": args.script, "source_sha256_before": source_before, "source_sha256_after": source_after, "exit_code": exit_code, "socket_guard_self_test": "PASS; synthetic audit event, no socket operation", "network_events": network_events, "forbidden_writes": forbidden_writes, "nested_processes": nested_processes, "error": error_text, "scope": "One local frozen-script execution under a Python audit guard; not independent-team reproduction or an operating-system network sandbox."}
    with receipt.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    raise SystemExit(exit_code)


if __name__ == "__main__":
    main()
