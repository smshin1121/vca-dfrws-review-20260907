"""Recalculate the preserved integrity cases after verifying the package files."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def check_files(root, manifest):
    for name, expected in manifest["files"].items():
        path = (root / name).resolve()
        if not path.is_relative_to(root) or digest(path) != expected["sha256"]:
            raise ValueError("Package file mismatch: " + name)
    return len(manifest["files"])


WORKER = r'''
import runpy, sys
def guard(event, args):
    if event in {"socket.connect", "socket.getaddrinfo", "socket.bind"}:
        raise PermissionError("Offline integrity review forbids network access: " + event)
sys.addaudithook(guard)
script, root, output = sys.argv[1:]
sys.argv = [script, "--root", root, "--output", output]
runpy.run_path(script, run_name="__main__")
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--with-runtime", action="store_true")
    parser.add_argument("--python", default=sys.executable,
                        help="Python interpreter; use the revision-5 frozen environment for --with-runtime")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    output = (root / args.output_dir).resolve()
    if not output.is_relative_to(root) or output == root or output.exists():
        raise ValueError("Use a new output directory inside the extracted package")
    manifest_path = root / "INTEGRITY_MANIFEST.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    before = check_files(root, manifest)
    output.mkdir(parents=True)
    names = ["edge_audit", "wei_audit"]
    if args.with_runtime:
        names.append("wei_runtime")
    rows = []
    for name in names:
        script = root / "experiments/revision_v6_integrity" / (name + ".py")
        generated = output / (name + ".json")
        command = [args.python, "-B", "-X", "utf8", "-c", WORKER, str(script), str(root), str(generated)]
        result = subprocess.run(command, cwd=root, capture_output=True, text=True, encoding="utf-8", check=False)
        (output / (name + ".stdout.txt")).write_text(result.stdout, encoding="utf-8")
        (output / (name + ".stderr.txt")).write_text(result.stderr, encoding="utf-8")
        if result.returncode:
            raise RuntimeError(f"{name} exited {result.returncode}; retain its logs")
        actual = json.loads(generated.read_text(encoding="utf-8"))
        expected = json.loads((root / "experiments/revision_v6_integrity" / (name + ".json")).read_text(encoding="utf-8"))
        if name == "edge_audit":
            actual.pop("created_utc", None)
            expected.pop("created_utc", None)
        if actual != expected or actual["status"] != "PASS":
            raise ValueError("Recalculated report differs: " + name)
        rows.append({"check": name, "exit_code": result.returncode, "status": "PASS",
                     "report_sha256": digest(generated)})
    after = check_files(root, manifest)
    summary = {"status": "PASS", "package_files_checked_before": before,
               "package_files_checked_after": after, "manifest_sha256": digest(manifest_path),
               "executions": rows, "network_policy": "Each child blocks socket connection, DNS and bind events",
               "scope": "Saved-graph recount and raw-amount audit; no new sample or independent-team reproduction."}
    (output / "RESULT.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
