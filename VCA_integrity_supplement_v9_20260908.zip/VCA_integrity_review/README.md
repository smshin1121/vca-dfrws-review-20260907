# Integrity supplement: graph rows and raw Ethereum amounts

This supplement explains two reporting issues in Sections 4.7 and 4.9. It adds
recalculations of preserved records, not a new evaluation sample. Earlier
archives, predictions and graphs remain unchanged.

- **Graph counts:** removing all overrides retains 2,142 edge rows, removes 985
  and adds six: 3,127 − 985 + 6 = 2,148. The original graph contains one complete
  record twice. Counting distinct complete records instead gives 984 removals.
  The audit reports both bases for the baseline and all five variants. Identical
  graph records do not establish duplicate on-chain events.
- **Raw amounts:** the saved JSON-RPC response contains calldata amount
  `0x005ee4d662d96ab0` and transaction value `0x5ee4d662d96aae`, a 2-wei difference.
  Direct integer extraction and the preserved normalization records agree.
  The audit does not identify the cause upstream of the archived response,
  authenticate a transaction signature, or validate chain consensus.

## Run the two standalone checks

Extract the ZIP to a short, new directory. Open a terminal **inside
`VCA_integrity_review`** and use Python 3.11 or later:

```text
python -B run_checks.py --output-dir review_run
```

No network access or additional Python packages are needed for these two checks.
The runner verifies every manifest-listed file before and after the calculations.
It creates new reports and compares them with the supplied references, ignoring
only the edge report's execution timestamp. Each calculation runs in a separate
process with socket/DNS blocking. Read `review_run/RESULT.json` and both execution
logs. The result must contain `PASS` for `edge_audit` and `wei_audit`.

An existing output directory is refused. Keep failed attempts and use a new name
on a subsequent run. Do not overwrite the reference reports or original graphs.
The outer ZIP checksum is supplied in the download manifest and review channel;
the internal manifest alone does not authenticate its publisher.

## Optional execution of the original decoder path

The `wei_runtime` record additionally reports actual execution of the unchanged
VCA normalizer and decoder: 96 matching normalizations, the original rank-65
rejection, and four controls. Two controls make the amounts equal **in memory**
and decode successfully. They do not modify the original input or the 46/96 result.

To repeat this optional check, use the locked Python 3.12.13 environment installed
from revision 5. From `VCA_integrity_review`, substitute its actual executable path:

```text
python -B run_checks.py --output-dir review_with_runtime --with-runtime --python PATH_TO_REVISION5_PYTHON
```

This runs all three checks. The preserved VCA modules are included here and their
loaded file hashes are recorded. The interpreter supplies the locked dependencies;
no environment installation or online acquisition is performed by the runner.
Optional runtime evidence is separate from the dependency-free raw-hex check.

## Files and provenance

`experiments/revision_v6_integrity/edge_audit.json` contains the common, removed,
added and duplicate records. `wei_audit.json` links the exact raw response hash,
field locations, 96 predictions, integer conversion path, and period-wise ETH
partition results. `wei_runtime.json` records the actual decoder path and controls.
Their adjacent Python files implement each recalculation.

All raw request/response and frozen code bytes are preserved. Two metadata files
are published derivatives: local user-directory prefixes in
`first_predictions.file_reads_observed` are redacted, and the corresponding
`capture_state.first_predictions_sha256` is updated. `ANONYMIZATION.json` records
the original and published hashes and changed fields. Prediction rows, evaluation
rows, selections and monetary values are unchanged. The original local files are
retained, and this redaction is not a new pre-evaluation commitment.

See [the review guide](REVIEW_GUIDE.md) for the complete section–archive–command
mapping and for the separate purposes of the 40, 96, 11, 3 and 1-case sets.
