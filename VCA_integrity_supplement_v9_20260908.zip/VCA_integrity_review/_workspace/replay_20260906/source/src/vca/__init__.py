"""VCA — Virtual asset Crime Analyzer."""

__version__ = "0.0.0"

__all__ = ["__version__"]
