"""SQLAlchemy 2.0 ORM models for the P0 / P1 persistence layer.

P0-005 shipped the foundation tables: :class:`Case`, :class:`Chain`,
:class:`Address`, :class:`Transaction`, and :class:`RawResponse`. P1-016
extends the schema with three graph tables — :class:`GraphNodeRow`,
:class:`FlowEdgeRow`, and :class:`CaseStage` — that round-trip a frozen
:class:`vca.tracer.CaseGraph` and :class:`vca.tracer.stage_classifier.StageAssignment`
pair byte-equal under :class:`vca.persistence.GraphRepository`.

Schemas mirror the contracts in ``_workspace/P0-005_architect_wbs.md`` §3,
``_workspace/P1-016_architect_wbs.md`` §4, and ``ARCHITECTURE.md`` §4.1.

Type choices favour PostgreSQL/SQLite portability:

* UUID columns use ``String(36)`` so SQLite stays viable for tests.
* ``DateTime(timezone=True)`` lets PostgreSQL persist tz-aware values; SQLite
  passes them through unchanged.
* ``Numeric(40, 0)`` represents wei/satoshi totals without precision loss on
  PostgreSQL.  SQLite stores the value as text via NUMERIC affinity, which is
  acceptable for migration tests.
* ``Numeric(78, 0)`` (graph tables) covers ``2**256 - 1`` (max EVM wei) plus
  one safety digit. Documented in migration 0004.
* Closed enums (StageLabel/EdgeKind/TerminationReason) persist as
  ``String(N)`` + named CHECK; native PG ENUM is intentionally NOT used for
  SQLite parity (``R-CLOSED-VOCAB-PERSIST``).

The ``GraphNodeRow`` ORM class is named with a ``Row`` suffix to disambiguate
the in-memory :class:`vca.tracer.graph.GraphNode` Pydantic DTO when both
modules are imported in the same translation unit. ``FlowEdgeRow`` mirrors
the same pattern. Persistence consumers import the ORM rows under the plain
names from this module; tracer consumers import the DTOs from
:mod:`vca.tracer.graph`.

Foreign keys to tables introduced in later migrations (e.g. ``cluster``) are
deliberately omitted; their columns stay nullable until the relevant FK
constraint is added in a follow-up revision.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    DateTime,
    Dialect,
    Float,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    TypeDecorator,
    false,
    func,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from vca.tracer.graph import EdgeKind, TerminationReason
from vca.tracer.stage_classifier import StageLabel


class BigDecimal(TypeDecorator[Decimal]):
    """Numeric column type that round-trips ``Decimal`` losslessly on SQLite.

    PostgreSQL preserves ``Numeric(precision, scale)`` exactly, but SQLite's
    NUMERIC affinity stores values that exceed 64-bit signed range as
    ``REAL`` — a 22-digit ``value_minor`` like ``116500000000000000000000``
    wei round-trips with float-precision drift (last seven digits replaced
    by the nearest representable double). The persistence layer needs
    byte-equal round-trip for ``R-DETERMINISTIC-RT``, so this decorator
    coerces SQLite to ``TEXT`` storage (with ``Decimal`` round-trip on
    bind/result) while keeping the documented ``Numeric(p, s)`` type on
    PostgreSQL where native precision works.
    """

    impl = Numeric
    cache_ok = True

    def __init__(self, *, precision: int, scale: int) -> None:
        super().__init__()
        self._precision: int = precision
        self._scale: int = scale

    def load_dialect_impl(self, dialect: Dialect) -> Any:
        if dialect.name == "sqlite":
            return dialect.type_descriptor(Text())
        return dialect.type_descriptor(Numeric(precision=self._precision, scale=self._scale))

    def process_bind_param(self, value: Decimal | int | None, dialect: Dialect) -> Any:
        if value is None:
            return None
        if dialect.name == "sqlite":
            # Render integer-valued decimals without a trailing ``.``,
            # so the TEXT round-trip matches the original integer
            # representation byte-for-byte.
            if isinstance(value, int) and not isinstance(value, bool):
                return str(value)
            dec = Decimal(value) if not isinstance(value, Decimal) else value
            return format(dec, "f")
        return value

    def process_result_value(self, value: Any, dialect: Dialect) -> Decimal | None:
        if value is None:
            return None
        if isinstance(value, Decimal):
            return value
        return Decimal(value)


class Base(DeclarativeBase):
    """Common declarative base shared by every VCA persistence model."""


def _new_uuid() -> str:
    """Return a fresh UUID4 as a 36-character string (DB-portable)."""
    return str(uuid.uuid4())


class Case(Base):
    """Investigation case (one per incident, e.g. ``"kelpdao"``)."""

    __tablename__ = "case"

    case_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    victim: Mapped[str] = mapped_column(String(255), nullable=False)
    exploit_tx: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    attribution: Mapped[str | None] = mapped_column(String(255), nullable=True)
    severity_usd: Mapped[Decimal | None] = mapped_column(Numeric(20, 2), nullable=True)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, server_default="open")
    summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_by: Mapped[str | None] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )


class Chain(Base):
    """Blockchain registry (Ethereum, Arbitrum, Bitcoin, ...)."""

    __tablename__ = "chain"

    chain_id: Mapped[str] = mapped_column(String(8), primary_key=True)
    name: Mapped[str] = mapped_column(String(64), nullable=False)
    native_symbol: Mapped[str] = mapped_column(String(8), nullable=False)
    scanner_base_url: Mapped[str | None] = mapped_column(String(255), nullable=True)


class Address(Base):
    """Wallet/contract address scoped by :class:`Chain`."""

    __tablename__ = "address"
    __table_args__ = (Index("ix_address_chain_addr", "chain_id", "address"),)

    address_id: Mapped[str] = mapped_column(String(80), primary_key=True)
    chain_id: Mapped[str] = mapped_column(String(8), ForeignKey("chain.chain_id"), nullable=False)
    # Widened to ``String(80)`` in migration 0002 (round-8 P2-24): max-length
    # BTC bech32m P2TR mainnet addresses are 74 chars, exceeding the original
    # 64-char ceiling. The new bound matches ``address_id`` / ``tx_id``.
    address: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    first_seen_block: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    first_seen_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    label_primary: Mapped[str | None] = mapped_column(String(128), nullable=True)
    cluster_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    risk_score: Mapped[float | None] = mapped_column(Float, nullable=True)


class Transaction(Base):
    """On-chain transaction record (EVM or UTXO)."""

    __tablename__ = "transaction"

    tx_id: Mapped[str] = mapped_column(String(80), primary_key=True)
    chain_id: Mapped[str] = mapped_column(
        String(8), ForeignKey("chain.chain_id"), nullable=False, index=True
    )
    hash: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    block_number: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    block_time: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    # ``String(80)`` accommodates BTC bech32m P2TR mainnet addresses up to
    # 74 chars (round-8 P2-24); see migration 0002 for the schema upgrade.
    from_addr: Mapped[str | None] = mapped_column(String(80), nullable=True, index=True)
    to_addr: Mapped[str | None] = mapped_column(String(80), nullable=True, index=True)
    # ``Numeric(40, 0)`` is a PLAIN numeric column — NOT the ``BigDecimal``
    # TEXT-affinity decorator (models.py:69) that ``FlowEdgeRow.value_minor``
    # uses. On SQLite this maps to NUMERIC affinity and round-trips through a
    # float64, so any integer above ``2**53`` (~9.0e15, ~16 digits) silently
    # loses precision — e.g. "1 ETH + 7 wei" (``10**18 + 7``) reads back as
    # ``10**18``. This is SAFE only because the column is DORMANT: the
    # discovered-row materialiser
    # (``case_materialize._upsert_discovered_transactions``) never writes it
    # (always NULL) and case bootstrap sets it to ``0``. The authoritative
    # per-edge amount is ``FlowEdgeRow.value_minor`` (``BigDecimal(78, 0)``,
    # exact). Do NOT write a wei-scale value here without first switching this
    # column to ``BigDecimal`` — guarded by
    # ``tests/unit/persistence/test_transaction_value_native_dormant.py``.
    value_native: Mapped[Decimal | None] = mapped_column(Numeric(40, 0), nullable=True)
    gas_used: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    status: Mapped[int | None] = mapped_column(Integer, nullable=True)
    raw_json_uri: Mapped[str | None] = mapped_column(String(512), nullable=True)
    # P1-012 R2 P2-2: optional EVM calldata. Mirrors
    # :attr:`vca.types.normalized.NormalizedTransaction.input`. ``Text`` so
    # large bridge calldata round-trips without a fixed-width ceiling; the
    # column is nullable because BTC and contract-creation rows have no
    # calldata. See migration ``0003_add_transaction_input_column``.
    input: Mapped[str | None] = mapped_column(Text, nullable=True)


class RawResponse(Base):
    """Raw external-API response with deduplication key (source, params_hash)."""

    __tablename__ = "raw_response"
    __table_args__ = (Index("ix_raw_response_source_params", "source", "params_hash"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_new_uuid)
    source: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    endpoint: Mapped[str] = mapped_column(String(255), nullable=False)
    params_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    fetched_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )
    status_code: Mapped[int | None] = mapped_column(Integer, nullable=True)
    storage_uri: Mapped[str] = mapped_column(String(512), nullable=False)
    ttl: Mapped[int | None] = mapped_column(Integer, nullable=True)


# ---------------------------------------------------------------------------
# P1-016 graph tables — see ``_workspace/P1-016_architect_wbs.md`` §4.
# ---------------------------------------------------------------------------


def _quote_sql_str(value: str) -> str:
    """Return *value* SQL-escaped as a single-quoted literal.

    ``repr(value)`` is intentionally NOT used: Python's repr emits ``\\u``
    escapes for non-ASCII characters (e.g. the ``추적 종료`` StageLabel),
    which would store a different byte sequence than the actual enum value
    inside the SQL CHECK list. Manual quoting keeps the literal byte-equal
    to the persisted column value across SQLite and PostgreSQL.
    """
    return "'" + value.replace("'", "''") + "'"


def _vocab_in_clause(column: str, values: tuple[str, ...]) -> str:
    """Build ``column IN (...)`` from *values* using SQL-safe quoting.

    Single source of truth for closed-enum CHECK constraints — the value
    list is computed inline from the Python enum at module load so
    ``alembic`` autogeneration stays aligned with the declarative model.
    """
    joined = ", ".join(_quote_sql_str(v) for v in values)
    return f"{column} IN ({joined})"


# Pre-computed value tuples for closed enums — built once at module load
# from the canonical Python definitions (``R-CLOSED-VOCAB-PERSIST``).
_STAGE_LABEL_VALUES: tuple[str, ...] = tuple(s.value for s in StageLabel)
_EDGE_KIND_VALUES: tuple[str, ...] = tuple(k.value for k in EdgeKind)
_TERMINATION_REASON_VALUES: tuple[str, ...] = tuple(r.value for r in TerminationReason)


class GraphNodeRow(Base):
    """One per ``(case_id, canonical_address_key)`` — see WBS §4.2.

    Stores ``GraphNode``-derived persistence rows; the Pydantic DTO lives
    in :class:`vca.tracer.graph.GraphNode`. Distinct names keep the two
    surfaces unambiguous at the import boundary.
    """

    __tablename__ = "graph_node"
    __table_args__ = (
        CheckConstraint("depth >= 0", name="ck_graph_node_depth_nonneg"),
        CheckConstraint("order_index >= 0", name="ck_graph_node_order_nonneg"),
        CheckConstraint(
            "termination_reason IS NULL OR "
            + _vocab_in_clause("termination_reason", _TERMINATION_REASON_VALUES),
            name="ck_graph_node_termination_reason_closed",
        ),
        Index("ix_graph_node_case_id", "case_id"),
        Index("ix_graph_node_case_terminal", "case_id", "terminal"),
        Index("ix_graph_node_case_order", "case_id", "order_index"),
    )

    # Composite PK ``(case_id, node_id)`` — codex round-1 P1 fix: a global
    # ``node_id`` PK collided when two saved cases shared the same address
    # (``canonical_address_key`` is chain-scoped but case-agnostic). Every
    # other graph table is already case-scoped via ``case_id``, so the
    # composite key keeps cross-case isolation intact.
    case_id: Mapped[str] = mapped_column(
        String(64),
        ForeignKey("case.case_id", ondelete="CASCADE"),
        primary_key=True,
    )
    node_id: Mapped[str] = mapped_column(String(96), primary_key=True)
    address_id: Mapped[str] = mapped_column(
        String(80),
        ForeignKey("address.address_id"),
        nullable=False,
    )
    depth: Mapped[int] = mapped_column(Integer, nullable=False)
    order_index: Mapped[int] = mapped_column(Integer, nullable=False)
    label_kind: Mapped[str | None] = mapped_column(String(32), nullable=True)
    # Codex round-1 P2 fix: ``label_json`` round-trips the full
    # :class:`vca.labeler.AddressLabel` (kind/source/confidence/evidence/
    # cluster_id/extras/observed_at) so ``GraphNode.label`` survives the
    # save/load cycle. ``label_kind`` stays as a denormalised query-helper
    # column. NULL when the node has no label.
    label_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    first_seen_tx_id: Mapped[str] = mapped_column(
        String(80),
        ForeignKey("transaction.tx_id"),
        nullable=False,
    )
    first_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    # Codex round-2 P1 fix: ``server_default="0"`` compiles to
    # ``BOOLEAN DEFAULT 0`` on PostgreSQL, which PG rejects (PG demands
    # ``false`` / ``true``). ``false()`` lets SQLAlchemy emit the
    # dialect-correct literal on both SQLite and Postgres.
    terminal: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=false())
    termination_reason: Mapped[str | None] = mapped_column(String(32), nullable=True)
    address_value: Mapped[str] = mapped_column(String(80), nullable=False)


class FlowEdgeRow(Base):
    """One per directed edge inside a :class:`Case` graph — see WBS §4.1.

    PK is the **bounded surrogate** ``edge_pk`` (codex round-7 P2 fix):
    a fixed 64-char SHA-256 hex digest of the post-sort
    ``edge_id_by_index`` value. The human-readable ``edge_id`` stays as
    a non-PK ``Text`` column for query convenience.

    Why the surrogate: PostgreSQL's btree index has a per-entry size
    limit (~2.7KB on default 8KB pages). Round 6 widened ``edge_id`` to
    unbounded ``Text``, but ``edge_id`` was the PK column — a FlowEdge
    with a multi-KB decoder produces an ``edge_id`` over the limit, so
    PG would reject the insert (SQLite has no btree limit on PKs and
    masks the failure mode). Hashing to a fixed 64-char digest pulls
    the PK column comfortably under the btree limit while preserving
    deterministic equality (modulo SHA-256 collision resistance — i.e.
    a non-issue in practice).

    No ``UNIQUE`` constraint on ``edge_id``: a unique index would have
    the same btree-size problem, and the surrogate already enforces
    edge uniqueness by construction (``edge_pk`` is a deterministic
    function of ``edge_id``, so two distinct ``edge_id`` values produce
    two distinct ``edge_pk`` digests with overwhelming probability).
    """

    __tablename__ = "flow_edge"
    __table_args__ = (
        CheckConstraint(
            _vocab_in_clause("kind", _EDGE_KIND_VALUES),
            name="ck_flow_edge_kind_closed",
        ),
        CheckConstraint(
            _vocab_in_clause("stage_label", _STAGE_LABEL_VALUES),
            name="ck_flow_edge_stage_label_closed",
        ),
        CheckConstraint(
            "decimals BETWEEN 0 AND 36",
            name="ck_flow_edge_decimals_range",
        ),
        CheckConstraint("order_index >= 0", name="ck_flow_edge_order_nonneg"),
        Index("ix_flow_edge_case_id", "case_id"),
        Index("ix_flow_edge_case_order", "case_id", "order_index"),
        Index("ix_flow_edge_src", "src_address_id"),
        Index("ix_flow_edge_dst", "dst_address_id"),
        Index("ix_flow_edge_via_tx", "via_tx_id"),
        Index("ix_flow_edge_case_kind", "case_id", "kind"),
        Index("ix_flow_edge_case_stage", "case_id", "stage_label"),
        Index("ix_flow_edge_case_src", "case_id", "src_address_id"),
    )

    # Composite PK ``(case_id, edge_pk)`` — codex round-7 P2 fix: the
    # post-sort ``edge_id`` value is unbounded ``Text`` (round 6) and
    # could overflow the PostgreSQL btree per-entry size limit
    # (~2.7KB) when the encoded edge id exceeds the limit. ``edge_pk``
    # is a deterministic 64-char SHA-256 hex digest of the same string
    # — fixed-width, comfortably under any btree limit, and unique by
    # construction. The human-readable ``edge_id`` stays as a non-PK
    # ``Text`` column for query convenience and round-trip fidelity.
    # Codex round-1 P1 fix (still active): ``case_id`` is the leading
    # PK column so two cases sharing the same ``edge_pk`` digest stay
    # isolated.
    case_id: Mapped[str] = mapped_column(
        String(64),
        ForeignKey("case.case_id", ondelete="CASCADE"),
        primary_key=True,
    )
    # Codex round-7 P2 fix: bounded SHA-256 digest of ``edge_id`` — see
    # class docstring for the btree-size rationale.
    edge_pk: Mapped[str] = mapped_column(String(64), primary_key=True)
    # Codex round-6 P2 fix: ``edge_id`` widened from ``String(512)`` to
    # ``Text`` (unbounded). Codex round-7 P2 fix: ``edge_id`` is no
    # longer the PK — the bounded ``edge_pk`` surrogate above takes
    # over so the btree index entries stay under PostgreSQL's per-entry
    # size limit.
    edge_id: Mapped[str] = mapped_column(Text, nullable=False)
    order_index: Mapped[int] = mapped_column(Integer, nullable=False)
    src_address_id: Mapped[str] = mapped_column(
        String(80),
        ForeignKey("address.address_id"),
        nullable=False,
    )
    dst_address_id: Mapped[str] = mapped_column(
        String(80),
        ForeignKey("address.address_id"),
        nullable=False,
    )
    src_chain: Mapped[str] = mapped_column(
        String(8),
        ForeignKey("chain.chain_id"),
        nullable=False,
    )
    dst_chain: Mapped[str] = mapped_column(
        String(8),
        ForeignKey("chain.chain_id"),
        nullable=False,
    )
    via_tx_id: Mapped[str | None] = mapped_column(
        String(80),
        ForeignKey("transaction.tx_id"),
        nullable=True,
    )
    kind: Mapped[str] = mapped_column(String(16), nullable=False)
    value_minor: Mapped[Decimal | None] = mapped_column(
        BigDecimal(precision=78, scale=0), nullable=True
    )
    asset_symbol: Mapped[str] = mapped_column(String(32), nullable=False)
    decimals: Mapped[int] = mapped_column(Integer, nullable=False)
    # scan #16 Lens B: the moved token's on-chain ``(chain, contract)`` identity,
    # stored as the canonical ``"{chain}:{value}"`` string (mirrors
    # ``src_address_id``). Nullable — native-coin / self-loop edges carry ``None``.
    # Migration 0007 adds it. Distinct from ``asset_symbol`` (which keeps the
    # placeholder ``"ERC20"`` for synthesized edges).
    asset_contract: Mapped[str | None] = mapped_column(String(80), nullable=True)
    # Codex round-6 P2 fix: ``decoder`` widened from ``String(255)`` to
    # ``Text`` (unbounded). The public :class:`vca.tracer.graph.FlowEdge`
    # DTO enforces the ``[a-z0-9_.-]+`` charset with NO max-length cap, so
    # ``String(255)`` would still let PostgreSQL reject a 300-char value
    # at INSERT (round 5 only widened the ceiling, didn't remove it).
    # Adding a max-length to the DTO would violate R-NO-FREEZE-CHANGE,
    # so the schema accepts whatever the DTO admits. ``Text`` has no
    # length bound on PG and is identical to ``String`` on SQLite.
    decoder: Mapped[str | None] = mapped_column(Text, nullable=True)
    block_number: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    block_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    stage_label: Mapped[str] = mapped_column(String(32), nullable=False)
    rationale: Mapped[str] = mapped_column(String(256), nullable=False)
    extras_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    hop_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    # Codex round-8 P2 fix: ``detected_at`` no longer has
    # ``server_default=func.now()``. Pre-fix, every save evaluated
    # ``now()`` server-side because the save path is DELETE-then-INSERT
    # (R-IDEMPOTENT-WRITE) — re-saving a byte-identical
    # ``(graph, assignment)`` flipped the column to a fresh wall-clock
    # value, surfacing as a spurious "row updated" signal to any
    # consumer reading ``detected_at``. The mapper now derives the
    # value deterministically from
    # :attr:`vca.tracer.graph.TraceMetrics.finished_at` (Option A in
    # the codex round-8 review) so the column reflects "when was this
    # case last classified" — semantically meaningful and stable per
    # CaseGraph content. The column stays NOT NULL; the mapper
    # populates it on every insert. Migration 0004 drops the
    # ``server_default`` in lock-step (the table is fresh in 0004, no
    # backward-compat path needed).
    detected_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
    )


class CaseGraphMeta(Base):
    """Per-case envelope for ``CaseGraph.metadata`` / ``metrics`` round-trip.

    Phase 1 deviation from ``_workspace/P1-016_architect_wbs.md`` §4 — the
    WBS lists three tables (``graph_node`` / ``flow_edge`` / ``case_stage``)
    but DoD-5 (``R-DETERMINISTIC-RT``) requires the loader to reproduce the
    input pair's ``model_dump_json()`` byte-equal, including ``metadata``
    (recursive-frozen mapping) and ``metrics`` (:class:`TraceMetrics`).
    Neither field has a home in the WBS schema, so we add a single-row
    envelope keyed by ``case_id`` with two ``Text`` columns holding
    deterministic JSON. No CHECK constraints — both payloads are
    free-form Pydantic dumps.

    Codex round-4 P2 fix: dropped the denormalised ``seed_chain`` /
    ``seed_tx_hash`` columns. ``seed_tx_id`` (canonical
    ``f"{chain}:{tx_hash}"`` form, FK to ``transaction.tx_id``) is now
    the single source of truth for the seed transaction. The previous
    schema allowed a raw INSERT to set ``seed_tx_id`` to one tx and
    ``seed_tx_hash`` to a different tx; both halves passed FK + NOT
    NULL checks but the load path read the wrong pair, reconstructing
    a :class:`TxRef` that pointed at a non-existent transaction.
    Parsing ``seed_tx_id`` at load time eliminates the skew. The
    column format already matches the rest of the schema
    (``graph_node.first_seen_tx_id``, ``flow_edge.via_tx_id``).

    The deviation is documented in ``_workspace/P1-016_builder_notes.md``.
    """

    __tablename__ = "case_graph_meta"

    case_id: Mapped[str] = mapped_column(
        String(64),
        ForeignKey("case.case_id", ondelete="CASCADE"),
        primary_key=True,
    )
    # Codex round-4 P2 fix: ``seed_tx_id`` is the single source of
    # truth for the seed transaction (canonical
    # ``f"{chain}:{tx_hash}"`` form, FK to ``transaction.tx_id``). The
    # ``seed_chain`` / ``seed_tx_hash`` columns were dropped to
    # eliminate the skew possibility documented in the class docstring.
    seed_tx_id: Mapped[str] = mapped_column(
        String(80),
        ForeignKey("transaction.tx_id"),
        nullable=False,
    )
    metadata_json: Mapped[str] = mapped_column(Text, nullable=False)
    metrics_json: Mapped[str] = mapped_column(Text, nullable=False)


class CaseStage(Base):
    """Per-case stage rollup — see WBS §4.3.

    Phase 1 leaves ``agg_value_native`` ``NULL`` when callers do not
    pre-compute it (USD pricing is Phase 2). The :class:`GraphRepository`
    accepts an empty stages tuple and writes zero rows.

    Codex round-7 P2 fix: ``id`` is a deterministic 64-char SHA-256 hex
    digest of ``f"{case_id}|{order_index}|{stage_label}"`` (computed in
    :func:`vca.persistence._graph_mappers.case_stage_to_row`) instead
    of a fresh ``uuid4``. Re-saving the same ``(graph, assignment,
    stages)`` tuple now produces byte-equal ``case_stage.id`` values
    — required for ``R-IDEMPOTENT-WRITE`` so consumers (audit logs,
    later joins) can track stages stably across saves. The ``(case_id,
    order_index, stage_label)`` triple is naturally unique per the WBS
    contract, so the digest is collision-free for any valid input.
    """

    __tablename__ = "case_stage"
    __table_args__ = (
        CheckConstraint("order_index >= 0", name="ck_case_stage_order_nonneg"),
        CheckConstraint("edge_count >= 0", name="ck_case_stage_edge_count_nonneg"),
        CheckConstraint("end_at >= start_at", name="ck_case_stage_window"),
        CheckConstraint(
            _vocab_in_clause("stage_label", _STAGE_LABEL_VALUES),
            name="ck_case_stage_label_closed",
        ),
        Index("ix_case_stage_case_order", "case_id", "order_index"),
    )

    # Codex round-7 P2 fix: widened from ``String(36)`` (uuid4) to
    # ``String(64)`` (SHA-256 hex digest). The default factory was
    # removed because the mapper now derives ``id`` deterministically
    # from ``(case_id, order_index, stage_label)``.
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    case_id: Mapped[str] = mapped_column(
        String(64),
        ForeignKey("case.case_id", ondelete="CASCADE"),
        nullable=False,
    )
    order_index: Mapped[int] = mapped_column(Integer, nullable=False)
    stage_label: Mapped[str] = mapped_column(String(32), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    start_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    end_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    agg_value_native: Mapped[Decimal | None] = mapped_column(
        BigDecimal(precision=78, scale=0), nullable=True
    )
    edge_count: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        server_default="0",
    )


# ---------------------------------------------------------------------------
# P3-012 annotation table — see ``docs/plan/PHASE3_UI_PLAN.md`` §P3-012.
# ---------------------------------------------------------------------------


class CaseAnnotationRow(Base):
    """Analyst annotation attached to a node/edge of one case graph.

    The ONLY hard FK is ``case_id`` (codex P3 R5 P1):
    ``GraphRepository.save_case_graph`` DELETEs + reinserts the
    ``graph_node`` / ``flow_edge`` rows on every case re-run, so a hard
    FK to those rows would either fail the re-save (RESTRICT) or
    cascade-delete the analyst's annotations. Targets are therefore
    STABLE CONTENT KEYS stored as ``(target_kind, target_key)``:

    * ``target_kind == "node"`` — ``target_key`` is the canonical
      address key (matches ``graph_node.node_id``, ``String(96)``).
    * ``target_kind == "edge"`` — ``target_key`` is the FULL 64-hex
      ``flow_edge.edge_pk`` SHA-256 digest (codex R6: the redacted
      ``<edge:XXXXXXXX>`` 8-hex token is a LOG format and
      collision-prone as a key; ``edge_pk`` is collision-free and
      survives delete/reinsert).

    The surrogate PK ``annotation_id`` (Integer autoincrement) is part
    of the table contract (codex R12): P3-013's
    ``PUT/DELETE .../{annotation_id}`` item routes need an unambiguous
    item identifier.

    NO CHECK constraint on purpose — the ``target_kind`` vocabulary is
    enforced in Python at :mod:`vca.persistence._annotation_mappers`,
    keeping the closed-vocab persistence audits scoped to the graph
    tables. Timestamps carry no server default (the ``detected_at``
    lesson — codex P1-016 round 8): the mapper supplies explicit
    tz-aware UTC values.
    """

    __tablename__ = "case_annotation"
    # ``sqlite_autoincrement`` (codex P3-012 P2): without the SQLite
    # ``AUTOINCREMENT`` keyword, deleting the highest-numbered annotation
    # lets SQLite REUSE that rowid on the next insert — a stale P3-013
    # ``PUT/DELETE .../{annotation_id}`` could then hit a newly-created
    # annotation. PostgreSQL sequences never reuse; this flag restores
    # monotonic-id parity on SQLite (no-op on other dialects). Mirrored
    # in migration 0005.
    __table_args__ = (
        Index("ix_case_annotation_case_id", "case_id"),
        Index("ix_case_annotation_case_target", "case_id", "target_kind", "target_key"),
        {"sqlite_autoincrement": True},
    )

    annotation_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    case_id: Mapped[str] = mapped_column(
        String(64),
        ForeignKey("case.case_id", ondelete="CASCADE"),
        nullable=False,
    )
    target_kind: Mapped[str] = mapped_column(String(8), nullable=False)
    target_key: Mapped[str] = mapped_column(String(96), nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


# ---------------------------------------------------------------------------
# P3.3-001 web settings table — see
# ``_workspace/p3_3_web_settings_architect_wbs.md`` §2.
# ---------------------------------------------------------------------------


class WebSettingRow(Base):
    """Single-row-per-key web dashboard setting (P3.3-001).

    The web settings store is one key-value table. Unlike
    ``case_annotation`` (which needs a surrogate ``annotation_id`` for its
    ``PUT/DELETE .../{annotation_id}`` item routes), settings are
    addressed by KEY and never by row id — so the PK is the NATURAL string
    ``setting_key`` (``String(64)``) and each key is its own natural
    upsert target. This is the single deliberate divergence from the
    annotation mirror; consequently there is NO ``sqlite_autoincrement``
    flag (no surrogate id to keep monotonic).

    ``value`` is ``Text`` — a charset-only field holding the string
    serialization of every setting type; the typing/validation lives in
    Python at :mod:`vca.web._settings_schema`, NOT a DB CHECK (the
    closed-vocab persistence audits stay scoped to the graph tables).

    ZERO foreign keys — settings are global, not case-scoped (the mirror
    of ``case_annotation``'s "ONLY hard FK" discipline is a documented
    ZERO-FK rationale). NO CHECK constraint and no server default; the
    mapper supplies explicit tz-aware UTC for ``updated_at`` (the
    ``detected_at`` lesson — codex P1-016 round 8).
    """

    __tablename__ = "web_setting"

    setting_key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str] = mapped_column(Text, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


__all__ = [
    "Address",
    "Base",
    "Case",
    "CaseAnnotationRow",
    "CaseGraphMeta",
    "CaseStage",
    "Chain",
    "FlowEdgeRow",
    "GraphNodeRow",
    "RawResponse",
    "Transaction",
    "WebSettingRow",
]
