"""Graph persistence repository (P1-016).

Pure synchronous repository that round-trips the in-memory
:class:`vca.tracer.graph.CaseGraph` and
:class:`vca.tracer.stage_classifier.StageAssignment` pair through four
ORM tables (:class:`GraphNodeRow`, :class:`FlowEdgeRow`, :class:`CaseStage`,
:class:`CaseGraphMeta`) defined in :mod:`vca.persistence.models`.

R-rules (see ``_workspace/P1-016_architect_wbs.md`` §7):

* ``R-PURE-REPO`` — no classification, no HTTP, no decoding.
* ``R-ATOMIC-WRITE`` — every write runs in the caller's open
  :class:`Session`; this module never calls ``session.commit()``.
* ``R-IDEMPOTENT-WRITE`` — DELETE-then-INSERT per ``case_id`` so
  re-saving the same input produces zero net delta.
* ``R-FK-INTEGRITY`` — strict-mode preflight: missing ``Case`` /
  ``Chain`` / ``Address`` / ``Transaction`` raises
  :class:`GraphPersistenceError`.
* ``R-DETERMINISTIC-RT`` — :func:`GraphRepository.load_case_graph`
  reconstructs DTOs whose ``model_dump_json()`` is byte-equal to the
  inputs.
* ``R-CLOSED-VOCAB-PERSIST`` — :class:`StageLabel` /
  :class:`EdgeKind` / :class:`TerminationReason` persist as their
  ``.value`` strings; CHECK constraints (defined in :mod:`models`)
  enforce the vocab.
* ``R-NEO4J-OFF`` — the module never imports any Neo4j SDK; the
  Cypher exporter is a Phase-2 stub raising :class:`NotImplementedError`.

Mapper helpers, the :class:`CaseStageInput` DTO, and the
:class:`GraphPersistenceError` exception live in
:mod:`vca.persistence._graph_mappers` so this module stays under the
WBS R-FILE-CAP soft cap (600 LoC).

The :class:`GraphNode` ORM table collides with the
:class:`vca.tracer.graph.GraphNode` Pydantic DTO — disambiguation is
handled in :mod:`vca.persistence.models` where the ORM class is named
``GraphNodeRow`` (and ``FlowEdgeRow`` mirrors the pattern).
"""

from __future__ import annotations

import decimal
import json
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol, cast

from pydantic import ValidationError
from sqlalchemy import delete, insert, select
from sqlalchemy.engine import CursorResult
from sqlalchemy.orm import Session

from vca.observability.logging import get_logger
from vca.persistence._graph_mappers import (
    CaseStageInput,
    GraphPersistenceError,
    _atomic_write_text,
    _redact,
    _redact_edge_id,
    _storage_json,
    case_stage_to_row,
    flow_edge_to_row,
    graph_node_to_row,
    row_to_flow_edge,
    row_to_graph_node,
)
from vca.persistence.models import Address as AddressRow
from vca.persistence.models import Case as CaseRow
from vca.persistence.models import (
    CaseGraphMeta,
    CaseStage,
    FlowEdgeRow,
    GraphNodeRow,
)
from vca.persistence.models import Chain as ChainRow
from vca.persistence.models import Transaction as TransactionRow
from vca.tracer.graph import (
    CaseGraph,
    TerminationReason,
    TraceMetrics,
    TxRef,
    canonical_address_key,
)
from vca.tracer.graph import FlowEdge as DomainFlowEdge
from vca.tracer.graph import GraphNode as DomainGraphNode
from vca.tracer.stage_classifier import StageAssignment, StageLabel
from vca.tracer.stage_classifier._policy import StagePolicy
from vca.tracer.stage_classifier._priority import ClassifierContext
from vca.types import ChainId

_LOG = get_logger(__name__)


# ---------------------------------------------------------------------------
# Phase-2 Neo4j sink protocol — declared without an implementation.
# ---------------------------------------------------------------------------


class Neo4jSink(Protocol):
    """Phase-2 dual-write surface — no concrete implementation yet.

    Pinned by :mod:`tests.unit.persistence.test_graph_no_neo4j` to ensure
    the persistence layer never imports a Neo4j SDK in Phase 1
    (``R-NEO4J-OFF``).
    """

    def write(self, graph: CaseGraph, /) -> None:  # pragma: no cover - protocol
        ...


# ---------------------------------------------------------------------------
# Repository
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class _PreparedRows:
    """Internal DTO grouping the three row-dict batches built by ``prepare``."""

    node_rows: tuple[dict[str, Any], ...]
    edge_rows: tuple[dict[str, Any], ...]
    stage_rows: tuple[dict[str, Any], ...]


class GraphRepository:
    """Stateless DELETE-then-INSERT graph repository.

    Methods accept the caller's open :class:`Session`; the repository
    never opens or closes its own transaction. Pair with
    ``with session.begin():`` so a commit failure rolls back the entire
    save (R-ATOMIC-WRITE).
    """

    # ---- public surface ---------------------------------------------------

    def save_case_graph(
        self,
        session: Session,
        graph: CaseGraph,
        assignment: StageAssignment,
        *,
        stages: tuple[CaseStageInput, ...] = (),
    ) -> None:
        """Persist *graph* + *assignment* under *graph.case_id*.

        DELETE-then-INSERT semantics — re-saving the same pair produces
        zero net DB delta (R-IDEMPOTENT-WRITE). Strict FK preflight runs
        BEFORE any write so a missing :class:`Case` / :class:`Chain` /
        :class:`Address` / :class:`Transaction` raises before mutating
        the database.

        FK preflight always validates :attr:`CaseGraph.seed_tx` because
        :class:`CaseGraphMeta` writes ``seed_tx_id`` on every save —
        even for graphs with empty edges + nodes (e.g. a reverted seed)
        the seed transaction row must already exist (Codex round-2 P2
        fix).
        """
        if assignment.case_id != graph.case_id:
            raise GraphPersistenceError(
                f"assignment.case_id ({assignment.case_id!r}) != graph.case_id ({graph.case_id!r})"
            )

        ctx = ClassifierContext.build(graph, StagePolicy())
        edge_id_by_index: Mapping[int, str] = ctx.edge_id_by_index

        expected_keys = {edge_id_by_index[i] for i in range(len(graph.edges))}
        actual_keys = set(assignment.edge_labels.keys())
        missing = expected_keys - actual_keys
        extra = actual_keys - expected_keys
        if missing or extra:
            # Codex round-8 P2 fix: report COUNTS plus a small redacted
            # sample. ``edge_id`` concatenates source/dst canonical
            # address keys, the tx hash, ``value_minor``, decoder name,
            # asset symbol, decimals, and block timestamps — every
            # constituent the persistence layer otherwise redacts via
            # :func:`_redact`. Pre-fix, ``sorted(missing|extra)``
            # interpolated full ``edge_id`` strings into the exception
            # message, so a stray log line or CLI / API surface would
            # leak everything :func:`_redact` is paid to hide. The
            # redacted samples (``<edge:XXXXXXXX>`` — first 8 hex chars
            # of SHA-256) preserve operator-actionable diagnostics
            # (two reports naming distinct edges produce distinct
            # tokens) without exposing any constituent of the
            # original.
            sample_cap = 3
            graph_only_sample = [_redact_edge_id(e) for e in sorted(missing)[:sample_cap]]
            assignment_only_sample = [_redact_edge_id(e) for e in sorted(extra)[:sample_cap]]
            raise GraphPersistenceError(
                "assignment edge-id key set does not match graph edges: "
                f"graph_only_count={len(missing)}, "
                f"assignment_only_count={len(extra)}, "
                f"graph_only_sample={graph_only_sample}, "
                f"assignment_only_sample={assignment_only_sample}"
            )

        self._preflight_fk(session, graph)

        prepared = self._prepare_rows(graph, assignment, edge_id_by_index, stages)

        # DELETE-then-INSERT inside the caller's transaction. Order
        # matches FK direction: child rows first so FK targets remain
        # valid for the brief moment before reinsert.
        session.execute(delete(CaseStage).where(CaseStage.case_id == graph.case_id))
        session.execute(delete(FlowEdgeRow).where(FlowEdgeRow.case_id == graph.case_id))
        session.execute(delete(GraphNodeRow).where(GraphNodeRow.case_id == graph.case_id))
        session.execute(delete(CaseGraphMeta).where(CaseGraphMeta.case_id == graph.case_id))

        # Insert parent meta first so the envelope is present whenever
        # graph rows exist for the case. Codex round-1 P2 fix: use
        # :func:`_storage_json` (insertion-order preserving) so the
        # caller's :attr:`CaseGraph.metadata` key order survives the
        # save→load cycle byte-equal (R-DETERMINISTIC-RT).
        # Codex round-4 P2 fix: ``seed_tx_id`` is the SINGLE source of
        # truth (canonical ``f"{chain}:{tx_hash}"`` form, FK to
        # ``transaction.tx_id``). The denormalised ``seed_chain`` /
        # ``seed_tx_hash`` columns were dropped — the load path now
        # parses ``seed_tx_id`` itself, so the prior skew (raw INSERT
        # could set ``seed_tx_id`` and ``seed_tx_hash`` to different
        # transactions) is no longer expressible.
        meta_dump = graph.model_dump(mode="json")
        seed_tx_id = f"{graph.seed_tx.chain.value}:{graph.seed_tx.tx_hash}"
        session.execute(
            insert(CaseGraphMeta),
            [
                {
                    "case_id": graph.case_id,
                    "seed_tx_id": seed_tx_id,
                    "metadata_json": _storage_json(meta_dump["metadata"]),
                    "metrics_json": _storage_json(meta_dump["metrics"]),
                }
            ],
        )
        if prepared.node_rows:
            session.execute(insert(GraphNodeRow), list(prepared.node_rows))
        if prepared.edge_rows:
            session.execute(insert(FlowEdgeRow), list(prepared.edge_rows))
        if prepared.stage_rows:
            session.execute(insert(CaseStage), list(prepared.stage_rows))

        _LOG.info(
            "graph_persistence.save",
            case_id=graph.case_id,
            node_count=len(prepared.node_rows),
            edge_count=len(prepared.edge_rows),
            stage_count=len(prepared.stage_rows),
            seed_tx=_redact(graph.seed_tx.tx_hash),
        )

    def load_case_graph(self, session: Session, case_id: str) -> tuple[CaseGraph, StageAssignment]:
        """Reconstruct the frozen ``(CaseGraph, StageAssignment)`` pair.

        Raises :class:`LookupError` when no rows exist for *case_id*.
        """
        # ITER-50: the row-FETCH is itself a trust boundary. The DATETIME columns
        # (``graph_node.first_seen_at`` / ``flow_edge.block_time`` /
        # ``flow_edge.detected_at``, all ``DateTime(timezone=True)``) have no
        # strict SQLite storage type, so a corrupt stored value is fed to
        # SQLAlchemy's ``str_to_datetime`` result processor DURING
        # ``.scalars().all()`` — BEFORE any wrapped mapper runs. A corrupt TEXT
        # value raises ``ValueError`` (``Invalid isoformat string``); a non-text
        # value (SQLite loose typing lets an older writer store an int) raises
        # ``TypeError`` (``fromisoformat: argument must be str``). Wrap BOTH so the
        # corruption surfaces as the typed GraphPersistenceError like every other
        # corrupt-row failure (ITER-19/27/31/35/43). ``LookupError`` (the "no rows"
        # case below) is a subclass of neither → never swallowed. R-SECRET-SAFE:
        # omit the raw value/exc; ``from exc`` keeps the cause.
        try:
            node_rows = list(
                session.execute(
                    select(GraphNodeRow)
                    .where(GraphNodeRow.case_id == case_id)
                    .order_by(GraphNodeRow.order_index)
                )
                .scalars()
                .all()
            )
            edge_rows = list(
                session.execute(
                    select(FlowEdgeRow)
                    .where(FlowEdgeRow.case_id == case_id)
                    .order_by(FlowEdgeRow.order_index)
                )
                .scalars()
                .all()
            )
        except (ValueError, TypeError, decimal.InvalidOperation) as exc:
            # ITER-50 wrapped the corrupt-datetime fetch; ITER-63 broadens it to
            # the corrupt-Decimal case — a TEXT ``value_minor`` like ``"abc"``/``""``
            # makes ``BigDecimal.process_result_value`` raise ``decimal.InvalidOperation``
            # (an ArithmeticError, NOT ValueError/TypeError) DURING the fetch.
            raise GraphPersistenceError(
                f"case graph rows contain a malformed datetime or numeric value "
                f"for case_id={case_id!r}"
            ) from exc
        meta_row = session.get(CaseGraphMeta, case_id)
        if not node_rows and not edge_rows and meta_row is None:
            raise LookupError(f"no graph rows for case_id={case_id!r}")
        if meta_row is None:
            raise LookupError(
                f"missing case_graph_meta for case_id={case_id!r} "
                "(graph rows present without envelope — DB corruption)"
            )

        # Codex round-4 P2 fix: parse the canonical ``seed_tx_id`` itself
        # (``f"{chain}:{tx_hash}"``) — single source of truth. The
        # denormalised ``seed_chain`` / ``seed_tx_hash`` columns were
        # dropped so a raw INSERT can no longer skew the chain/hash pair
        # against the FK target.
        #
        # ITER-31: the seed parse is part of the same DB-row trust boundary
        # as the JSON envelopes wrapped below — a corrupt ``seed_tx_id`` (no
        # colon → ``ValueError`` from ``str.split``; unknown chain prefix →
        # ``ValueError`` from ``ChainId.from_str``; malformed hash →
        # ``pydantic.ValidationError`` from ``TxRef``) must surface as the
        # typed GraphPersistenceError, not leak out of the repository
        # (sibling-parity completion of ITER-19's stated invariant — the
        # ``seed_tx_id`` FK target may itself hold a malformed id written by
        # an older/buggy version). The message omits the raw value/cause
        # (R-SECRET-SAFE: pydantic echoes the tx hash); ``from exc`` keeps it
        # for server-side debugging.
        try:
            seed_chain_str, seed_tx_hash = meta_row.seed_tx_id.split(":", 1)
            seed_tx = TxRef(chain=ChainId.from_str(seed_chain_str), tx_hash=seed_tx_hash)
        except (ValueError, ValidationError) as exc:
            raise GraphPersistenceError(
                f"case_graph_meta.seed_tx_id is malformed for case_id={case_id!r}"
            ) from exc
        # The stored JSON envelopes are a trust boundary (DB rows may be
        # corrupt or written by an older/buggy version). Wrap the raw
        # deserialization so malformed content surfaces as the typed
        # GraphPersistenceError rather than leaking a raw json.JSONDecodeError
        # / pydantic.ValidationError out of the repository boundary.
        try:
            decoded_metadata = json.loads(meta_row.metadata_json)
        except json.JSONDecodeError as exc:
            raise GraphPersistenceError(
                f"case_graph_meta.metadata_json is not valid JSON for case_id={case_id!r}: {exc}"
            ) from exc
        if not isinstance(decoded_metadata, dict):
            raise GraphPersistenceError(
                "case_graph_meta.metadata_json must decode to a dict, "
                f"got: {type(decoded_metadata).__name__}"
            )
        # Metrics: parse via ``model_validate_json`` so ISO-8601 datetime
        # strings are coerced to ``datetime`` instances under strict mode.
        try:
            metrics = TraceMetrics.model_validate_json(meta_row.metrics_json)
        except ValidationError as exc:
            raise GraphPersistenceError(
                f"case_graph_meta.metrics_json failed TraceMetrics validation "
                f"for case_id={case_id!r}: {exc}"
            ) from exc

        # Walk the rows in stored ``order_index`` (already pinned by the
        # ``ORDER BY`` clauses above) so the loaded graph's ``nodes`` and
        # ``edges`` tuples are byte-equal to the input.
        nodes_in_order: list[DomainGraphNode] = [
            row_to_graph_node(node_row) for node_row in node_rows
        ]
        # Codex round-2 P2 fix: gate on ``termination_reason IS NOT
        # NULL`` rather than the ``terminal`` flag. ``CaseGraph`` allows
        # ``(terminal=False, terminal_reasons[key]=…)`` (the validator
        # only requires the key to appear in ``nodes`` — it does NOT
        # couple ``terminal`` and ``terminal_reasons``). Gating on
        # ``terminal=True`` would silently drop the reason on round-trip
        # when the saving caller had ``terminal=False``.
        # ITER-43: ``termination_reason`` / ``stage_label`` (below) are closed-
        # vocab StrEnum coercions on stored DB columns — the same DB-row trust
        # boundary as the seed/JSON parses wrapped above (CHECK constraints exist
        # on write but SQLite does not always enforce them, and an older/buggy
        # writer could persist an out-of-vocab value). Wrap both so a bad value
        # surfaces as the typed GraphPersistenceError, not a raw ValueError out
        # of the repository (R-SECRET-SAFE: redact the row id, omit the raw
        # value; ``from exc`` keeps the cause for server-side debugging).
        terminal_reasons: dict[str, TerminationReason] = {}
        for node_row in node_rows:
            if node_row.termination_reason is not None:
                try:
                    reason = TerminationReason(node_row.termination_reason)
                except ValueError as exc:
                    raise GraphPersistenceError(
                        f"graph_node.termination_reason is malformed for "
                        f"{_redact(node_row.address_id)}"
                    ) from exc
                key = canonical_address_key(row_to_graph_node(node_row).address)
                terminal_reasons[key] = reason

        edges: list[DomainFlowEdge] = []
        edge_labels: dict[str, StageLabel] = {}
        rationale: dict[str, str] = {}
        for edge_row in edge_rows:
            edges.append(row_to_flow_edge(edge_row))
            try:
                stage_label = StageLabel(edge_row.stage_label)
            except ValueError as exc:
                raise GraphPersistenceError(
                    f"flow_edge.stage_label is malformed for {_redact_edge_id(edge_row.edge_id)}"
                ) from exc
            edge_labels[edge_row.edge_id] = stage_label
            rationale[edge_row.edge_id] = edge_row.rationale

        # Iteration-76: the per-row mappers (ITER-19/27/31/35/43/50/63) wrap every
        # corrupt-value path, but the two AGGREGATE DTO assemblies carry cross-field
        # validators that run ONLY here — ``CaseGraph._validate_referential_integrity``
        # (an orphan ``flow_edge`` / ``graph_node`` row left by an interrupted
        # delete-then-insert, or a ``terminal_reasons`` key absent from the node set)
        # and ``StageAssignment._validate_rationale_charset`` (an empty / uppercase /
        # non-ASCII ``rationale`` from an older/buggy writer). Either raises a bare
        # ``ValueError`` that pydantic wraps as a raw ``ValidationError`` escaping the
        # typed ``GraphPersistenceError`` contract this module promises. R-SECRET-SAFE:
        # the message omits the raw value/exc (the validators echo addresses /
        # rationale); ``from exc`` preserves the cause.
        try:
            graph = CaseGraph(
                case_id=case_id,
                seed_tx=seed_tx,
                nodes=tuple(nodes_in_order),
                edges=tuple(edges),
                terminal_reasons=terminal_reasons,
                metrics=metrics,
                metadata=decoded_metadata,
            )
            assignment = StageAssignment(
                case_id=case_id,
                edge_labels=edge_labels,
                rationale=rationale,
            )
        except (ValueError, ValidationError) as exc:
            raise GraphPersistenceError(
                f"case graph rows fail DTO reconstruction for case_id={case_id!r}"
            ) from exc
        return graph, assignment

    def delete_case_graph(self, session: Session, case_id: str) -> int:
        """Drop graph rows for *case_id* and return the total row count.

        Drops ``case_stage`` → ``flow_edge`` → ``graph_node`` →
        ``case_graph_meta`` (child → parent so FK targets never block).
        Domain tables (``case``, ``address``, ``transaction``, ``chain``)
        are untouched.
        """
        deleted = 0
        for table_cls in (CaseStage, FlowEdgeRow, GraphNodeRow, CaseGraphMeta):
            stmt = delete(table_cls).where(table_cls.case_id == case_id)
            deleted += int(cast(CursorResult[Any], session.execute(stmt)).rowcount or 0)
        return deleted

    # ---- internal preflight + row preparation -----------------------------

    def _preflight_fk(self, session: Session, graph: CaseGraph) -> None:
        """Verify every Case / Chain / Address / Transaction FK exists."""
        case_row = session.get(CaseRow, graph.case_id)
        if case_row is None:
            raise GraphPersistenceError(f"missing FK row: case.case_id={graph.case_id!r}")

        required_chains: set[str] = {graph.seed_tx.chain.value}
        required_addresses: set[str] = set()
        # Codex round-2 P2 fix: seed_tx is always written into
        # ``case_graph_meta.seed_tx_id``, so its FK target must always
        # be validated — even when the graph has empty edges + nodes
        # (reverted seed scenario) and neither the edge nor node loop
        # below would otherwise add it.
        required_tx_ids: set[str] = {f"{graph.seed_tx.chain.value}:{graph.seed_tx.tx_hash}"}
        for node in graph.nodes:
            required_chains.add(node.address.chain.value)
            required_addresses.add(str(node.address))
            required_tx_ids.add(f"{node.first_seen_tx.chain.value}:{node.first_seen_tx.tx_hash}")
        for edge in graph.edges:
            required_chains.add(edge.source.chain.value)
            required_chains.add(edge.target.chain.value)
            required_addresses.add(str(edge.source))
            required_addresses.add(str(edge.target))
            if edge.tx_hash is not None:
                required_tx_ids.add(f"{edge.source.chain.value}:{edge.tx_hash}")

        if required_chains:
            present_chains = set(
                session.execute(
                    select(ChainRow.chain_id).where(ChainRow.chain_id.in_(required_chains))
                ).scalars()
            )
            missing_chains = required_chains - present_chains
            if missing_chains:
                raise GraphPersistenceError(
                    f"missing FK row: chain.chain_id in {sorted(missing_chains)}"
                )
        if required_addresses:
            present_addresses = set(
                session.execute(
                    select(AddressRow.address_id).where(
                        AddressRow.address_id.in_(required_addresses)
                    )
                ).scalars()
            )
            missing_addresses = required_addresses - present_addresses
            if missing_addresses:
                redacted = sorted(_redact(a) for a in missing_addresses)
                raise GraphPersistenceError(f"missing FK row: address.address_id in {redacted}")
        if required_tx_ids:
            present_tx = set(
                session.execute(
                    select(TransactionRow.tx_id).where(TransactionRow.tx_id.in_(required_tx_ids))
                ).scalars()
            )
            missing_tx = required_tx_ids - present_tx
            if missing_tx:
                redacted = sorted(_redact(t) for t in missing_tx)
                raise GraphPersistenceError(f"missing FK row: transaction.tx_id in {redacted}")

    def _prepare_rows(
        self,
        graph: CaseGraph,
        assignment: StageAssignment,
        edge_id_by_index: Mapping[int, str],
        stages: tuple[CaseStageInput, ...],
    ) -> _PreparedRows:
        """Build the three row-dict batches for bulk insert."""
        # Nodes — keyed by canonical_address_key so duplicate-canonical
        # rows (already rejected by P1-014's referential integrity
        # validator) cannot be smuggled past the unique PK. ``order_index``
        # mirrors the input tuple position so the round-trip preserves
        # the caller's node ordering byte-equal (R-DETERMINISTIC-RT).
        node_rows: list[dict[str, Any]] = []
        for index, node in enumerate(graph.nodes):
            row = graph_node_to_row(
                node,
                case_id=graph.case_id,
                node_id=canonical_address_key(node.address),
                order_index=index,
            )
            reason = graph.terminal_reasons.get(canonical_address_key(node.address))
            row["termination_reason"] = reason.value if reason is not None else None
            node_rows.append(row)

        # Edges — index-driven so the post-sort ``|#N`` suffix matches the
        # classifier output. The ``order_index`` column preserves input
        # tuple order across the round-trip so ``model_dump_json()`` is
        # byte-equal even though the PK is the bounded ``edge_pk``
        # surrogate (codex round-7 P2 fix; see
        # :func:`vca.persistence._graph_mappers.compute_edge_pk`).
        # Codex round-8 P2 fix: ``detected_at`` is sourced from
        # ``CaseGraph.metrics.finished_at`` so the column is
        # deterministic per CaseGraph content. The pre-fix
        # ``server_default=func.now()`` evaluated on every
        # DELETE-then-INSERT, breaking R-IDEMPOTENT-WRITE for the
        # column itself (consumers reading ``detected_at`` saw a fresh
        # wall-clock value on every re-save of byte-identical inputs).
        detected_at = graph.metrics.finished_at
        edge_rows: list[dict[str, Any]] = []
        for index, edge in enumerate(graph.edges):
            edge_id = edge_id_by_index[index]
            label = assignment.edge_labels[edge_id]
            rat = assignment.rationale[edge_id]
            edge_rows.append(
                flow_edge_to_row(
                    edge,
                    case_id=graph.case_id,
                    edge_id=edge_id,
                    order_index=index,
                    stage_label=label,
                    rationale=rat,
                    detected_at=detected_at,
                )
            )

        stage_rows = [case_stage_to_row(stage, graph.case_id) for stage in stages]

        return _PreparedRows(
            node_rows=tuple(node_rows),
            edge_rows=tuple(edge_rows),
            stage_rows=tuple(stage_rows),
        )


# ---------------------------------------------------------------------------
# JSON / Cypher exporters
# ---------------------------------------------------------------------------


# graph.json envelope schema version. History:
#   1.0 — original {case_id, schema_version, graph, assignment} shape.
#   1.1 — added FlowEdge.asset_contract (nullable) per edge (scan #16 Lens B).
_JSON_SCHEMA_VERSION = "1.1"


def export_graph_json(graph: CaseGraph, assignment: StageAssignment, out_path: Path) -> Path:
    """Write the ``out/cases/{case_id}/graph.json`` shape and return *out_path*.

    Atomic via ``.tmp`` + rename so a crash never leaves a half-written
    JSON file. Single-source-of-truth schema (envelope keys in this fixed
    insertion order):

    .. code-block:: json

        {"case_id": "...", "schema_version": "1.1",
         "graph": <CaseGraph json>, "assignment": <StageAssignment json>}

    Codex round-4 P2 fix: the prior implementation called
    :func:`_canonical_json` which recursively sorts ALL mapping keys —
    including nested ``CaseGraph.metadata`` and ``FlowEdge.extras``
    payloads. Loading that JSON via ``CaseGraph.model_validate_json``
    then produced a ``model_dump_json()`` whose nested keys differed
    from the input (because Pydantic preserves insertion order via
    :mod:`vca.types._extras_freeze`). The byte-equal R-DETERMINISTIC-RT
    contract therefore failed for the public exporter even after the
    storage path was fixed in round 1. We now build a fixed-order
    envelope dict and dump with ``sort_keys=False`` so insertion order
    is preserved end-to-end. The envelope key order is itself stable
    because it's hard-coded here, not driven by ``sort_keys=True``.
    """
    envelope: dict[str, Any] = {
        "case_id": graph.case_id,
        "schema_version": _JSON_SCHEMA_VERSION,
        "graph": graph.model_dump(mode="json"),
        "assignment": assignment.model_dump(mode="json"),
    }
    body = json.dumps(
        envelope,
        ensure_ascii=False,
        sort_keys=False,
        separators=(",", ":"),
    )
    _atomic_write_text(out_path, body)
    return out_path


def export_graph_cypher(graph: CaseGraph, assignment: StageAssignment, out_path: Path) -> Path:
    """Phase-2 Neo4j Cypher exporter — explicitly NOT implemented in Phase 1.

    Kept on the public surface so the P1-019 CLI flag handler fails fast
    with a clear "Phase 2 only" message rather than ``AttributeError``.
    """
    del graph, assignment, out_path  # Phase-2 placeholder
    raise NotImplementedError("Phase 2 — Neo4j dual-write opt-in (PHASE0_PHASE1_PLAN line 397)")


__all__ = [
    "CaseStageInput",
    "GraphPersistenceError",
    "GraphRepository",
    "Neo4jSink",
    "export_graph_cypher",
    "export_graph_json",
]
