"""Pure DTO ↔ row dict mappers for the P1-016 graph repository.

Extracted from :mod:`vca.persistence.graph` to keep the repository
module under the WBS R-FILE-CAP soft cap (600 LoC). All helpers are
private — the public surface stays in :mod:`vca.persistence.graph`.
"""

from __future__ import annotations

import hashlib
import json
import os
import uuid
from collections.abc import Mapping
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, ValidationError, model_validator

from vca.labeler import AddressLabel
from vca.persistence.models import FlowEdgeRow, GraphNodeRow
from vca.tracer.graph import EdgeKind, TxRef
from vca.tracer.graph import FlowEdge as DomainFlowEdge
from vca.tracer.graph import GraphNode as DomainGraphNode
from vca.tracer.stage_classifier import StageLabel
from vca.types import Address, BlockRef, ChainId, CrossChainHop

# ---------------------------------------------------------------------------
# Public exception
# ---------------------------------------------------------------------------


class GraphPersistenceError(RuntimeError):
    """Raised on a missing FK row, vocab mismatch, or assignment-key skew.

    Single exception type — flat-string ``args`` carries the diagnostic
    so callers (P1-018 / P1-019) can route on the message prefix without
    parsing nested error objects.
    """


# ---------------------------------------------------------------------------
# Caller-supplied case-stage input DTO
# ---------------------------------------------------------------------------


class CaseStageInput(BaseModel):
    """Frozen input for a single :class:`vca.persistence.models.CaseStage`.

    Phase 1 callers (P1-017 reporter, P1-019 CLI) supply this; the
    repository never constructs it.
    """

    model_config = {"frozen": True, "strict": True, "extra": "forbid"}

    order_index: int = Field(ge=0)
    stage_label: StageLabel
    description: str | None = None
    start_at: datetime
    end_at: datetime
    agg_value_native: int | None = Field(default=None, ge=0)
    edge_count: int = Field(ge=0)

    @model_validator(mode="after")
    def _validate_window(self) -> CaseStageInput:
        # Codex round-3 P2 fix: strict ``start < end`` so the model
        # validator and the save-time :func:`_normalize_stage_window`
        # share a single contract. Tz-aware comparison handles non-UTC
        # inputs (e.g. ``Asia/Seoul``) correctly because Python compares
        # aware datetimes by absolute UTC offset; naive datetimes that
        # mix with aware ones would raise a :class:`TypeError`, which
        # is also caught and re-raised as :class:`ValueError` below.
        try:
            if self.end_at <= self.start_at:
                raise ValueError(
                    "CaseStageInput.end_at must be > start_at, "
                    f"got start_at={self.start_at}, end_at={self.end_at}"
                )
        except TypeError as exc:
            # Naive vs aware comparison — surface as a clean ValueError so
            # Pydantic emits the same field-level error shape.
            raise ValueError(
                "CaseStageInput.start_at and end_at must share tz-awareness "
                f"(got start_at={self.start_at!r}, end_at={self.end_at!r})"
            ) from exc
        return self


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _redact(value: str) -> str:
    """Truncate addresses / tx hashes for log lines (R-SECRET-SAFE)."""
    if len(value) <= 12:
        return value
    return f"{value[:6]}…{value[-4:]}"


def _redact_edge_id(edge_id: str) -> str:
    """Return a one-way redacted token for *edge_id* (R-SECRET-SAFE).

    Codex round-8 P2 fix: the assignment-key mismatch path used to
    interpolate full ``edge_id`` strings into the
    :class:`GraphPersistenceError` message. ``edge_id`` concatenates
    source / dst canonical address keys, the tx hash, ``value_minor``,
    decoder name, asset symbol, decimals, and the block timestamp —
    every constituent the rest of the persistence layer carefully
    redacts via :func:`_redact`. Logging or surfacing the raw string
    via the CLI / API would leak everything :func:`_redact` is paid
    to hide.

    The redacted form is the first 8 hex characters of
    ``sha256(edge_id)`` framed by ``<edge:…>``. Eight hex chars give
    ~4 billion distinct buckets — plenty for "show the operator that
    two error reports name two distinct edges" without exposing any
    constituent of the original string. The transform is one-way (no
    reverse map persists) and deterministic, so re-running the same
    failure produces the same token.
    """
    digest = hashlib.sha256(edge_id.encode("utf-8")).hexdigest()[:8]
    return f"<edge:{digest}>"


def _storage_json(payload: Any) -> str:
    """Insertion-order-preserving JSON encoder for round-trip storage.

    Codex round-1 P2 fix: the previous storage path called a sorted-keys
    encoder which alphabetised mapping keys at write time. The Pydantic
    layer (:mod:`vca.types._extras_freeze`) already canonicalises mapping
    order via ``MappingProxyType`` reconstructions that walk the source
    in insertion order — so the Pydantic input ``{"zebra": …, "alpha":
    …}`` round-tripped through ``model_dump_json`` preserves
    ``{"zebra", "alpha"}``. Sorting in storage flipped that order on
    load, breaking the byte-equal R-DETERMINISTIC-RT contract for
    ``CaseGraph.metadata``, ``FlowEdge.extras``, and
    ``CrossChainHop.extras`` (when populated). Insertion-order JSON
    storage keeps the Pydantic determinism intact end-to-end.

    Codex round-4 P2 follow-up: the public exporter
    :func:`vca.persistence.graph.export_graph_json` now also uses
    insertion-order semantics (a fixed envelope-key order built explicitly
    + ``sort_keys=False`` for nested mappings) so the same byte-equal
    contract holds for the on-disk ``graph.json`` re-load path.
    """
    return json.dumps(payload, ensure_ascii=False, sort_keys=False, separators=(",", ":"))


def _ensure_utc(value: datetime) -> datetime:
    """Coerce a SQLite-loaded datetime back to tz-aware UTC.

    SQLite has no native ``TIMESTAMP WITH TIME ZONE`` type — every
    ``DateTime(timezone=True)`` column round-trips as a naive ``datetime``
    on read. The persistence DTOs (P1-014 ``GraphNode.first_seen_at``,
    ``BlockRef.timestamp``, ``CaseStage.start_at`` …) all enforce
    tz-aware UTC at validation time, so we re-attach the UTC tzinfo here.
    PostgreSQL preserves the tzinfo natively so the helper is a no-op
    on that backend.
    """
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


def _ensure_utc_strict(value: datetime, *, field: str) -> datetime:
    """Strict tz-aware UTC enforcement for save-time stage windows.

    Mirrors :func:`vca.tracer._types._ensure_utc` (re-declared here per
    the Phase-1 ``R-NO-PRIVATE-IMPORT`` discipline — the tracer module
    redeclares helpers rather than reaching across the encapsulation
    boundary, so the persistence layer follows the same pattern).

    Raises :class:`ValueError` when *value* is naive or carries a
    ``utcoffset()`` of ``None`` (e.g. a custom tzinfo subclass that
    refuses to resolve). Returns the input converted to UTC otherwise.
    Used at save time on caller-supplied :class:`CaseStageInput` values
    so a non-UTC input (e.g. ``Asia/Seoul``) does not collapse the
    ``ck_case_stage_window`` CHECK on SQLite (which strips tzinfo).
    """
    if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
        raise ValueError(f"{field} must be timezone-aware (UTC), got naive datetime: {value!r}")
    return value.astimezone(UTC)


def _normalize_stage_window(start_at: datetime, end_at: datetime) -> tuple[datetime, datetime]:
    """Normalize a :class:`CaseStageInput` window to tz-aware UTC.

    Codex round-3 P2 fix: SQLite's ``DateTime`` columns strip ``tzinfo``,
    so a caller passing ``start=12:00+09:00, end=04:00Z`` (semantically
    valid: ``start_utc < end_utc``) would store the naive locals
    ``(12:00, 04:00)`` and then trip the ``ck_case_stage_window`` CHECK
    (``end_at >= start_at``) at INSERT time. Normalising both ends to
    UTC at save time keeps the stored values consistent with the absolute
    time ordering of the input.

    Raises :class:`ValueError` for naive datetimes (fail-fast) and for
    inverted windows (``start_utc >= end_utc``) so the caller sees a
    clear error before the row reaches the DB.
    """
    start_utc = _ensure_utc_strict(start_at, field="start_at")
    end_utc = _ensure_utc_strict(end_at, field="end_at")
    if start_utc >= end_utc:
        raise ValueError(
            f"stage window start_at ({start_utc.isoformat()}) must precede "
            f"end_at ({end_utc.isoformat()})"
        )
    return start_utc, end_utc


def compute_edge_pk(edge_id: str) -> str:
    """Return the bounded surrogate PK for *edge_id* (codex round-7 P2 fix).

    The persistence layer uses a 64-char SHA-256 hex digest of the
    human-readable ``edge_id`` as the ``flow_edge`` PK column
    (``edge_pk``). Round 6 widened ``edge_id`` to unbounded ``Text``
    but kept it as the PK; PostgreSQL's btree index has a per-entry
    size limit (~2.7KB on default 8KB pages), so a FlowEdge with a
    multi-KB decoder produced an ``edge_id`` that PG would reject on
    insert (SQLite has no btree limit and silently accepted the same
    row). Hashing to a fixed-width digest keeps the PK comfortably
    under any btree limit while staying unique by construction —
    SHA-256 collision resistance makes ``edge_id`` collisions
    mathematically irrelevant.

    The function is deterministic and side-effect-free; the same
    ``edge_id`` always produces the same digest, which is required
    for ``R-IDEMPOTENT-WRITE`` (re-saving the same graph yields
    byte-equal ``edge_pk`` values).
    """
    return hashlib.sha256(edge_id.encode("utf-8")).hexdigest()


def compute_case_stage_id(case_id: str, order_index: int, stage_label: str) -> str:
    """Return the deterministic ``case_stage.id`` PK (codex round-7 P2 fix).

    Pre-fix, the mapper minted a fresh ``uuid4`` per save — re-saving
    the same ``(graph, assignment, stages)`` tuple changed the
    ``case_stage.id`` PK on every call, breaking
    ``R-IDEMPOTENT-WRITE``. The ``(case_id, order_index, stage_label)``
    triple is naturally unique per the WBS contract (no two stage rows
    in the same case share the same ``(order_index, stage_label)``),
    so a SHA-256 digest of the joined string is a deterministic,
    collision-free PK by construction.

    The pipe (``|``) separator avoids ambiguity between adjacent
    fields (e.g. ``case_id="a", order_index=12`` vs. ``case_id="a1",
    order_index=2`` would collide under naive concatenation but stay
    distinct with the pipe-delimited form).
    """
    payload = f"{case_id}|{order_index}|{stage_label}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _atomic_write_text(target: Path, body: str) -> None:
    """Write *body* to *target* atomically via ``os.replace``.

    Mirrors the ``LocalRawResponseStore`` pattern: write to a sibling
    ``.tmp`` and rename in-place so a crash leaves either the previous
    payload or the new one — never a partial file.

    ``newline=""`` disables platform newline translation so the on-disk
    bytes equal ``body.encode("utf-8")`` on every OS; without it Windows
    rewrites ``\\n`` as ``\\r\\n``, making multi-line artifacts such as
    ``report.md`` byte-different across platforms.
    """
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(f"{target.name}.{uuid.uuid4().hex}.tmp")
    tmp.write_text(body, encoding="utf-8", newline="")
    os.replace(tmp, target)


# ---------------------------------------------------------------------------
# DTO ↔ row dict mappers
# ---------------------------------------------------------------------------


def graph_node_to_row(
    node: DomainGraphNode,
    *,
    case_id: str,
    node_id: str,
    order_index: int,
) -> dict[str, Any]:
    """Map :class:`GraphNode` → ``graph_node`` row dict for bulk insert.

    Codex round-1 P2 fix: the full :class:`AddressLabel` (when present)
    is serialised into ``label_json`` so the round-trip rebuilds every
    field (kind / source / confidence / observed_at / evidence /
    cluster_id / extras). ``label_kind`` keeps its denormalised role as
    a query helper.
    """
    label_kind = None if node.label is None else node.label.kind.value
    label_json = None if node.label is None else node.label.model_dump_json()
    return {
        "node_id": node_id,
        "case_id": case_id,
        "address_id": str(node.address),
        "depth": node.depth,
        "order_index": order_index,
        "label_kind": label_kind,
        "label_json": label_json,
        "first_seen_tx_id": f"{node.first_seen_tx.chain.value}:{node.first_seen_tx.tx_hash}",
        "first_seen_at": node.first_seen_at,
        "terminal": node.terminal,
        "address_value": node.address.value,
        # ``termination_reason`` is populated at the case-graph level via
        # :attr:`CaseGraph.terminal_reasons`, NOT on the node DTO. The
        # caller overwrites this placeholder after looking the reason up
        # by canonical_key.
        "termination_reason": None,
    }


def row_to_graph_node(row: GraphNodeRow) -> DomainGraphNode:
    """Map a :class:`GraphNodeRow` back to a frozen :class:`GraphNode` DTO.

    Routes the dict through :meth:`GraphNode.model_validate` so every
    P1-014 cross-field validator re-runs (R-DETERMINISTIC-RT). Codex
    round-1 P2 fix: when ``label_json`` is set, rehydrate the full
    :class:`AddressLabel` via ``model_validate_json`` so the loaded node
    is byte-equal to the input.
    """
    # ITER-35: the identifier parses are the same corrupt-DB trust boundary as
    # label_json below — a malformed stored address_id / first_seen_tx_id (no
    # colon → ValueError on unpack; unknown chain prefix → ValueError from
    # ChainId.from_str; malformed address/tx hash → ValueError/pydantic
    # ValidationError) must surface as the typed GraphPersistenceError, not leak
    # raw out of the repository load boundary (ITER-27 wrapped only the JSON
    # columns; ITER-31 wrapped only graph.py's own seed_tx_id). R-SECRET-SAFE:
    # redact, no raw value/exc; ``from exc`` keeps the cause.
    try:
        chain = ChainId.from_str(row.address_id.split(":", 1)[0])
        address = Address.from_str(row.address_value, chain)
        tx_chain_str, tx_hash = row.first_seen_tx_id.split(":", 1)
        tx_ref = TxRef(chain=ChainId.from_str(tx_chain_str), tx_hash=tx_hash)
    except (ValueError, ValidationError) as exc:
        raise GraphPersistenceError(
            f"graph_node row identifiers are malformed for {_redact(row.address_id)}"
        ) from exc
    if row.label_json is None:
        label = None
    else:
        # ``label_json`` is a stored trust boundary (corrupt-DB read): a malformed
        # JSON string or a schema-invalid AddressLabel must surface as the typed
        # GraphPersistenceError the repository contract documents, NOT a raw
        # json.JSONDecodeError / pydantic.ValidationError. ITER-19 wrapped only the
        # meta envelope (graph.py); this is the row-mapper twin.
        try:
            label = AddressLabel.model_validate_json(row.label_json)
        except (json.JSONDecodeError, ValidationError) as exc:
            # R-SECRET-SAFE: redact the address id and DO NOT interpolate the raw
            # exception (a pydantic ValidationError echoes offending input values);
            # ``from exc`` preserves the full cause in the chain for debugging.
            raise GraphPersistenceError(
                f"graph_node.label_json is corrupt for {_redact(row.address_id)}"
            ) from exc
    # ITER-35 (+ codex round-8 P2 symmetry with row_to_flow_edge): the final
    # validation is part of the same corrupt-row boundary — a field that fails
    # GraphNode validation (e.g. a negative depth) must surface as the typed
    # GraphPersistenceError, not a raw pydantic.ValidationError. R-SECRET-SAFE.
    try:
        return DomainGraphNode.model_validate(
            {
                "address": address,
                "depth": row.depth,
                "label": label,
                "first_seen_tx": tx_ref,
                "first_seen_at": _ensure_utc(row.first_seen_at),
                "terminal": row.terminal,
            }
        )
    except ValidationError as exc:
        raise GraphPersistenceError(
            f"graph_node row is malformed for {_redact(row.address_id)}"
        ) from exc


def flow_edge_to_row(
    edge: DomainFlowEdge,
    *,
    case_id: str,
    edge_id: str,
    order_index: int,
    stage_label: StageLabel,
    rationale: str,
    detected_at: datetime,
) -> dict[str, Any]:
    """Map :class:`FlowEdge` + classifier outputs → ``flow_edge`` row dict.

    Codex round-7 P2 fix: the row dict carries both the human-readable
    ``edge_id`` (non-PK ``Text`` column for query convenience) and the
    bounded ``edge_pk`` surrogate (PK; 64-char SHA-256 hex digest of
    ``edge_id``) — see :func:`compute_edge_pk` for the btree-size
    rationale.

    Codex round-8 P2 fix: ``detected_at`` is now passed in by the
    repository (sourced from :attr:`CaseGraph.metrics.finished_at`)
    instead of relying on the column's ``server_default=func.now()``.
    Pre-fix, the DELETE-then-INSERT save path (R-IDEMPOTENT-WRITE)
    re-evaluated the server default on every save, so a re-save of a
    byte-identical input flipped ``detected_at`` to a fresh wall-clock
    value. Sourcing from ``metrics.finished_at`` makes the column
    deterministic per content — the column reflects "when was this
    case last classified", semantically meaningful and stable across
    saves. The caller always normalises *detected_at* to tz-aware UTC
    via :func:`_ensure_utc_strict` so SQLite (which strips tzinfo on
    read) round-trips byte-equal with PostgreSQL.
    """
    extras_json: str | None
    if edge.extras:
        # ``model_dump`` re-runs the recursive thaw helper (P1-014
        # field_serializer) so MappingProxyType collapses to a plain dict
        # while preserving insertion order. Codex round-1 P2 fix: storage
        # uses :func:`_storage_json` (no key sorting) so the byte-equal
        # round-trip survives the save→load cycle.
        extras_dump = DomainFlowEdge.model_validate(edge).model_dump(mode="json")
        extras_json = _storage_json(extras_dump["extras"])
    else:
        extras_json = None
    hop_json = None if edge.hop is None else _storage_json(edge.hop.model_dump(mode="json"))
    via_tx_id = None if edge.tx_hash is None else f"{edge.source.chain.value}:{edge.tx_hash}"
    block_number = None if edge.block is None else edge.block.number
    block_time = None if edge.block is None else edge.block.timestamp
    value_minor = None if edge.value_minor is None else Decimal(edge.value_minor)
    return {
        "edge_pk": compute_edge_pk(edge_id),
        "edge_id": edge_id,
        "case_id": case_id,
        "order_index": order_index,
        "src_address_id": str(edge.source),
        "dst_address_id": str(edge.target),
        "src_chain": edge.source.chain.value,
        "dst_chain": edge.target.chain.value,
        "via_tx_id": via_tx_id,
        "kind": edge.kind.value,
        "value_minor": value_minor,
        "asset_symbol": edge.asset_symbol,
        "decimals": edge.decimals,
        # scan #16 Lens B: store the token contract as the canonical
        # ``"{chain}:{value}"`` string (mirror ``src_address_id``); ``None`` for
        # native / self-loop edges.
        "asset_contract": None if edge.asset_contract is None else str(edge.asset_contract),
        "decoder": edge.decoder,
        "block_number": block_number,
        "block_time": block_time,
        "stage_label": stage_label.value,
        "rationale": rationale,
        "extras_json": extras_json,
        "hop_json": hop_json,
        "detected_at": _ensure_utc_strict(detected_at, field="detected_at"),
    }


def row_to_flow_edge(row: FlowEdgeRow) -> DomainFlowEdge:
    """Map a :class:`FlowEdgeRow` back to a frozen :class:`FlowEdge` DTO."""
    # ITER-35: identifier-parse trust boundary (see row_to_graph_node). A corrupt
    # stored src/dst chain or address id (unknown chain → ValueError; no colon →
    # IndexError from split[1]; malformed address → ValueError/ValidationError)
    # must surface as the typed GraphPersistenceError, not leak raw out of the
    # repository load boundary. R-SECRET-SAFE: redact, no raw value/exc.
    try:
        src_chain = ChainId.from_str(row.src_chain)
        dst_chain = ChainId.from_str(row.dst_chain)
        src_addr_value = row.src_address_id.split(":", 1)[1]
        dst_addr_value = row.dst_address_id.split(":", 1)[1]
        source = Address.from_str(src_addr_value, src_chain)
        target = Address.from_str(dst_addr_value, dst_chain)
    except (ValueError, ValidationError, IndexError) as exc:
        raise GraphPersistenceError(
            f"flow_edge row identifiers are malformed for {_redact(row.src_address_id)}"
        ) from exc
    extras: Mapping[str, Any]
    if row.extras_json is None:
        extras = {}
    else:
        # Stored trust boundary (corrupt-DB read): a malformed-JSON ``extras_json``
        # must surface as the typed GraphPersistenceError, NOT a raw
        # json.JSONDecodeError. The isinstance(dict) guard below (ITER-14) covers
        # only the decode-succeeds-but-non-dict case.
        try:
            decoded_extras = json.loads(row.extras_json)
        except json.JSONDecodeError as exc:
            # R-SECRET-SAFE: redact the address id; ``from exc`` keeps the cause.
            raise GraphPersistenceError(
                f"flow_edge.extras_json is corrupt for {_redact(row.src_address_id)}"
            ) from exc
        if not isinstance(decoded_extras, dict):
            raise GraphPersistenceError(
                f"flow_edge.extras_json must decode to a dict, got: {type(decoded_extras).__name__}"
            )
        extras = decoded_extras
    hop: CrossChainHop | None
    if row.hop_json is None:
        hop = None
    else:
        try:
            decoded_hop = json.loads(row.hop_json)
        except json.JSONDecodeError as exc:
            # R-SECRET-SAFE: redact the address id; ``from exc`` keeps the cause.
            raise GraphPersistenceError(
                f"flow_edge.hop_json is corrupt for {_redact(row.src_address_id)}"
            ) from exc
        if not isinstance(decoded_hop, dict):
            raise GraphPersistenceError(
                f"flow_edge.hop_json must decode to a dict, got: {type(decoded_hop).__name__}"
            )
        # A decode-succeeds, dict-shaped hop can still be schema-invalid
        # (CrossChainHop validators): wrap that too so it is typed, not a raw
        # pydantic.ValidationError out of the repository read.
        try:
            hop = CrossChainHop.model_validate(decoded_hop)
        except ValidationError as exc:
            # R-SECRET-SAFE: redact the address id and DO NOT interpolate the raw
            # ValidationError (it echoes offending input); ``from exc`` keeps it.
            raise GraphPersistenceError(
                f"flow_edge.hop_json failed CrossChainHop validation for "
                f"{_redact(row.src_address_id)}"
            ) from exc
    # ITER-35 (+ codex round-8 P2): the via_tx_id parse, EdgeKind coercion, and
    # the final FlowEdge validation are the remaining corrupt-row surface — a
    # no-colon via_tx_id (IndexError from split[1]), an unknown kind (ValueError),
    # or a malformed tx_hash / any other field that fails FlowEdge validation
    # (pydantic ValidationError, e.g. via_tx_id="eth:not-a-valid-hash" passes the
    # split but fails the tx_hash regex) must surface as the typed
    # GraphPersistenceError, not leak raw out of the repository load boundary.
    # R-SECRET-SAFE: redact the address id, no raw value/exc; ``from exc`` keeps it.
    try:
        # ITER-63: the block (BlockRef) construction and value_minor int-coercion
        # are INSIDE this try — a corrupt block_number (non-int → ValidationError),
        # value_minor='NaN' (int() → ValueError) or 'Infinity' (int() → OverflowError)
        # must surface as the typed GraphPersistenceError, not leak raw out of load.
        block: BlockRef | None
        if row.block_number is None or row.block_time is None:
            block = None
        else:
            block = BlockRef(
                chain=src_chain,
                number=row.block_number,
                timestamp=_ensure_utc(row.block_time),
            )
        value_minor = None if row.value_minor is None else int(row.value_minor)
        via_tx_hash = None if row.via_tx_id is None else row.via_tx_id.split(":", 1)[1]
        # scan #16 Lens B: deserialize the stored ``"{chain}:{value}"`` token
        # contract back to an Address (or None for native / self-loop edges). A
        # corrupt value (unknown chain / no colon / malformed address) surfaces as
        # the typed GraphPersistenceError via this wrapping try.
        asset_contract: Address | None
        if row.asset_contract is None:
            asset_contract = None
        else:
            ac_chain_str, _, ac_value = row.asset_contract.partition(":")
            asset_contract = Address.from_str(ac_value, ChainId.from_str(ac_chain_str))
        payload: dict[str, Any] = {
            "source": source,
            "target": target,
            "kind": EdgeKind(row.kind),
            "value_minor": value_minor,
            "asset_symbol": row.asset_symbol,
            "decimals": row.decimals,
            "asset_contract": asset_contract,
            "tx_hash": via_tx_hash,
            "block": block,
            "decoder": row.decoder,
            "hop": hop,
            "extras": extras,
        }
        return DomainFlowEdge.model_validate(payload)
    except (ValueError, IndexError, ValidationError, OverflowError) as exc:
        raise GraphPersistenceError(
            f"flow_edge row is malformed for {_redact(row.src_address_id)}"
        ) from exc


def case_stage_to_row(stage: CaseStageInput, case_id: str) -> dict[str, Any]:
    """Map :class:`CaseStageInput` → ``case_stage`` row dict.

    Codex round-3 P2 fix: ``start_at`` / ``end_at`` are normalised to
    tz-aware UTC via :func:`_normalize_stage_window` before storage so
    the SQLite ``ck_case_stage_window`` CHECK does not falsely reject a
    semantically valid non-UTC pair (e.g. ``start=12:00+09:00,
    end=04:00Z``). Naive datetimes raise :class:`ValueError`; inverted
    windows (``start_utc >= end_utc``) raise :class:`ValueError` instead
    of bubbling up as the opaque DB-level :class:`IntegrityError`.

    Codex round-7 P2 fix: ``id`` is now a deterministic SHA-256 hex
    digest of ``f"{case_id}|{order_index}|{stage_label}"`` (see
    :func:`compute_case_stage_id`) instead of a fresh ``uuid4``.
    Re-saving the same input produces byte-equal row PKs across saves
    — required for ``R-IDEMPOTENT-WRITE`` so consumers tracking
    stages by ``id`` (audit logs, future joins) don't break.
    """
    start_utc, end_utc = _normalize_stage_window(stage.start_at, stage.end_at)
    agg_value_native = None if stage.agg_value_native is None else Decimal(stage.agg_value_native)
    stage_label = stage.stage_label.value
    return {
        "id": compute_case_stage_id(case_id, stage.order_index, stage_label),
        "case_id": case_id,
        "order_index": stage.order_index,
        "stage_label": stage_label,
        "description": stage.description,
        "start_at": start_utc,
        "end_at": end_utc,
        "agg_value_native": agg_value_native,
        "edge_count": stage.edge_count,
    }


__all__ = [
    "CaseStageInput",
    "GraphPersistenceError",
    "_atomic_write_text",
    "_ensure_utc",
    "_redact",
    "_redact_edge_id",
    "_storage_json",
    "case_stage_to_row",
    "compute_case_stage_id",
    "compute_edge_pk",
    "flow_edge_to_row",
    "graph_node_to_row",
    "row_to_flow_edge",
    "row_to_graph_node",
]
