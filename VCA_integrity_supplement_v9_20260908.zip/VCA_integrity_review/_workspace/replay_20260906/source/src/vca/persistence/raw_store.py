"""Raw external-API response store (P0-006).

Defines the :class:`RawResponseStore` Protocol and a local-disk implementation.
A MinIO/S3 backend is intentionally left as a placeholder
(:class:`MinIORawResponseStore`) raising :class:`NotImplementedError` until a
follow-up PR adds the SDK dependency and integration tests.

Backend dispatch goes through :func:`make_raw_store` driven by
``settings.vca_raw_store``. Phase 0/1 dev/test environments default to
``"local"`` (see ``.env.example`` and :class:`vca.config.Settings`).

Architectural decisions live in ``_workspace/P0-006_architect_wbs.md``;
the highlights:

* **Dual storage**: the JSON payload goes to a file, while metadata
  (``source/endpoint/params_hash/storage_uri/...``) is recorded as a
  :class:`vca.persistence.models.RawResponse` row.
* **Atomic write**: payload is written to a sibling ``.tmp`` file and
  promoted via :func:`os.replace`, the cross-platform atomic rename.
* **Deterministic JSON**: ``json.dumps(payload, ensure_ascii=False,
  sort_keys=True, separators=(",", ":"))`` so identical inputs produce
  byte-identical outputs (helps golden-cassette comparisons).
* **Defensive sanitisation**: ``source`` and ``params_hash`` must match
  ``[A-Za-z0-9_-]+`` to block path-traversal attempts before they reach
  the filesystem.
"""

from __future__ import annotations

import json
import os
import re
import uuid
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

import aiofiles  # type: ignore[import-untyped]
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from vca.persistence.models import RawResponse

# Allowed characters for path-bound tokens. SHA-1 hex (``[a-f0-9]+``) is a
# subset, leaving headroom for callers that include short identifiers.
_SAFE_TOKEN = re.compile(r"^[A-Za-z0-9_-]+$")

# Default base directory when ``settings.vca_raw_store == "local"`` and the
# caller does not override ``base_dir``. Co-located with the gitignored
# ``out/`` tree so artefacts stay out of source control.
_DEFAULT_BASE_DIR = Path("out/raw")


class RawResponseNotFound(LookupError):  # noqa: N818 — mirrors stdlib FileNotFoundError naming
    """Raised when a ``storage_uri`` does not resolve to an existing payload."""


@runtime_checkable
class RawResponseStore(Protocol):
    """Abstract store for raw external-API responses.

    Implementations must persist the payload object to a backend-specific
    location and record metadata (``source``, ``endpoint``, ``params_hash``,
    ``storage_uri`` …) in the ``raw_response`` table.
    """

    async def put(
        self,
        *,
        source: str,
        endpoint: str,
        params_hash: str,
        payload: dict[str, Any],
        status_code: int | None = None,
        ttl: int | None = None,
    ) -> str:
        """Persist *payload* and return the backend-specific ``storage_uri``."""
        ...

    async def get(self, storage_uri: str) -> dict[str, Any]:
        """Return the payload at *storage_uri* or raise :class:`RawResponseNotFound`."""
        ...


def _sanitize(token: str, name: str) -> str:
    """Validate *token* against ``[A-Za-z0-9_-]+``; raise ``ValueError`` otherwise.

    Acts as the final path-traversal gate even when callers (HTTP client,
    cache layer) already validate upstream — defence in depth. Uses
    :func:`re.fullmatch` rather than :meth:`re.match` because the latter's
    ``$`` anchor accepts a trailing newline (``"abc\\n"``).
    """
    if not token or not _SAFE_TOKEN.fullmatch(token):
        raise ValueError(f"{name} must match [A-Za-z0-9_-]+ and be non-empty, got: {token!r}")
    return token


def _serialize(payload: dict[str, Any]) -> str:
    """Encode *payload* deterministically as compact UTF-8 JSON."""
    return json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


class LocalRawResponseStore:
    """Local-disk implementation of :class:`RawResponseStore`.

    Writes payloads under ``{base_dir}/{source}/{params_hash[:2]}/{params_hash}.json``
    and inserts a metadata row per call. The 2-character shard avoids
    accumulating tens of thousands of files inside a single directory.
    """

    def __init__(
        self,
        *,
        base_dir: Path,
        session_factory: async_sessionmaker[AsyncSession],
    ) -> None:
        self._base = Path(base_dir)
        self._session_factory = session_factory

    async def put(
        self,
        *,
        source: str,
        endpoint: str,
        params_hash: str,
        payload: dict[str, Any],
        status_code: int | None = None,
        ttl: int | None = None,
    ) -> str:
        src = _sanitize(source, "source")
        ph = _sanitize(params_hash, "params_hash")

        # Each fetch gets its own immutable file under the (source, params_hash)
        # shard so that re-fetching the same upstream key never overwrites a
        # payload already referenced by older RawResponse rows. The fetch_id
        # also doubles as the temp suffix during atomic write so concurrent
        # writers cannot collide on the same ``.tmp`` path.
        fetch_id = uuid.uuid4().hex
        target = self._base / src / ph[:2] / f"{ph}_{fetch_id}.json"
        target.parent.mkdir(parents=True, exist_ok=True)

        await self._atomic_write(target, _serialize(payload), tmp_token=fetch_id)

        storage_uri = target.as_posix()
        await self._record_metadata(
            source=src,
            endpoint=endpoint,
            params_hash=ph,
            storage_uri=storage_uri,
            status_code=status_code,
            ttl=ttl,
        )
        return storage_uri

    async def get(self, storage_uri: str) -> dict[str, Any]:
        path = Path(storage_uri)
        if not path.is_file():
            raise RawResponseNotFound(storage_uri)
        # ITER-51: the Protocol documents a single failure mode
        # (:class:`RawResponseNotFound`). ``put`` always writes valid UTF-8 JSON
        # dicts via ``_serialize`` + ``_atomic_write``, but ``get`` reads arbitrary
        # on-disk bytes — a corrupt payload (truncated/half-written by an external
        # writer, disk corruption, a manual edit) must surface as
        # ``RawResponseNotFound`` (operationally "cannot resolve the payload";
        # callers already catch it) rather than leaking a raw exception out of the
        # boundary. Wrap the READ as well as the decode: invalid UTF-8 bytes raise
        # ``UnicodeDecodeError`` from ``f.read()`` BEFORE ``json.loads`` (codex P2);
        # malformed JSON raises ``json.JSONDecodeError``; a non-dict slips both.
        try:
            async with aiofiles.open(path, encoding="utf-8") as f:
                text = await f.read()
            decoded = json.loads(text)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise RawResponseNotFound(storage_uri) from exc
        if not isinstance(decoded, dict):
            raise RawResponseNotFound(storage_uri)
        return decoded

    @staticmethod
    async def _atomic_write(target: Path, body: str, *, tmp_token: str) -> None:
        """Write *body* to *target* atomically via a unique sibling ``.tmp`` file.

        ``os.replace`` is atomic on POSIX (rename(2)) and Windows (MoveFileEx
        with ``MOVEFILE_REPLACE_EXISTING``), so a crash mid-write leaves
        either the previous payload or the new one — never a partial file.
        The temp filename includes *tmp_token* so two concurrent writers
        targeting the same shard never collide on the same scratch file.
        """
        tmp = target.with_name(f"{target.name}.{tmp_token}.tmp")
        async with aiofiles.open(tmp, mode="w", encoding="utf-8") as f:
            await f.write(body)
        os.replace(tmp, target)

    async def _record_metadata(
        self,
        *,
        source: str,
        endpoint: str,
        params_hash: str,
        storage_uri: str,
        status_code: int | None,
        ttl: int | None,
    ) -> None:
        """Insert a fresh ``raw_response`` row.

        WBS §6 D-H: no UPSERT — the cache layer (P0-008) already deduplicates
        upstream calls so true duplicates are rare; orphan rows are reaped
        by the future GC job (P0-RG-1).
        """
        async with self._session_factory() as session:
            row = RawResponse(
                id=str(uuid.uuid4()),
                source=source,
                endpoint=endpoint,
                params_hash=params_hash,
                status_code=status_code,
                storage_uri=storage_uri,
                ttl=ttl,
            )
            session.add(row)
            await session.commit()


class MinIORawResponseStore:
    """Placeholder MinIO/S3 backend.

    Materialised in a follow-up PR (``P0-006-MinIO``) once the project takes
    on the ``minio`` / ``aioboto3`` dependency. Phase 0/1 work uses
    :class:`LocalRawResponseStore` via ``VCA_RAW_STORE=local``.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        raise NotImplementedError(
            "MinIO backend pending — see P0-006-MinIO. Set VCA_RAW_STORE=local for Phase 0/1."
        )

    async def put(self, **_: Any) -> str:  # pragma: no cover - placeholder
        raise NotImplementedError

    async def get(self, storage_uri: str) -> dict[str, Any]:  # pragma: no cover
        raise NotImplementedError


@dataclass(frozen=True)
class _InMemoryPutEntry:
    """One :meth:`InMemoryRawResponseStore.put` call.

    Frozen DTO (immutability rule) — fields mirror the production
    ``LocalRawResponseStore.put`` keyword surface so swap-in tests can
    inspect each persisted blob.
    """

    source: str
    endpoint: str
    params_hash: str
    payload: Mapping[str, Any]
    status_code: int | None
    ttl: int | None
    storage_uri: str


@dataclass
class InMemoryRawResponseStore:
    """In-memory implementation of :class:`RawResponseStore`.

    Promoted from ``tests/unit/adapters/evm/_fakes.py`` in P1-021.0 so the
    cassette adapter factory (which must never touch ``tests/``) can
    consume it. Append-only; each :meth:`put` returns a deterministic
    ``mem://`` URI keyed by the running entry count so callers can
    cross-reference :attr:`vca.types.NormalizedTransaction.raw_uri`.

    Lifecycle: in-process only. ``LocalRawResponseStore`` remains the
    on-disk production backend (P0-006); ``InMemoryRawResponseStore`` is
    used by:

    * unit tests for ``vca.adapters.evm`` / ``vca.adapters.btc``
    * the cassette CLI mode (P1-021.0) which has no DB session factory
      because raw responses are sourced from the committed cassettes.
    """

    entries: list[_InMemoryPutEntry] = field(default_factory=list)

    async def put(
        self,
        *,
        source: str,
        endpoint: str,
        params_hash: str,
        payload: dict[str, Any],
        status_code: int | None = None,
        ttl: int | None = None,
    ) -> str:
        storage_uri = f"mem://{source}/{params_hash}/{len(self.entries)}"
        self.entries.append(
            _InMemoryPutEntry(
                source=source,
                endpoint=endpoint,
                params_hash=params_hash,
                payload=dict(payload),
                status_code=status_code,
                ttl=ttl,
                storage_uri=storage_uri,
            )
        )
        return storage_uri

    async def get(self, storage_uri: str) -> dict[str, Any]:
        for entry in self.entries:
            if entry.storage_uri == storage_uri:
                return dict(entry.payload)
        # ITER-80: the RawResponseStore Protocol contract documents that get()
        # raises RawResponseNotFound on a missing storage_uri; a bare KeyError
        # escaped that typed boundary. Last-twin of ITER-51 which closed the same
        # leak in LocalRawResponseStore.get.
        raise RawResponseNotFound(storage_uri)


def make_raw_store(
    settings: Any,
    *,
    session_factory: async_sessionmaker[AsyncSession],
    base_dir: Path | None = None,
) -> RawResponseStore:
    """Build a :class:`RawResponseStore` based on ``settings.vca_raw_store``.

    Typed as ``Any`` rather than :class:`vca.config.Settings` so test stubs
    (``SimpleNamespace``) can be passed without subclassing pydantic models.

    Parameters
    ----------
    settings:
        Object exposing ``vca_raw_store`` (``"local"`` or ``"minio"``).
    session_factory:
        Async session factory bound to the metadata DB.
    base_dir:
        Optional override for the local backend root. Defaults to
        ``out/raw`` (gitignored).

    Returns
    -------
    RawResponseStore
        The selected backend. ``"minio"`` raises :class:`NotImplementedError`
        eagerly; an unknown literal raises :class:`ValueError`.
    """
    backend = settings.vca_raw_store
    if backend == "local":
        return LocalRawResponseStore(
            base_dir=base_dir or _DEFAULT_BASE_DIR,
            session_factory=session_factory,
        )
    if backend == "minio":
        return MinIORawResponseStore(settings=settings)
    raise ValueError(f"unknown raw_store backend: {backend!r}")


__all__ = [
    "InMemoryRawResponseStore",
    "LocalRawResponseStore",
    "MinIORawResponseStore",
    "RawResponseNotFound",
    "RawResponseStore",
    "make_raw_store",
]
