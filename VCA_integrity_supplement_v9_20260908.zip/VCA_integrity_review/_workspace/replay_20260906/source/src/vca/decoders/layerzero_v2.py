"""LayerZero V2 OFT decoder (P1-009).

First concrete :class:`vca.decoders.BridgeDecoder` implementation: the
KelpDAO rsETH exploit (source §2.가, §3.가.1) is delivered to Ethereum
via the LayerZero V2 OFT pipeline. Given an inbound ``lzReceive`` call to
the registered Endpoint V2 address and the post-execution event logs, the
decoder returns a single :class:`vca.types.CrossChainHop` that records the
Unichain→Ethereum delivery for the canonical 116,500 rsETH amount.

Slices in order:

* **Slice A** — keccak-pinned selectors / topics + Phase 1 default
  endpoint / EID / OFT-asset tables wrapped in a frozen
  :class:`LayerZeroV2DecoderConfig` dataclass.
* **Slice B** — :class:`LayerZeroV2Decoder` Pydantic v2 model
  (frozen, BridgeDecoder Protocol compliant) + ``matches`` four-arm AND.
* **Slice C** — pure helpers (``_decode_lz_receive_calldata``,
  ``_parse_oft_message``, ``_find_oft_event``, ``_find_packet_event``,
  ``_assert_event_calldata_coherence``, ``_scale_amount_sd_to_18``) and
  the public :meth:`LayerZeroV2Decoder.decode` orchestrator.

Critical correction relative to the WBS draft: the canonical
LayerZero V2 Endpoint signature is

::

    lzReceive((uint32,bytes32,uint64),address,bytes32,bytes,bytes)

(Origin tuple, _receiver, _guid, _message, _extraData) — not the variant
quoted in WBS §3 Slice A. The canonical form is the one whose
keccak256 prefix is ``0x0c0c389e`` (matches the byte-for-byte selector in
``tests/fixtures/kelpdao/cassettes/ethereum/stage1_exploit_tx.yaml``
line 19); the alternate ordering produces ``0x13137d65``.

The decoder is **pure**: no I/O, no clock reads, no environment access,
no logging. R-CODEC-REUSE re-imports the shared
:data:`vca.decoders.abi_fallback.decode._CODEC` for ABI decoding so we
never build a second :class:`eth_abi.codec.ABICodec`. The OFT
``_message`` payload (32-byte sendToAddress + 8-byte amountSD uint64) is
decoded by fixed-offset slicing — wrapping two trivial slices in another
``eth_abi.decode`` would only inflate the test surface.

See ``_workspace/p1-009_architect_wbs.md`` for the full WBS.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Final

from eth_utils import keccak  # type: ignore[attr-defined]
from pydantic import BaseModel, Field, ValidationError

from vca.decoders.abi_fallback.decode import _CODEC
from vca.decoders.registry import register_decoder
from vca.types import (
    Address,
    Amount,
    Asset,
    ChainId,
    CrossChainHop,
    NormalizedLog,
    NormalizedTransaction,
)
from vca.types.normalized import _FROZEN_CONFIG

__all__ = [
    "LAYERZERO_V2_DECODER_NAME",
    "LayerZeroV2Decoder",
    "LayerZeroV2DecoderConfig",
    "register_layerzero_v2_decoder",
]


# ---------------------------------------------------------------------------
# Signatures pinned at module import (DoD-12)
# ---------------------------------------------------------------------------

_LZ_RECEIVE_SIGNATURE: Final[str] = "lzReceive((uint32,bytes32,uint64),address,bytes32,bytes,bytes)"
_OFT_RECEIVED_SIGNATURE: Final[str] = "OFTReceived(bytes32,uint32,address,uint256)"
_PACKET_DELIVERED_SIGNATURE: Final[str] = "PacketDelivered((uint32,bytes32,uint64),address)"


def _selector(sig: str) -> str:
    """Return the 4-byte function selector (``0x`` + 8 hex) for ``sig``."""
    return "0x" + keccak(text=sig).hex()[:8]


def _topic(sig: str) -> str:
    """Return the 32-byte event topic (``0x`` + 64 hex) for ``sig``."""
    return "0x" + keccak(text=sig).hex()


# Verified against cassette `stage1_exploit_tx.yaml` line 19:
#   "input":"0x0c0c389e..."
_LZ_RECEIVE_SELECTOR: Final[str] = _selector(_LZ_RECEIVE_SIGNATURE)
# Verified against cassette `stage1_exploit_logs.yaml` line 19:
#   OFT log topics[0] = 0xefed6d35... ; Endpoint log topics[0] = 0x3cd5e48f...
_OFT_RECEIVED_TOPIC: Final[str] = _topic(_OFT_RECEIVED_SIGNATURE)
_PACKET_DELIVERED_TOPIC: Final[str] = _topic(_PACKET_DELIVERED_SIGNATURE)


# R-SELECTOR-TRIPWIRE (P2-DECODER-TRIPWIRE-PARITY.1): import-time keccak
# pin. Mirrors the :mod:`vca.decoders.aave_v3` / :mod:`vca.decoders.compound_v3`
# pattern — any drift in ``eth_utils.keccak`` or the LayerZero V2 ABI fails
# at first module import rather than producing a silent decode failure.
_EXPECTED_SELECTORS: Final[Mapping[str, str]] = MappingProxyType(
    {_LZ_RECEIVE_SIGNATURE: "0x0c0c389e"},
)
for _sig, _expected in _EXPECTED_SELECTORS.items():
    if _selector(_sig) != _expected:  # pragma: no cover - import-time tripwire
        raise RuntimeError(
            f"LayerZero V2 selector drift for {_sig!r}: "
            f"{_selector(_sig)!r} (expected {_expected!r}). "
            "Refusing module import — investigate LayerZero V2 ABI or eth_utils.keccak."
        )

# R-EVENT-TOPIC-TRIPWIRE (P2-DECODER-TRIPWIRE-PARITY.1): import-time keccak
# pin for the two events ``decode`` cross-validates.
_EXPECTED_EVENT_TOPICS: Final[Mapping[str, str]] = MappingProxyType(
    {
        _OFT_RECEIVED_SIGNATURE: (
            "0xefed6d3500546b29533b128a29e3a94d70788727f0507505ac12eaf2e578fd9c"
        ),
        _PACKET_DELIVERED_SIGNATURE: (
            "0x3cd5e48f9730b129dc7550f0fcea9c767b7be37837cd10e55eb35f734f4bca04"
        ),
    },
)
for _sig, _expected in _EXPECTED_EVENT_TOPICS.items():
    if _topic(_sig) != _expected:  # pragma: no cover - import-time tripwire
        raise RuntimeError(
            f"LayerZero V2 event topic drift for {_sig!r}: "
            f"{_topic(_sig)!r} (expected {_expected!r}). "
            "Refusing module import — investigate LayerZero V2 ABI or eth_utils.keccak."
        )


# ---------------------------------------------------------------------------
# Phase 1 default Endpoint / EID / OFT-asset tables (DoD-10, DoD-11)
# ---------------------------------------------------------------------------


def _eth_addr(value: str) -> Address:
    return Address.from_str(value, ChainId.ETHEREUM)


# Source §3.가 line 106; KelpDAO bootstrap pins this same value as
# KELPDAO_LZ_ENDPOINT_V2 (kelpdao_seed line 112) — single source of truth.
_DEFAULT_ENDPOINTS: Final[Mapping[ChainId, Address]] = MappingProxyType(
    {ChainId.ETHEREUM: _eth_addr("0x1a44076050125825900e736c501f859c50fE728c")}
)

# Source §2.다.3 line 43: KelpDAO src_chain = Unichain (LayerZero EID 30320).
# Cassette stage1_exploit_tx.yaml line 19 word[0] = 0x...7670 = 30320.
_DEFAULT_EID_TO_CHAIN: Final[Mapping[int, ChainId]] = MappingProxyType({30320: ChainId.UNICHAIN})

# Source §3.가 line 99-110 fixes the rsETH adapter and token addresses.
_RSETH_ASSET_ETH: Final[Asset] = Asset(
    symbol="rsETH",
    decimals=18,
    chain=ChainId.ETHEREUM,
    contract=_eth_addr("0xA1290d69c65A6Fe4DF752f95823fae25cB99e5A7"),
)
_DEFAULT_OFT_ASSETS: Final[Mapping[Address, Asset]] = MappingProxyType(
    {_eth_addr("0x85d456B2DfF1fd8245387C0BfB64Dfb700e98Ef3"): _RSETH_ASSET_ETH}
)


@dataclass(frozen=True, slots=True)
class LayerZeroV2DecoderConfig:
    """Phase 1 decoder configuration — endpoints, EID map, OFT-asset map.

    All three mappings default to :class:`types.MappingProxyType` so the
    "default" instance is structurally immutable; callers MUST pass
    ``MappingProxyType(...)`` for overrides as well to preserve the
    invariant (the dataclass ``frozen=True`` blocks re-assignment of the
    attribute itself).
    """

    endpoints: Mapping[ChainId, Address] = field(default=_DEFAULT_ENDPOINTS)
    eid_to_chain: Mapping[int, ChainId] = field(default=_DEFAULT_EID_TO_CHAIN)
    oft_assets: Mapping[Address, Asset] = field(default=_DEFAULT_OFT_ASSETS)


LAYERZERO_V2_DECODER_NAME: Final[str] = "layerzero_v2"

# OFT V2 shared-decimals: the on-wire ``amountSD`` is encoded with this
# many fractional digits and the receiver multiplies up to the local
# asset's decimals. KelpDAO rsETH uses 6 (verified: 0x1b1ff0ed00 = 116_500e6
# scaled by 10^12 == 116500 * 10^18 = the ERC-20 Transfer log data).
_DEFAULT_OFT_SHARED_DECIMALS: Final[int] = 6
_LOCAL_ASSET_DECIMALS: Final[int] = 18

# OFT V2 wire-format layout constants (R-LZ-V2-OFT-MESSAGE-WIRE-FORMAT-SSOT).
# Extracted from inline literals at decoder bodies so a single-character
# byte-offset typo (e.g. ``message[32:40]`` -> ``message[33:41]``) cannot
# silently mis-decode amountSD with NO test failure beyond OFT happy-path
# golden.  See ``tests/unit/decoders/
# test_lz_v2_oft_message_wire_format_ssot_audit.py`` for the cross-site
# arithmetic identity invariants pinning wire-format completeness.
_SELECTOR_HEX_LENGTH: Final[int] = 10  # "0x" prefix + 4-byte selector x 2 hex
_OFT_MESSAGE_MIN_LENGTH: Final[int] = 40  # bytes32 recipient + uint64 amountSD
_OFT_RECIPIENT_BYTES: Final[int] = 32  # bytes32 recipient slice length
_OFT_RECIPIENT_PAD_BYTES: Final[int] = 12  # zero-pad bytes preceding 20-byte EVM address
_OFT_AMOUNT_SD_OFFSET: Final[int] = 32  # start offset of amountSD slice in message
_OFT_AMOUNT_SD_BYTES: Final[int] = 8  # uint64 amountSD slice length


# ---------------------------------------------------------------------------
# Slice C — Pure helpers
# ---------------------------------------------------------------------------


def _validation_error(msg: str) -> ValidationError:
    """Wrap ``msg`` in a :class:`pydantic.ValidationError` for DoD-6/8/RE."""

    class _GuardModel(BaseModel):
        model_config = _FROZEN_CONFIG
        marker: str

    try:
        _GuardModel(marker=msg, extra_field_that_does_not_exist=True)  # type: ignore[call-arg]
    except ValidationError as exc:
        return exc
    # Unreachable — extra="forbid" guarantees the call above raises.
    raise RuntimeError("validation guard failed to raise")  # pragma: no cover


def _decode_lz_receive_calldata(
    input_hex: str,
) -> tuple[int, str, int, str, str, bytes, bytes]:
    """Decode ``lzReceive((uint32,bytes32,uint64),address,bytes32,bytes,bytes)``.

    Returns
    -------
    (src_eid, sender_b32_hex, nonce, receiver_hex, guid_hex, message, extra_data)

    ``sender_b32_hex`` and ``guid_hex`` are ``0x`` + 64 hex (lowercase).
    ``receiver_hex`` is the 20-byte hex extracted from the head's address
    word. ``message`` and ``extra_data`` are bytes blobs.

    Raises :class:`pydantic.ValidationError` on misaligned length /
    nonsense head shape (DoD-6).
    """
    if not input_hex.startswith("0x") or len(input_hex) < _SELECTOR_HEX_LENGTH:
        raise _validation_error(f"lzReceive calldata too short: len={len(input_hex)}")
    body_hex = input_hex[_SELECTOR_HEX_LENGTH:]
    if len(body_hex) % 64 != 0:
        raise _validation_error(
            f"lzReceive calldata body not 32-byte aligned: hex_len={len(body_hex)}"
        )
    body = bytes.fromhex(body_hex)
    types = ("(uint32,bytes32,uint64)", "address", "bytes32", "bytes", "bytes")
    try:
        decoded = _CODEC.decode(types, body)
    except Exception as exc:  # eth_abi.DecodingError + ValueError variants
        raise _validation_error(
            f"lzReceive head decode failed: {type(exc).__name__}: {exc}"
        ) from exc
    origin, receiver, guid_bytes, message, extra_data = decoded
    src_eid, sender_bytes, nonce = origin
    sender_b32_hex = "0x" + bytes(sender_bytes).hex()
    guid_hex = "0x" + bytes(guid_bytes).hex()
    return (
        int(src_eid),
        sender_b32_hex,
        int(nonce),
        str(receiver),
        guid_hex,
        bytes(message),
        bytes(extra_data),
    )


def _parse_oft_message(message: bytes) -> tuple[str, int]:
    """Slice the OFT V2 ``_message`` payload.

    Layout: ``message[0:32]`` is the recipient (left-padded EVM address,
    ``bytes32``); ``message[32:40]`` is the ``amountSD`` (uint64
    big-endian). Anything beyond byte 40 is OFT compose data (ignored
    here; out-of-scope per §2 manifest).

    Raises :class:`pydantic.ValidationError` on short payload or when the
    recipient's top 12 bytes are non-zero (DoD-6).
    """
    if len(message) < _OFT_MESSAGE_MIN_LENGTH:
        raise _validation_error(
            f"OFT _message too short: len={len(message)} (need >= {_OFT_MESSAGE_MIN_LENGTH})"
        )
    recipient = message[:_OFT_RECIPIENT_BYTES]
    if any(b != 0 for b in recipient[:_OFT_RECIPIENT_PAD_BYTES]):
        raise _validation_error(
            f"OFT recipient bytes32 top {_OFT_RECIPIENT_PAD_BYTES} bytes "
            f"non-zero: {recipient[:_OFT_RECIPIENT_PAD_BYTES].hex()}"
        )
    amount_sd = int.from_bytes(
        message[_OFT_AMOUNT_SD_OFFSET : _OFT_AMOUNT_SD_OFFSET + _OFT_AMOUNT_SD_BYTES],
        "big",
    )
    return "0x" + recipient.hex(), amount_sd


def _find_oft_event(
    logs: tuple[NormalizedLog, ...],
    *,
    oft_adapters: Mapping[Address, Asset],
) -> NormalizedLog | None:
    """Return the first OFT event emitted by a known adapter, or ``None``."""
    for log in logs:
        if log.topics and log.topics[0] == _OFT_RECEIVED_TOPIC and log.address in oft_adapters:
            return log
    return None


def _find_packet_event(
    logs: tuple[NormalizedLog, ...],
    *,
    endpoint: Address,
) -> NormalizedLog | None:
    """Return the first PacketDelivered event from ``endpoint``, or ``None``."""
    for log in logs:
        if log.topics and log.topics[0] == _PACKET_DELIVERED_TOPIC and log.address == endpoint:
            return log
    return None


def _read_word(data_hex: str, word_index: int) -> int:
    """Read the ``word_index``-th 32-byte word from a hex ``data`` blob."""
    offset = 2 + word_index * 64  # skip '0x'
    return int(data_hex[offset : offset + 64], 16)


def _assert_event_calldata_coherence(
    *,
    guid: str,
    src_eid: int,
    amount_sd: int,
    oft_log: NormalizedLog | None,
    packet_log: NormalizedLog | None,
) -> None:
    """Cross-validate calldata fields against the emitted event logs (DoD-8).

    On any mismatch raises :class:`pydantic.ValidationError`. This is
    intentionally strict: structural on-chain corruption must not silently
    produce a bogus :class:`CrossChainHop`. Single-event presence skips the
    missing arm's checks; both-absent is caller's responsibility (decode
    returns ``()`` in that case per DoD-7).
    """
    if oft_log is not None:
        # ``_find_oft_event`` gates only on ``topics[0] == _OFT_RECEIVED_TOPIC``,
        # which guarantees >=1 topic but NOT >=2; guard the indexed-guid read by
        # LENGTH (parity with every sibling decoder's ``len(...) < N`` form) so a
        # 1-topic OFT log raises the decoder's ValidationError, not a raw
        # ``IndexError`` escaping the contract. This also makes the ``<missing>``
        # message branch below reachable.
        if len(oft_log.topics) < 2 or oft_log.topics[1] != guid:
            raise _validation_error(
                "OFTReceived.guid mismatch: "
                f"calldata guid={guid}, log topics[1]="
                f"{oft_log.topics[1] if len(oft_log.topics) > 1 else '<missing>'}"
            )
        # OFT log ``data`` is two 32-byte words: srcEid then amount (uint256).
        # Length guard before the word-index-1 read so a too-short ``data``
        # raises the decoder's ValidationError, not a raw ``int("", 16)``
        # ValueError (parity with every sibling decoder's event-data read).
        if len(oft_log.data) < 2 + 2 * 64:
            raise _validation_error(
                f"OFTReceived data too short for srcEid+amount words: {len(oft_log.data)} < 130"
            )
        # Cross-check amount: log amount must equal amount_sd scaled to 18 dec.
        log_amount = _read_word(oft_log.data, 1)
        expected = _scale_amount_sd_to_18(amount_sd)
        if log_amount != expected:
            raise _validation_error(
                f"OFTReceived.amount mismatch: log={log_amount}, "
                f"calldata amount_sd scaled={expected}"
            )
    if packet_log is not None:
        # Length guard before the word-0 read (parity with the OFT arm above).
        if len(packet_log.data) < 2 + 64:
            raise _validation_error(
                f"PacketDelivered data too short for srcEid word: {len(packet_log.data)} < 66"
            )
        log_src_eid = _read_word(packet_log.data, 0)
        if log_src_eid != src_eid:
            raise _validation_error(
                f"PacketDelivered.srcEid mismatch: log={log_src_eid}, calldata src_eid={src_eid}"
            )


def _scale_amount_sd_to_18(
    amount_sd: int, *, shared_decimals: int = _DEFAULT_OFT_SHARED_DECIMALS
) -> int:
    """Scale the OFT shared-decimals amount up to 18-decimal minor units.

    LayerZero V2 OFT amounts travel on-wire with a configurable
    ``sharedDecimals`` (KelpDAO rsETH uses 6); the receiver multiplies by
    ``10 ** (localDecimals - sharedDecimals)`` to reach the local asset's
    decimals. Raises :class:`ValueError` on negative input (matches the
    bytes-to-int parse which produces a non-negative uint64).
    """
    if amount_sd < 0:
        raise ValueError(f"amount_sd must be non-negative, got {amount_sd}")
    return int(amount_sd * (10 ** (_LOCAL_ASSET_DECIMALS - shared_decimals)))


def _address_from_bytes32(b32_hex: str, *, chain: ChainId) -> Address:
    """Convert an EVM left-padded ``bytes32`` (66-char hex) to a chain Address.

    Caller guarantees the top 12 bytes are zero
    (validated in :func:`_parse_oft_message`).
    """
    bottom_20 = b32_hex[-40:]
    return Address.from_str("0x" + bottom_20, chain)


# ---------------------------------------------------------------------------
# Slice B — Decoder model
# ---------------------------------------------------------------------------


class LayerZeroV2Decoder(BaseModel):
    """Pydantic v2 :class:`BridgeDecoder` for LayerZero V2 OFT deliveries.

    The model is :data:`_FROZEN_CONFIG`-protected so all attributes are
    immutable post-construction; the registry's ``runtime_checkable``
    Protocol probe inspects attribute presence (``name``, ``priority``,
    ``matches``, ``decode``) which Pydantic v2 supplies as descriptors
    on the class.
    """

    model_config = _FROZEN_CONFIG

    name: str = LAYERZERO_V2_DECODER_NAME
    priority: int = 10
    config: LayerZeroV2DecoderConfig = Field(default_factory=LayerZeroV2DecoderConfig)

    def matches(self, tx: NormalizedTransaction) -> bool:
        """Cheap four-arm AND predicate (DoD-4).

        Never raises on ill-formed (but valid :class:`NormalizedTransaction`)
        input — that's the registry's contract. A ``None`` tx is malformed
        (B-T12 documents the natural ``AttributeError`` surface).
        """
        chain = tx.chain
        if chain not in self.config.endpoints:
            return False
        if chain is not ChainId.ETHEREUM:
            return False
        endpoint = self.config.endpoints[chain]
        if tx.to_addr is None or tx.to_addr != endpoint:
            return False
        input_hex = tx.input
        if input_hex is None or len(input_hex) < _SELECTOR_HEX_LENGTH:
            return False
        return input_hex[:_SELECTOR_HEX_LENGTH] == _LZ_RECEIVE_SELECTOR

    def decode(
        self,
        tx: NormalizedTransaction,
        logs: tuple[NormalizedLog, ...],
    ) -> tuple[CrossChainHop, ...]:
        """Decode ``lzReceive`` calldata + cross-validate against event logs.

        Returns a 1-element tuple when all gates pass; ``()`` for routine
        "matches the selector but the shape doesn't fit our Phase 1 OFT
        pattern" outcomes (unknown EID, missing logs, ambiguous adapter).
        Raises :class:`pydantic.ValidationError` only for structural
        corruption (mis-aligned calldata, non-left-padded recipient,
        mismatched on-chain evidence — DoD-6 / DoD-8).
        """
        if not self.matches(tx):
            return ()
        input_hex = tx.input
        # ``matches`` rules out ``None``; mypy needs the explicit guard.
        assert input_hex is not None
        (
            src_eid,
            _sender_b32,
            _nonce,
            _receiver_hex,
            guid,
            message,
            _extra_data,
        ) = _decode_lz_receive_calldata(input_hex)
        recipient_b32, amount_sd = _parse_oft_message(message)
        # EID miss → () (DoD-10 / D-1) — never raise.
        try:
            src_chain = self.config.eid_to_chain[src_eid]
        except KeyError:
            return ()
        oft_event = _find_oft_event(logs, oft_adapters=self.config.oft_assets)
        endpoint = self.config.endpoints[tx.chain]
        packet_event = _find_packet_event(logs, endpoint=endpoint)
        if oft_event is None and packet_event is None:
            return ()
        _assert_event_calldata_coherence(
            guid=guid,
            src_eid=src_eid,
            amount_sd=amount_sd,
            oft_log=oft_event,
            packet_log=packet_event,
        )
        # Resolve asset_out: the OFT log's emitter is authoritative; if
        # absent, fall back to the unique configured asset (Phase 1).
        if oft_event is not None:
            asset_out = self.config.oft_assets[oft_event.address]
        elif len(self.config.oft_assets) == 1:
            asset_out = next(iter(self.config.oft_assets.values()))
        else:
            return ()  # Ambiguous — defer to abi_fallback.
        # The OFT adapter contract on the src chain is unknown — Asset
        # cross-validates ``contract.chain == self.chain`` so we must drop
        # the destination-chain contract reference when rebinding.
        asset_in = asset_out.model_copy(update={"chain": src_chain, "contract": None})
        recipient = _address_from_bytes32(recipient_b32, chain=tx.chain)
        raw_18 = _scale_amount_sd_to_18(amount_sd)
        amount = Amount(raw=raw_18, decimals=_LOCAL_ASSET_DECIMALS)
        hop = CrossChainHop(
            src_chain=src_chain,
            dst_chain=tx.chain,
            src_tx=tx.tx_hash,
            dst_address=recipient,
            via=LAYERZERO_V2_DECODER_NAME,
            memo=None,
            asset_in=asset_in,
            asset_out=asset_out,
            amount_in=amount,
            amount_out=amount,
        )
        return (hop,)


def register_layerzero_v2_decoder(
    config: LayerZeroV2DecoderConfig | None = None,
) -> LayerZeroV2Decoder:
    """Construct and register the LayerZero V2 decoder on the singleton.

    Caller controls the lifecycle: import-time registration is
    deliberately avoided so ``get_decoder_registry.cache_clear()`` test
    discipline (P1-008 DoD-14) keeps working. Tests / bootstraps that
    need the decoder call this explicitly.
    """
    decoder = LayerZeroV2Decoder() if config is None else LayerZeroV2Decoder(config=config)
    register_decoder(decoder)
    return decoder


# Silence pyflakes / mypy "imported but unused" — these are part of the
# documented module surface for downstream tests.
_ = (_OFT_RECEIVED_TOPIC, _PACKET_DELIVERED_TOPIC, Any)
