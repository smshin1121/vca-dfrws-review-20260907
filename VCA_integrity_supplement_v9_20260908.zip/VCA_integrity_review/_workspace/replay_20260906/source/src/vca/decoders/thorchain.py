"""THORChain Router decoder (P1-010).

Second concrete :class:`vca.decoders.BridgeDecoder` implementation:
THORChain's public exit hatch ``depositWithExpiry(vault, asset, amount,
memo, expiry)`` is the call the KelpDAO laundering chain uses to bridge
ETH→BTC (source §3.가.3.사 anchor + line 174). Given a
:class:`NormalizedTransaction` whose ``to_addr`` is a registered Router
and whose ``input[:10]`` is the ``depositWithExpiry`` selector, the
decoder:

1. ABI-decodes the call head via the shared
   :data:`vca.decoders.abi_fallback.decode._CODEC` (P1-012 R-CODEC-REUSE),
2. parses the memo string with the canonical Phase-1 regex pinned to
   :data:`_THORCHAIN_MEMO_REGEX_VERSION` ``= "v1"`` (RR-3: future memo
   format ships as a NEW decoder class, never a mutation),
3. validates the parsed ``target_chain`` against a closed Phase-1 set
   (``b``, ``btc``, ``eth``, ``bsc``, ``ltc``, ``doge``, ``bch``,
   ``gaia``, ``thor``),
4. structurally cross-validates the calldata ``amount`` against the
   ERC-20 ``Transfer`` log emitted by ``asset`` when present (DoD-8:
   silent-bug guardrail — mismatch raises :class:`ValidationError`),
5. returns a single :class:`CrossChainHop` only when the parsed chain
   code is BTC (``b`` or ``btc``); other recognised codes return ``()``
   under the Phase-1 R-BTC-ONLY-PHASE1 rule.

The decoder is **pure**: no I/O, no clock reads, no environment access,
no logging. R-CODEC-REUSE re-imports the shared ABI codec rather than
constructing a second :class:`eth_abi.codec.ABICodec`. R-NO-NEW-DEP: the
module reaches for ``eth_utils.keccak`` (already locked transitively via
``eth_abi``) only at import time to pin the selector / Transfer topic.

See ``_workspace/p1-010_architect_wbs.md`` for the full WBS.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from re import Pattern
from re import compile as _re_compile
from types import MappingProxyType
from typing import Final

from eth_utils import keccak  # type: ignore[attr-defined]
from pydantic import BaseModel, Field, ValidationError

from vca.decoders.abi_fallback.decode import _CODEC
from vca.decoders.registry import register_decoder
from vca.types import (
    Address,
    Amount,
    Asset,
    ChainId,
    CrossChainHop,
    NormalizedLog,
    NormalizedTransaction,
)
from vca.types._bech32 import normalize_btc_address
from vca.types.normalized import _FROZEN_CONFIG

__all__ = [
    "THORCHAIN_DECODER_NAME",
    "ThorchainDecoder",
    "ThorchainDecoderConfig",
    "register_thorchain_decoder",
]


# ---------------------------------------------------------------------------
# Slice A — Constants pinned at module import (DoD-12)
# ---------------------------------------------------------------------------


_DEPOSIT_WITH_EXPIRY_SIGNATURE: Final[str] = (
    "depositWithExpiry(address,address,uint256,string,uint256)"
)
_TRANSFER_SIGNATURE: Final[str] = "Transfer(address,address,uint256)"


def _selector(sig: str) -> str:
    """4-byte function selector ``0x`` + 8 hex (lowercase)."""
    return "0x" + keccak(text=sig).hex()[:8]


def _topic(sig: str) -> str:
    """32-byte event topic ``0x`` + 64 hex (lowercase)."""
    return "0x" + keccak(text=sig).hex()


# WBS DoD-12: builder pre-flight verified this equals "0x44bc937b" before
# the first RED test was written. The module-level assert below is the
# import-time tripwire so any future eth_utils upgrade that drifts keccak
# is caught at first import rather than at runtime decode.
_DEPOSIT_WITH_EXPIRY_SELECTOR: Final[str] = _selector(_DEPOSIT_WITH_EXPIRY_SIGNATURE)
_ERC20_TRANSFER_TOPIC: Final[str] = _topic(_TRANSFER_SIGNATURE)


# Import-time selector tripwire (WBS R-1 mitigation, DoD-12). Any drift in
# eth_utils.keccak relative to the EVM spec would corrupt every Router
# match silently — surface it at module load so the test suite cannot even
# import.
if _DEPOSIT_WITH_EXPIRY_SELECTOR != "0x44bc937b":  # pragma: no cover - import-time tripwire
    raise RuntimeError(
        f"depositWithExpiry selector keccak drift detected: "
        f"{_DEPOSIT_WITH_EXPIRY_SELECTOR!r} (expected 0x44bc937b). "
        "Refusing module import — investigate eth_utils.keccak."
    )


# WBS RR-3 / R-MEMO-VERSION: dot-versioned name + version constant pin
# the intent that a v2 memo format ships as a NEW class, not a mutation.
_THORCHAIN_MEMO_REGEX_VERSION: Final[str] = "v1"
_THORCHAIN_MEMO_RE_V1: Final[Pattern[str]] = _re_compile(
    r"^=:(?P<chain>[a-z]+):(?P<addr>[^:]+):(?P<limits>.*)$"
)


# DoD-11 closed Phase-1 set. Adding a code is a controlled change (RR-3).
_THORCHAIN_CHAIN_CODES: Final[frozenset[str]] = frozenset(
    {"b", "btc", "eth", "bsc", "ltc", "doge", "bch", "gaia", "thor"}
)
_BTC_CHAIN_CODES: Final[frozenset[str]] = frozenset({"b", "btc"})


# P3.2-007: THORChain's native-ETH Router deposits encode the ``asset`` argument
# as the ZERO ADDRESS — the deposited value is native ETH (the calldata
# ``amount`` field, == ``tx.value_native.raw``) with NO ERC-20 ``Transfer`` log.
# Decode-time the decoder branches on this sentinel: zero address → native-ETH
# branch (mirrors :mod:`vca.decoders.thorchain_vault`); non-zero → the existing
# ERC-20 ``asset_decimals`` + Transfer-log coherence branch.
_ZERO_ADDRESS: Final[str] = "0x0000000000000000000000000000000000000000"


def _eth_addr(value: str) -> Address:
    return Address.from_str(value, ChainId.ETHEREUM)


# THORChain Router V4 (Ethereum). Source-doc §3.가.3.사 body is redacted;
# this is the THORChain public docs canonical address. PR reviewer SHOULD
# cross-check on Etherscan before merge (WBS DoD-25 / R-ROUTER-PIN).
_DEFAULT_THORCHAIN_ROUTER_V4_ETH: Final[str] = "0xD37BbE5744D730a1d98d8DC97c42F0Ca46aD7146"
_DEFAULT_ROUTERS: Final[Mapping[ChainId, Address]] = MappingProxyType(
    {ChainId.ETHEREUM: _eth_addr(_DEFAULT_THORCHAIN_ROUTER_V4_ETH)}
)


# WBS R-ASSET-DECIMAL-TABLE: the default is empty. Case bootstrap
# (P1-018 follow-up) injects ``{WETH9: 18}`` when wiring the decoder
# into the live tracer.
_DEFAULT_ASSET_DECIMALS: Final[Mapping[Address, int]] = MappingProxyType({})


# WBS R-ASSET-SYMBOL-OPACITY: a tiny default-symbol map for the one
# Phase-1 asset (wETH9) so the emitted :class:`Asset` round-trips with a
# meaningful symbol when the case bootstrap wires it. Missing entry → the
# decoder uses the ``"TC_ASSET"`` placeholder.
_WETH9_ETH: Final[Address] = _eth_addr("0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2")
_DEFAULT_ASSET_SYMBOLS: Final[Mapping[Address, str]] = MappingProxyType({_WETH9_ETH: "wETH"})
_PLACEHOLDER_ASSET_SYMBOL: Final[str] = "TC_ASSET"


@dataclass(frozen=True, slots=True)
class ThorchainDecoderConfig:
    """Phase-1 decoder configuration — Router addresses + asset decimals.

    Both mappings default to :class:`types.MappingProxyType` so the
    default instance is structurally immutable; callers passing
    overrides MUST wrap them in ``MappingProxyType(...)`` to preserve
    the invariant (the dataclass ``frozen=True`` only blocks
    re-assignment of the attribute itself).
    """

    routers: Mapping[ChainId, Address] = field(default=_DEFAULT_ROUTERS)
    asset_decimals: Mapping[Address, int] = field(default=_DEFAULT_ASSET_DECIMALS)
    asset_symbols: Mapping[Address, str] = field(default=_DEFAULT_ASSET_SYMBOLS)


THORCHAIN_DECODER_NAME: Final[str] = "thorchain.v1"


# ---------------------------------------------------------------------------
# Slice C — Pure helpers (calldata + memo + Transfer log + amount coherence)
# ---------------------------------------------------------------------------


class _MemoDecodeError(Exception):
    """Sentinel raised when calldata head is sound but the memo bytes are
    not valid UTF-8. Caught inside :meth:`ThorchainDecoder.decode` and
    mapped to ``()`` per DoD-7 (memo encoding is *not* structural
    corruption — the call still lands on-chain).
    """


def _validation_error(msg: str) -> ValidationError:
    """Wrap ``msg`` in :class:`pydantic.ValidationError` (DoD-6/8 surface).

    Mirrors the P1-009 helper: build a throw-away ``_FROZEN_CONFIG`` /
    ``extra="forbid"`` model and trigger validation with an unknown extra
    field. Pydantic translates that into a :class:`ValidationError` whose
    ``errors()`` list contains ``msg``, satisfying ``pytest.raises``.
    """

    class _GuardModel(BaseModel):
        model_config = _FROZEN_CONFIG
        marker: str

    try:
        _GuardModel(marker=msg, extra_field_that_does_not_exist=True)  # type: ignore[call-arg]
    except ValidationError as exc:
        return exc
    # Unreachable — extra="forbid" guarantees the call above raises.
    raise RuntimeError("validation guard failed to raise")  # pragma: no cover


def _decode_deposit_with_expiry_calldata(
    input_hex: str,
) -> tuple[str, str, int, str, int]:
    """Decode ``depositWithExpiry(address,address,uint256,string,uint256)``.

    Returns ``(vault_hex, asset_hex, amount, memo_str, expiry)``.

    Raises :class:`pydantic.ValidationError` on mis-aligned length or any
    ``eth_abi`` decode failure (DoD-6). Raises :class:`_MemoDecodeError`
    when the memo bytes are not valid UTF-8 (DoD-7 — caller maps to ``()``).
    """
    if not input_hex.startswith("0x") or len(input_hex) < 10:
        raise _validation_error(f"depositWithExpiry calldata too short: len={len(input_hex)}")
    body_hex = input_hex[10:]
    if len(body_hex) % 64 != 0:
        raise _validation_error(
            f"depositWithExpiry calldata body not 32-byte aligned: hex_len={len(body_hex)}"
        )
    body = bytes.fromhex(body_hex)
    types = ("address", "address", "uint256", "string", "uint256")
    try:
        decoded = _CODEC.decode(types, body)
    except UnicodeDecodeError as exc:
        # eth_abi raises this when the inline string field fails utf-8 decode.
        raise _MemoDecodeError(str(exc)) from exc
    except Exception as exc:  # eth_abi.DecodingError + ValueError variants
        raise _validation_error(
            f"depositWithExpiry head decode failed: {type(exc).__name__}: {exc}"
        ) from exc
    vault, asset, amount, memo, expiry = decoded
    return str(vault), str(asset), int(amount), str(memo), int(expiry)


def _parse_thorchain_memo(memo: str) -> tuple[str, str, str] | None:
    """Apply :data:`_THORCHAIN_MEMO_RE_V1`; return ``None`` on non-match.

    Returns ``(chain_code, addr, limits_tail)``. The regex's ``chain``
    group is constrained to ``[a-z]+`` so ``chain_code`` is naturally
    lowercase; ``addr`` is preserved case-sensitively because base58 BTC
    addresses are case-sensitive.
    """
    match = _THORCHAIN_MEMO_RE_V1.fullmatch(memo)
    if match is None:
        return None
    return match.group("chain"), match.group("addr"), match.group("limits")


def _topic_address(topic: str, chain: ChainId) -> Address | None:
    """Convert a 32-byte indexed-address topic word to :class:`Address`.

    :class:`NormalizedLog` already validates topic hex shape (``0x`` +
    64 lowercase hex), so the helper only needs to defend against the
    one structural failure that survives that gate: non-zero top 12
    bytes (a malformed indexed address). Pure.
    """
    if any(c != "0" for c in topic[2:26]):
        return None
    return Address.from_str("0x" + topic[26:], chain)


def _find_transfer_event(
    logs: tuple[NormalizedLog, ...],
    *,
    asset: Address,
    from_addr: Address,
    to_addr: Address,
) -> NormalizedLog | None:
    """First ERC-20 ``Transfer`` log emitted by ``asset`` matching from/to.

    Returns ``None`` if no such log is present. Pure. Defensive: empty
    topics tuple, mis-formed topic words, and indexed-from/indexed-to
    mismatches all route to a skip rather than a raise (D-2: missing log
    is normal).
    """
    chain = asset.chain
    for log in logs:
        if not log.topics or log.topics[0] != _ERC20_TRANSFER_TOPIC:
            continue
        if log.address != asset:
            continue
        if len(log.topics) < 3:
            continue
        log_from = _topic_address(log.topics[1], chain)
        log_to = _topic_address(log.topics[2], chain)
        if log_from == from_addr and log_to == to_addr:
            return log
    return None


def _read_uint256_word(data_hex: str, word_index: int) -> int:
    """Read the ``word_index``-th 32-byte word as uint256 (big-endian)."""
    offset = 2 + word_index * 64  # skip '0x'
    return int(data_hex[offset : offset + 64], 16)


def _assert_amount_coherence(
    *,
    decoded_amount: int,
    transfer_log: NormalizedLog | None,
) -> None:
    """DoD-8: cross-validate calldata ``amount`` vs Transfer log ``value``.

    No-op when ``transfer_log`` is ``None`` (missing log is the
    weaker-provenance branch — D-2: tracer logs and continues). Mismatch
    raises :class:`pydantic.ValidationError`.
    """
    if transfer_log is None:
        return
    log_value = _read_uint256_word(transfer_log.data, 0)
    if log_value != decoded_amount:
        raise _validation_error(
            f"Transfer.value mismatch: log_value={log_value}, calldata_amount={decoded_amount}"
        )


def _assert_native_amount_coherence(*, decoded_amount: int, value_native_raw: int) -> None:
    """P3.2-007 silent-bug guard for the native-ETH Router branch.

    The native analogue of :func:`_assert_amount_coherence`: a native-ETH
    THORChain Router deposit carries NO ERC-20 ``Transfer`` log, so the calldata
    ``amount`` is cross-validated against the on-chain native value
    (``tx.value_native.raw``) instead. A genuine mismatch raises
    :class:`pydantic.ValidationError` (a deposit whose advertised ``amount``
    diverges from the ETH actually sent is structural corruption, never a
    weaker-provenance branch). This is a NEW helper, not a mutation of the
    SSOT-pinned :func:`_assert_amount_coherence` (gated at the native call site
    only).
    """
    if decoded_amount != value_native_raw:
        raise _validation_error(
            f"native amount mismatch: calldata_amount={decoded_amount}, "
            f"value_native={value_native_raw}"
        )


# ---------------------------------------------------------------------------
# Slice B / C — Decoder model
# ---------------------------------------------------------------------------


class ThorchainDecoder(BaseModel):
    """Pydantic v2 :class:`BridgeDecoder` for THORChain Router deposits.

    Frozen post-construction (``_FROZEN_CONFIG``); the registry's
    ``runtime_checkable`` Protocol probe inspects attribute presence
    (``name``, ``priority``, ``matches``, ``decode``), all of which
    Pydantic v2 supplies as descriptors on the class.
    """

    model_config = _FROZEN_CONFIG

    name: str = THORCHAIN_DECODER_NAME
    priority: int = 20
    config: ThorchainDecoderConfig = Field(default_factory=ThorchainDecoderConfig)

    # P2-006.2: direct-to-vault THORChain deposits are intentionally NOT
    # matched here. The Stage-7 capture (P2-006.1) found 8 of 25 deposits
    # (Exploiter 18/19) send ETH straight to the THORChain Asgard vault
    # (0x9Fc30541611132C5AC38318E8eEE044d2d36996F) with the swap memo as RAW
    # calldata (input[:10] == 0x3d3a4254 == "=:BT"; memo form
    # "=:BTC.BTC:<addr>:<limit>/1/0"), emitting no Deposit event. ``matches``
    # below only recognises Router ``depositWithExpiry`` calls (to_addr ==
    # router AND selector == 0x44bc937b). Those 8 BTC hops are decoded by the
    # separate :class:`vca.decoders.thorchain_vault.ThorchainVaultDecoder`
    # (new transport + ``=:ASSET.ASSET:`` memo regex; a NEW class per RR-3,
    # not a mutation of this v1 decoder). The two match arms are DISJOINT.
    def matches(self, tx: NormalizedTransaction) -> bool:
        """Cheap four-arm AND predicate (DoD-4).

        Never raises on a valid :class:`NormalizedTransaction`. A ``None``
        ``tx`` is malformed (not ill-formed) and surfaces as the natural
        :class:`AttributeError` documented in B-T12.
        """
        chain = tx.chain
        if chain is not ChainId.ETHEREUM:
            return False
        router = self.config.routers.get(chain)
        if router is None:
            return False
        if tx.to_addr is None or tx.to_addr != router:
            return False
        input_hex = tx.input
        if input_hex is None or len(input_hex) < 10:
            return False
        return input_hex[:10] == _DEPOSIT_WITH_EXPIRY_SELECTOR

    def decode(
        self,
        tx: NormalizedTransaction,
        logs: tuple[NormalizedLog, ...],
    ) -> tuple[CrossChainHop, ...]:
        """Decode + cross-validate; emit one BTC hop or ``()``.

        Two asset branches keyed on the calldata ``asset`` argument:

        * **Native ETH (zero address)** — P3.2-007: the deposited value is
          native ETH (the calldata ``amount``, == ``tx.value_native.raw``) with
          no ERC-20 ``Transfer`` log. ``asset_in`` is :meth:`Asset.native` on
          the tx chain; the amount is cross-validated against the native value
          (``_assert_native_amount_coherence``), mirroring
          :mod:`vca.decoders.thorchain_vault`.
        * **ERC-20 (non-zero address)** — the original branch: the asset is
          looked up in ``config.asset_decimals`` and the calldata ``amount`` is
          cross-validated against the ERC-20 ``Transfer`` log.

        Routine non-BTC memos, unknown chain codes, invalid BTC addresses,
        and (ERC-20 branch only) missing asset-decimals entries all return
        ``()`` (DoD-7 / D-1). Structural corruption (mis-aligned calldata,
        amount mismatch on either branch) raises
        :class:`pydantic.ValidationError` (DoD-6 / DoD-8).
        """
        if not self.matches(tx):
            return ()
        # ``matches`` guarantees both `tx.input` and `tx.to_addr` are set;
        # mypy still needs the explicit guards.
        assert tx.input is not None
        assert tx.from_addr is not None
        try:
            vault_hex, asset_hex, amount, memo_str, _expiry = _decode_deposit_with_expiry_calldata(
                tx.input
            )
        except _MemoDecodeError:
            return ()
        parsed = _parse_thorchain_memo(memo_str)
        if parsed is None:
            return ()
        chain_code, addr, _limits = parsed
        if chain_code not in _THORCHAIN_CHAIN_CODES:
            return ()
        if chain_code not in _BTC_CHAIN_CODES:
            return ()
        try:
            canonical_btc = normalize_btc_address(addr)
        except ValueError:
            return ()
        asset_addr = Address.from_str(asset_hex, tx.chain)
        zero_addr = Address.from_str(_ZERO_ADDRESS, tx.chain)
        if asset_addr == zero_addr:
            # P3.2-007 native-ETH Router deposit: the ``asset`` argument is the
            # zero address and the deposited ETH is carried in ``msg.value``
            # (``tx.value_native.raw``). There is no ERC-20 ``Transfer`` log, so
            # the ERC-20 ``asset_decimals`` lookup + Transfer-log coherence is
            # skipped; the native value is cross-validated instead (mirrors
            # :mod:`vca.decoders.thorchain_vault`). The SSOT-pinned
            # ``_assert_amount_coherence`` is intentionally NOT reached here.
            #
            # P3.4-002 (Bybit): the THORChain Router ``depositWithExpiry``
            # calldata ``amount`` argument is overloaded across native deposits:
            # KelpDAO's hop sets it to the deposited value (== ``msg.value``),
            # but Bybit's hop (tx ``0x16ed29f9``) sets it to ``0`` and relies on
            # ``msg.value`` alone (a valid native-deposit convention). Treat a
            # zero calldata amount as "use ``msg.value``"; for a NON-zero
            # calldata amount, still cross-validate it equals ``msg.value`` so a
            # genuine advertised/sent divergence remains structural corruption.
            effective_amount = tx.value_native.raw if amount == 0 else amount
            _assert_native_amount_coherence(
                decoded_amount=effective_amount, value_native_raw=tx.value_native.raw
            )
            asset_in = Asset.native(tx.chain)
            amount_in = Amount(raw=effective_amount, decimals=asset_in.decimals)
        else:
            # Existing ERC-20 branch (asset_decimals lookup + Transfer-log
            # coherence) — unchanged. A non-zero asset absent from the table
            # defers to () exactly as before (DoD-7 / R-ASSET-DECIMAL-TABLE).
            if asset_addr not in self.config.asset_decimals:
                return ()
            vault_addr = Address.from_str(vault_hex, tx.chain)
            transfer_log = _find_transfer_event(
                logs,
                asset=asset_addr,
                from_addr=tx.from_addr,
                to_addr=vault_addr,
            )
            # Length guard before the coherence word-0 read — a malformed
            # ``Transfer`` log with ``data="0x"`` would otherwise raise a raw
            # ``ValueError`` from ``int("", 16)`` instead of the decoder's
            # contract-level :class:`pydantic.ValidationError`. Guarded at the
            # call site (the ``_assert_amount_coherence`` body is SSOT-pinned).
            if transfer_log is not None:
                expected_transfer_data_hex_len = 2 + 64
                if len(transfer_log.data) < expected_transfer_data_hex_len:
                    raise _validation_error(
                        f"THORChain Transfer log data too short: "
                        f"{len(transfer_log.data)} < {expected_transfer_data_hex_len}"
                    )
            _assert_amount_coherence(decoded_amount=amount, transfer_log=transfer_log)
            decimals = self.config.asset_decimals[asset_addr]
            symbol = self.config.asset_symbols.get(asset_addr, _PLACEHOLDER_ASSET_SYMBOL)
            asset_in = Asset(
                chain=tx.chain,
                symbol=symbol,
                decimals=decimals,
                contract=asset_addr,
            )
            amount_in = Amount(raw=amount, decimals=decimals)
        asset_out = Asset.native(ChainId.BITCOIN)
        hop = CrossChainHop(
            src_chain=tx.chain,
            dst_chain=ChainId.BITCOIN,
            src_tx=tx.tx_hash,
            dst_address=Address.from_str(canonical_btc, ChainId.BITCOIN),
            via=THORCHAIN_DECODER_NAME,
            memo=memo_str,
            asset_in=asset_in,
            asset_out=asset_out,
            amount_in=amount_in,
            amount_out=None,
        )
        return (hop,)


def register_thorchain_decoder(
    config: ThorchainDecoderConfig | None = None,
) -> ThorchainDecoder:
    """Construct and register the THORChain decoder on the singleton.

    Caller controls the lifecycle: import-time registration is
    deliberately avoided so ``get_decoder_registry.cache_clear()`` test
    discipline (P1-008 DoD-14) keeps working.
    """
    decoder = ThorchainDecoder() if config is None else ThorchainDecoder(config=config)
    register_decoder(decoder)
    return decoder
