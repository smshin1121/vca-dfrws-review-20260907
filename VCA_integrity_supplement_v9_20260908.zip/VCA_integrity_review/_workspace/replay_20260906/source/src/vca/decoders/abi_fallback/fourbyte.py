"""4byte.directory tier client (P1-012).

Selector-keyed signature lookup. Public API, no key. Returns up to 50
candidates per selector for common collisions; the in-tier ranking
(:func:`vca.decoders.abi_fallback.decode.rank_candidates`) attempts older
``id`` entries first.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any, Final

import httpx

from vca.decoders.abi_fallback._errors import FourByteError
from vca.decoders.abi_fallback.decode import AbiCandidate, AbiSource

_FOURBYTE_DEFAULT_BASE_URL: Final[str] = "https://www.4byte.directory"
_FOURBYTE_PATH: Final[str] = "/api/v1/signatures/"


def is_fourbyte_ok(payload: Mapping[str, Any]) -> bool:
    """Cache-write gate: reject obviously-malformed 4byte responses.

    A genuine empty answer (``{"count":0,"results":[]}``) is cacheable —
    the resolver still treats it as "no candidates". A non-dict body or a
    body missing ``"results"`` is corrupt and must not poison the cache.
    """
    if not isinstance(payload, dict):
        return False
    if "results" not in payload:
        return False
    return isinstance(payload["results"], list)


async def lookup_fourbyte(
    http_client: Any,
    *,
    selector: str,
    base_url: str = _FOURBYTE_DEFAULT_BASE_URL,
    ttl: int | None,
    rate_limit_source: str,
    raw_store: Any | None = None,
) -> tuple[AbiCandidate, ...]:
    """GET ``/api/v1/signatures/?hex_signature=<sel>`` and return candidates.

    Returns:
        Possibly empty tuple of :class:`AbiCandidate`. Each candidate
        carries the 4byte ``id`` in ``extras`` so the in-tier ranker can
        sort by ascending insertion order.

    Raises:
        FourByteError: 5xx-after-retry, malformed JSON, missing
            ``"results"`` key, or unexpected ``"results"`` shape.
    """
    url = base_url.rstrip("/") + _FOURBYTE_PATH
    params: dict[str, Any] = {
        "hex_signature": selector,
        "format": "json",
        "ordering": "created_at",
    }
    try:
        payload = await http_client.get_json(
            url,
            params,
            source=rate_limit_source,
            ttl=ttl,
            validator=is_fourbyte_ok,
        )
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            return ()
        raise FourByteError(
            f"4byte HTTP {exc.response.status_code} for selector={selector}",
            tier=AbiSource.FOURBYTE,
            selector=selector,
            original_status=exc.response.status_code,
        ) from exc
    except httpx.HTTPError as exc:
        raise FourByteError(
            f"4byte transport failure for selector={selector}: {exc}",
            tier=AbiSource.FOURBYTE,
            selector=selector,
        ) from exc
    except json.JSONDecodeError as exc:
        # Codex P2-1: a 200 response carrying invalid JSON would otherwise
        # propagate ``json.JSONDecodeError`` past ``AbiFallbackResolver`` and
        # crash the entire ``resolve()`` call. Wrap into the tier-specific
        # error so the resolver isolates the failure and moves to the next
        # tier (Sourcify / Etherscan) as documented.
        raise FourByteError(
            f"4byte response was not valid JSON for selector={selector}: {exc.msg}",
            tier=AbiSource.FOURBYTE,
            selector=selector,
        ) from exc

    if raw_store is not None:
        # Persistence is best-effort; we intentionally never let a raw_store
        # failure bring the resolver down. The unit-test FakeRawStore raises
        # nothing, but a real LocalRawStore could surface IOError.
        try:
            from vca.http.client import params_hash

            await raw_store.put(
                source=rate_limit_source,
                endpoint="4byte/signatures",
                params_hash=params_hash(params, url=url),
                payload=payload,
                status_code=200,
                ttl=ttl,
            )
        except Exception:
            pass

    if not isinstance(payload, dict) or "results" not in payload:
        raise FourByteError(
            f"4byte response missing 'results' key for selector={selector}",
            tier=AbiSource.FOURBYTE,
            selector=selector,
        )
    results = payload["results"]
    if not isinstance(results, list):
        raise FourByteError(
            f"4byte 'results' must be a list, got {type(results).__name__}",
            tier=AbiSource.FOURBYTE,
            selector=selector,
        )
    candidates: list[AbiCandidate] = []
    for entry in results:
        if not isinstance(entry, Mapping):
            continue
        text_sig = entry.get("text_signature")
        if not isinstance(text_sig, str):
            continue
        fourbyte_id = entry.get("id")
        extras: dict[str, Any] = {}
        if isinstance(fourbyte_id, int):
            extras["fourbyte_id"] = fourbyte_id
        candidates.append(
            AbiCandidate(
                source=AbiSource.FOURBYTE,
                selector=selector,
                signature_or_abi=text_sig,
                address=None,
                text_signature=text_sig,
                extras=extras,
            )
        )
    return tuple(candidates)


__all__ = [
    "is_fourbyte_ok",
    "lookup_fourbyte",
]
