"""Euler Finance (EVK / Euler Vault Kit) decoder (P2-001.0b).

Second Group A pre-pend decoder for Phase 2 (Option C Hybrid critical path).
Mirrors the P2-001.0a :mod:`vca.decoders.compound_v3` pattern: import-time
keccak tripwire, shared :data:`vca.decoders.abi_fallback.decode._CODEC`,
ERC-20 ``Transfer`` log cross-validation against synthetic fixtures (R-1
silent-bug guardrail), frozen Pydantic config + :class:`DefiAction`
emission.

R-FILE-CAP 350 WAIVE: this module ships a 4-selector + 4-event-topic
matrix and is therefore allowed to exceed the 350-LoC guideline.
Precedent: :mod:`vca.decoders.compound_v3` (P2-001.0a, 457 LoC) covers
5 selectors; :mod:`vca.decoders.aave_v3` (P1-011, 386 LoC) covers 4
selectors with a sentinel; Euler V3 has 4 selectors + 4 event-topic
discriminators (Deposit/Withdraw/Borrow/Repay) and a vault-whitelist
tripwire plus distinct collateral/borrowable asset resolution, so a
similar LoC budget is justified.

Euler V3 is a per-vault money market (EVK — Euler Vault Kit). Each
vault deploys ERC-4626 standard interfaces plus Euler-specific borrow /
repay extensions. Public functions decoded:

* ``deposit(uint256 assets, address receiver)``                → 0x6e553f65
* ``withdraw(uint256 assets, address receiver, address owner)`` → 0xb460af94
* ``borrow(uint256 assets, address receiver)``                  → 0x4b3fd148
* ``repay(uint256 assets, address receiver)``                   → 0xacb70815

Event-driven action kind discrimination (R-1 silent-bug guardrail):

* ``Deposit(address sender, address owner, uint256 assets, uint256 shares)``
                                                       → COLLATERAL_SUPPLY
* ``Withdraw(address sender, address receiver, address owner, uint256 assets, uint256 shares)``
                                                       → COLLATERAL_WITHDRAW
* ``Borrow(address account, uint256 assets)``         → BORROW
* ``Repay(address account, uint256 assets)``          → REPAY

Vault whitelist (R-VAULT-WHITELIST-TRIPWIRE): decoder refuses to match
on TXs whose ``to_addr`` is not in :attr:`EulerDecoderConfig.vault_addresses`.
Defaults are empty — operator capture step (P2-001.1) will inject the
real mainnet WETH/WBTC vault contracts. EIP-55 checksum normalisation
is enforced via :class:`Address.from_str` on both config and lookup
sides (so callers may pass lowercase or mixed-case addresses).

EVC batch path (P3.2-003b): the KelpDAO Stage 3-A Euler TXs do NOT call
the vault directly — ``tx.to`` is the Ethereum Vault Connector (EVC) and
the calldata is a ``batch(...)`` (selector ``0xc16ae7a4``) carrying many
inner sub-calls. The direct-vault ``matches`` predicate never fires on
those TXs, so the decoder gains a second arm: ``tx.to == evc_address``
AND ``selector == batch``. The batch decode is EVENT-DRIVEN — it does not
parse the batch calldata at all; instead it iterates the receipt logs for
Euler ``Deposit`` / ``Withdraw`` / ``Borrow`` / ``Repay`` events emitted by
whitelisted vault addresses and emits one :class:`DefiAction` per event
(a single batch routinely opens collateral on one vault and borrows on a
second, so the output is multi-action). The EVC address is injected from
config exactly like ``vault_addresses`` — package default is empty so the
decoder is an inert no-op until the case bootstrap wires the real EVC and
vault→asset maps (R-ASSET-DECIMAL-TABLE silent-no-op bootstrap doctrine).

Pure: no I/O, no clock, no env. Direct-vault path keeps the synthetic
fixture doctrine (P1-010 / P2-001.0a); the EVC batch path is exercised
against the captured KelpDAO cassettes (e5_1/e5_2/e5_3).
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Final

from eth_utils import keccak  # type: ignore[attr-defined]
from pydantic import BaseModel, Field, ValidationError

from vca.decoders.abi_fallback.decode import _CODEC
from vca.decoders.base import DefiAction, DefiActionKind
from vca.decoders.registry import register_decoder
from vca.types import (
    Address,
    Amount,
    Asset,
    ChainId,
    NormalizedLog,
    NormalizedTransaction,
)
from vca.types.normalized import _FROZEN_CONFIG

__all__ = [
    "EULER_DECODER_NAME",
    "EulerDecoder",
    "EulerDecoderConfig",
    "register_euler_decoder",
]


# ---------------------------------------------------------------------------
# Slice A — Constants pinned at module import (R-SELECTOR-TRIPWIRE)
# ---------------------------------------------------------------------------

_DEPOSIT_SIG: Final[str] = "deposit(uint256,address)"
_WITHDRAW_SIG: Final[str] = "withdraw(uint256,address,address)"
_BORROW_SIG: Final[str] = "borrow(uint256,address)"
_REPAY_SIG: Final[str] = "repay(uint256,address)"

# EVC batch wrapper (P3.2-003b). The Ethereum Vault Connector aggregates
# many vault sub-calls under one ``batch`` selector; the KelpDAO Stage 3-A
# Euler TXs all route through it. We never decode the batch calldata —
# matching only gates on this selector, then iterates the receipt logs.
_BATCH_SIG: Final[str] = "batch((address,address,uint256,bytes)[])"

_DEPOSIT_EVENT_SIG: Final[str] = "Deposit(address,address,uint256,uint256)"
_WITHDRAW_EVENT_SIG: Final[str] = "Withdraw(address,address,address,uint256,uint256)"
_BORROW_EVENT_SIG: Final[str] = "Borrow(address,uint256)"
_REPAY_EVENT_SIG: Final[str] = "Repay(address,uint256)"
_TRANSFER_SIG: Final[str] = "Transfer(address,address,uint256)"


def _selector(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()[:8]


def _topic(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()


_DEPOSIT_SELECTOR: Final[str] = _selector(_DEPOSIT_SIG)
_WITHDRAW_SELECTOR: Final[str] = _selector(_WITHDRAW_SIG)
_BORROW_SELECTOR: Final[str] = _selector(_BORROW_SIG)
_REPAY_SELECTOR: Final[str] = _selector(_REPAY_SIG)
_BATCH_SELECTOR: Final[str] = _selector(_BATCH_SIG)

_DEPOSIT_TOPIC: Final[str] = _topic(_DEPOSIT_EVENT_SIG)
_WITHDRAW_TOPIC: Final[str] = _topic(_WITHDRAW_EVENT_SIG)
_BORROW_TOPIC: Final[str] = _topic(_BORROW_EVENT_SIG)
_REPAY_TOPIC: Final[str] = _topic(_REPAY_EVENT_SIG)
_ERC20_TRANSFER_TOPIC: Final[str] = _topic(_TRANSFER_SIG)

# R-SELECTOR-TRIPWIRE: import-time keccak pin. Any drift in
# ``eth_utils.keccak`` or the Euler V3 ABI fails at first module import.
# This roster is the closed set of per-VAULT call selectors; the EVC
# ``batch`` selector is a routing wrapper, not a vault op, so it is pinned
# separately below to keep this roster (and ``_EULER_SELECTORS``) closed.
_EXPECTED_SELECTORS: Final[Mapping[str, str]] = MappingProxyType(
    {
        _DEPOSIT_SIG: "0x6e553f65",
        _WITHDRAW_SIG: "0xb460af94",
        _BORROW_SIG: "0x4b3fd148",
        _REPAY_SIG: "0xacb70815",
    }
)
for _sig, _expected in _EXPECTED_SELECTORS.items():
    if _selector(_sig) != _expected:  # pragma: no cover - import-time tripwire
        raise RuntimeError(
            f"Euler V3 selector drift for {_sig!r}: "
            f"{_selector(_sig)!r} (expected {_expected!r}). "
            "Refusing module import — investigate Euler ABI or eth_utils.keccak."
        )

# EVC ``batch`` selector — own import-time keccak pin (P3.2-003b). Kept out
# of ``_EXPECTED_SELECTORS`` so the per-vault roster stays a closed 4-set.
_EXPECTED_BATCH_SELECTOR: Final[str] = "0xc16ae7a4"
if _BATCH_SELECTOR != _EXPECTED_BATCH_SELECTOR:  # pragma: no cover - import-time tripwire
    raise RuntimeError(
        f"Euler EVC batch selector drift: {_BATCH_SELECTOR!r} "
        f"(expected {_EXPECTED_BATCH_SELECTOR!r}). Refusing module import."
    )

_EULER_SELECTORS: Final[frozenset[str]] = frozenset(
    {
        _DEPOSIT_SELECTOR,
        _WITHDRAW_SELECTOR,
        _BORROW_SELECTOR,
        _REPAY_SELECTOR,
    }
)

# Selector → ABI head types (shared :data:`_CODEC`).
_EULER_HEAD_TYPES: Final[Mapping[str, tuple[str, ...]]] = MappingProxyType(
    {
        _DEPOSIT_SELECTOR: ("uint256", "address"),
        _WITHDRAW_SELECTOR: ("uint256", "address", "address"),
        _BORROW_SELECTOR: ("uint256", "address"),
        _REPAY_SELECTOR: ("uint256", "address"),
    }
)

# Selector → human-readable function name for the ``extras["function"]`` tag.
_SELECTOR_TO_FUNCTION_NAME: Final[Mapping[str, str]] = MappingProxyType(
    {
        _DEPOSIT_SELECTOR: "deposit",
        _WITHDRAW_SELECTOR: "withdraw",
        _BORROW_SELECTOR: "borrow",
        _REPAY_SELECTOR: "repay",
    }
)

# Selector → default :class:`DefiActionKind` when no matching event log
# is present. Borrow / Repay are unambiguous from the selector alone;
# Deposit / Withdraw default to collateral semantics (Euler vaults are
# primarily collateral vaults — same conservative choice P2-001.0a made).
_SELECTOR_DEFAULT_KIND: Final[Mapping[str, DefiActionKind]] = MappingProxyType(
    {
        _DEPOSIT_SELECTOR: DefiActionKind.COLLATERAL_SUPPLY,
        _WITHDRAW_SELECTOR: DefiActionKind.COLLATERAL_WITHDRAW,
        _BORROW_SELECTOR: DefiActionKind.BORROW,
        _REPAY_SELECTOR: DefiActionKind.REPAY,
    }
)

# Selector families — deposit / withdraw operate on the vault's
# collateral asset; borrow / repay operate on the borrowable asset.
_COLLATERAL_FAMILY: Final[frozenset[str]] = frozenset({_DEPOSIT_SELECTOR, _WITHDRAW_SELECTOR})

# EVC batch path (P3.2-003b) — event topic → action kind. Drives the
# event-driven multi-action decode: each whitelisted-vault event becomes
# one :class:`DefiAction`. The "synthetic selector" each topic maps to lets
# the EVC path reuse the direct-path family / endpoint / asset helpers.
_EVENT_TOPIC_TO_KIND: Final[Mapping[str, DefiActionKind]] = MappingProxyType(
    {
        _DEPOSIT_TOPIC: DefiActionKind.COLLATERAL_SUPPLY,
        _WITHDRAW_TOPIC: DefiActionKind.COLLATERAL_WITHDRAW,
        _BORROW_TOPIC: DefiActionKind.BORROW,
        _REPAY_TOPIC: DefiActionKind.REPAY,
    }
)

# Event topic → the per-vault selector whose family / endpoint rules apply.
_EVENT_TOPIC_TO_SELECTOR: Final[Mapping[str, str]] = MappingProxyType(
    {
        _DEPOSIT_TOPIC: _DEPOSIT_SELECTOR,
        _WITHDRAW_TOPIC: _WITHDRAW_SELECTOR,
        _BORROW_TOPIC: _BORROW_SELECTOR,
        _REPAY_TOPIC: _REPAY_SELECTOR,
    }
)

_DEFAULT_EVC_ADDRESSES: Final[Mapping[ChainId, Address]] = MappingProxyType({})
_DEFAULT_VAULT_ADDRESSES: Final[Mapping[ChainId, frozenset[Address]]] = MappingProxyType({})
_DEFAULT_VAULT_COLLATERAL_ASSET: Final[Mapping[ChainId, Mapping[Address, Address]]] = (
    MappingProxyType({})
)
_DEFAULT_VAULT_BORROWABLE_ASSET: Final[Mapping[ChainId, Mapping[Address, Address]]] = (
    MappingProxyType({})
)
_DEFAULT_ASSET_DECIMALS: Final[Mapping[Address, int]] = MappingProxyType({})
_DEFAULT_ASSET_SYMBOLS: Final[Mapping[Address, str]] = MappingProxyType({})
_PLACEHOLDER_ASSET_SYMBOL: Final[str] = "EULER_ASSET"

EULER_DECODER_NAME: Final[str] = "euler_v2"


@dataclass(frozen=True, slots=True)
class EulerDecoderConfig:
    """Phase-2 Euler V3 config. Callers MUST wrap overrides in
    ``MappingProxyType(...)`` to preserve immutability.

    Vault addresses are intentionally empty by default — the operator
    capture step (P2-001.1) injects the real mainnet WETH/WBTC vault
    contracts. EIP-55 checksum normalisation is enforced by
    :class:`Address.from_str` on both config and lookup sides, so
    callers may pass lowercase or mixed-case strings into ``Address``.

    ``vault_collateral_asset`` / ``vault_borrowable_asset`` partition the
    asset-side of each vault: deposit / withdraw move the collateral
    asset, borrow / repay move the borrowable asset. Downstream LTV
    ratio validation is intentionally NOT performed here — that hook
    belongs in a future labeler / stage classifier; the decoder stays
    pure and reports the on-chain calldata + Transfer log truth.

    ``evc_addresses`` (P3.2-003b) maps each chain to its Ethereum Vault
    Connector contract. When ``tx.to`` equals this address and the
    selector is the EVC ``batch`` selector, the decoder takes the
    event-driven batch path. Empty by default — the case bootstrap
    injects the real EVC address; until then the batch arm never fires.
    """

    evc_addresses: Mapping[ChainId, Address] = field(default=_DEFAULT_EVC_ADDRESSES)
    vault_addresses: Mapping[ChainId, frozenset[Address]] = field(default=_DEFAULT_VAULT_ADDRESSES)
    vault_collateral_asset: Mapping[ChainId, Mapping[Address, Address]] = field(
        default=_DEFAULT_VAULT_COLLATERAL_ASSET
    )
    vault_borrowable_asset: Mapping[ChainId, Mapping[Address, Address]] = field(
        default=_DEFAULT_VAULT_BORROWABLE_ASSET
    )
    asset_decimals: Mapping[Address, int] = field(default=_DEFAULT_ASSET_DECIMALS)
    asset_symbols: Mapping[Address, str] = field(default=_DEFAULT_ASSET_SYMBOLS)


# ---------------------------------------------------------------------------
# Slice C — Pure helpers
# ---------------------------------------------------------------------------


def _validation_error(msg: str) -> ValidationError:
    """Wrap ``msg`` in :class:`pydantic.ValidationError`."""

    class _GuardModel(BaseModel):
        model_config = _FROZEN_CONFIG
        marker: str

    try:
        _GuardModel(marker=msg, extra_field_that_does_not_exist=True)  # type: ignore[call-arg]
    except ValidationError as exc:
        return exc
    raise RuntimeError("validation guard failed to raise")  # pragma: no cover


def _decode_euler_calldata(selector: str, input_hex: str) -> tuple[Any, ...]:
    """Decode the per-selector ABI head via shared :data:`_CODEC`."""
    if not input_hex.startswith("0x") or len(input_hex) < 10:
        raise _validation_error(f"euler calldata too short: len={len(input_hex)}")
    body_hex = input_hex[10:]
    if len(body_hex) % 64 != 0:
        raise _validation_error(f"euler calldata body not 32-byte aligned: hex_len={len(body_hex)}")
    try:
        body = bytes.fromhex(body_hex)
    except ValueError as exc:
        raise _validation_error(f"euler calldata body is not valid hex: {exc}") from exc
    try:
        decoded = _CODEC.decode(_EULER_HEAD_TYPES[selector], body)
    except Exception as exc:
        raise _validation_error(
            f"euler head decode failed for selector {selector!r}: {type(exc).__name__}: {exc}"
        ) from exc
    return tuple(decoded)


def _parse_head(
    selector: str, head: tuple[Any, ...], *, chain: ChainId, tx_from: Address
) -> tuple[int, Address]:
    """Return ``(amount, actor)`` for an Euler V3 calldata head.

    * ``deposit(amount, receiver)``                       → actor = receiver
    * ``withdraw(amount, receiver, owner)``               → actor = receiver
    * ``borrow(amount, receiver)``                        → actor = receiver
    * ``repay(amount, receiver)``                         → actor = receiver
    """
    amount = int(head[0])
    receiver_raw = str(head[1])
    actor = Address.from_str(receiver_raw, chain)
    del tx_from  # actor is always the calldata receiver in the Euler ABI
    return amount, actor


def _topic_address(topic: str, chain: ChainId) -> Address | None:
    """Convert a 32-byte indexed-address topic word to :class:`Address`."""
    if any(c != "0" for c in topic[2:26]):
        return None
    return Address.from_str("0x" + topic[26:], chain)


def _find_action_transfer(
    logs: tuple[NormalizedLog, ...],
    *,
    asset: Address,
    expected_from: Address,
    expected_to: Address,
) -> NormalizedLog | None:
    """First ERC-20 ``Transfer`` from ``asset`` matching from/to (D-2 absent OK)."""
    chain = asset.chain
    for log in logs:
        if not log.topics or log.topics[0] != _ERC20_TRANSFER_TOPIC:
            continue
        if log.address != asset:
            continue
        if len(log.topics) < 3:
            continue
        log_from = _topic_address(log.topics[1], chain)
        log_to = _topic_address(log.topics[2], chain)
        if log_from == expected_from and log_to == expected_to:
            return log
    return None


def _find_funding_payer(
    logs: tuple[NormalizedLog, ...],
    *,
    asset: Address,
    vault: Address,
    amount: int,
    consumed_log_indices: set[int],
) -> Address | None:
    """Payer of a vault funding Transfer (EVC batch; codex P3.2-003 R2 P2).

    The symmetric mirror of :func:`_find_disbursement_receiver` for the
    deposit / repay legs: the first unconsumed Transfer of ``asset`` with
    ``to == vault`` AND ``value == amount`` names the address the funds
    ACTUALLY left. The Deposit event's indexed ``owner`` is deliberately
    NOT used here — in the e5 cassettes it is an EVC sub-account
    (``…1455cd/ce/cf``, position bookkeeping derived from the EOA) that
    never held the rsETH; pinning the actor to the VALUE source keeps the
    FlowEdge (SUPPLY renders ``actor → pool``) byte-consistent with the
    real ERC-20 Transfer and keeps the R-1 coherence binding intact.
    Returns ``None`` when no such Transfer exists (D-2 — caller falls
    back to ``tx.from``).
    """
    chain = asset.chain
    for log in logs:
        if log.log_index in consumed_log_indices:
            continue
        if not log.topics or log.topics[0] != _ERC20_TRANSFER_TOPIC:
            continue
        if log.address != asset:
            continue
        if len(log.topics) < 3:
            continue
        if len(log.data) < 2 + 64:
            continue
        if _read_uint256_word(log.data, 0) != amount:
            continue
        if _topic_address(log.topics[2], chain) != vault:
            continue
        return _topic_address(log.topics[1], chain)
    return None


def _find_disbursement_receiver(
    logs: tuple[NormalizedLog, ...],
    *,
    asset: Address,
    vault: Address,
    amount: int,
    consumed_log_indices: set[int],
) -> Address | None:
    """Receiver of a vault disbursement Transfer (EVC batch; codex P3.2-003 R1 P2).

    Inner ``borrow`` / ``withdraw`` calls inside an EVC ``batch`` may name
    a receiver other than the batch submitter, and the batch calldata is
    deliberately NOT parsed (event-driven path) — so the receiver is
    recovered from the asset's own ERC-20 ``Transfer``: the first
    unconsumed Transfer of ``asset`` with ``from == vault`` AND
    ``value == amount`` (the Euler event's ``assets`` word — an
    exact-amount anchor, stronger than endpoint guessing). Returns
    ``None`` when no such Transfer exists (D-2 tolerance — the caller
    falls back to ``tx.from``).
    """
    chain = asset.chain
    for log in logs:
        if log.log_index in consumed_log_indices:
            continue
        if not log.topics or log.topics[0] != _ERC20_TRANSFER_TOPIC:
            continue
        if log.address != asset:
            continue
        if len(log.topics) < 3:
            continue
        if len(log.data) < 2 + 64:
            continue
        if _read_uint256_word(log.data, 0) != amount:
            continue
        if _topic_address(log.topics[1], chain) != vault:
            continue
        return _topic_address(log.topics[2], chain)
    return None


def _read_uint256_word(data_hex: str, word_index: int) -> int:
    offset = 2 + word_index * 64  # skip '0x'
    return int(data_hex[offset : offset + 64], 16)


def _read_event_assets_amount(log: NormalizedLog) -> int:
    """Read the ``assets`` word (``data[0]``) of an Euler vault event.

    All four Euler events lead their non-indexed data with ``assets``:
    ``Deposit(... assets, shares)`` / ``Withdraw(... assets, shares)`` /
    ``Borrow(account, assets)`` / ``Repay(account, assets)``. A malformed
    event whose ``data`` is shorter than one 32-byte word raises the
    decoder-contract :class:`pydantic.ValidationError` (not a bare
    ``ValueError`` from ``int("", 16)``).
    """
    if len(log.data) < 2 + 64:
        raise _validation_error(
            f"Euler V2 event data too short for assets word: hex_len={len(log.data)}"
        )
    return _read_uint256_word(log.data, 0)


def _assert_amount_coherence(
    *,
    decoded_amount: int,
    transfer_log: NormalizedLog | None,
) -> None:
    """R-1 cross-validation; D-2 missing-log no-ops."""
    if transfer_log is None:
        return
    log_value = _read_uint256_word(transfer_log.data, 0)
    if log_value != decoded_amount:
        raise _validation_error(
            f"Transfer.value mismatch: log_value={log_value}, calldata_amount={decoded_amount}"
        )


def _expected_transfer_endpoints(
    selector: str,
    *,
    tx_from: Address,
    vault: Address,
    actor: Address,
) -> tuple[Address, Address]:
    """Per-action ``(from, to)`` Transfer endpoints.

    * deposit / repay  → user → vault   (user supplies tokens to vault)
    * withdraw / borrow → vault → actor (vault releases tokens to recipient)
    """
    if selector in (_DEPOSIT_SELECTOR, _REPAY_SELECTOR):
        return tx_from, vault
    return vault, actor


def _classify_action_kind(
    *,
    selector: str,
    logs: tuple[NormalizedLog, ...],
    vault: Address,
) -> DefiActionKind:
    """Event-driven action kind discrimination.

    Inspects the emitted Euler V3 events on the ``vault`` address:

    * ``Deposit``  → :data:`DefiActionKind.COLLATERAL_SUPPLY`
    * ``Withdraw`` → :data:`DefiActionKind.COLLATERAL_WITHDRAW`
    * ``Borrow``   → :data:`DefiActionKind.BORROW`
    * ``Repay``    → :data:`DefiActionKind.REPAY`

    Selector-only fallback when no matching event is present is given by
    :data:`_SELECTOR_DEFAULT_KIND`.
    """
    for log in logs:
        if log.address != vault:
            continue
        if not log.topics:
            continue
        topic0 = log.topics[0]
        if topic0 == _DEPOSIT_TOPIC:
            return DefiActionKind.COLLATERAL_SUPPLY
        if topic0 == _WITHDRAW_TOPIC:
            return DefiActionKind.COLLATERAL_WITHDRAW
        if topic0 == _BORROW_TOPIC:
            return DefiActionKind.BORROW
        if topic0 == _REPAY_TOPIC:
            return DefiActionKind.REPAY
    return _SELECTOR_DEFAULT_KIND[selector]


def _resolve_action_asset(
    selector: str,
    *,
    chain: ChainId,
    vault: Address,
    config: EulerDecoderConfig,
) -> Address | None:
    """Resolve the on-chain asset address for the action.

    * Collateral selectors (deposit / withdraw) read from
      ``vault_collateral_asset[chain][vault]``.
    * Borrowable selectors (borrow / repay) read from
      ``vault_borrowable_asset[chain][vault]``.

    Returns ``None`` if no mapping is configured (decoder short-circuits
    to ``()`` — same R-ASSET-DECIMAL-TABLE pattern as Aave V3).
    """
    if selector in _COLLATERAL_FAMILY:
        chain_map = config.vault_collateral_asset.get(chain)
    else:
        chain_map = config.vault_borrowable_asset.get(chain)
    if chain_map is None:
        return None
    return chain_map.get(vault)


# ---------------------------------------------------------------------------
# Slice B / C — Decoder model
# ---------------------------------------------------------------------------


class EulerDecoder(BaseModel):
    """Pydantic v2 :class:`BridgeDecoder` for Euler Finance V3 (EVK) vaults."""

    model_config = _FROZEN_CONFIG

    name: str = EULER_DECODER_NAME
    priority: int = 120
    config: EulerDecoderConfig = Field(default_factory=EulerDecoderConfig)

    def _matches_evc_batch(self, tx: NormalizedTransaction) -> bool:
        """Path B predicate: ``tx.to == evc_address`` AND batch selector."""
        evc = self.config.evc_addresses.get(tx.chain)
        if evc is None or tx.to_addr is None or tx.to_addr != evc:
            return False
        input_hex = tx.input
        if input_hex is None or len(input_hex) < 10:
            return False
        return input_hex[:10].lower() == _BATCH_SELECTOR

    def _matches_direct_vault(self, tx: NormalizedTransaction) -> bool:
        """Path A predicate (R-VAULT-WHITELIST-TRIPWIRE on arm 2)."""
        vaults = self.config.vault_addresses.get(tx.chain)
        if vaults is None or not vaults:
            return False
        if tx.to_addr is None or tx.to_addr not in vaults:
            return False
        input_hex = tx.input
        if input_hex is None or len(input_hex) < 10:
            return False
        return input_hex[:10].lower() in _EULER_SELECTORS

    def matches(self, tx: NormalizedTransaction) -> bool:
        """Match either the direct-vault call (A) or the EVC batch (B).

        The direct-vault selector membership check is kept inline here (not
        only in :meth:`_matches_direct_vault`) so the closed
        ``_EULER_SELECTORS`` roster is consumed at the public predicate site.
        """
        if self._matches_evc_batch(tx):
            return True
        vaults = self.config.vault_addresses.get(tx.chain)
        if vaults is None or not vaults:
            return False
        if tx.to_addr is None or tx.to_addr not in vaults:
            return False
        input_hex = tx.input
        if input_hex is None or len(input_hex) < 10:
            return False
        return input_hex[:10].lower() in _EULER_SELECTORS

    def decode(
        self,
        tx: NormalizedTransaction,
        logs: tuple[NormalizedLog, ...],
    ) -> tuple[DefiAction, ...]:
        """Dispatch to the direct-vault (A) or EVC batch (B) decoder."""
        if self._matches_evc_batch(tx):
            return self._decode_evc_batch(tx, logs)
        if self._matches_direct_vault(tx):
            return self._decode_direct_vault_call(tx, logs)
        return ()

    def _decode_direct_vault_call(
        self,
        tx: NormalizedTransaction,
        logs: tuple[NormalizedLog, ...],
    ) -> tuple[DefiAction, ...]:
        """Decode + cross-validate a direct vault call; emit one action or ``()``."""
        assert tx.input is not None
        assert tx.from_addr is not None
        assert tx.to_addr is not None
        selector = tx.input[:10].lower()
        head = _decode_euler_calldata(selector, tx.input)

        amount, actor = _parse_head(selector, head, chain=tx.chain, tx_from=tx.from_addr)
        if amount == 0:
            raise _validation_error("Euler V3 amount=0 is impossible in well-formed calldata")

        vault = tx.to_addr
        action = self._build_action(
            selector=selector,
            kind=_classify_action_kind(selector=selector, logs=logs, vault=vault),
            amount=amount,
            actor=actor,
            vault=vault,
            tx_from=tx.from_addr,
            chain=tx.chain,
            logs=logs,
            consumed_log_indices=set(),
        )
        if action is None:
            return ()
        return (action,)

    def _decode_evc_batch(
        self,
        tx: NormalizedTransaction,
        logs: tuple[NormalizedLog, ...],
    ) -> tuple[DefiAction, ...]:
        """Event-driven multi-action decode of an EVC ``batch`` TX.

        The batch calldata is intentionally NOT parsed — every Euler
        ``Deposit`` / ``Withdraw`` / ``Borrow`` / ``Repay`` event emitted by a
        whitelisted vault becomes one :class:`DefiAction`. The event's
        ``assets`` word (``data[0]``) is the amount and is cross-validated
        against the matching ERC-20 ``Transfer`` of the resolved asset (R-1).
        A ``consumed_log_indices`` set prevents two actions from claiming the
        same underlying Transfer (project memory: first-match-raise multi-event
        batch is forbidden).
        """
        assert tx.from_addr is not None
        vaults = self.config.vault_addresses.get(tx.chain)
        if vaults is None or not vaults:
            return ()
        consumed_log_indices: set[int] = set()
        actions: list[DefiAction] = []
        for log in logs:
            if not log.topics:
                continue
            topic0 = log.topics[0]
            selector = _EVENT_TOPIC_TO_SELECTOR.get(topic0)
            if selector is None:
                continue
            if log.address not in vaults:
                continue  # event from an unknown / out-of-scope vault — skip
            amount = _read_event_assets_amount(log)
            if amount == 0:
                continue  # well-formed Euler events never carry assets=0
            # Codex P3.2-003 R1+R2 P2: the batch calldata is not parsed,
            # so per-leg endpoints are recovered from the exact-amount
            # asset Transfer instead of hard-coding ``tx.from``:
            # disbursement legs (borrow / withdraw) take the vault->X
            # receiver; funding legs (deposit / repay) take the X->vault
            # payer (the VALUE source — deliberately NOT the Deposit
            # event's indexed sub-account owner; see
            # ``_find_funding_payer``). ``tx.from`` is the D-2 fallback
            # when no matching Transfer exists.
            actor = tx.from_addr
            endpoint_anchor = tx.from_addr
            asset_addr = _resolve_action_asset(
                selector, chain=tx.chain, vault=log.address, config=self.config
            )
            if asset_addr is not None:
                if selector in (_WITHDRAW_SELECTOR, _BORROW_SELECTOR):
                    receiver = _find_disbursement_receiver(
                        logs,
                        asset=asset_addr,
                        vault=log.address,
                        amount=amount,
                        consumed_log_indices=consumed_log_indices,
                    )
                    if receiver is not None:
                        actor = receiver
                else:
                    payer = _find_funding_payer(
                        logs,
                        asset=asset_addr,
                        vault=log.address,
                        amount=amount,
                        consumed_log_indices=consumed_log_indices,
                    )
                    if payer is not None:
                        actor = payer
                        # The funding-leg Transfer endpoints bind
                        # ``(tx_from, vault)`` — anchor them on the
                        # derived payer so the R-1 coherence check binds
                        # the SAME Transfer the payer was read from.
                        endpoint_anchor = payer
            action = self._build_action(
                selector=selector,
                # Codex P3.2-003 R1 P2: the loop KNOWS the current event's
                # kind — re-scanning the whole receipt via
                # ``_classify_action_kind`` would return the FIRST event's
                # kind for this vault and flip a later borrow/withdraw leg.
                kind=_EVENT_TOPIC_TO_KIND[topic0],
                amount=amount,
                actor=actor,
                vault=log.address,
                tx_from=endpoint_anchor,
                chain=tx.chain,
                logs=logs,
                consumed_log_indices=consumed_log_indices,
            )
            if action is not None:
                actions.append(action)
        return tuple(actions)

    def _build_action(
        self,
        *,
        selector: str,
        kind: DefiActionKind,
        amount: int,
        actor: Address,
        vault: Address,
        tx_from: Address,
        chain: ChainId,
        logs: tuple[NormalizedLog, ...],
        consumed_log_indices: set[int],
    ) -> DefiAction | None:
        """Resolve asset, cross-validate the funding Transfer, build the action.

        ``kind`` is the caller's responsibility (codex P3.2-003 R1 P2):
        the EVC batch loop passes the CURRENT event's kind
        (``_EVENT_TOPIC_TO_KIND``); the direct path passes the
        receipt-scan result (``_classify_action_kind``). Re-deriving it
        here from a whole-receipt scan would return the first event's
        kind for the vault and mislabel later batch legs.

        Returns ``None`` (skip) when the vault's asset side is unconfigured —
        the same R-ASSET-DECIMAL-TABLE silent-skip the direct path applies.
        ``consumed_log_indices`` is mutated to claim the matched Transfer so a
        later action on the same asset/endpoints cannot double-count it.
        """
        asset_addr = _resolve_action_asset(selector, chain=chain, vault=vault, config=self.config)
        if asset_addr is None:
            return None
        if asset_addr not in self.config.asset_decimals:
            return None
        decimals = self.config.asset_decimals[asset_addr]
        symbol = self.config.asset_symbols.get(asset_addr, _PLACEHOLDER_ASSET_SYMBOL)
        asset = Asset(chain=chain, symbol=symbol, decimals=decimals, contract=asset_addr)

        expected_from, expected_to = _expected_transfer_endpoints(
            selector, tx_from=tx_from, vault=vault, actor=actor
        )
        # Call-site consumed-log filtering (mirrors the aave_v3 multicall
        # pattern): pre-drop already-claimed Transfers instead of teaching
        # the helper an extra parameter — ``_find_action_transfer`` must
        # stay byte-identical to the canonical 8-clone family the
        # find-action-transfer SSOT audit pins.
        remaining_logs = tuple(log for log in logs if log.log_index not in consumed_log_indices)
        transfer_log = _find_action_transfer(
            remaining_logs,
            asset=asset_addr,
            expected_from=expected_from,
            expected_to=expected_to,
        )
        # Length guard before the coherence word-0 read — a malformed
        # ``Transfer`` log with ``data="0x"`` would otherwise raise a raw
        # ``ValueError`` from ``int("", 16)`` instead of the decoder's
        # contract-level :class:`pydantic.ValidationError`. Guarded at the
        # call site (the ``_assert_amount_coherence`` body is SSOT-pinned).
        if transfer_log is not None:
            expected_transfer_data_hex_len = 2 + 64
            if len(transfer_log.data) < expected_transfer_data_hex_len:
                raise _validation_error(
                    f"Euler V2 Transfer log data too short: "
                    f"{len(transfer_log.data)} < {expected_transfer_data_hex_len}"
                )
            consumed_log_indices.add(transfer_log.log_index)
        _assert_amount_coherence(decoded_amount=amount, transfer_log=transfer_log)

        function_name = _SELECTOR_TO_FUNCTION_NAME[selector]
        return DefiAction(
            kind=kind,
            chain=chain,
            protocol=EULER_DECODER_NAME,
            asset=asset,
            amount=Amount(raw=amount, decimals=decimals),
            actor=actor,
            pool=vault,
            extras={"function": function_name},
        )


def register_euler_decoder(
    config: EulerDecoderConfig | None = None,
) -> EulerDecoder:
    """Construct and register the Euler V3 decoder on the singleton registry."""
    decoder = EulerDecoder() if config is None else EulerDecoder(config=config)
    register_decoder(decoder)
    return decoder
