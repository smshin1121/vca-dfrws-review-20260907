"""``AbiFallbackResolver`` — orchestrates the 3-tier ABI recovery chain (P1-012).

NOT a :class:`vca.decoders.BridgeDecoder` (R-NOT-DECODER). The resolver is
a standalone class consumed by :class:`vca.tracer.FlowTracer` (P1-014)
*after* :meth:`vca.decoders.DecoderRegistry.find_matching` returns ``()``.

Tier order is fixed: 4byte → Sourcify → Etherscan ABI. Cache hits are
per-tier; the resolver never short-circuits to a different tier just
because that tier's cache is warm.
"""

from __future__ import annotations

import logging
from typing import Any, Final

from pydantic import SecretStr

from vca.decoders.abi_fallback._errors import AbiFallbackError
from vca.decoders.abi_fallback._log_redact import scrub_exc_for_log
from vca.decoders.abi_fallback.decode import (
    AbiCandidate,
    AbiSource,
    RecoveredAbi,
    canonical_signature_for_candidate,
    decode_calldata_with_abi,
    rank_candidates,
)
from vca.decoders.abi_fallback.etherscan_abi import lookup_etherscan_abi
from vca.decoders.abi_fallback.fourbyte import lookup_fourbyte
from vca.decoders.abi_fallback.sourcify import lookup_sourcify
from vca.types import ChainId, DecodedCall, NormalizedTransaction

logger = logging.getLogger(__name__)

_FOURBYTE_DEFAULT_BASE_URL: Final[str] = "https://www.4byte.directory"
_SOURCIFY_DEFAULT_BASE_URL: Final[str] = "https://sourcify.dev/server"
_ETHERSCAN_V2_DEFAULT_BASE_URL: Final[str] = "https://api.etherscan.io/v2/api"

_CHAIN_ID_TO_SCANNER_CHAINID: dict[ChainId, int] = {
    ChainId.ETHEREUM: 1,
    ChainId.ARBITRUM: 42161,
}

_CONFIDENCE_BY_SOURCE: dict[AbiSource, float] = {
    AbiSource.FOURBYTE: 0.5,
    AbiSource.SOURCIFY: 1.0,
    AbiSource.ETHERSCAN_ABI: 1.0,
}

_ADDRESS_KEYED_BY_SOURCE: dict[AbiSource, bool] = {
    AbiSource.FOURBYTE: False,
    AbiSource.SOURCIFY: True,
    AbiSource.ETHERSCAN_ABI: True,
}

_PLACEHOLDER_SECRET: Final[str] = "__REQUIRED__"


class AbiFallbackResolver:
    """Standalone ABI recovery + calldata decoder (P1-012).

    NOT a :class:`vca.decoders.BridgeDecoder`. Consumers must import this
    class explicitly via ``from vca.decoders.abi_fallback import
    AbiFallbackResolver``; the resolver does NOT register itself with
    :class:`vca.decoders.DecoderRegistry`.
    """

    def __init__(
        self,
        *,
        http_client: Any,
        settings: Any,
        raw_store: Any | None = None,
        fourbyte_url: str = _FOURBYTE_DEFAULT_BASE_URL,
        sourcify_url: str = _SOURCIFY_DEFAULT_BASE_URL,
        etherscan_v2_url: str = _ETHERSCAN_V2_DEFAULT_BASE_URL,
        fourbyte_ttl_sec: int | None = None,
        sourcify_ttl_sec: int | None = None,
        etherscan_ttl_sec: int | None = None,
        rate_limit_source_4byte: str = "fourbyte",
        rate_limit_source_sourcify: str = "sourcify",
        rate_limit_source_etherscan: str = "etherscan",
        enable_fourbyte: bool = True,
        enable_sourcify: bool = True,
        enable_etherscan: bool = True,
    ) -> None:
        self._http = http_client
        self._settings = settings
        self._raw = raw_store
        self._fourbyte_url = fourbyte_url
        self._sourcify_url = sourcify_url
        self._etherscan_v2_url = etherscan_v2_url
        self._fourbyte_ttl = fourbyte_ttl_sec
        self._sourcify_ttl = sourcify_ttl_sec
        self._etherscan_ttl = etherscan_ttl_sec
        self._rate_limit_source_4byte = rate_limit_source_4byte
        self._rate_limit_source_sourcify = rate_limit_source_sourcify
        self._rate_limit_source_etherscan = rate_limit_source_etherscan
        self._enable_fourbyte = enable_fourbyte
        self._enable_sourcify = enable_sourcify
        self._enable_etherscan = enable_etherscan
        if enable_etherscan:
            self._validate_etherscan_secrets(settings)

    # ------------------------------------------------------------------
    # Public surface
    # ------------------------------------------------------------------

    async def resolve(self, tx: NormalizedTransaction) -> DecodedCall | None:
        """Walk 4byte → Sourcify → Etherscan; return the first decoded call.

        Returns ``None`` when:
        * ``tx.chain == ChainId.BITCOIN`` (no calldata model);
        * ``tx.to_addr is None`` (contract creation tx);
        * ``tx.input`` is ``None`` / ``""`` / ``"0x"`` (no calldata);
        * ``len(tx.input) < 10`` (selector incomplete);
        * every enabled tier failed to produce a usable decode.

        Otherwise returns a :class:`vca.types.DecodedCall` with
        ``decoder=f"abi_fallback.{recovered.source.value}"``.
        """
        if tx.chain is ChainId.BITCOIN or not tx.chain.is_evm:
            return None
        if tx.to_addr is None:
            return None
        calldata = tx.input
        if calldata is None or calldata == "" or calldata == "0x":
            return None
        if len(calldata) < 10:
            return None
        selector = calldata[:10].lower()

        # Tier 1 — 4byte
        if self._enable_fourbyte:
            decoded = await self._try_fourbyte(calldata=calldata, selector=selector)
            if decoded is not None:
                return decoded

        # Tier 2 — Sourcify
        if self._enable_sourcify:
            decoded = await self._try_sourcify(tx=tx, calldata=calldata, selector=selector)
            if decoded is not None:
                return decoded

        # Tier 3 — Etherscan ABI
        if self._enable_etherscan:
            decoded = await self._try_etherscan(tx=tx, calldata=calldata, selector=selector)
            if decoded is not None:
                return decoded

        return None

    # ------------------------------------------------------------------
    # Tier orchestration
    # ------------------------------------------------------------------

    async def _try_fourbyte(self, *, calldata: str, selector: str) -> DecodedCall | None:
        try:
            candidates = await lookup_fourbyte(
                self._http,
                selector=selector,
                base_url=self._fourbyte_url,
                ttl=self._fourbyte_ttl,
                rate_limit_source=self._rate_limit_source_4byte,
                raw_store=self._raw,
            )
        except AbiFallbackError as exc:
            logger.warning(
                "abi_fallback.4byte tier failed: tier=%s selector=%s status=%s err=%s",
                exc.tier.value,
                exc.selector,
                exc.original_status,
                scrub_exc_for_log(exc),
            )
            return None
        return self._first_decoding_candidate(
            candidates=candidates,
            calldata=calldata,
            source=AbiSource.FOURBYTE,
        )

    async def _try_sourcify(
        self, *, tx: NormalizedTransaction, calldata: str, selector: str
    ) -> DecodedCall | None:
        chain_id = _CHAIN_ID_TO_SCANNER_CHAINID.get(tx.chain)
        if chain_id is None:
            return None
        if tx.to_addr is None:
            return None
        try:
            candidates = await lookup_sourcify(
                self._http,
                address=tx.to_addr.value,
                chain_id=chain_id,
                base_url=self._sourcify_url,
                ttl=self._sourcify_ttl,
                rate_limit_source=self._rate_limit_source_sourcify,
                raw_store=self._raw,
            )
        except AbiFallbackError as exc:
            logger.warning(
                "abi_fallback.sourcify tier failed: tier=%s selector=%s addr=%s status=%s err=%s",
                exc.tier.value,
                selector,
                exc.address,
                exc.original_status,
                scrub_exc_for_log(exc),
            )
            return None
        return self._first_decoding_candidate(
            candidates=candidates,
            calldata=calldata,
            source=AbiSource.SOURCIFY,
        )

    async def _try_etherscan(
        self, *, tx: NormalizedTransaction, calldata: str, selector: str
    ) -> DecodedCall | None:
        chain_id = _CHAIN_ID_TO_SCANNER_CHAINID.get(tx.chain)
        if chain_id is None:
            return None
        if tx.to_addr is None:
            return None
        api_key = self._etherscan_api_key_for(tx.chain)
        try:
            candidates = await lookup_etherscan_abi(
                self._http,
                address=tx.to_addr.value,
                chain_id=chain_id,
                base_url=self._etherscan_v2_url,
                api_key=api_key,
                ttl=self._etherscan_ttl,
                rate_limit_source=self._rate_limit_source_etherscan,
                raw_store=self._raw,
            )
        except AbiFallbackError as exc:
            logger.warning(
                "abi_fallback.etherscan tier failed: tier=%s selector=%s addr=%s status=%s err=%s",
                exc.tier.value,
                selector,
                exc.address,
                exc.original_status,
                scrub_exc_for_log(exc),
            )
            return None
        return self._first_decoding_candidate(
            candidates=candidates,
            calldata=calldata,
            source=AbiSource.ETHERSCAN_ABI,
        )

    def _first_decoding_candidate(
        self,
        *,
        candidates: tuple[AbiCandidate, ...],
        calldata: str,
        source: AbiSource,
    ) -> DecodedCall | None:
        """Try each ranked candidate; return the first to decode successfully."""
        if not candidates:
            return None
        # Calldata is normalised lowercase before the resolver dispatches
        # tiers; recompute the selector defensively so the
        # :class:`RecoveredAbi` always advertises the calldata's selector
        # (Codex round-2 P3-1) instead of an empty placeholder.
        calldata_selector = calldata[:10].lower() if len(calldata) >= 10 else ""
        ranked = rank_candidates(candidates)
        for candidate in ranked:
            try:
                decoded_call = decode_calldata_with_abi(
                    calldata,
                    candidate.signature_or_abi,
                    source=source,
                )
            except AbiFallbackError as exc:
                logger.debug(
                    "abi_fallback candidate decode failed: source=%s sig=%s err=%s",
                    source.value,
                    candidate.text_signature or candidate.signature_or_abi[:32],
                    exc,
                )
                continue
            # The RecoveredAbi is logged for evidence; not returned to the
            # caller because P1-012 ships only the ``DecodedCall`` surface.
            recovered = self._build_recovered_abi(
                candidate=candidate,
                decoded=decoded_call,
                source=source,
                calldata_selector=calldata_selector,
            )
            logger.debug(
                "abi_fallback hit: source=%s confidence=%.2f sig=%s",
                source.value,
                recovered.confidence,
                recovered.function_signature,
            )
            return decoded_call
        return None

    def _build_recovered_abi(
        self,
        *,
        candidate: AbiCandidate,
        decoded: DecodedCall,
        source: AbiSource,
        calldata_selector: str,
    ) -> RecoveredAbi:
        """Construct the :class:`RecoveredAbi` advertised after a tier hit.

        Codex round-2 P3-1: Sourcify and Etherscan candidates carry a JSON
        ABI string in ``signature_or_abi`` and ``None`` in ``text_signature``
        / ``selector``; constructing the DTO with those raw fields would
        have produced ``selector=""`` and
        ``function_signature="transfer"`` (just the function name). We
        prefer the calldata's actual selector and the matched ABI entry's
        canonical ``"name(t1,...)"`` signature instead. For 4byte the
        candidate already advertises both, so the helper falls through to
        :attr:`AbiCandidate.text_signature` when present.
        """
        # Prefer the candidate-advertised selector (4byte populates it
        # explicitly); fall back to the calldata selector for ABI tiers.
        selector = candidate.selector or calldata_selector
        canonical_sig = canonical_signature_for_candidate(candidate, selector=selector)
        function_signature = canonical_sig or candidate.text_signature or decoded.function_name
        return RecoveredAbi(
            source=source,
            selector=selector,
            function_signature=function_signature,
            confidence=_CONFIDENCE_BY_SOURCE[source],
            address_keyed=_ADDRESS_KEYED_BY_SOURCE[source],
            extras=dict(candidate.extras),
        )

    # ------------------------------------------------------------------
    # Settings helpers
    # ------------------------------------------------------------------

    def _etherscan_api_key_for(self, chain: ChainId) -> SecretStr:
        if chain is ChainId.ETHEREUM:
            return self._read_secret("etherscan_api_key_primary")
        if chain is ChainId.ARBITRUM:
            return self._read_secret("arbiscan_api_key_primary")
        raise ValueError(
            f"AbiFallbackResolver Etherscan tier does not support chain={chain.value!r}"
        )

    def _read_secret(self, attr: str) -> SecretStr:
        value = getattr(self._settings, attr)
        if not isinstance(value, SecretStr):
            raise TypeError(f"settings.{attr} must be SecretStr, got {type(value).__name__}")
        if value.get_secret_value().strip() in ("", _PLACEHOLDER_SECRET):
            raise ValueError(
                f"settings.{attr} is required when enable_etherscan=True; "
                "set it via env or pass enable_etherscan=False"
            )
        return value

    def _validate_etherscan_secrets(self, settings: Any) -> None:
        """Fail-fast in __init__ when Etherscan tier is enabled but keys are missing.

        ``ValueError`` (instead of ``TypeError``) is intentional: Pydantic's
        validator translation maps :class:`ValueError` to user-facing
        validation messages. The not-SecretStr branch is a configuration
        error from the operator's perspective, not a programmer-error.
        """
        for attr in ("etherscan_api_key_primary", "arbiscan_api_key_primary"):
            value = getattr(settings, attr, None)
            if not isinstance(value, SecretStr):
                raise ValueError(  # noqa: TRY004 - configuration error surface
                    f"settings.{attr} must be SecretStr when enable_etherscan=True; "
                    f"got {type(value).__name__}"
                )
            if value.get_secret_value().strip() in ("", _PLACEHOLDER_SECRET):
                raise ValueError(
                    f"settings.{attr} is required when enable_etherscan=True; "
                    "set it via env or pass enable_etherscan=False"
                )


__all__ = ["AbiFallbackResolver"]
