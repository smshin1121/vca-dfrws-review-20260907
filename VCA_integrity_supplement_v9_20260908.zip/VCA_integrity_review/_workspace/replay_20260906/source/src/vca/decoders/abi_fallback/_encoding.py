"""ABI text-signature parsing + value normalisation helpers (P1-012).

Pure functions, no side effects. Lifted out of :mod:`.decode` to keep that
module's body focused on the public ``decode_calldata_with_abi`` entry-point
and its ranking surface.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any

from eth_utils import keccak  # type: ignore[attr-defined]

# ``"<name>(<types>)"`` form; tightly anchored so leading whitespace,
# trailing tokens, or anything mis-shaped surfaces as a clean ValueError
# rather than an opaque codec error.
_TEXT_SIG_RE = re.compile(r"([a-zA-Z_$][a-zA-Z0-9_$]*)\((.*)\)\Z")


def parse_text_signature(text_sig: str) -> tuple[str, tuple[str, ...]]:
    """Parse ``"name(type1,type2,...)"`` → ``("name", ("type1", "type2"))``.

    Empty-arg case (``"name()"``) returns ``(name, ())``. Tuple-typed args
    (e.g. ``"swap((address,uint256))"``) propagate verbatim — the caller
    hands them to ``eth_abi`` which speaks the tuple grammar natively.

    Raises:
        ValueError: input does not match the canonical form.
    """
    match = _TEXT_SIG_RE.fullmatch(text_sig.strip())
    if match is None:
        raise ValueError(f"invalid function signature: {text_sig!r}")
    name = match.group(1)
    raw_args = match.group(2).strip()
    if not raw_args:
        return name, ()
    parts: list[str] = []
    depth = 0
    buf: list[str] = []
    for char in raw_args:
        if char == "(":
            depth += 1
            buf.append(char)
        elif char == ")":
            depth -= 1
            buf.append(char)
        elif char == "," and depth == 0:
            parts.append("".join(buf).strip())
            buf = []
        else:
            buf.append(char)
    parts.append("".join(buf).strip())
    return name, tuple(parts)


def selector_from_text_sig(text_sig: str) -> str:
    """Return ``"0x" + 8 lowercase hex`` selector for a text signature.

    Solidity selectors are the first 4 bytes of ``keccak256("name(t1,...)")``;
    we compute it directly via :func:`eth_utils.keccak` to avoid the
    ``function_abi_to_4byte_selector`` API which (as of eth_utils 5.x)
    requires a parsed ABI dict rather than a text string.
    """
    return "0x" + keccak(text=text_sig)[:4].hex()


def selector_from_abi_entry(entry: Mapping[str, Any]) -> str | None:
    """Return the canonical selector for a JSON ABI function entry, or None.

    ``None`` for non-function entries (constructor / event / fallback /
    receive) so the caller can walk the ABI list without filtering twice.

    Codex round-1 P2-3: defensively skips ABI entries whose ``inputs``
    array carries non-dict members (e.g. ``null`` from a malformed Sourcify
    / Etherscan payload). Returning ``None`` here lets the resolver move
    on to the next ABI entry / candidate / tier rather than raising
    :class:`AttributeError` and aborting ``resolve()``.
    """
    text_sig = canonical_signature_from_abi_entry(entry)
    if text_sig is None:
        return None
    return selector_from_text_sig(text_sig)


def canonical_signature_from_abi_entry(entry: Mapping[str, Any]) -> str | None:
    """Return ``"name(t1,t2,...)"`` for a JSON ABI function entry, or None.

    Mirrors the defensive shape checks in :func:`selector_from_abi_entry`
    so the two helpers stay in lockstep — every entry that yields a
    selector also yields a canonical signature, and vice versa. Lifted
    out so :class:`vca.decoders.abi_fallback.resolver.AbiFallbackResolver`
    can populate :attr:`vca.decoders.abi_fallback.RecoveredAbi.function_signature`
    with the matched ABI's canonical form for Sourcify / Etherscan hits
    (Codex round-2 P3-1).
    """
    if entry.get("type") != "function":
        return None
    name = entry.get("name")
    if not isinstance(name, str):
        return None
    inputs = entry.get("inputs") or ()
    if not isinstance(inputs, (list, tuple)):
        return None
    if not all(isinstance(i, Mapping) for i in inputs):
        return None
    types = tuple(canonical_abi_type(i) for i in inputs)
    return f"{name}({','.join(types)})"


def canonical_abi_type(input_entry: Mapping[str, Any]) -> str:
    """Render an ABI input entry to its canonical selector-grammar form.

    Tuple types ``{"type": "tuple", "components": [...]}`` expand into
    ``"(type1,type2,...)"``. Tuple arrays carry an ``[]`` / ``[N]`` suffix.
    Non-tuple types pass through verbatim.

    Codex round-1 P2-3: nested ``components`` may contain non-dict members
    on hostile input — skip them so a single bad component cannot crash the
    decoder layer with :class:`AttributeError`.
    """
    type_str = str(input_entry.get("type", ""))
    if type_str.startswith("tuple"):
        components = input_entry.get("components") or ()
        if not isinstance(components, (list, tuple)):
            components = ()
        rendered_components = tuple(
            canonical_abi_type(c) for c in components if isinstance(c, Mapping)
        )
        rendered = "(" + ",".join(rendered_components) + ")"
        suffix = type_str[len("tuple") :]
        return rendered + suffix
    return type_str


def normalise_decoded(value: Any, type_str: str | None = None) -> Any:
    """Recursively normalise ``eth_abi`` output for :attr:`DecodedCall.params`.

    * ``bytes`` → ``"0x<lowercase hex>"`` (the freeze pipeline rejects raw
      ``bytes`` because ``model_dump_json`` mishandles non-utf8 payloads).
    * ``tuple`` → ``list`` (later re-frozen to a tuple by the freeze
      pipeline; using ``list`` here is just to keep the recursion intent
      explicit before handing to the freezer).
    * ``str`` (without ABI type context, legacy fallback) — preserved
      verbatim. Address-shaped strings are NOT lowercased without a
      confirming ``address`` ABI type to avoid corrupting Solidity
      ``string`` payloads that happen to look like ``0x`` + 40 hex
      (Codex round-5 P2-1).
    * ``str`` with ``type_str == "address"`` → lowercase (address
      normalisation, deterministic for joins).
    * ``str`` with ``type_str == "string"`` → preserved verbatim.
    * ``int`` / ``bool`` / ``None`` / finite ``float`` → unchanged.

    The optional ``type_str`` argument is the canonical ABI type form
    (``"address"`` / ``"string"`` / ``"address[]"`` / ``"(address,uint256)"``
    etc). Array types (``"<base>[]"`` / ``"<base>[N]"``) recurse with the
    base type so each element is normalised under the right rule. Tuple
    types (``"(t1,t2,...)"``) recurse with the matching component types
    in lockstep.
    """
    if isinstance(value, bytes):
        return "0x" + value.hex()
    if isinstance(value, (list, tuple)):
        element_type = _array_element_type(type_str)
        if element_type is not None:
            return [normalise_decoded(v, element_type) for v in value]
        component_types = _tuple_component_types(type_str)
        if component_types is not None and len(component_types) == len(value):
            return [normalise_decoded(v, t) for v, t in zip(value, component_types, strict=True)]
        # Unknown / mismatched shape: recurse without a type so children
        # fall through to the "no type context" branch and never silently
        # mutate string-shaped data on shape ambiguity.
        return [normalise_decoded(v) for v in value]
    if isinstance(value, str):
        if type_str == "address":
            return value.lower()
        # All other typed strings (Solidity ``string``, ``bytesN``, etc.)
        # are returned verbatim. ``bytes`` / ``bytesN`` ABI types decode
        # to ``bytes`` (handled above), not ``str``, so no further branch
        # is needed here.
        return value
    return value


def _array_element_type(type_str: str | None) -> str | None:
    """Return the element type of an ABI array (``T[]`` / ``T[N]``) or None."""
    if type_str is None:
        return None
    if not type_str.endswith("]"):
        return None
    bracket = type_str.rfind("[")
    if bracket <= 0:
        return None
    return type_str[:bracket]


def _tuple_component_types(type_str: str | None) -> tuple[str, ...] | None:
    """Return the component types of a tuple ABI type (``(t1,t2,...)``) or None.

    Tuple-array types (``(t1,t2)[]`` / ``(t1,t2)[N]``) are NOT handled here
    — they are unwrapped one level at a time by :func:`_array_element_type`
    first, and only the inner ``(t1,t2)`` form reaches this helper.
    """
    if type_str is None:
        return None
    if not (type_str.startswith("(") and type_str.endswith(")")):
        return None
    inner = type_str[1:-1]
    if not inner:
        return ()
    parts: list[str] = []
    depth = 0
    buf: list[str] = []
    for char in inner:
        if char == "(":
            depth += 1
            buf.append(char)
        elif char == ")":
            depth -= 1
            buf.append(char)
        elif char == "," and depth == 0:
            parts.append("".join(buf).strip())
            buf = []
        else:
            buf.append(char)
    parts.append("".join(buf).strip())
    return tuple(parts)


__all__ = [
    "canonical_abi_type",
    "canonical_signature_from_abi_entry",
    "normalise_decoded",
    "parse_text_signature",
    "selector_from_abi_entry",
    "selector_from_text_sig",
]
