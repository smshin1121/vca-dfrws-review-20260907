"""Polygon PoS Bridge ``depositFor`` boundary recognizer (P2-008.0d).

Stage 8 Route B out-of-scope **boundary recognizer**. Phase 2 explicitly
excludes Polygon chain post-Ethereum-exit per supplement PDF "분석 범위
한정" section. This decoder recognizes when funds leave Ethereum via the
Polygon PoS Bridge and emits a marker (``extras["stage_label"] ==
"OUT_OF_SCOPE_POLYGON"``) so downstream tracer code terminates trace
expansion at the Ethereum boundary.

RootChainManagerProxy — mainnet hosts TWO canonical deployments
(``0xA0c68C638235ee32657e8f720a23ceC1bFc77C77`` and
``0xD06029b23e9d4CD24bAd01d436837Fa02B8f0dd9``), both proxying the same
``RootChainManager`` impl; both are recognized:

* ``depositFor(address user, address rootToken, bytes depositData)``
                                      → 0xe3dec8fb
  ABI layout (post-selector):
    word 0: user                     (address, left-padded)
    word 1: rootToken                (address, left-padded)
    word 2: offset of depositData    (canonical = 0x60)
    word 3+: depositData length + contents

  For ERC-20 deposits, ``depositData`` is ``abi.encode(uint256 amount)``
  (a single 32-byte uint256).

* Event (emitted by **ERC20Predicate** proxy — mainnet hosts TWO, one per
  RootChainManagerProxy: ``0x40ec5B33f54e0E8A33A975908C5BA1c14e5BbbDf``
  for proxy 1 and ``0x89a93F94C0a3f388930C4A568430F5e8fFFfd3eC`` for proxy
  2; both are whitelisted):
  ``LockedERC20(address depositor, address depositReceiver,
                address rootToken, uint256 amount)``
        → 0x9b217a401a5ddf7c4d474074aff9958a18d48690d77cc2151c4706aa7348b401

Action kind: closest-fit ``COLLATERAL_SUPPLY`` (closed Phase-1 enum;
0 new values, per P2-001.0c / P2-008.0a precedent). The flow is
*send-side* — the actor's Ethereum funds are locked into the predicate
contract on the way out to Polygon — so the tracer's
``_make_defi_edge`` builds the FlowEdge as ``actor → pool`` (predicate)
on this kind. The ``actor`` is the **LockedERC20 depositor** (the
Ethereum-side ``msg.sender`` that funded the deposit), which can differ
from the calldata ``user`` param when the caller is depositing on
behalf of a Polygon-side receiver.

Boundary semantics carried in ``extras``:
``kind_override="bridge_out_boundary"``,
``stage_label="OUT_OF_SCOPE_POLYGON"``, ``bridge="polygon_pos_bridge"``,
``destination_chain="polygon_pos"``, ``depositor_user`` (calldata
user param — the Polygon-side receiver), ``ethereum_depositor`` (the
Ethereum sender from the LockedERC20 event), ``deposit_data_hex``,
``bridge_contract``, ``predicate_contract``.

R-1 amount coherence: 4-way (calldata user/rootToken/amount + Transfer
+ LockedERC20 depositReceiver/rootToken/amount).

**Tracer-side boundary consumption is deferred to P2-008.1**. The decoder
ships the ``stage_label="OUT_OF_SCOPE_POLYGON"`` payload in
``DefiAction.extras`` so it is available the moment ``FlowTracer``
(:mod:`vca.tracer._run`) is taught to copy boundary extras onto
``FlowEdge`` and to short-circuit BFS expansion when an edge carries
that label. The architect WBS scopes the cassette-wiring + classifier
hook to a downstream task; until that ships, the marker survives only
in the persisted ``DefiAction`` and report metadata. This split is
intentional: the decoder is pure / boundary-recognition, the tracer
mutation is a separate cross-component change.

Pure: no I/O, no clock, no env. Synthetic fixture doctrine.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Final

from eth_utils import keccak  # type: ignore[attr-defined]
from pydantic import BaseModel, Field, ValidationError

from vca.decoders.base import DefiAction, DefiActionKind
from vca.decoders.registry import register_decoder
from vca.types import (
    Address,
    Amount,
    Asset,
    ChainId,
    NormalizedLog,
    NormalizedTransaction,
)
from vca.types.normalized import _FROZEN_CONFIG

__all__ = [
    "POLYGON_POS_BRIDGE_DECODER_NAME",
    "PolygonPosBridgeDecoder",
    "PolygonPosBridgeDecoderConfig",
    "register_polygon_pos_bridge_decoder",
]


# Slice A — Constants (R-SELECTOR-TRIPWIRE + R-EVENT-TOPIC-TRIPWIRE).
_DEPOSITFOR_SIG: Final[str] = "depositFor(address,address,bytes)"
_LOCKEDERC20_EVENT_SIG: Final[str] = "LockedERC20(address,address,address,uint256)"
_TRANSFER_SIG: Final[str] = "Transfer(address,address,uint256)"


def _selector(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()[:8]


def _topic(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()


_DEPOSITFOR_SELECTOR: Final[str] = _selector(_DEPOSITFOR_SIG)
_LOCKEDERC20_TOPIC: Final[str] = _topic(_LOCKEDERC20_EVENT_SIG)
_ERC20_TRANSFER_TOPIC: Final[str] = _topic(_TRANSFER_SIG)

# Import-time keccak pin (R-SELECTOR-TRIPWIRE).
_EXPECTED_SELECTORS: Final[Mapping[str, str]] = MappingProxyType(
    {_DEPOSITFOR_SIG: "0xe3dec8fb"},
)
for _sig, _expected in _EXPECTED_SELECTORS.items():
    if _selector(_sig) != _expected:  # pragma: no cover - import-time tripwire
        raise RuntimeError(
            f"Polygon PoS Bridge selector drift for {_sig!r}: "
            f"{_selector(_sig)!r} (expected {_expected!r}). "
            "Refusing module import — investigate Polygon PoS Bridge ABI or eth_utils.keccak."
        )

# Import-time keccak pin (R-EVENT-TOPIC-TRIPWIRE).
_EXPECTED_EVENT_TOPICS: Final[Mapping[str, str]] = MappingProxyType(
    {
        _LOCKEDERC20_EVENT_SIG: (
            "0x9b217a401a5ddf7c4d474074aff9958a18d48690d77cc2151c4706aa7348b401"
        ),
    },
)
for _sig, _expected in _EXPECTED_EVENT_TOPICS.items():
    if _topic(_sig) != _expected:  # pragma: no cover - import-time tripwire
        raise RuntimeError(
            f"Polygon PoS Bridge event topic drift for {_sig!r}: "
            f"{_topic(_sig)!r} (expected {_expected!r}). "
            "Refusing module import — investigate Polygon PoS Bridge ABI or eth_utils.keccak."
        )

_POLYGON_POS_BRIDGE_SELECTORS: Final[frozenset[str]] = frozenset({_DEPOSITFOR_SELECTOR})

# Mainnet RootChainManagerProxy (Etherscan-verified, EIP-55 verbatim).
# Ethereum mainnet hosts TWO canonical RootChainManagerProxy deployments;
# getsourcecode confirms both proxy to the same ``RootChainManager`` impl,
# are long-lived, and report status OK. The KelpDAO K1 boundary tx routes
# ~99,953 USDT through the SECOND proxy, so both MUST be whitelisted or the
# decoder is blind to a real canonical bridge deposit.
_ROOT_CHAIN_MANAGER_ETH: Final[Address] = Address.from_str(
    "0xA0c68C638235ee32657e8f720a23ceC1bFc77C77", ChainId.ETHEREUM
)
_ROOT_CHAIN_MANAGER_2_ETH: Final[Address] = Address.from_str(
    "0xD06029b23e9d4CD24bAd01d436837Fa02B8f0dd9", ChainId.ETHEREUM
)
_DEFAULT_BRIDGE_ADDRESSES: Final[Mapping[ChainId, frozenset[Address]]] = MappingProxyType(
    {ChainId.ETHEREUM: frozenset({_ROOT_CHAIN_MANAGER_ETH, _ROOT_CHAIN_MANAGER_2_ETH})}
)

# Mainnet ERC20Predicate (Etherscan-verified, EIP-55 verbatim).
# Each RootChainManagerProxy locks ERC-20 deposits into a DISTINCT
# ERC20Predicate, so the two-proxy whitelist needs a paired two-predicate
# whitelist. ``_ERC20_PREDICATE_ETH`` pairs with the first proxy
# ``0xA0c6…7C77``; ``_ERC20_PREDICATE_2_ETH`` pairs with the second proxy
# ``0xD06029b2…`` and is the LockedERC20 emitter for the KelpDAO K1
# boundary tx ``0x5036a42…`` (verified against the captured cassette
# ``stage8b_polygon_boundary_01_logs.yaml``). Without the second predicate
# the decoder ``matches()`` the second-proxy TX but ``decode()`` raises a
# missing-``LockedERC20`` error because ``_find_lockederc20_event`` filters
# by predicate address — the K1 boundary would be invisible end-to-end.
_ERC20_PREDICATE_ETH: Final[Address] = Address.from_str(
    "0x40ec5B33f54e0E8A33A975908C5BA1c14e5BbbDf", ChainId.ETHEREUM
)
_ERC20_PREDICATE_2_ETH: Final[Address] = Address.from_str(
    "0x89a93F94C0a3f388930C4A568430F5e8fFFfd3eC", ChainId.ETHEREUM
)
_DEFAULT_PREDICATE_ADDRESSES: Final[Mapping[ChainId, frozenset[Address]]] = MappingProxyType(
    {ChainId.ETHEREUM: frozenset({_ERC20_PREDICATE_ETH, _ERC20_PREDICATE_2_ETH})}
)

_DEFAULT_ASSET_DECIMALS: Final[Mapping[Address, int]] = MappingProxyType({})
_DEFAULT_ASSET_SYMBOLS: Final[Mapping[Address, str]] = MappingProxyType({})
_PLACEHOLDER_ASSET_SYMBOL: Final[str] = "POLYGON_POS_BRIDGE_ASSET"
POLYGON_POS_BRIDGE_DECODER_NAME: Final[str] = "polygon_pos_bridge"

# R-OUT-OF-SCOPE-LABEL: pinned stage_label emitted via extras.
_OUT_OF_SCOPE_STAGE_LABEL: Final[str] = "OUT_OF_SCOPE_POLYGON"
_DESTINATION_CHAIN: Final[str] = "polygon_pos"
_KIND_OVERRIDE: Final[str] = "bridge_out_boundary"
_BRIDGE_TAG: Final[str] = "polygon_pos_bridge"

# Canonical depositData offset (0x60 = 96 bytes) for the 3-arg signature
# (user, rootToken, bytes depositData).
_CANONICAL_DEPOSITDATA_OFFSET: Final[int] = 0x60


@dataclass(frozen=True, slots=True)
class PolygonPosBridgeDecoderConfig:
    """Phase-2 Polygon PoS Bridge config. Wrap overrides in ``MappingProxyType``.

    ``bridge_addresses`` ships mainnet RootChainManagerProxy pre-pinned
    (R-BRIDGE-WHITELIST-TRIPWIRE); ``predicate_addresses`` ships mainnet
    ERC20Predicate pre-pinned (R-PREDICATE-WHITELIST-TRIPWIRE); asset
    tables empty until P2-008 stage vertical injects USDT entry.
    """

    bridge_addresses: Mapping[ChainId, frozenset[Address]] = field(
        default=_DEFAULT_BRIDGE_ADDRESSES
    )
    predicate_addresses: Mapping[ChainId, frozenset[Address]] = field(
        default=_DEFAULT_PREDICATE_ADDRESSES
    )
    asset_decimals: Mapping[Address, int] = field(default=_DEFAULT_ASSET_DECIMALS)
    asset_symbols: Mapping[Address, str] = field(default=_DEFAULT_ASSET_SYMBOLS)


# Slice C — Pure helpers.


def _validation_error(msg: str) -> ValidationError:
    """Wrap ``msg`` in :class:`pydantic.ValidationError`."""

    class _GuardModel(BaseModel):
        model_config = _FROZEN_CONFIG
        marker: str

    try:
        _GuardModel(marker=msg, extra_field_that_does_not_exist=True)  # type: ignore[call-arg]
    except ValidationError as exc:
        return exc
    raise RuntimeError("validation guard failed to raise")  # pragma: no cover


def _topic_address(topic: str, chain: ChainId) -> Address | None:
    """32-byte indexed-address topic → :class:`Address` or ``None``."""
    if any(c != "0" for c in topic[2:26]):
        return None
    return Address.from_str("0x" + topic[26:], chain)


def _read_uint256_word(data_hex: str, word_index: int) -> int:
    offset = 2 + word_index * 64  # skip '0x'
    return int(data_hex[offset : offset + 64], 16)


def _parse_depositfor_calldata(input_hex: str, *, chain: ChainId) -> tuple[Address, Address, bytes]:
    """Decode ``(user, rootToken, depositData)`` from depositFor calldata.

    Layout: 4-byte selector + 3 head words (user / rootToken / offset)
    + length word + content bytes.

    Raises :class:`pydantic.ValidationError` on short input, malformed
    address padding, non-canonical offset, or length-overflowing data.
    """
    # Selector + 4 mandatory head/length words (user, rootToken, offset, length).
    minimum_len = 10 + 4 * 64
    if len(input_hex) < minimum_len:
        raise _validation_error(
            f"Polygon PoS Bridge calldata too short: {len(input_hex)} < {minimum_len}"
        )

    user_word = input_hex[10 : 10 + 64]
    if any(c != "0" for c in user_word[:24]):
        raise _validation_error(
            f"Polygon PoS Bridge user param topic malformed (non-zero upper 12 bytes): "
            f"{user_word!r}"
        )
    user = Address.from_str("0x" + user_word[24:], chain)

    token_word = input_hex[10 + 64 : 10 + 2 * 64]
    if any(c != "0" for c in token_word[:24]):
        raise _validation_error(
            f"Polygon PoS Bridge rootToken topic malformed (non-zero upper 12 bytes): "
            f"{token_word!r}"
        )
    root_token = Address.from_str("0x" + token_word[24:], chain)

    offset = int(input_hex[10 + 2 * 64 : 10 + 3 * 64], 16)
    if offset != _CANONICAL_DEPOSITDATA_OFFSET:
        raise _validation_error(
            f"Polygon PoS Bridge depositData offset non-canonical: "
            f"got {offset}, expected {_CANONICAL_DEPOSITDATA_OFFSET}"
        )

    length = int(input_hex[10 + 3 * 64 : 10 + 4 * 64], 16)
    # depositData content starts at hex position 10 + 4 * 64 = 266.
    content_start_hex = 10 + 4 * 64
    content_end_hex = content_start_hex + 2 * length
    if content_end_hex > len(input_hex):
        raise _validation_error(
            f"Polygon PoS Bridge depositData length {length} overruns calldata "
            f"of length {len(input_hex)}"
        )
    deposit_data = bytes.fromhex(input_hex[content_start_hex:content_end_hex])
    return user, root_token, deposit_data


def _decode_erc20_amount_from_deposit_data(deposit_data: bytes) -> int | None:
    """Decode ``uint256 amount`` from ERC-20 depositData.

    ERC-20 deposits encode ``depositData`` as ``abi.encode(uint256
    amount)``, which is exactly 32 bytes. Returns ``None`` for any other
    shape so the caller can route to ERC-721 / native flow handling if
    needed (Phase 2: USDT path only, so non-32-byte data is rejected
    upstream).
    """
    if len(deposit_data) != 32:
        return None
    return int.from_bytes(deposit_data, "big")


def _find_lockederc20_event(
    logs: tuple[NormalizedLog, ...],
    *,
    predicate_addresses: frozenset[Address],
) -> NormalizedLog | None:
    """First ``LockedERC20`` event emitted at one of the whitelisted predicate
    addresses (D-2 absent OK)."""
    for log in logs:
        if not log.topics:
            continue
        if log.topics[0] != _LOCKEDERC20_TOPIC:
            continue
        if log.address not in predicate_addresses:
            continue
        return log
    return None


def _parse_lockederc20_payload(
    log: NormalizedLog, *, chain: ChainId
) -> tuple[Address, Address, Address, int]:
    """``LockedERC20`` event log → ``(depositor, depositReceiver, rootToken, amount)``.

    All three address params are indexed (topic[1..3]); ``amount`` is the
    sole non-indexed uint256 word in data.
    """
    if len(log.topics) < 4:
        raise _validation_error(
            f"Polygon PoS Bridge LockedERC20 event missing indexed topics: "
            f"got {len(log.topics)}, expected ≥4"
        )
    depositor = _topic_address(log.topics[1], chain)
    if depositor is None:
        raise _validation_error(
            f"Polygon PoS Bridge LockedERC20 depositor topic malformed: {log.topics[1]!r}"
        )
    deposit_receiver = _topic_address(log.topics[2], chain)
    if deposit_receiver is None:
        raise _validation_error(
            f"Polygon PoS Bridge LockedERC20 depositReceiver topic malformed: {log.topics[2]!r}"
        )
    root_token = _topic_address(log.topics[3], chain)
    if root_token is None:
        raise _validation_error(
            f"Polygon PoS Bridge LockedERC20 rootToken topic malformed: {log.topics[3]!r}"
        )
    expected_hex_len = 2 + 64
    if len(log.data) < expected_hex_len:
        raise _validation_error(
            f"Polygon PoS Bridge LockedERC20 event data too short: "
            f"{len(log.data)} < {expected_hex_len}"
        )
    amount = _read_uint256_word(log.data, 0)
    return depositor, deposit_receiver, root_token, amount


def _find_action_transfer(
    logs: tuple[NormalizedLog, ...],
    *,
    asset: Address,
    expected_from: Address,
    expected_to: Address,
) -> NormalizedLog | None:
    """First ERC-20 ``Transfer`` of ``asset`` matching ``(from, to)``.

    Both endpoints are pinned: ``from`` is the LockedERC20 depositor (the
    Ethereum-side ``msg.sender``) and ``to`` is the predicate contract
    locking the tokens. A Transfer that does not match both ends is not
    the canonical bridge-deposit Transfer and MUST be skipped.
    """
    chain = asset.chain
    for log in logs:
        if not log.topics or log.topics[0] != _ERC20_TRANSFER_TOPIC:
            continue
        if log.address != asset:
            continue
        if len(log.topics) < 3:
            continue
        log_from = _topic_address(log.topics[1], chain)
        log_to = _topic_address(log.topics[2], chain)
        if log_from == expected_from and log_to == expected_to:
            return log
    return None


# Slice B / C — Decoder model.


class PolygonPosBridgeDecoder(BaseModel):
    """Pydantic v2 :class:`BridgeDecoder` for Polygon PoS Bridge ``depositFor``
    boundary recognition (event-driven: LockedERC20 event is the truth)."""

    model_config = _FROZEN_CONFIG

    name: str = POLYGON_POS_BRIDGE_DECODER_NAME
    priority: int = 130
    config: PolygonPosBridgeDecoderConfig = Field(default_factory=PolygonPosBridgeDecoderConfig)

    def matches(self, tx: NormalizedTransaction) -> bool:
        """Four-arm AND predicate (R-BRIDGE-WHITELIST-TRIPWIRE on arm 2)."""
        bridges = self.config.bridge_addresses.get(tx.chain)
        if bridges is None or not bridges:
            return False
        if tx.to_addr is None or tx.to_addr not in bridges:
            return False
        input_hex = tx.input
        if input_hex is None or len(input_hex) < 10:
            return False
        return input_hex[:10].lower() in _POLYGON_POS_BRIDGE_SELECTORS

    def decode(
        self,
        tx: NormalizedTransaction,
        logs: tuple[NormalizedLog, ...],
    ) -> tuple[DefiAction, ...]:
        """Decode + cross-validate; emit one boundary :class:`DefiAction` or ``()``.

        Returns ``()`` (non-match, NOT ValidationError) for:
        * non-ERC-20 ``depositFor`` shapes — RootChainManager also routes
          ERC-721 / MintableERC20 deposits through the same selector,
          which we treat as "matches but no extractable ERC-20 amount"
          per the BridgeDecoder Protocol contract (empty tuple ≠ raise).
        * ``root_token`` not in :attr:`config.asset_decimals` — operator
          has not configured this token (Phase 2 ships with USDT only).

        Tracer-side **boundary consumption** of ``extras["stage_label"]``
        is deferred to **P2-008.1** (cassette wiring + classifier hook);
        this slice ships the marker payload so it is available the
        moment the tracer is taught to read it.
        """
        if not self.matches(tx):
            return ()
        assert tx.input is not None
        assert tx.to_addr is not None
        bridge = tx.to_addr

        user, root_token, deposit_data = _parse_depositfor_calldata(tx.input, chain=tx.chain)

        # Non-ERC-20 shape (e.g. ERC-721 tokenId+data): return () so the
        # tracer treats this as a non-match rather than a decoder error.
        # Phase 2 explicitly scopes to USDT ERC-20 only; non-ERC-20 paths
        # are still Polygon-bound and thus out-of-scope for the trace.
        calldata_amount = _decode_erc20_amount_from_deposit_data(deposit_data)
        if calldata_amount is None:
            return ()

        # Asset resolution gate: skip silently when token is not configured.
        # This MUST precede the LockedERC20 lookup so that ERC-721 deposits
        # (whose 32-byte payload happens to decode as a tokenId) cannot
        # raise when no matching event is present.
        if root_token not in self.config.asset_decimals:
            return ()

        if calldata_amount == 0:
            raise _validation_error(
                "Polygon PoS Bridge calldata amount=0 is impossible in well-formed depositFor"
            )

        predicates = self.config.predicate_addresses.get(tx.chain, frozenset())
        event = _find_lockederc20_event(logs, predicate_addresses=predicates)
        if event is None:
            raise _validation_error(
                f"Polygon PoS Bridge depositFor TX missing required LockedERC20 event "
                f"on any predicate {tuple(a.value for a in predicates)!r}"
            )

        depositor, deposit_receiver, event_root_token, event_amount = _parse_lockederc20_payload(
            event, chain=tx.chain
        )

        # R-1 part 1: calldata rootToken == event rootToken.
        if event_root_token != root_token:
            raise _validation_error(
                f"Polygon PoS Bridge rootToken mismatch: "
                f"calldata={root_token.value}, event={event_root_token.value}"
            )

        # R-1 part 2: calldata amount == event amount.
        if event_amount != calldata_amount:
            raise _validation_error(
                f"Polygon PoS Bridge amount mismatch (calldata vs LockedERC20): "
                f"calldata={calldata_amount}, event={event_amount}"
            )

        # R-1 part 3 (receiver coherence): calldata user == event depositReceiver.
        # This guards against picking up an unrelated predicate event that
        # happens to share token + amount but targets a different Polygon
        # receiver — without this check, the decoder would emit an action
        # combining the calldata user with a foreign event's depositor.
        if deposit_receiver != user:
            raise _validation_error(
                f"Polygon PoS Bridge depositReceiver mismatch: "
                f"calldata user={user.value}, event depositReceiver={deposit_receiver.value}"
            )

        # Asset resolution: gating was already done before the event lookup;
        # at this point ``root_token`` is guaranteed to be in ``asset_decimals``.
        decimals = self.config.asset_decimals[root_token]
        symbol = self.config.asset_symbols.get(root_token, _PLACEHOLDER_ASSET_SYMBOL)
        asset = Asset(chain=tx.chain, symbol=symbol, decimals=decimals, contract=root_token)

        # R-1 part 3: ERC-20 Transfer (depositor → predicate) amount coherence.
        # The Transfer's ``from`` MUST be the LockedERC20 depositor (the
        # Ethereum-side msg.sender funding the deposit), and ``to`` must
        # be the predicate that locks the tokens.
        predicate_addr = event.address
        transfer_log = _find_action_transfer(
            logs,
            asset=root_token,
            expected_from=depositor,
            expected_to=predicate_addr,
        )
        if transfer_log is None:
            raise _validation_error(
                f"Polygon PoS Bridge depositFor TX missing ERC-20 Transfer "
                f"({root_token.value} from depositor {depositor.value} "
                f"to predicate {predicate_addr.value})"
            )
        # Same length guard the LockedERC20 path uses — a malformed
        # ``Transfer`` log with ``data="0x"`` would otherwise raise a raw
        # ``ValueError`` from ``int("", 16)`` instead of the decoder's
        # contract-level :class:`pydantic.ValidationError`.
        expected_transfer_data_hex_len = 2 + 64
        if len(transfer_log.data) < expected_transfer_data_hex_len:
            raise _validation_error(
                f"Polygon PoS Bridge Transfer log data too short: "
                f"{len(transfer_log.data)} < {expected_transfer_data_hex_len}"
            )
        transfer_amount = _read_uint256_word(transfer_log.data, 0)
        if transfer_amount != calldata_amount:
            raise _validation_error(
                f"Polygon PoS Bridge Transfer.value mismatch: "
                f"transfer={transfer_amount}, calldata={calldata_amount}"
            )

        extras: dict[str, object] = {
            "kind_override": _KIND_OVERRIDE,
            "stage_label": _OUT_OF_SCOPE_STAGE_LABEL,
            "bridge": _BRIDGE_TAG,
            "destination_chain": _DESTINATION_CHAIN,
            "depositor_user": user.value,
            "ethereum_depositor": depositor.value,
            "deposit_data_hex": "0x" + deposit_data.hex(),
            "bridge_contract": bridge.value,
            "predicate_contract": predicate_addr.value,
        }

        # Send-side flow: COLLATERAL_SUPPLY makes the tracer build
        # the FlowEdge as actor → pool (Ethereum-depositor → predicate).
        action = DefiAction(
            kind=DefiActionKind.COLLATERAL_SUPPLY,
            chain=tx.chain,
            protocol=POLYGON_POS_BRIDGE_DECODER_NAME,
            asset=asset,
            amount=Amount(raw=calldata_amount, decimals=decimals),
            actor=depositor,
            pool=predicate_addr,
            extras=extras,
        )
        return (action,)


def register_polygon_pos_bridge_decoder(
    config: PolygonPosBridgeDecoderConfig | None = None,
) -> PolygonPosBridgeDecoder:
    """Construct and register the Polygon PoS Bridge decoder on the singleton registry."""
    decoder = (
        PolygonPosBridgeDecoder() if config is None else PolygonPosBridgeDecoder(config=config)
    )
    register_decoder(decoder)
    return decoder
