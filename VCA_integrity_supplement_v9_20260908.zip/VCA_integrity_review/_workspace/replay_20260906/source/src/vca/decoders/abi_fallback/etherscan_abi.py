"""Etherscan / Arbiscan v2 ``getabi`` tier client (P1-012).

Address-keyed verified-contract ABI from the centralised explorer. The v2
multi-chain endpoint (``api.etherscan.io/v2/api``) routes per chain via
the ``chainid`` query param; the API key flows through ``apikey`` and is
excluded from the cache key by :class:`vca.http.client.HttpClient`'s
default ``cache_key_excludes`` set.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any, Final

import httpx
from pydantic import SecretStr

from vca.decoders.abi_fallback._errors import EtherscanAbiError
from vca.decoders.abi_fallback.decode import AbiCandidate, AbiSource

_ETHERSCAN_NOT_VERIFIED: Final[str] = "Contract source code not verified"


def is_etherscan_abi_ok(payload: Mapping[str, Any]) -> bool:
    """Cache-write gate.

    Caches:
    * ``status="1"`` with a JSON-parseable ABI list string (verified contract).
    * ``status="0"`` with the canonical "not verified" answer (the contract
      genuinely is not verified — caching avoids rehitting Etherscan for
      every BFS visit on the same address).

    Rejects (so they do NOT poison the cache):
    * ``status="0"`` with any other message (auth failure, rate limit).
    * ``status="1"`` with a non-JSON or non-list ``result`` payload —
      Codex round-1 P2-2: without this guard a malformed envelope would
      poison the unbounded cache until manual eviction. The validator
      must agree with :func:`lookup_etherscan_abi`'s decode-time shape
      check so we never persist a body the consumer is about to reject.
    * Missing ``"result"`` / ``"status"`` keys.
    """
    if not isinstance(payload, dict):
        return False
    if "status" not in payload or "result" not in payload:
        return False
    status = str(payload.get("status"))
    result = payload.get("result")
    if status == "1":
        if not isinstance(result, str) or result.strip() == "":
            return False
        # Pre-validate the ABI string. Caching a non-JSON / non-list result
        # would force every subsequent ``lookup_etherscan_abi`` call to
        # raise :class:`EtherscanAbiError` from the cached entry.
        try:
            parsed = json.loads(result)
        except json.JSONDecodeError:
            return False
        return isinstance(parsed, list)
    # status != "1" — only the verified-or-not "not verified" answer is cacheable.
    return isinstance(result, str) and result.startswith(_ETHERSCAN_NOT_VERIFIED)


async def lookup_etherscan_abi(
    http_client: Any,
    *,
    address: str,
    chain_id: int,
    base_url: str,
    api_key: SecretStr,
    ttl: int | None,
    rate_limit_source: str,
    raw_store: Any | None = None,
) -> tuple[AbiCandidate, ...]:
    """GET ``module=contract&action=getabi`` → up to one :class:`AbiCandidate`.

    Returns ``()`` when Etherscan signals "not verified". Raises
    :class:`EtherscanAbiError` on auth / rate-limit / shape failures.
    """
    address_lower = address.lower()
    params: dict[str, Any] = {
        "module": "contract",
        "action": "getabi",
        "address": address_lower,
        "chainid": chain_id,
        "apikey": api_key.get_secret_value(),
    }
    try:
        payload = await http_client.get_json(
            base_url,
            params,
            source=rate_limit_source,
            ttl=ttl,
            validator=is_etherscan_abi_ok,
        )
    except httpx.HTTPStatusError as exc:
        raise EtherscanAbiError(
            f"Etherscan ABI HTTP {exc.response.status_code} for address={address_lower}",
            tier=AbiSource.ETHERSCAN_ABI,
            selector="",
            address=address_lower,
            original_status=exc.response.status_code,
        ) from exc
    except httpx.HTTPError as exc:
        raise EtherscanAbiError(
            f"Etherscan ABI transport failure for address={address_lower}: {exc}",
            tier=AbiSource.ETHERSCAN_ABI,
            selector="",
            address=address_lower,
        ) from exc
    except json.JSONDecodeError as exc:
        # Codex P2-1: a 200 response with a malformed body would otherwise
        # propagate ``json.JSONDecodeError`` past the resolver and abort
        # the entire ``resolve()`` call. Surface as the tier-specific error
        # so the resolver returns ``None`` after the lower tiers also fail.
        raise EtherscanAbiError(
            f"Etherscan ABI response was not valid JSON for address={address_lower}: {exc.msg}",
            tier=AbiSource.ETHERSCAN_ABI,
            selector="",
            address=address_lower,
        ) from exc

    if raw_store is not None:
        try:
            from vca.http.client import params_hash

            await raw_store.put(
                source=rate_limit_source,
                endpoint="contract/getabi",
                params_hash=params_hash(params, url=base_url),
                payload=payload,
                status_code=200,
                ttl=ttl,
            )
        except Exception:
            pass

    if not isinstance(payload, Mapping):
        raise EtherscanAbiError(
            f"Etherscan ABI response not a dict for address={address_lower}",
            tier=AbiSource.ETHERSCAN_ABI,
            selector="",
            address=address_lower,
        )
    status = str(payload.get("status"))
    result = payload.get("result")
    if status == "1":
        if not isinstance(result, str) or not result.strip():
            raise EtherscanAbiError(
                f"Etherscan ABI status=1 but result not a non-empty string "
                f"for address={address_lower}",
                tier=AbiSource.ETHERSCAN_ABI,
                selector="",
                address=address_lower,
            )
        # Validate the JSON shape early so a malformed ABI string surfaces
        # as a typed error instead of leaking through to ``decode_calldata_with_abi``.
        try:
            parsed = json.loads(result)
        except json.JSONDecodeError as exc:
            raise EtherscanAbiError(
                f"Etherscan ABI not parseable JSON for address={address_lower}: {exc.msg}",
                tier=AbiSource.ETHERSCAN_ABI,
                selector="",
                address=address_lower,
            ) from exc
        if not isinstance(parsed, list):
            raise EtherscanAbiError(
                f"Etherscan ABI must be a JSON list, got {type(parsed).__name__}",
                tier=AbiSource.ETHERSCAN_ABI,
                selector="",
                address=address_lower,
            )
        return (
            AbiCandidate(
                source=AbiSource.ETHERSCAN_ABI,
                selector="",
                signature_or_abi=result,
                address=address_lower,
                text_signature=None,
                extras={},
            ),
        )
    # status != "1"
    if isinstance(result, str) and result.startswith(_ETHERSCAN_NOT_VERIFIED):
        return ()
    raise EtherscanAbiError(
        f"Etherscan ABI error for address={address_lower}: status={status}, result={result!r}",
        tier=AbiSource.ETHERSCAN_ABI,
        selector="",
        address=address_lower,
        original_status=0,
    )


__all__ = [
    "is_etherscan_abi_ok",
    "lookup_etherscan_abi",
]
