"""THORChain direct-to-vault deposit decoder (P2-006.2).

A NEW :class:`vca.decoders.BridgeDecoder` for the 8 Exploiter-18/19
direct-to-Asgard-vault ETH→BTC THORChain deposits in Stage 7 that the
Router-only :class:`vca.decoders.thorchain.ThorchainDecoder` cannot reach.
Those deposits send native ETH straight to the THORChain Asgard vault with
the swap memo carried as RAW calldata (``input[:10] == 0x3d3a4254`` ==
ASCII ``"=:BT"``; memo form ``=:BTC.BTC:<btc_addr>:<limit>/1/0``) — no
Router call, no ``Deposit`` event. The Router decoder gates on
``depositWithExpiry`` (selector ``0x44bc937b``) and the Router endpoint, so
those 8 BTC hops were previously undecoded.

RR-3 (mirrored from ``thorchain.py``): a new memo TRANSPORT ships as a NEW
decoder class, never a mutation of the v1 Router decoder. The match arm
here is DISJOINT from the Router arm (vault ``to_addr`` + ``0x3d3a4254``
selector vs Router ``to_addr`` + ``0x44bc937b`` selector), so Router
behaviour stays byte-identical.

Given a :class:`NormalizedTransaction` whose ``to_addr`` is the registered
Asgard vault and whose ``input[:10]`` is the raw-memo prefix, the decoder:

1. decodes the raw calldata bytes back to the UTF-8 memo string,
2. parses it with the canonical P2-006.2 regex pinned to
   :data:`_THORCHAIN_VAULT_MEMO_REGEX_VERSION` ``= "v1"`` (the
   ``=:ASSET.ASSET:<addr>:<limits>`` form, distinct from the Router
   ``=:CHAIN:<addr>:<limits>`` form),
3. emits a single :class:`CrossChainHop` ETH→BITCOIN only when the parsed
   ``CHAIN.ASSET`` pair is the documented native ``BTC.BTC`` form (both groups
   equal and BTC); a divergent pair (e.g. ``BTX.BTC`` whose chain merely starts
   with the ``=:BT`` selector, or ``BTC.ETH``) / invalid BTC addresses /
   unparseable memos all return ``()`` (defer policy mirrors the Router
   decoder's DoD-7 / D-1 rule).

The native deposit path carries NO ERC-20 ``Transfer`` log, so the hop's
``amount_in`` is the native ETH value (``tx.value_native``) and
``asset_in`` is :meth:`Asset.native` on Ethereum — there is no token
contract to cross-validate against.

Structurally corrupt calldata hex (odd length / non-hex digits) raises
:class:`pydantic.ValidationError` via the shared ``_validation_error`` helper
(byte-identical to the Router decoder's, the cross-decoder SSOT clone); the
defer-vs-raise split mirrors the Router decoder exactly.

The decoder is **pure**: no I/O, no clock reads, no environment access, no
logging. R-NO-NEW-DEP: the raw-memo selector is an ASCII literal (not a
keccak hash), so unlike the Router decoder this module never imports
``eth_utils.keccak`` — it imports nothing new.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from re import Pattern
from re import compile as _re_compile
from types import MappingProxyType
from typing import Final

from pydantic import BaseModel, Field, ValidationError

from vca.decoders.registry import register_decoder
from vca.types import (
    Address,
    Asset,
    ChainId,
    CrossChainHop,
    NormalizedLog,
    NormalizedTransaction,
)
from vca.types._bech32 import normalize_btc_address
from vca.types.normalized import _FROZEN_CONFIG

__all__ = [
    "THORCHAIN_VAULT_DECODER_NAME",
    "ThorchainVaultDecoder",
    "ThorchainVaultDecoderConfig",
    "register_thorchain_vault_decoder",
]


# ---------------------------------------------------------------------------
# Constants pinned at module import
# ---------------------------------------------------------------------------


# The raw-memo selector is the first 4 bytes of the ASCII memo "=:BTC.BTC:...".
# ``"=:BT"`` == bytes 3d 3a 42 54. Unlike the Router decoder this is NOT a
# keccak function selector — it is the literal start of the swap memo, which
# the vault treats as raw calldata.
_VAULT_MEMO_SELECTOR: Final[str] = "0x3d3a4254"


# Import-time tripwire (mirrors the Router decoder's selector guard): the
# selector MUST equal the ASCII "=:BT" prefix. Any refactor that corrupts it
# would silently stop matching every vault deposit — surface it at module
# load so the test suite cannot even import.
if (
    bytes.fromhex(_VAULT_MEMO_SELECTOR[2:]).decode("ascii", "replace") != "=:BT"
):  # pragma: no cover - import-time tripwire
    raise RuntimeError(
        f"THORChain vault memo selector drift detected: {_VAULT_MEMO_SELECTOR!r} "
        "(expected 0x3d3a4254 == ASCII '=:BT'). Refusing module import."
    )


# RR-3 / R-MEMO-VERSION: dot-versioned name + version constant pin the intent
# that a v2 memo format ships as a NEW class, not a mutation.
_THORCHAIN_VAULT_MEMO_REGEX_VERSION: Final[str] = "v1"
# The ``=:ASSET.ASSET:<addr>:<limits>`` raw-memo form. ``chain``/``asset`` are
# constrained to ASCII letters; ``addr`` is preserved case-sensitively because
# base58 BTC addresses are case-sensitive. Distinct from the Router decoder's
# ``=:CHAIN:`` (no dotted asset) form.
_THORCHAIN_VAULT_MEMO_RE_V1: Final[Pattern[str]] = _re_compile(
    r"^=:(?P<chain>[A-Za-z]+)\.(?P<asset>[A-Za-z]+):(?P<addr>[^:]+):(?P<limits>.*)$"
)


# Closed Phase-2 BTC asset-code set for the dotted ``=:ASSET.ASSET:`` memo.
# A vault memo whose dotted asset code is not BTC returns () under the
# R-BTC-ONLY-PHASE1 rule. Named distinctly from the Router decoder's audited
# ``_BTC_CHAIN_CODES`` (which holds the SHORT chain codes ``b``/``btc``) so the
# thorchain SSOT roster audit's single-source invariant is preserved.
_VAULT_BTC_ASSET_CODES: Final[frozenset[str]] = frozenset({"BTC"})


def _eth_addr(value: str) -> Address:
    return Address.from_str(value, ChainId.ETHEREUM)


# THORChain Asgard vault (Ethereum), on-chain verified during the P2-006.1
# capture (test_stage7_thorchain_router_cross_commit.py:44). EIP-55 mixed case.
_DEFAULT_THORCHAIN_VAULT_ETH: Final[str] = "0x9Fc30541611132C5AC38318E8eEE044d2d36996F"
_DEFAULT_VAULTS: Final[Mapping[ChainId, Address]] = MappingProxyType(
    {ChainId.ETHEREUM: _eth_addr(_DEFAULT_THORCHAIN_VAULT_ETH)}
)


@dataclass(frozen=True, slots=True)
class ThorchainVaultDecoderConfig:
    """Decoder configuration — Asgard vault addresses keyed by chain.

    ``vaults`` defaults to a :class:`types.MappingProxyType` so the default
    instance is structurally immutable; callers passing overrides MUST wrap
    them in ``MappingProxyType(...)`` to preserve the invariant.
    """

    vaults: Mapping[ChainId, Address] = field(default=_DEFAULT_VAULTS)


THORCHAIN_VAULT_DECODER_NAME: Final[str] = "thorchain_vault.v1"


# ---------------------------------------------------------------------------
# Pure helpers
# ---------------------------------------------------------------------------


class _MemoDecodeError(Exception):
    """Sentinel raised when the calldata hex is structurally sound but the
    memo bytes are not valid UTF-8. Caught inside
    :meth:`ThorchainVaultDecoder.decode` and mapped to ``()`` (memo encoding
    is *not* structural corruption — the call still lands on-chain, mirroring
    the Router decoder's DoD-7).
    """


def _validation_error(msg: str) -> ValidationError:
    """Wrap ``msg`` in :class:`pydantic.ValidationError` (DoD-6/8 surface).

    Mirrors the P1-009 helper: build a throw-away ``_FROZEN_CONFIG`` /
    ``extra="forbid"`` model and trigger validation with an unknown extra
    field. Pydantic translates that into a :class:`ValidationError` whose
    ``errors()`` list contains ``msg``, satisfying ``pytest.raises``.
    """

    class _GuardModel(BaseModel):
        model_config = _FROZEN_CONFIG
        marker: str

    try:
        _GuardModel(marker=msg, extra_field_that_does_not_exist=True)  # type: ignore[call-arg]
    except ValidationError as exc:
        return exc
    # Unreachable — extra="forbid" guarantees the call above raises.
    raise RuntimeError("validation guard failed to raise")  # pragma: no cover


def _decode_raw_memo(input_hex: str) -> str:
    """Decode raw calldata hex back to the UTF-8 memo string.

    Raises :class:`pydantic.ValidationError` when the calldata hex is
    structurally corrupt (odd length / non-hex digits — a call that could
    never have landed on-chain). Raises :class:`_MemoDecodeError` when the
    bytes are valid hex but not valid UTF-8 (the caller maps that to ``()``;
    memo encoding is *not* structural corruption).
    """
    try:
        raw = bytes.fromhex(input_hex[2:])
    except ValueError as exc:
        raise _validation_error(f"vault calldata not valid hex: {exc}") from exc
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise _MemoDecodeError(str(exc)) from exc


def _parse_vault_memo(memo: str) -> tuple[str, str, str, str] | None:
    """Apply :data:`_THORCHAIN_VAULT_MEMO_RE_V1`; return ``None`` on non-match.

    Returns ``(chain_code, asset_code, addr, limits_tail)``. BOTH groups of the
    dotted ``CHAIN.ASSET`` pair are preserved so the caller can validate them
    together: the documented native THORChain output form repeats the same code
    (e.g. ``BTC.BTC``). The chain group is NOT discarded — a memo whose chain
    component merely starts with ``BT`` (e.g. ``BTX.BTC``) passes the 4-byte
    ``=:BT`` selector and must be rejected on the parsed chain code, not the
    asset alone (codex P2 / validate-at-boundary).
    """
    match = _THORCHAIN_VAULT_MEMO_RE_V1.fullmatch(memo)
    if match is None:
        return None
    return (
        match.group("chain"),
        match.group("asset"),
        match.group("addr"),
        match.group("limits"),
    )


# ---------------------------------------------------------------------------
# Decoder model
# ---------------------------------------------------------------------------


class ThorchainVaultDecoder(BaseModel):
    """Pydantic v2 :class:`BridgeDecoder` for THORChain direct-to-vault deposits.

    Frozen post-construction (``_FROZEN_CONFIG``); the registry's
    ``runtime_checkable`` Protocol probe inspects attribute presence
    (``name``, ``priority``, ``matches``, ``decode``), all supplied as
    Pydantic descriptors.
    """

    model_config = _FROZEN_CONFIG

    name: str = THORCHAIN_VAULT_DECODER_NAME
    priority: int = 20
    config: ThorchainVaultDecoderConfig = Field(default_factory=ThorchainVaultDecoderConfig)

    def matches(self, tx: NormalizedTransaction) -> bool:
        """Cheap AND predicate: vault ``to_addr`` + raw-memo selector.

        DISJOINT from the Router decoder (Router ``to_addr`` + ``0x44bc937b``).
        Never raises on a valid :class:`NormalizedTransaction`.
        """
        chain = tx.chain
        if chain is not ChainId.ETHEREUM:
            return False
        vault = self.config.vaults.get(chain)
        if vault is None:
            return False
        if tx.to_addr is None or tx.to_addr != vault:
            return False
        input_hex = tx.input
        if input_hex is None or len(input_hex) < 10:
            return False
        return input_hex[:10] == _VAULT_MEMO_SELECTOR

    def decode(
        self,
        tx: NormalizedTransaction,
        logs: tuple[NormalizedLog, ...],
    ) -> tuple[CrossChainHop, ...]:
        """Decode the raw memo; emit one native ETH→BTC hop or ``()``.

        Any ``CHAIN.ASSET`` pair that is not the documented native ``BTC.BTC``
        form (chain not BTC, or chain != asset), invalid BTC addresses,
        non-UTF-8 memo bytes, and non-matching memos all return ``()`` (defer
        policy, mirroring the Router decoder's DoD-7 / D-1). Structurally
        corrupt calldata hex (odd length / non-hex) raises
        :class:`pydantic.ValidationError` (DoD-6). ``logs`` is unused on the
        native path (no ERC-20 ``Transfer`` to cross-validate).
        """
        if not self.matches(tx):
            return ()
        # ``matches`` guarantees ``tx.input`` is set; mypy still needs the guard.
        assert tx.input is not None
        try:
            memo_str = _decode_raw_memo(tx.input)
        except _MemoDecodeError:
            return ()
        parsed = _parse_vault_memo(memo_str)
        if parsed is None:
            return ()
        chain_code, asset_code, addr, _limits = parsed
        # Validate BOTH groups of the documented native ``CHAIN.ASSET`` pair.
        # The 4-byte ``=:BT`` selector only proves the chain group STARTS with
        # "BT" (``BTX.BTC`` slips through), so reject when the chain code is not
        # BTC or when chain and asset differ (the native form has them equal).
        if chain_code not in _VAULT_BTC_ASSET_CODES:
            return ()
        if asset_code != chain_code:
            return ()
        try:
            canonical_btc = normalize_btc_address(addr)
        except ValueError:
            return ()
        asset_in = Asset.native(ChainId.ETHEREUM)
        asset_out = Asset.native(ChainId.BITCOIN)
        hop = CrossChainHop(
            src_chain=ChainId.ETHEREUM,
            dst_chain=ChainId.BITCOIN,
            src_tx=tx.tx_hash,
            dst_address=Address.from_str(canonical_btc, ChainId.BITCOIN),
            via=THORCHAIN_VAULT_DECODER_NAME,
            memo=memo_str,
            asset_in=asset_in,
            asset_out=asset_out,
            amount_in=tx.value_native,
            amount_out=None,
        )
        return (hop,)


def register_thorchain_vault_decoder(
    config: ThorchainVaultDecoderConfig | None = None,
) -> ThorchainVaultDecoder:
    """Construct and register the THORChain vault decoder on the singleton.

    Caller controls the lifecycle: import-time registration is deliberately
    avoided so ``get_decoder_registry.cache_clear()`` test discipline keeps
    working.
    """
    decoder = ThorchainVaultDecoder() if config is None else ThorchainVaultDecoder(config=config)
    register_decoder(decoder)
    return decoder
