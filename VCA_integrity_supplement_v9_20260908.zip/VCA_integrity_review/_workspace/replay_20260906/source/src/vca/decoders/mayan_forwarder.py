"""Mayan Forwarder ``forwardERC20`` boundary recognizer (P2-008.0e).

Stage 8 Route B out-of-scope **boundary recognizer** — Solana exit pair.
Phase 2 explicitly excludes the Solana chain post-Ethereum-exit per
supplement PDF "분석 범위 한정" section. This decoder recognizes when
funds leave Ethereum via the Mayan Forwarder and emits a marker
(``extras["stage_label"] == "OUT_OF_SCOPE_SOLANA_MAYAN"``) so downstream
tracer code terminates trace expansion at the Ethereum boundary.

Mayan Forwarder v3 (mainnet ``0x337685fdaB40D39bd02028545a4FfA7D287cC3E2``):

* ``forwardERC20(address tokenIn, uint256 amountIn,
                 (uint256 value, uint256 deadline, uint8 v,
                  bytes32 r, bytes32 s) permitParams, uint16 protocolBps,
                 address mayanProtocol, bytes protocolData)``
                                                  → 0xcfe5afda

  The ``mayanProtocol`` field is expected to be the **Mayan Swift Source
  v3** contract (mainnet ``0xF18f923480dC144326e6C65d4F3D47Aa459bb41C``).
  When ``mayanProtocol`` is not in the configured ``swift_source_addresses``
  set, the decoder STILL emits the boundary marker (so tracer expansion
  stops at the Ethereum exit) but flags
  ``extras["unrecognized_destination"]=True`` for analytics review.

Cross-validation: ERC-20 ``Transfer(from=msg.sender, to=forwarder,
                                    value=amountIn)``. The Mayan Swift
``OrderCreated`` event has multiple variants across deployments; the
boundary recognizer therefore relies on the ERC-20 Transfer
cross-validation only — selector + forwarder whitelist + Swift Source
validation form the structural tripwire.

Action kind: ``COLLATERAL_SUPPLY`` (closed Phase-1 enum; 0 new values,
per P2-008.0d send-side precedent). The flow is *send-side* — the
actor's Ethereum funds flow into the forwarder contract on the way out
to Solana — so the tracer's ``_make_defi_edge`` builds the FlowEdge as
``actor → pool`` (forwarder) on this kind.

Boundary semantics carried in ``extras``:
``kind_override="bridge_out_boundary"``,
``stage_label="OUT_OF_SCOPE_SOLANA_MAYAN"``, ``bridge="mayan_forwarder"``,
``destination_chain="solana"``, ``forwarder_contract`` (EIP-55),
``mayan_protocol_contract`` (decoded calldata mayanProtocol param),
``protocol_data_hex`` (raw protocolData bytes as 0x-prefixed hex),
``protocol_bps`` (Mayan service-fee bps, uint16),
``solana_receiver_decoded=None``, ``solana_token_mint=None``,
``protocol_data_deep_decode_deferred=True``,
``unrecognized_destination`` (only set ``True`` when mayanProtocol is
not configured as a Swift Source).

The Solana receiver + USDC mint live inside the Mayan Swift order
encoding (``protocolData``); deep-decode of that payload is deferred to
the Phase 3 Solana adapter (Helius/RPC).

**Tracer-side boundary consumption is deferred to P2-008.1**. The
decoder ships the ``stage_label="OUT_OF_SCOPE_SOLANA_MAYAN"`` payload in
``DefiAction.extras`` so it is available the moment ``FlowTracer``
(:mod:`vca.tracer._run`) is taught to copy boundary extras onto
``FlowEdge`` and to short-circuit BFS expansion when an edge carries
that label. This split is intentional: the decoder is pure /
boundary-recognition, the tracer mutation is a separate cross-component
change.

Pure: no I/O, no clock, no env. Synthetic fixture doctrine.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Final

from eth_abi import decode as _abi_decode  # type: ignore[attr-defined]
from eth_utils import keccak  # type: ignore[attr-defined]
from pydantic import BaseModel, Field, ValidationError

from vca.decoders.base import DefiAction, DefiActionKind
from vca.decoders.registry import register_decoder
from vca.types import (
    Address,
    Amount,
    Asset,
    ChainId,
    NormalizedLog,
    NormalizedTransaction,
)
from vca.types.normalized import _FROZEN_CONFIG

__all__ = [
    "MAYAN_FORWARDER_DECODER_NAME",
    "MayanForwarderDecoder",
    "MayanForwarderDecoderConfig",
    "register_mayan_forwarder_decoder",
]


# Slice A — Constants (R-SELECTOR-TRIPWIRE + R-EVENT-TOPIC-TRIPWIRE).
_FORWARDERC20_SIG: Final[str] = (
    "forwardERC20(address,uint256,(uint256,uint256,uint8,bytes32,bytes32),uint16,address,bytes)"
)
_TRANSFER_SIG: Final[str] = "Transfer(address,address,uint256)"


def _selector(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()[:8]


def _topic(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()


_FORWARDERC20_SELECTOR: Final[str] = _selector(_FORWARDERC20_SIG)
_ERC20_TRANSFER_TOPIC: Final[str] = _topic(_TRANSFER_SIG)

# Import-time keccak pin (R-SELECTOR-TRIPWIRE).
_EXPECTED_SELECTORS: Final[Mapping[str, str]] = MappingProxyType(
    {_FORWARDERC20_SIG: "0xcfe5afda"},
)
for _sig, _expected in _EXPECTED_SELECTORS.items():
    if _selector(_sig) != _expected:  # pragma: no cover - import-time tripwire
        raise RuntimeError(
            f"Mayan Forwarder selector drift for {_sig!r}: "
            f"{_selector(_sig)!r} (expected {_expected!r}). "
            "Refusing module import — investigate Mayan Forwarder ABI or eth_utils.keccak."
        )

_MAYAN_FORWARDER_SELECTORS: Final[frozenset[str]] = frozenset({_FORWARDERC20_SELECTOR})

# Mainnet Mayan Forwarder v3 (Etherscan-verified, EIP-55 verbatim).
_FORWARDER_ETH: Final[Address] = Address.from_str(
    "0x337685fdaB40D39bd02028545a4FfA7D287cC3E2", ChainId.ETHEREUM
)
_DEFAULT_FORWARDER_ADDRESSES: Final[Mapping[ChainId, frozenset[Address]]] = MappingProxyType(
    {ChainId.ETHEREUM: frozenset({_FORWARDER_ETH})}
)

# Mainnet Mayan Swift Source v3 (Etherscan-verified, EIP-55 verbatim).
_SWIFT_SOURCE_ETH: Final[Address] = Address.from_str(
    "0xF18f923480dC144326e6C65d4F3D47Aa459bb41C", ChainId.ETHEREUM
)
_DEFAULT_SWIFT_SOURCE_ADDRESSES: Final[Mapping[ChainId, frozenset[Address]]] = MappingProxyType(
    {ChainId.ETHEREUM: frozenset({_SWIFT_SOURCE_ETH})}
)

_DEFAULT_ASSET_DECIMALS: Final[Mapping[Address, int]] = MappingProxyType({})
_DEFAULT_ASSET_SYMBOLS: Final[Mapping[Address, str]] = MappingProxyType({})
_PLACEHOLDER_ASSET_SYMBOL: Final[str] = "MAYAN_FORWARDER_ASSET"
MAYAN_FORWARDER_DECODER_NAME: Final[str] = "mayan_forwarder"

# R-OUT-OF-SCOPE-LABEL: pinned stage_label emitted via extras.
_OUT_OF_SCOPE_STAGE_LABEL: Final[str] = "OUT_OF_SCOPE_SOLANA_MAYAN"
_DESTINATION_CHAIN: Final[str] = "solana"
_KIND_OVERRIDE: Final[str] = "bridge_out_boundary"
_BRIDGE_TAG: Final[str] = "mayan_forwarder"

# ABI tuple for ``forwardERC20`` body (post-selector).
_FORWARDERC20_ABI_TYPES: Final[tuple[str, ...]] = (
    "address",
    "uint256",
    "(uint256,uint256,uint8,bytes32,bytes32)",
    "uint16",
    "address",
    "bytes",
)


@dataclass(frozen=True, slots=True)
class MayanForwarderDecoderConfig:
    """Phase-2 Mayan Forwarder config. Wrap overrides in ``MappingProxyType``.

    ``forwarder_addresses`` ships mainnet Mayan Forwarder v3 pre-pinned
    (R-FORWARDER-WHITELIST-TRIPWIRE); ``swift_source_addresses`` ships
    mainnet Mayan Swift Source v3 pre-pinned (R-SWIFT-SOURCE-VALIDATION);
    asset tables empty until P2-008 stage vertical injects USDC entry.
    """

    forwarder_addresses: Mapping[ChainId, frozenset[Address]] = field(
        default=_DEFAULT_FORWARDER_ADDRESSES
    )
    swift_source_addresses: Mapping[ChainId, frozenset[Address]] = field(
        default=_DEFAULT_SWIFT_SOURCE_ADDRESSES
    )
    asset_decimals: Mapping[Address, int] = field(default=_DEFAULT_ASSET_DECIMALS)
    asset_symbols: Mapping[Address, str] = field(default=_DEFAULT_ASSET_SYMBOLS)


# Slice C — Pure helpers.


def _validation_error(msg: str) -> ValidationError:
    """Wrap ``msg`` in :class:`pydantic.ValidationError`."""

    class _GuardModel(BaseModel):
        model_config = _FROZEN_CONFIG
        marker: str

    try:
        _GuardModel(marker=msg, extra_field_that_does_not_exist=True)  # type: ignore[call-arg]
    except ValidationError as exc:
        return exc
    raise RuntimeError("validation guard failed to raise")  # pragma: no cover


def _topic_address(topic: str, chain: ChainId) -> Address | None:
    """32-byte indexed-address topic → :class:`Address` or ``None``."""
    if any(c != "0" for c in topic[2:26]):
        return None
    return Address.from_str("0x" + topic[26:], chain)


def _read_uint256_word(data_hex: str, word_index: int) -> int:
    offset = 2 + word_index * 64  # skip '0x'
    return int(data_hex[offset : offset + 64], 16)


def _parse_forwarderc20_calldata(
    input_hex: str, *, chain: ChainId
) -> tuple[Address, int, Address, int, bytes]:
    """Decode ``(tokenIn, amountIn, mayanProtocol, protocolBps, protocolData)``
    from forwardERC20 calldata.

    Uses :mod:`eth_abi` to parse the ABI-encoded body (post-selector),
    since the signature contains a tuple (permitParams) and a dynamic
    ``bytes`` field (protocolData). The permit struct is parsed but not
    propagated — boundary recognition only needs token + amount + Mayan
    destination.

    Raises :class:`pydantic.ValidationError` when the body cannot be
    decoded against the expected ABI tuple.
    """
    # Minimum: selector (10 hex) + 6 head words (192 bytes = 384 hex).
    minimum_len = 10 + 6 * 64
    if len(input_hex) < minimum_len:
        raise _validation_error(
            f"Mayan Forwarder calldata too short: {len(input_hex)} < {minimum_len}"
        )

    body_hex = input_hex[10:]
    try:
        body_bytes = bytes.fromhex(body_hex)
    except ValueError as exc:  # pragma: no cover - matches() filters non-hex first
        raise _validation_error(f"Mayan Forwarder calldata body not valid hex: {exc}") from None

    try:
        decoded = _abi_decode(_FORWARDERC20_ABI_TYPES, body_bytes)
    except Exception as exc:
        # eth_abi raises a variety of internal exceptions
        # (InsufficientDataBytes, DecodingError, OverflowError, …) — wrap
        # all of them so the public surface is ValidationError per the
        # BridgeDecoder Protocol contract.
        raise _validation_error(
            f"Mayan Forwarder calldata could not be ABI-decoded: {exc.__class__.__name__}"
        ) from None

    token_in_str, amount_in, _permit, protocol_bps, mayan_protocol_str, protocol_data = decoded
    # eth_abi returns address strings as lowercase hex; normalise via Address.
    token_in = Address.from_str(token_in_str, chain)
    mayan_protocol = Address.from_str(mayan_protocol_str, chain)
    return token_in, int(amount_in), mayan_protocol, int(protocol_bps), bytes(protocol_data)


def _find_action_transfer(
    logs: tuple[NormalizedLog, ...],
    *,
    asset: Address,
    expected_from: Address,
    expected_to: Address,
) -> NormalizedLog | None:
    """First ERC-20 ``Transfer`` of ``asset`` matching ``(from, to)``.

    Both endpoints are pinned: ``from`` is the Ethereum-side msg.sender
    funding the bridge call and ``to`` is the Mayan Forwarder contract
    receiving the bridge-bound tokens. A Transfer that does not match
    both ends is not the canonical bridge-deposit Transfer and MUST be
    skipped.
    """
    chain = asset.chain
    for log in logs:
        if not log.topics or log.topics[0] != _ERC20_TRANSFER_TOPIC:
            continue
        if log.address != asset:
            continue
        if len(log.topics) < 3:
            continue
        log_from = _topic_address(log.topics[1], chain)
        log_to = _topic_address(log.topics[2], chain)
        if log_from == expected_from and log_to == expected_to:
            return log
    return None


# Slice B / C — Decoder model.


class MayanForwarderDecoder(BaseModel):
    """Pydantic v2 :class:`BridgeDecoder` for Mayan Forwarder
    ``forwardERC20`` boundary recognition (Transfer-driven cross-validation
    against ABI-decoded calldata)."""

    model_config = _FROZEN_CONFIG

    name: str = MAYAN_FORWARDER_DECODER_NAME
    priority: int = 130
    config: MayanForwarderDecoderConfig = Field(default_factory=MayanForwarderDecoderConfig)

    def matches(self, tx: NormalizedTransaction) -> bool:
        """Four-arm AND predicate (R-FORWARDER-WHITELIST-TRIPWIRE on arm 2)."""
        forwarders = self.config.forwarder_addresses.get(tx.chain)
        if forwarders is None or not forwarders:
            return False
        if tx.to_addr is None or tx.to_addr not in forwarders:
            return False
        input_hex = tx.input
        if input_hex is None or len(input_hex) < 10:
            return False
        return input_hex[:10].lower() in _MAYAN_FORWARDER_SELECTORS

    def decode(
        self,
        tx: NormalizedTransaction,
        logs: tuple[NormalizedLog, ...],
    ) -> tuple[DefiAction, ...]:
        """Decode + cross-validate; emit one boundary :class:`DefiAction` or ``()``.

        Returns ``()`` (non-match, NOT ValidationError) for:
        * calldata that fails to decode as the expected forwardERC20 tuple
          — the BridgeDecoder Protocol mandates "matches but unparseable"
          path returns empty rather than raising.
        * ``token_in`` not in :attr:`config.asset_decimals` — operator
          has not configured this token (Phase 2 ships with USDC only).

        Raises :class:`pydantic.ValidationError` when calldata decodes but
        cross-validation (Transfer presence + amount coherence) fails.

        Tracer-side **boundary consumption** of ``extras["stage_label"]``
        is deferred to **P2-008.1**.
        """
        if not self.matches(tx):
            return ()
        assert tx.input is not None
        assert tx.to_addr is not None
        assert tx.from_addr is not None
        forwarder = tx.to_addr
        sender = tx.from_addr

        try:
            token_in, amount_in, mayan_protocol, protocol_bps, protocol_data = (
                _parse_forwarderc20_calldata(tx.input, chain=tx.chain)
            )
        except ValidationError:
            # ABI mismatch on a TX with the right selector → non-ERC-20 shape
            # or unrelated overload; treat as non-match per BridgeDecoder
            # Protocol contract (empty tuple ≠ raise).
            return ()

        # Asset resolution gate: skip silently when token is not configured.
        if token_in not in self.config.asset_decimals:
            return ()

        if amount_in == 0:
            raise _validation_error(
                "Mayan Forwarder calldata amount=0 is impossible in well-formed forwardERC20"
            )

        # R-1 amount coherence: ERC-20 Transfer (sender → forwarder) must
        # match calldata amountIn. The Transfer's ``from`` MUST be the
        # tx.from (the Ethereum-side msg.sender), and ``to`` must be the
        # forwarder receiving the bridge-bound tokens.
        transfer_log = _find_action_transfer(
            logs,
            asset=token_in,
            expected_from=sender,
            expected_to=forwarder,
        )
        if transfer_log is None:
            raise _validation_error(
                f"Mayan Forwarder forwardERC20 TX missing ERC-20 Transfer "
                f"({token_in.value} from sender {sender.value} "
                f"to forwarder {forwarder.value})"
            )
        # Length guard before ``int("", 16)`` to ensure malformed Transfer
        # raises ValidationError (decoder contract) not raw ValueError.
        expected_transfer_data_hex_len = 2 + 64
        if len(transfer_log.data) < expected_transfer_data_hex_len:
            raise _validation_error(
                f"Mayan Forwarder Transfer log data too short: "
                f"{len(transfer_log.data)} < {expected_transfer_data_hex_len}"
            )
        transfer_amount = _read_uint256_word(transfer_log.data, 0)
        if transfer_amount != amount_in:
            raise _validation_error(
                f"Mayan Forwarder Transfer.value mismatch: "
                f"transfer={transfer_amount}, calldata={amount_in}"
            )

        # R-SWIFT-SOURCE-VALIDATION: mayanProtocol field check. When the
        # field is not in the configured Swift Source set, STILL emit the
        # boundary marker (so tracer expansion stops) but flag
        # extras["unrecognized_destination"]=True for analytics review.
        swift_sources = self.config.swift_source_addresses.get(tx.chain, frozenset())
        unrecognized_destination = mayan_protocol not in swift_sources

        # Asset resolution: gating was already done before validation.
        decimals = self.config.asset_decimals[token_in]
        symbol = self.config.asset_symbols.get(token_in, _PLACEHOLDER_ASSET_SYMBOL)
        asset = Asset(chain=tx.chain, symbol=symbol, decimals=decimals, contract=token_in)

        extras: dict[str, object] = {
            "kind_override": _KIND_OVERRIDE,
            "stage_label": _OUT_OF_SCOPE_STAGE_LABEL,
            "bridge": _BRIDGE_TAG,
            "destination_chain": _DESTINATION_CHAIN,
            "forwarder_contract": forwarder.value,
            "mayan_protocol_contract": mayan_protocol.value,
            "protocol_data_hex": "0x" + protocol_data.hex(),
            "protocol_bps": protocol_bps,
            "solana_receiver_decoded": None,
            "solana_token_mint": None,
            "protocol_data_deep_decode_deferred": True,
            "unrecognized_destination": unrecognized_destination,
        }

        # Send-side flow: COLLATERAL_SUPPLY makes the tracer build
        # the FlowEdge as actor → pool (sender → forwarder).
        action = DefiAction(
            kind=DefiActionKind.COLLATERAL_SUPPLY,
            chain=tx.chain,
            protocol=MAYAN_FORWARDER_DECODER_NAME,
            asset=asset,
            amount=Amount(raw=amount_in, decimals=decimals),
            actor=sender,
            pool=forwarder,
            extras=extras,
        )
        return (action,)


def register_mayan_forwarder_decoder(
    config: MayanForwarderDecoderConfig | None = None,
) -> MayanForwarderDecoder:
    """Construct and register the Mayan Forwarder decoder on the singleton registry."""
    decoder = MayanForwarderDecoder() if config is None else MayanForwarderDecoder(config=config)
    register_decoder(decoder)
    return decoder
