"""DecoderRegistry — process-wide ``name → BridgeDecoder`` binding (P1-008).

Mirrors :mod:`vca.adapters.registry`: a small dict + an ordered-tuple cache
plus six query helpers. ``find_matching`` is the only TX-dependent surface
and is hot-path safe (read-only, O(N), no per-call sort). Concurrency
policy mirrors the adapter registry — registration happens once at
bootstrap on a single thread before async consumers start; the registry
takes no internal locks (WBS R-CONC).

The :func:`get_decoder_registry` singleton is an :func:`functools.lru_cache`
mirroring :func:`vca.adapters.registry.get_registry` and
:func:`vca.config.get_settings`. Tests must call
:func:`get_decoder_registry.cache_clear` between cases.
"""

from __future__ import annotations

import re
from functools import lru_cache
from typing import Final

from vca.decoders.base import BridgeDecoder

__all__ = [
    "DecoderRegistry",
    "get_decoder_registry",
    "register_decoder",
]

# Charset matches Etherscan source labels, which downstream
# :attr:`vca.types.DecodedCall.decoder` already trusts at the persistence
# layer. Stable, URL-safe names matter for the labeler join key (P1-013).
_NAME_RE: Final[re.Pattern[str]] = re.compile(r"[a-z0-9_.-]+")
_PRIORITY_MIN: Final[int] = 0
_PRIORITY_MAX: Final[int] = 1000


class DecoderRegistry:
    """``name → BridgeDecoder`` registry with priority-then-insertion ordering.

    Concurrency: the same single-thread bootstrap rule as
    :class:`vca.adapters.registry.AdapterRegistry` applies — registration
    happens once before the asyncio loop starts. :meth:`find_matching` is
    hot-path safe (read-only, O(N)).
    """

    __slots__ = ("_by_name", "_ordered")

    def __init__(self) -> None:
        self._by_name: dict[str, BridgeDecoder] = {}
        # Priority-then-insertion ordered tuple, recomputed on every
        # register/unregister. find_matching iterates this — never sorts
        # per call (DoD-12).
        self._ordered: tuple[BridgeDecoder, ...] = ()

    def register(
        self,
        decoder: BridgeDecoder,
        *,
        replace: bool = False,
    ) -> None:
        """Register ``decoder`` keyed by ``decoder.name``.

        Validation order (matches WBS §5.2):

        1. ``runtime_checkable`` Protocol probe → :class:`TypeError`.
        2. ``decoder.name`` / ``decoder.priority`` runtime types → ``TypeError``.
        3. ``decoder.name`` charset / non-empty → :class:`ValueError`.
        4. ``decoder.priority`` range ``[0, 1000]`` → ``ValueError``.
        5. Duplicate-name guard (unless ``replace=True``) → ``ValueError``.
        6. Commit to ``_by_name`` and recompute ``_ordered``.

        Raises:
            TypeError: ``decoder`` does not satisfy :class:`BridgeDecoder` or
                ``decoder.name`` is not ``str`` / ``decoder.priority`` is not
                ``int``.
            ValueError: ``decoder.name`` empty / outside charset; or
                ``decoder.priority`` outside ``[0, 1000]``; or
                ``replace=False`` and ``decoder.name`` already registered.
        """
        # 1. Protocol attribute probe (parity with AdapterRegistry).
        if not isinstance(decoder, BridgeDecoder):
            raise TypeError(
                f"decoder must implement BridgeDecoder Protocol "
                f"(missing required attributes or methods), got "
                f"{type(decoder).__name__}"
            )
        # 2. Runtime type guards. ``runtime_checkable`` only inspects attribute
        # *presence*, so a fake whose ``name`` is ``None``/``int`` slips past
        # ``isinstance``. Surface the documented :class:`TypeError` here so
        # the charset check below never runs on a non-string. ``bool``
        # subclasses ``int`` — reject explicitly to mirror
        # :func:`vca.types.normalized._reject_bool`.
        if not isinstance(decoder.name, str):
            raise TypeError(
                f"decoder.name must be str, got {type(decoder.name).__name__}: {decoder.name!r}"
            )
        if isinstance(decoder.priority, bool) or not isinstance(decoder.priority, int):
            raise TypeError(
                f"decoder.priority must be int, got "
                f"{type(decoder.priority).__name__}: {decoder.priority!r}"
            )
        name = decoder.name
        priority = decoder.priority
        # 3. Name charset / non-empty.
        if not name or not _NAME_RE.fullmatch(name):
            raise ValueError(
                f"decoder.name must match [a-z0-9_.-]+ and be non-empty, got: {name!r}"
            )
        # 4. Priority range.
        if priority < _PRIORITY_MIN or priority > _PRIORITY_MAX:
            raise ValueError(
                f"decoder.priority must be in [{_PRIORITY_MIN}, {_PRIORITY_MAX}], got: {priority}"
            )
        # 5. Duplicate-name guard.
        if not replace and name in self._by_name:
            raise ValueError(
                f"decoder name {name!r} already registered; pass replace=True to override"
            )
        # 6. Commit + recompute ordering.
        self._by_name[name] = decoder
        self._recompute_ordered()

    def unregister(self, name: str) -> None:
        """Remove the decoder with ``name``. Raises :class:`KeyError` if absent.

        The error message lists currently-registered names (parity with
        :meth:`vca.adapters.registry.AdapterRegistry.get`).
        """
        if name not in self._by_name:
            known = ", ".join(self.names()) or "<none>"
            raise KeyError(f"decoder name {name!r} not registered; known names: [{known}]")
        del self._by_name[name]
        self._recompute_ordered()

    def get(self, name: str) -> BridgeDecoder:
        """Return the decoder for ``name``. Raises :class:`KeyError` if absent."""
        try:
            return self._by_name[name]
        except KeyError as exc:
            known = ", ".join(self.names()) or "<none>"
            raise KeyError(f"decoder name {name!r} not registered; known names: [{known}]") from exc

    def has(self, name: str) -> bool:
        return name in self._by_name

    def names(self) -> tuple[str, ...]:
        """Registered names in priority-then-insertion order (DoD-9)."""
        return tuple(d.name for d in self._ordered)

    def decoders(self) -> tuple[BridgeDecoder, ...]:
        """All decoders in priority-then-insertion order."""
        return self._ordered

    def find_matching(
        self,
        tx: object,
    ) -> tuple[BridgeDecoder, ...]:
        """Return every decoder whose ``matches(tx)`` is True, priority order.

        O(N) in the number of registered decoders. Does NOT call
        :meth:`BridgeDecoder.decode`. Exceptions raised by ``matches``
        propagate as-is (DoD-13). The signature accepts ``object`` for the
        TX so callers do not need to import :class:`vca.types.NormalizedTransaction`
        here — runtime behaviour is unchanged because the decoders' own
        ``matches`` annotations enforce the type.
        """
        return tuple(d for d in self._ordered if d.matches(tx))  # type: ignore[arg-type]

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _recompute_ordered(self) -> None:
        """Recompute the priority-then-insertion ordered tuple.

        Python ``sorted`` is stable, so ties on ``priority`` preserve the
        ``dict`` insertion order — see DoD-9 / behaviour 27.
        """
        self._ordered = tuple(sorted(self._by_name.values(), key=lambda d: d.priority))


@lru_cache(maxsize=1)
def get_decoder_registry() -> DecoderRegistry:
    """Process-wide singleton :class:`DecoderRegistry`.

    Mirrors :func:`vca.adapters.registry.get_registry` and
    :func:`vca.config.get_settings`. Tests must call
    :func:`get_decoder_registry.cache_clear` between cases.
    """
    return DecoderRegistry()


def register_decoder(
    decoder: BridgeDecoder,
    *,
    replace: bool = False,
) -> None:
    """Convenience: register ``decoder`` on the singleton registry."""
    get_decoder_registry().register(decoder, replace=replace)
