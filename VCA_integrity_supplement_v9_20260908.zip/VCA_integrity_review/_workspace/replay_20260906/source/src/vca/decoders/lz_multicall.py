"""LZMultiCall wrapper decoder (P2-002.0).

Stage 3-B Arbitrum bridge layer. Wraps N LayerZero V2 OFT ``send`` calls
into a single batched dispatch against the registered Stage 3-B wrapper
contract.

**Cassette-verified anchors** (codex P2-002.0 R-4 round 3): the
supplement PDF's quoted wrapper address and method shape are partially
incorrect; the on-chain authoritative values come from the repo-shipped
cassettes (``tests/fixtures/kelpdao/cassettes/ethereum/
stage2_dispersal_0x*_txs.yaml``):

* Wrapper address: ``0xacddac6c77318b615f7f6fb9bb67c6833e9c05f1``
  (supplement quote ``0xAcdDAC6C77318D615f7F6f39bb67c6833e9c05f1``
  differs at hex positions 14 + 22 — OCR/typo in source doc)
* Wrapper selector: ``0x571d3dc7`` (custom — NOT the OZ standard
  ``multicall(bytes[])`` selector ``0xac9650d8``); the wrapper's
  source/ABI is unpublished so the selector is pinned by its 4-byte
  hex value rather than via a signature → keccak derivation.

The decoder is **event-driven** (mirrors P2-008.0a ``cow_protocol`` and
P2-001.0c ``kyberswap``):

* Calldata gates only on (wrapper-address ∈ whitelist) + (selector ∈
  {``0x571d3dc7``}); the body of the wrapper call is opaque past the
  selector.
* The canonical truth (guid / dstEid / fromAddress / amountSentLD)
  lives in the ``OFTSent`` events emitted by the inner LayerZero V2 OFT
  contracts. A single ``decode`` call MAY emit multiple
  :class:`DefiAction`s — one per ``OFTSent`` event.

OFT ``OFTSent`` event signature — CASSETTE TRUTH (P3.2-004 re-pin):

::

    event OFTSent(
        bytes32 indexed guid,
        uint32 dstEid,
        address indexed fromAddress,
        uint256 amountSentLD
    );

``guid`` (topic[1]) and ``fromAddress`` (topic[2]) are indexed; ``dstEid``
and ``amountSentLD`` are packed as exactly TWO 32-byte words in ``data``.

**Divergence from canonical LayerZero V2 OFTCore.sol (P1-009 doctrine:
cassette bytes > synthetic guess).** The canonical
``layerzerolabs/lz-evm-oapp-v2`` ``OFTCore.sol`` declares a 5-param event
``OFTSent(bytes32,uint32,address,uint256,uint256)`` (topic0
``0x85496b76…``) with a trailing ``amountReceivedLD`` word. The configured
rsETH OFT adapter ``0x85d456…98Ef3`` actually emits the 4-param variant
``OFTSent(bytes32,uint32,address,uint256)`` (topic0 ``0xfff873bb…``) in
every repo cassette receipt:

* ``tests/fixtures/kelpdao/cassettes/ethereum/stage3a_e2_5_logs.yaml``
* ``tests/fixtures/kelpdao/cassettes/ethereum/stage3a_e4_5_logs.yaml``
* ``tests/fixtures/kelpdao/cassettes/ethereum/stage3a_e5_4_logs.yaml``
* ``tests/fixtures/kelpdao/cassettes/ethereum/stage3a_e6_2_logs.yaml``

Every observed OFTSent log carries 3 topics + exactly 2 data words. The
``amountReceivedLD`` field does NOT exist on this adapter, so the decoder
does not synthesise it (no ``amount_received_ld`` extras key — not
fabricated). Slippage detail, if ever needed, is a destination-chain
(Stage 3-B ARB) decoder concern.

R-EID-30110 cross-validation: every ``OFTSent.dstEid`` MUST equal an
allowed EID (default ``frozenset({30110})`` — Arbitrum only). Mismatch
raises :class:`pydantic.ValidationError`. Allow expanding via
:attr:`LzMultiCallDecoderConfig.allowed_dst_eids`.

R-1 amount coherence: per-OFTSent quartet match
``(token, from = fromAddress, to = wrapper, value = amountSentLD)``
disambiguates batched dispatches and ignores unrelated funding
transfers. Missing matching Transfer is permitted (D-2). An endpoint
match with the WRONG amount alongside no value-match still raises (R-1
anomaly detection).

DefiActionKind: ``COLLATERAL_SUPPLY`` with
``extras["kind_override"] = "bridge_send"`` (0 new enum values; SUPPLY
mirrors the user → wrapper value-flow direction used by
``_make_defi_edge``, per codex P2-002.0 R-1).

Pure: no I/O, no clock, no env. Synthetic fixture doctrine.

See ``_workspace/p2_source_doc_supplement_analysis.md`` for the
supplement PDF source (Stage 3-B: 39,742.795 rsETH total across 6 wallets
via this wrapper).
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Final

from eth_utils import keccak  # type: ignore[attr-defined]
from pydantic import BaseModel, Field, ValidationError

from vca.decoders.base import DefiAction, DefiActionKind
from vca.decoders.registry import register_decoder
from vca.types import (
    Address,
    Amount,
    Asset,
    ChainId,
    NormalizedLog,
    NormalizedTransaction,
)
from vca.types.normalized import _FROZEN_CONFIG

__all__ = [
    "LZ_MULTICALL_DECODER_NAME",
    "LzMultiCallDecoder",
    "LzMultiCallDecoderConfig",
    "register_lz_multicall_decoder",
]


# Slice A — Constants (R-SELECTOR-TRIPWIRE + R-EVENT-TOPIC-TRIPWIRE).
#
# Codex P2-002.0 R-4 finding: the supplement PDF quotes the LZMultiCall
# wrapper address as ``0xAcdDAC6C77318D615f7F6f39bb67c6833e9c05f1`` and
# describes the wrapping method generically as a "multicall", but the
# canonical on-chain artefacts (verified in repo-shipped cassettes
# ``tests/fixtures/kelpdao/cassettes/ethereum/stage2_dispersal_0x*_txs.yaml``)
# diverge from both quotes:
#
#   * Real wrapper address (cassette ``to`` field):
#     ``0xacddac6c77318b615f7f6fb9bb67c6833e9c05f1``
#     (two hex characters differ from the supplement quote — OCR/typo
#     in source doc, corrected here via the on-chain authoritative
#     value)
#   * Real wrapper selector: ``0x571d3dc7`` (custom — NOT the OZ
#     ``multicall(bytes[])`` selector ``0xac9650d8``). The function ABI
#     is not publicly verified on Etherscan, so the 4-byte selector is
#     pinned by its hex value rather than via a signature → keccak
#     derivation.
#
# Both anchors are cross-validated against the Stage 3-B seed-tx hashes
# the supplement enumerates: e.g. tx
# ``0x7497fe1116e9200f5b356191f95e571de90e7410649a9641f71213c3abbb6cdb``
# appears in ``stage2_dispersal_0xeba7_txs.yaml`` with
# ``methodId=0x571d3dc7`` and ``to=<real wrapper>``.
_OFT_SENT_EVENT_SIG: Final[str] = "OFTSent(bytes32,uint32,address,uint256)"
_TRANSFER_SIG: Final[str] = "Transfer(address,address,uint256)"


def _topic(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()


# Cassette-verified wrapper selector. The wrapper's ABI is unpublished,
# so the selector is pinned by its 4-byte hex value (R-SELECTOR-TRIPWIRE
# protects via the ``_EXPECTED_SELECTORS`` pin below). The remaining
# decoder ``_topic`` derivation is keccak-based for the event topics.
_MULTICALL_SELECTOR: Final[str] = "0x571d3dc7"
_OFT_SENT_TOPIC: Final[str] = _topic(_OFT_SENT_EVENT_SIG)
_ERC20_TRANSFER_TOPIC: Final[str] = _topic(_TRANSFER_SIG)

# Import-time pin (R-SELECTOR-TRIPWIRE). Cassette-verified anchor;
# any drift fails at first module import.
_EXPECTED_SELECTORS: Final[Mapping[str, str]] = MappingProxyType(
    {"cassette_verified_wrapper": "0x571d3dc7"},
)
for _name, _expected in _EXPECTED_SELECTORS.items():
    if _expected != _MULTICALL_SELECTOR:  # pragma: no cover - import-time tripwire
        raise RuntimeError(
            f"LZMultiCall selector drift for {_name!r}: "
            f"{_MULTICALL_SELECTOR!r} (expected {_expected!r}). "
            "Refusing module import — investigate cassette / wrapper ABI."
        )

# Import-time keccak pin (R-EVENT-TOPIC-TRIPWIRE).
_EXPECTED_EVENT_TOPICS: Final[Mapping[str, str]] = MappingProxyType(
    {
        _OFT_SENT_EVENT_SIG: ("0xfff873bb909b73d08a8c1af4b21779e87103bb8ea8cf3b3a0067eb8526b8b80a"),
    },
)
for _sig, _expected in _EXPECTED_EVENT_TOPICS.items():
    if _topic(_sig) != _expected:  # pragma: no cover - import-time tripwire
        raise RuntimeError(
            f"LZMultiCall event topic drift for {_sig!r}: "
            f"{_topic(_sig)!r} (expected {_expected!r}). "
            "Refusing module import — investigate LayerZero V2 ABI or eth_utils.keccak."
        )

_LZ_MULTICALL_SELECTORS: Final[frozenset[str]] = frozenset({_MULTICALL_SELECTOR})

# Mainnet LZMultiCall wrapper. Cassette-observed value is authoritative
# (the supplement PDF quote has a 2-character typo at positions 14 + 22;
# see Slice-A header for the diff). Address.from_str normalises to
# EIP-55.
_LZ_MULTICALL_ETH: Final[Address] = Address.from_str(
    "0xacddac6c77318b615f7f6fb9bb67c6833e9c05f1", ChainId.ETHEREUM
)
_DEFAULT_MULTICALL_ADDRESSES: Final[Mapping[ChainId, frozenset[Address]]] = MappingProxyType(
    {ChainId.ETHEREUM: frozenset({_LZ_MULTICALL_ETH})}
)

# R-EID-30110: default allowlist is Arbitrum One (LayerZero V2 EID 30110).
_ARB_EID: Final[int] = 30_110
_DEFAULT_ALLOWED_DST_EIDS: Final[frozenset[int]] = frozenset({_ARB_EID})

# EID → chain-name label for ``extras["dst_chain"]``. Pinned to the
# subset the decoder is willing to label; unknown EIDs that pass the
# allowlist (test-time only) surface the integer in ``extras["dst_eid"]``
# without a chain-name label.
_DST_EID_TO_CHAIN: Final[Mapping[int, str]] = MappingProxyType({_ARB_EID: "arbitrum"})

# R-ASSET-DECIMAL-TABLE: empty default; case bootstrap (P1-018) wires in
# rsETH/etc. Adapter → token mapping similarly empty by default and is
# how the decoder distinguishes Trade source-token in cassette-driven runs.
_DEFAULT_ADAPTER_TO_TOKEN: Final[Mapping[Address, Address]] = MappingProxyType({})
_DEFAULT_ASSET_DECIMALS: Final[Mapping[Address, int]] = MappingProxyType({})
_DEFAULT_ASSET_SYMBOLS: Final[Mapping[Address, str]] = MappingProxyType({})
_PLACEHOLDER_ASSET_SYMBOL: Final[str] = "LZ_MULTICALL_ASSET"
_ROUTER_TAG: Final[str] = "lz_multicall"
_KIND_OVERRIDE: Final[str] = "bridge_send"
LZ_MULTICALL_DECODER_NAME: Final[str] = "lz_multicall"


@dataclass(frozen=True, slots=True)
class LzMultiCallDecoderConfig:
    """Phase-2 LZMultiCall config. Wrap overrides in ``MappingProxyType``.

    ``multicall_addresses`` ships the mainnet wrapper pre-pinned
    (R-MULTICALL-WHITELIST-TRIPWIRE).

    ``allowed_dst_eids`` defaults to ``frozenset({30110})`` (Arbitrum only)
    — extend for cross-chain testing (e.g. ``frozenset({30110, 30111})``
    to admit Optimism).

    ``adapter_to_token`` maps the LayerZero OFT adapter address (event
    emitter) to the underlying ERC-20 token address; downstream
    ``asset_decimals`` / ``asset_symbols`` are then keyed by the
    underlying token. Empty default — case bootstrap wires the rsETH
    adapter → rsETH token pair (P1-018 / P2-002.1).
    """

    multicall_addresses: Mapping[ChainId, frozenset[Address]] = field(
        default=_DEFAULT_MULTICALL_ADDRESSES
    )
    allowed_dst_eids: frozenset[int] = field(default=_DEFAULT_ALLOWED_DST_EIDS)
    adapter_to_token: Mapping[Address, Address] = field(default=_DEFAULT_ADAPTER_TO_TOKEN)
    asset_decimals: Mapping[Address, int] = field(default=_DEFAULT_ASSET_DECIMALS)
    asset_symbols: Mapping[Address, str] = field(default=_DEFAULT_ASSET_SYMBOLS)


# Slice C — Pure helpers.


def _validation_error(msg: str) -> ValidationError:
    """Wrap ``msg`` in :class:`pydantic.ValidationError`."""

    class _GuardModel(BaseModel):
        model_config = _FROZEN_CONFIG
        marker: str

    try:
        _GuardModel(marker=msg, extra_field_that_does_not_exist=True)  # type: ignore[call-arg]
    except ValidationError as exc:
        return exc
    raise RuntimeError("validation guard failed to raise")  # pragma: no cover


def _topic_address(topic: str, chain: ChainId) -> Address | None:
    """32-byte indexed-address topic → :class:`Address` or ``None``."""
    if any(c != "0" for c in topic[2:26]):
        return None
    return Address.from_str("0x" + topic[26:], chain)


def _read_uint256_word(data_hex: str, word_index: int) -> int:
    offset = 2 + word_index * 64  # skip '0x'
    return int(data_hex[offset : offset + 64], 16)


def _find_oft_sent_events(
    logs: tuple[NormalizedLog, ...],
) -> tuple[NormalizedLog, ...]:
    """All ``OFTSent`` events in log order, regardless of emitter address.

    The OFTSent event is emitted by the inner OFT adapter contract — NOT
    the LZMultiCall wrapper — so we can't filter by the wrapper address.
    Filtering by topic[0] alone is correct because the OFTSent topic is
    LayerZero V2 specific and won't collide with unrelated events.
    """
    return tuple(log for log in logs if log.topics and log.topics[0] == _OFT_SENT_TOPIC)


def _parse_oft_sent_payload(log: NormalizedLog, *, chain: ChainId) -> tuple[str, Address, int, int]:
    """``OFTSent`` event log → ``(guid, fromAddress, dstEid, amountSentLD)``.

    ``guid`` (topic[1]) and ``fromAddress`` (topic[2]) are indexed.
    ``dstEid`` and ``amountSentLD`` occupy exactly TWO 32-byte words in
    ``data`` (cassette truth — see module docstring for the divergence
    from the canonical 5-param OFTCore.sol event). The real adapter does
    NOT emit ``amountReceivedLD``, so it is not parsed.

    Defensive arity policy (P3.2-004 Risk 2): require ``>= 2`` data words.
    A receipt carrying ``> 2`` words (e.g. a future adapter upgrade to the
    canonical 5-param variant) is accepted — only the leading two words
    are read — so the decoder does not break on a forward-compatible
    expansion. Fewer than 2 words is structural corruption and raises.

    Raises :class:`pydantic.ValidationError` on missing topic, malformed
    indexed address, or short data.
    """
    if len(log.topics) < 3:
        raise _validation_error(
            f"LZMultiCall OFTSent missing indexed topics: got {len(log.topics)} topics"
        )
    guid = log.topics[1]
    from_addr = _topic_address(log.topics[2], chain)
    if from_addr is None:
        raise _validation_error(
            f"LZMultiCall OFTSent fromAddress topic malformed: {log.topics[2]!r}"
        )
    expected_data_len = 2 + 2 * 64
    if len(log.data) < expected_data_len:
        raise _validation_error(
            f"LZMultiCall OFTSent data too short: {len(log.data)} < {expected_data_len}"
        )
    dst_eid = _read_uint256_word(log.data, 0)
    amount_sent_ld = _read_uint256_word(log.data, 1)
    return guid, from_addr, dst_eid, amount_sent_ld


def _find_action_transfer(
    logs: tuple[NormalizedLog, ...],
    *,
    asset: Address,
    expected_from: Address,
    expected_to: Address,
    minimum_amount: int,
    consumed_log_indices: frozenset[int] = frozenset(),
) -> NormalizedLog | None:
    """Un-consumed ERC-20 ``Transfer`` matching ``(asset, from, to)`` with
    a value ≥ ``minimum_amount`` (i.e., enough to fund the OFT send).

    Codex P2-002.0 R-2 + R-3 + R-6 findings (rounds 1, 2 + 5):

    * R-2 (round 1): in batched-recipient multicalls, multiple
      ``OFTSent`` events may share the same endpoint triple. Use
      ``consumed_log_indices`` to prevent double-counting.
    * R-3 (round 2): receipts may include unrelated funding transfers
      with the same endpoint triple; prefer value-matching logs.
    * R-6 (round 5): the user → wrapper funding Transfer carries the
      gross amount the wrapper pulls (including residual dust from
      shared-decimals rounding), while ``OFTSent.amountSentLD`` is the
      post-rounding net send amount. They are NOT equal in general —
      the funding amount is always **≥** ``amountSentLD`` (e.g. real
      cassette ``0xeba7`` shows ``12_573.795185625676946836`` funding
      vs. ``12_573.795185`` sent — diff ≈ 6.26e-7 rsETH residual).

    The match policy is therefore:

    1. Prefer an exact value-match (covers synthetic R-3 tests).
    2. Otherwise return the lowest-value Transfer whose value is
       ≥ ``minimum_amount`` (covers real-world residual-pull case).
    3. Skip any Transfer whose value is below ``minimum_amount`` (the
       wrapper cannot have sent more than it pulled).

    D-2: missing Transfer is permitted (returns ``None``).
    """
    chain = asset.chain
    candidate: NormalizedLog | None = None
    candidate_value: int | None = None
    for log in logs:
        if log.log_index in consumed_log_indices:
            continue
        if not log.topics or log.topics[0] != _ERC20_TRANSFER_TOPIC:
            continue
        if log.address != asset:
            continue
        if len(log.topics) < 3:
            continue
        log_from = _topic_address(log.topics[1], chain)
        log_to = _topic_address(log.topics[2], chain)
        if log_from != expected_from or log_to != expected_to:
            continue
        # Length guard before ``int("", 16)`` — a candidate Transfer with
        # ``data="0x"`` (or truncated, dropping high-order bytes) would
        # otherwise raise a raw ``ValueError`` or read a wrong-low value.
        # A structurally-corrupt Transfer is rejected with the decoder
        # contract's ValidationError (NOT silently skipped as a
        # well-formed under-funding Transfer would be below).
        expected_transfer_data_hex_len = 2 + 64
        if len(log.data) < expected_transfer_data_hex_len:
            raise _validation_error(
                f"LZMultiCall candidate Transfer log data too short: "
                f"{len(log.data)} < {expected_transfer_data_hex_len}"
            )
        log_value = _read_uint256_word(log.data, 0)
        if log_value < minimum_amount:
            # Pre-funding or under-funding transfer — cannot be the
            # send-side anchor for this OFTSent.
            continue
        if log_value == minimum_amount:
            # Exact match — preferred (handles synthetic R-2/R-3 cases).
            return log
        # Residual-pull candidate; prefer the smallest sufficient match.
        if candidate_value is None or log_value < candidate_value:
            candidate = log
            candidate_value = log_value
    return candidate


def _assert_send_coherence(
    *,
    transfer_log: NormalizedLog | None,
    amount_sent_ld: int,
) -> None:
    """R-1: when a Transfer log is paired with an OFTSent event, its
    value MUST be at least ``amountSentLD`` (the wrapper cannot send
    more than it pulled). The pairing helper already enforces
    ``value >= minimum_amount``, so this is a defence-in-depth check
    against future helper refactors.

    Missing Transfer (D-2) is permitted — silently returns.
    """
    if transfer_log is None:
        return
    # Length guard before ``int("", 16)`` so a malformed Transfer raises
    # ValidationError (decoder contract) not raw ValueError.
    expected_transfer_data_hex_len = 2 + 64
    if len(transfer_log.data) < expected_transfer_data_hex_len:
        raise _validation_error(
            f"LZMultiCall send-side Transfer log data too short: "
            f"{len(transfer_log.data)} < {expected_transfer_data_hex_len}"
        )
    log_value = _read_uint256_word(transfer_log.data, 0)
    if log_value < amount_sent_ld:  # pragma: no cover - defence-in-depth
        raise _validation_error(
            f"LZMultiCall send-side Transfer.value insufficient: "
            f"log_value={log_value} < amountSentLD={amount_sent_ld}"
        )


# Slice B / C — Decoder model.


class LzMultiCallDecoder(BaseModel):
    """Pydantic v2 :class:`BridgeDecoder` for the LZMultiCall wrapper around
    LayerZero V2 OFT batched-recipient dispatches (event-driven: ``OFTSent``
    events are the truth, and a single multicall TX may emit multiple
    ``OFTSent`` events → multiple actions)."""

    model_config = _FROZEN_CONFIG

    name: str = LZ_MULTICALL_DECODER_NAME
    # Bridge-wrapper decoders sit in 0-99 with P1-009 LayerZero V2 (10).
    # LZMultiCall is more selective (wrapper-whitelist + multicall selector
    # + OFTSent event) so we deliberately use a higher value within the
    # same band so LZ V2 fires first if both ever match (they shouldn't —
    # the wrapper's to_addr is distinct from the endpoint).
    priority: int = 15
    config: LzMultiCallDecoderConfig = Field(default_factory=LzMultiCallDecoderConfig)

    def matches(self, tx: NormalizedTransaction) -> bool:
        """Four-arm AND predicate (R-MULTICALL-WHITELIST-TRIPWIRE on arm 2)."""
        wrappers = self.config.multicall_addresses.get(tx.chain)
        if wrappers is None or not wrappers:
            return False
        if tx.to_addr is None or tx.to_addr not in wrappers:
            return False
        input_hex = tx.input
        if input_hex is None or len(input_hex) < 10:
            return False
        return input_hex[:10].lower() in _LZ_MULTICALL_SELECTORS

    def decode(
        self,
        tx: NormalizedTransaction,
        logs: tuple[NormalizedLog, ...],
    ) -> tuple[DefiAction, ...]:
        """Decode + cross-validate; emit one :class:`DefiAction` per OFTSent.

        Routine "no extractable data" (no OFTSent events, unknown
        token-adapter mapping) returns ``()`` (or skips the individual
        entry while continuing the batch). Structural corruption
        (missing topic, mismatched amount-vs-transfer, disallowed EID)
        raises :class:`pydantic.ValidationError`.
        """
        if not self.matches(tx):
            return ()
        assert tx.to_addr is not None  # proven by ``matches`` arm 2
        assert tx.from_addr is not None
        wrapper = tx.to_addr
        # Codex P2-002.0 R-5 (round 4): the user-identity for a bridge
        # send is ``tx.from_addr`` (the EOA submitter), NOT
        # ``OFTSent.fromAddress`` (which equals the wrapper because the
        # inner OFT.send is invoked by the wrapper as ``msg.sender``).
        # Using OFTSent.fromAddress as the actor would self-loop the
        # DefiAction (wrapper → wrapper) and break the user → wrapper
        # value-flow that ``_make_defi_edge`` renders for STAGE_3_A/B.
        user_eoa = tx.from_addr

        oft_sent_logs = _find_oft_sent_events(logs)
        if not oft_sent_logs:
            return ()

        actions: list[DefiAction] = []
        # Codex P2-002.0 R-2: track claimed Transfer log_indices so each
        # Transfer log can be consumed by at most one OFTSent event in
        # the same multicall transaction.
        consumed_transfer_log_indices: set[int] = set()
        for log in oft_sent_logs:
            guid, oft_from, dst_eid, amount_sent_ld = _parse_oft_sent_payload(log, chain=tx.chain)
            # R-EID-30110 cross-validation. Strict: any unexpected dst_eid
            # is a structural-anomaly signal worth raising for forensics.
            if dst_eid not in self.config.allowed_dst_eids:
                raise _validation_error(
                    f"LZMultiCall OFTSent dst_eid={dst_eid} not in "
                    f"allowed_dst_eids={sorted(self.config.allowed_dst_eids)} "
                    f"(R-EID-30110 cross-validation)"
                )
            if amount_sent_ld == 0:
                raise _validation_error(
                    "LZMultiCall amountSentLD=0 is impossible in well-formed OFTSent event"
                )

            adapter = log.address
            token = self.config.adapter_to_token.get(adapter)
            if token is None:
                # Adapter not registered → emit only if there is a default
                # mapping that aliases adapter == token (rare but supported
                # for tests that wire asset_decimals directly by adapter).
                token = adapter
            if token not in self.config.asset_decimals:
                # Unknown asset → skip this entry (continue the batch).
                continue
            decimals = self.config.asset_decimals[token]
            symbol = self.config.asset_symbols.get(token, _PLACEHOLDER_ASSET_SYMBOL)
            asset = Asset(
                chain=tx.chain,
                symbol=symbol,
                decimals=decimals,
                contract=token,
            )

            # R-1: cross-validate the send-side Transfer (user_eoa →
            # wrapper) against amountSentLD. D-2: missing Transfer is
            # OK.
            #
            # Codex P2-002.0 R-2 + R-3 + R-6: pair on
            # ``(asset, user_eoa, wrapper, value ≥ amountSentLD)`` to:
            # (R-2) avoid double-counting in batched multicalls,
            # (R-3) skip unrelated funding noise + handle reversed
            #       transfer/event ordering,
            # (R-6) accept the real-world case where the user→wrapper
            #       funding pull is slightly larger than amountSentLD
            #       (shared-decimals residual; cassette ``0xeba7``
            #       shows ≈6.26e-7 rsETH dust).
            consumed_snapshot = frozenset(consumed_transfer_log_indices)
            transfer_log = _find_action_transfer(
                logs,
                asset=token,
                expected_from=user_eoa,
                expected_to=wrapper,
                minimum_amount=amount_sent_ld,
                consumed_log_indices=consumed_snapshot,
            )
            _assert_send_coherence(
                transfer_log=transfer_log,
                amount_sent_ld=amount_sent_ld,
            )
            if transfer_log is not None:
                consumed_transfer_log_indices.add(transfer_log.log_index)

            # P3.2-004: ``amount_received_ld`` is intentionally ABSENT.
            # The configured rsETH adapter emits the 4-param OFTSent
            # variant (2 data words: dstEid + amountSentLD) — there is no
            # ``amountReceivedLD`` word on chain, so the decoder does not
            # synthesise one (cassette bytes > synthetic guess, P1-009).
            extras: dict[str, object] = {
                "kind_override": _KIND_OVERRIDE,
                "router": _ROUTER_TAG,
                "dst_eid": dst_eid,
                "guid": guid,
                "adapter": adapter.value,
                # Codex P2-002.0 R-5: ``OFTSent.fromAddress`` is the
                # wrapper's ``msg.sender`` view (i.e. the wrapper itself
                # in batched dispatches), preserved here for forensic
                # transparency but NOT used as the user-identity.
                "oft_from_address": oft_from.value,
            }
            dst_chain_label = _DST_EID_TO_CHAIN.get(dst_eid)
            if dst_chain_label is not None:
                extras["dst_chain"] = dst_chain_label

            # Codex P2-002.0 R-1 finding: a bridge SEND moves value FROM
            # the user EOA INTO the wrapper (the wrapper holds funds
            # until LayerZero delivery completes on the destination
            # chain). Under ``_make_defi_edge`` in tracer/_run.py:2555-86
            # the closed-vocab enum drives edge direction:
            #
            #   COLLATERAL_SUPPLY / REPAY     → actor → pool
            #   COLLATERAL_WITHDRAW / BORROW  → pool  → actor
            #
            # The on-chain ETH-side flow for a bridge dispatch is
            # ``user_eoa → wrapper`` (actor → pool), so
            # ``COLLATERAL_SUPPLY`` is the correct kind. Using
            # ``COLLATERAL_WITHDRAW`` would invert the edge and make
            # Stage 3-B render as a local DeFi withdrawal instead of a
            # bridge-to-Arbitrum outflow. The
            # ``extras["kind_override"] = "bridge_send"`` tag is
            # retained for downstream stage classification (Stage 3-B).
            #
            # Codex P2-002.0 R-5 round 4: actor MUST be the user EOA
            # (``tx.from_addr``) not ``OFTSent.fromAddress``, which is
            # the wrapper in batched dispatches (``msg.sender`` view).
            action = DefiAction(
                kind=DefiActionKind.COLLATERAL_SUPPLY,
                chain=tx.chain,
                protocol=LZ_MULTICALL_DECODER_NAME,
                asset=asset,
                amount=Amount(raw=amount_sent_ld, decimals=decimals),
                actor=user_eoa,
                pool=wrapper,
                extras=extras,
            )
            actions.append(action)
        return tuple(actions)


def register_lz_multicall_decoder(
    config: LzMultiCallDecoderConfig | None = None,
) -> LzMultiCallDecoder:
    """Construct and register the LZMultiCall decoder on the singleton registry."""
    decoder = LzMultiCallDecoder() if config is None else LzMultiCallDecoder(config=config)
    register_decoder(decoder)
    return decoder
