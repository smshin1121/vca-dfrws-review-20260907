"""BridgeDecoder Protocol + DefiAction DTO (P1-008).

The Protocol surface mirrors the architect's WBS §3.1; it is **synchronous**
(R-SYNC) — the Flow Tracer (P1-014) is async overall but the per-TX decode
step runs against already-fetched ``tx`` and ``logs`` (the adapter layer
already paid the I/O cost) so the decoder itself does not need to await.

DefiAction is the closed return type for protocol decoders (P1-011 Aave
V3 + future Compound / Euler extensions). The Stage classifier
(P1-015) treats a ``COLLATERAL_SUPPLY`` action as a "담보 전환" stage edge.
Cross-field validators enforce the same chain-coherence invariants as
:class:`vca.types.Balance` and :class:`vca.types.NormalizedTransfer`.

The ``extras`` recursive-freeze pipeline now lives in
:mod:`vca.types._extras_freeze` (lifted in P1-012 R-FREEZE-LIFT once
:class:`vca.decoders.abi_fallback.RecoveredAbi` became the third caller).
The thin wrappers below preserve P1-008's "DefiAction.extras"-prefixed
error messages while delegating the actual walking to the shared helper.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from enum import StrEnum
from typing import Annotated, Any, Final, Protocol, Self, runtime_checkable

from pydantic import BaseModel, BeforeValidator, Field, field_serializer, model_validator

from vca.types import (
    Address,
    Amount,
    Asset,
    CrossChainHop,
    NormalizedLog,
    NormalizedTransaction,
)
from vca.types._extras_freeze import (
    check_str_keys as _check_str_keys_shared,
)
from vca.types._extras_freeze import (
    freeze_extras_value as _freeze_extras_value_shared,
)
from vca.types._extras_freeze import (
    thaw_extras_value as _thaw_extras_value_shared,
)
from vca.types.normalized import _FROZEN_CONFIG, ChainIdField

__all__ = [
    "BridgeDecoder",
    "DefiAction",
    "DefiActionKind",
]


# ---------------------------------------------------------------------------
# BridgeDecoder Protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class BridgeDecoder(Protocol):
    """Bridge / DeFi protocol decoder — chain-agnostic plug-in surface.

    Concrete decoders (P1-009 LayerZero V2, P1-010 THORChain, P1-011 Aave V3,
    P1-012 ABI fallback) implement this Protocol; consumers (P1-014 Flow
    Tracer, P1-015 Stage classifier) depend ONLY on this surface.

    Methods are deliberately synchronous — see ARCHITECTURE.md §3.2 line
    124-128 and WBS §6 R-SYNC.
    """

    name: str
    """Stable identifier — used as registry key and persisted in
    :attr:`vca.types.DecodedCall.decoder`. Charset ``[a-z0-9_.-]+``,
    non-empty. Examples: ``"layerzero_v2"``, ``"thorchain.v1"``,
    ``"aave_v3"``, ``"abi_fallback"``."""

    priority: int
    """Lower runs first. Range ``[0, 1000]``. Phase-1 conventions:
    - ``0..99``    high-confidence specific decoders (LayerZero, THORChain)
    - ``100..499`` protocol decoders (Aave, Compound, Euler)
    - ``500..899`` reserved
    - ``900..999`` fallback decoders (ABI fallback = 999)"""

    def matches(self, tx: NormalizedTransaction) -> bool:
        """Cheap predicate — must NOT raise on ill-formed input, must NOT do I/O.

        Implementations gate on cheap signals: ``tx.to_addr``, function selector
        (``input[:10]``), or topic[0] of a known log. Heavy work belongs in
        :meth:`decode`. The registry calls this on every registered decoder for
        every TX the tracer visits, so per-call cost must be O(1) in tx size.
        """
        ...

    def decode(
        self,
        tx: NormalizedTransaction,
        logs: tuple[NormalizedLog, ...],
    ) -> tuple[CrossChainHop | DefiAction, ...]:
        """Return decoded hops / actions.

        Empty tuple ``()`` is legal — it means "matches but no extractable
        data on this particular TX". Implementations MAY raise
        :class:`pydantic.ValidationError` only when the TX shape itself is
        corrupt (bad hex, misaligned length); routine "doesn't match my
        pattern" cases must return ``()`` instead. The tracer treats raise
        vs. empty distinctly: empty is normal; raise is a bug.
        """
        ...


# ---------------------------------------------------------------------------
# DefiActionKind — closed vocabulary
# ---------------------------------------------------------------------------


class DefiActionKind(StrEnum):
    """Closed vocabulary for :attr:`DefiAction.kind`.

    Adding a member is a public-API change; the enum is the closed
    vocabulary for ``DefiAction.kind`` and downstream Stage classifier
    (P1-015) match arms.
    """

    COLLATERAL_SUPPLY = "collateral_supply"
    COLLATERAL_WITHDRAW = "collateral_withdraw"
    BORROW = "borrow"
    REPAY = "repay"


def _coerce_kind(value: Any) -> Any:
    """Strict-mode pre-coercion for :class:`DefiActionKind` fields.

    Strict Pydantic rejects ``str → StrEnum`` coercion, but the persistence
    boundary (``DecodedCall.params``) and JSON round-trip paths legitimately
    ship the enum as a string. Mirrors
    :func:`vca.types.normalized._coerce_chain_id`.
    """
    if isinstance(value, DefiActionKind):
        return value
    if isinstance(value, str):
        return DefiActionKind(value)  # raises ValueError on unknown str
    return value


DefiActionKindField = Annotated[DefiActionKind, BeforeValidator(_coerce_kind)]


# ---------------------------------------------------------------------------
# Recursive-freeze pipeline for ``DefiAction.extras``
#
# Lifted to :mod:`vca.types._extras_freeze` in P1-012 R-FREEZE-LIFT once
# :class:`vca.decoders.abi_fallback.RecoveredAbi` became the third caller.
# These thin wrappers preserve the historical "DefiAction.extras"-prefixed
# error messages while delegating the actual walking logic to the shared
# helpers — no behaviour change for P1-008 callers.
# ---------------------------------------------------------------------------


_PROTOCOL_RE = re.compile(r"[a-z0-9_]+")
_DEFI_ACTION_EXTRAS_LABEL: Final[str] = "DefiAction.extras"


def _check_str_keys(mapping: Mapping[Any, Any]) -> None:
    """Enforce ``str`` keys at every nesting level of ``DefiAction.extras``."""
    _check_str_keys_shared(mapping, label=_DEFI_ACTION_EXTRAS_LABEL)


def _freeze_extras_value(value: Any) -> Any:
    """Recursively freeze ``value`` into a JSON-friendly immutable form."""
    return _freeze_extras_value_shared(value, label=_DEFI_ACTION_EXTRAS_LABEL)


def _thaw_extras_value(value: Any) -> Any:
    """Inverse of :func:`_freeze_extras_value` for serialisation paths."""
    return _thaw_extras_value_shared(value)


# ---------------------------------------------------------------------------
# DefiAction DTO
# ---------------------------------------------------------------------------


class DefiAction(BaseModel):
    """DeFi protocol action: collateral / borrow / repay event.

    Emitted by :meth:`BridgeDecoder.decode` when the TX is an Aave-style
    money-market interaction. Cross-field validators enforce the same
    chain-coherence invariants as :class:`vca.types.Balance` and
    :class:`vca.types.NormalizedTransfer`.

    ``extras`` is a forward-looking slot for protocol-specific extras
    (e.g. Aave's ``interestRateMode``); it is recursively frozen the same
    way :attr:`vca.types.DecodedCall.params` is.
    """

    model_config = _FROZEN_CONFIG

    kind: DefiActionKindField
    chain: ChainIdField
    protocol: str
    asset: Asset
    amount: Amount
    actor: Address | None = None
    pool: Address | None = None
    extras: Mapping[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_chain_coherence(self) -> Self:
        """``asset.chain == self.chain``; ``actor.chain``/``pool.chain`` if set."""
        if self.asset.chain is not self.chain:
            raise ValueError(
                f"DefiAction.asset.chain mismatch: action.chain={self.chain.value}, "
                f"asset.chain={self.asset.chain.value}"
            )
        if self.actor is not None and self.actor.chain is not self.chain:
            raise ValueError(
                f"DefiAction.actor.chain mismatch: action.chain={self.chain.value}, "
                f"actor.chain={self.actor.chain.value}"
            )
        if self.pool is not None and self.pool.chain is not self.chain:
            raise ValueError(
                f"DefiAction.pool.chain mismatch: action.chain={self.chain.value}, "
                f"pool.chain={self.pool.chain.value}"
            )
        return self

    @model_validator(mode="after")
    def _decimals_match(self) -> Self:
        """``amount.decimals == asset.decimals`` (NormalizedTransfer pattern)."""
        if self.amount.decimals != self.asset.decimals:
            raise ValueError(
                f"DefiAction decimals mismatch for asset {self.asset.symbol!r}: "
                f"asset.decimals={self.asset.decimals}, "
                f"amount.decimals={self.amount.decimals}"
            )
        return self

    @model_validator(mode="after")
    def _validate_protocol_charset(self) -> Self:
        """``protocol`` must match ``[a-z0-9_]+`` and be non-empty.

        Stage classifier and persistence layer key on this value; uppercase /
        whitespace / dot / hyphen would break that join silently.
        """
        if not self.protocol or not _PROTOCOL_RE.fullmatch(self.protocol):
            raise ValueError(
                f"DefiAction.protocol must match [a-z0-9_]+ and be non-empty, "
                f"got: {self.protocol!r}"
            )
        return self

    @model_validator(mode="after")
    def _freeze_extras(self) -> Self:
        """Recursively freeze ``extras`` and reject non-JSON-friendly values.

        Pydantic v2 coerces ``Mapping`` annotations back to ``dict`` during
        validation, so we wrap *after* validation completes and bypass
        ``frozen=True`` via :func:`object.__setattr__` (the same hatch
        :class:`vca.types.DecodedCall` uses for ``params``).
        """
        frozen = _freeze_extras_value(dict(self.extras))
        object.__setattr__(self, "extras", frozen)
        return self

    @field_serializer("extras")
    def _serialize_extras(self, value: Mapping[str, Any]) -> dict[str, Any]:
        """Surface ``extras`` as plain ``dict``/``list`` on the wire.

        ``MappingProxyType`` and nested ``tuple`` are not the wire shape we
        want; downstream consumers (and ``stable_dump_json``) expect regular
        JSON objects/arrays.
        """
        thawed = _thaw_extras_value(value)
        if not isinstance(thawed, dict):  # pragma: no cover - structural guarantee
            raise TypeError("extras must serialise to a dict at the top level")
        return thawed
