"""Shared ABI ``bytes[]`` unwrap helper (P3.2-003c).

Consumed cross-module by :mod:`vca.decoders.aave_v3` (Aave V3
``multicall(bytes[])`` — selector ``0xac9650d8``) and reserved for the
Euler EVC ``batch`` path (P3.2-003b). Pure: no I/O, no clock, no env.

The module is private (leading-underscore filename) on purpose — it is
shared *infrastructure*, not a :class:`vca.decoders.BridgeDecoder`. The
per-decoder roster audits (``test_validation_error_helper_ssot_audit`` /
``test_decoder_tripwire_parity_audit``) glob ``src/vca/decoders/*.py`` and
exclude ``_*.py`` private modules, so this helper is correctly classified
as a non-decoder utility (same idiom as ``vca.adapters.btc._mempool`` /
``vca.persistence._graph_mappers``). It is therefore NOT re-exported from
``vca.decoders.__init__`` and does NOT appear in the package aggregator
roster.

``unwrap_calldata_array`` parses the ABI encoding of a dynamic ``bytes[]``
argument (the calldata body AFTER the outer multicall selector). The
layout, relative to the body start:

    [word 0]                     head offset to the array (canonically 0x20)
    [@head]                      array length N
    [@head + 0x20 + i*0x20]      per-item offset_i (RELATIVE to ``@head``)
    [@head + offset_i]           item_i length word + right-padded data

Strict validation: any malformed length, out-of-bounds offset, truncated
data, or non-32-byte-aligned body raises :class:`pydantic.ValidationError`
(the :class:`BridgeDecoder` fail-mode contract — a bare ``ValueError`` from
``int(...)`` / ``bytes.fromhex(...)`` would escape that contract and defeat
the registry's "decode raised the documented type" expectation).
"""

from __future__ import annotations

from typing import Final

from pydantic import BaseModel, ValidationError

from vca.types.normalized import _FROZEN_CONFIG

__all__ = ["unwrap_calldata_array"]

_WORD_BYTES: Final[int] = 32


def _validation_error(msg: str) -> ValidationError:
    """Wrap ``msg`` in :class:`pydantic.ValidationError` (decoder fail-mode
    contract surface — mirrors the per-decoder ``_validation_error`` helper).
    """

    class _GuardModel(BaseModel):
        model_config = _FROZEN_CONFIG
        marker: str

    try:
        _GuardModel(marker=msg, extra_field_that_does_not_exist=True)  # type: ignore[call-arg]
    except ValidationError as exc:
        return exc
    raise RuntimeError("validation guard failed to raise")  # pragma: no cover


def _body_bytes(input_hex: str) -> bytes:
    """Decode the ``0x``-prefixed, 32-byte-aligned calldata body to bytes."""
    if not isinstance(input_hex, str) or not input_hex.startswith("0x"):
        raise _validation_error(f"multicall body must be 0x-prefixed, got: {input_hex!r}")
    hex_body = input_hex[2:]
    if len(hex_body) % 2 != 0:
        raise _validation_error(f"multicall body has odd hex length: {len(hex_body)}")
    try:
        body = bytes.fromhex(hex_body)
    except ValueError as exc:
        raise _validation_error(f"multicall body is not valid hex: {exc}") from exc
    if len(body) < _WORD_BYTES:
        raise _validation_error(f"multicall body too short for head offset word: {len(body)} bytes")
    if len(body) % _WORD_BYTES != 0:
        raise _validation_error(f"multicall body not 32-byte aligned: {len(body)} bytes")
    return body


def _read_word(body: bytes, offset: int) -> int:
    """Read a 32-byte big-endian word at ``offset`` or raise on overrun."""
    end = offset + _WORD_BYTES
    if offset < 0 or end > len(body):
        raise _validation_error(
            f"multicall word read out of bounds: [{offset}:{end}] of {len(body)} bytes"
        )
    return int.from_bytes(body[offset:end], "big")


def _read_item(body: bytes, item_start: int) -> bytes:
    """Read one ``bytes`` item (length word + padded data) at ``item_start``."""
    length = _read_word(body, item_start)
    data_start = item_start + _WORD_BYTES
    data_end = data_start + length
    if data_end > len(body):
        raise _validation_error(
            f"multicall item data overruns calldata: need {data_end} bytes, have {len(body)}"
        )
    return body[data_start:data_end]


def unwrap_calldata_array(input_hex: str, *, max_items: int | None = None) -> list[bytes]:
    """Extract the inner calldata items from an ABI ``bytes[]`` body.

    *input_hex* is the calldata body AFTER the outer multicall selector
    (i.e. ``tx.input[10:]`` re-prefixed with ``0x``). Returns the inner
    calldata items in array order — each entry begins with its own 4-byte
    selector (callers slice ``item[:4]`` to dispatch).

    ``max_items`` (codex P3.2-003 R2 P3) is enforced against the array's
    LENGTH WORD before the offset table is validated or any item is
    materialized — a hostile length word must not be able to drive
    O(count) parsing work or allocation before the caller's cap check.
    ``None`` keeps the helper budget-free (caller enforces its own cap,
    or none).

    Raises:
        pydantic.ValidationError: malformed length, out-of-bounds offset,
            truncated data, non-aligned body, or a length word exceeding
            ``max_items``.
    """
    body = _body_bytes(input_hex)

    head_offset = _read_word(body, 0)
    if head_offset % _WORD_BYTES != 0:
        raise _validation_error(f"multicall array head offset not 32-aligned: {head_offset}")
    # Codex P3.2-003 R4 P3: for a single ``bytes[]`` argument the tuple
    # head is exactly one word, so a head offset below 32 points back
    # INTO the head — ``head_offset=0`` would read the head word itself
    # as the array length (a zero word then decodes as an empty batch,
    # silently swallowing malformed calldata instead of raising).
    if head_offset < _WORD_BYTES:
        raise _validation_error(
            f"multicall array head offset points into the tuple head: {head_offset} < {_WORD_BYTES}"
        )
    if head_offset + _WORD_BYTES > len(body):
        raise _validation_error(
            f"multicall array head offset out of bounds: {head_offset} of {len(body)} bytes"
        )

    count = _read_word(body, head_offset)
    if max_items is not None and count > max_items:
        raise _validation_error(f"multicall array claims {count} items; max_items is {max_items}")
    # The array's data area begins right after the length word; per-item
    # offsets are RELATIVE to this position (ABI dynamic-array semantics).
    data_area_start = head_offset + _WORD_BYTES
    # The per-item offset table sits at the front of the data area; reject a
    # length word that claims more items than the calldata can index.
    offset_table_end = data_area_start + count * _WORD_BYTES
    if offset_table_end > len(body):
        raise _validation_error(
            f"multicall offset table overruns calldata: {count} items need "
            f"{offset_table_end} bytes, have {len(body)}"
        )

    items: list[bytes] = []
    for index in range(count):
        rel_offset = _read_word(body, data_area_start + index * _WORD_BYTES)
        # Codex P3.2-003 R3 P2: standard ABI decoding rejects invalid
        # pointers — a rel_offset that is non-canonical (not 32-aligned)
        # or that points BACK into the offset table (e.g. rel_offset=0
        # with count=1 would read the offset word itself as the item
        # length and silently yield ``b''``) must raise the structural
        # ValidationError, not produce a phantom empty item the caller
        # silently skips.
        if rel_offset % _WORD_BYTES != 0:
            raise _validation_error(f"multicall item[{index}] offset not 32-aligned: {rel_offset}")
        if rel_offset < count * _WORD_BYTES:
            raise _validation_error(
                f"multicall item[{index}] offset points into the offset table: "
                f"{rel_offset} < {count * _WORD_BYTES}"
            )
        item_start = data_area_start + rel_offset
        if item_start + _WORD_BYTES > len(body):
            raise _validation_error(
                f"multicall item[{index}] offset out of bounds: {item_start} of {len(body)} bytes"
            )
        items.append(_read_item(body, item_start))
    return items
