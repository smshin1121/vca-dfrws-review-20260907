"""ABI source enum, candidate / recovered DTOs, and pure decode helper (P1-012).

Holds every type the resolver and the three tier clients share so each tier
client only depends on this single module (plus :mod:`._errors`).

The ``decode_calldata_with_abi`` helper is the single decode entry-point.
It accepts either a 4byte text signature ("transfer(address,uint256)") or
a JSON ABI list (Sourcify/Etherscan), looks up the function entry whose
selector matches the calldata, and returns a frozen
:class:`vca.types.DecodedCall` whose ``params`` are recursively frozen by
the same pipeline :class:`vca.types.DecodedCall.params` already uses.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from enum import StrEnum
from typing import Any, Final, Self

from eth_abi import encode as _eth_abi_encode  # type: ignore[attr-defined]
from eth_abi.codec import ABICodec
from eth_abi.exceptions import DecodingError as EthAbiDecodingError
from eth_abi.registry import registry as default_eth_abi_registry
from pydantic import BaseModel, Field, field_serializer, model_validator

from vca.decoders.abi_fallback._encoding import (
    canonical_abi_type as _canonical_abi_type,
)
from vca.decoders.abi_fallback._encoding import (
    canonical_signature_from_abi_entry as _canonical_signature_from_abi_entry,
)
from vca.decoders.abi_fallback._encoding import (
    normalise_decoded as _normalise_decoded,
)
from vca.decoders.abi_fallback._encoding import (
    parse_text_signature,
)
from vca.decoders.abi_fallback._encoding import (
    selector_from_abi_entry as _selector_from_abi_entry,
)
from vca.decoders.abi_fallback._encoding import (
    selector_from_text_sig as _selector_from_text_sig,
)
from vca.decoders.abi_fallback._errors import AbiFallbackError
from vca.types import DecodedCall
from vca.types._extras_freeze import freeze_extras_value, thaw_extras_value
from vca.types.normalized import _FROZEN_CONFIG

# A shared codec — :class:`eth_abi.codec.ABICodec` is thread-safe for
# read-only access. Building one per call is wasteful; building a module-
# level singleton is fine.
_CODEC = ABICodec(default_eth_abi_registry)


class AbiSource(StrEnum):
    """Closed vocabulary for the ABI recovery tier that produced a hit.

    Adding a member is a public-API change: the value is concatenated into
    :attr:`vca.types.DecodedCall.decoder` as ``"abi_fallback.{value}"`` and
    persisted by the labeler/persistence layer.
    """

    FOURBYTE = "4byte"
    SOURCIFY = "sourcify"
    ETHERSCAN_ABI = "etherscan_abi"


# Codex round-1 P2-4: every ``extras``-bearing DTO in this module routes
# its mapping through the shared :mod:`vca.types._extras_freeze` pipeline,
# the same recursive-freeze contract :class:`vca.types.DecodedCall.params`
# and :class:`vca.decoders.base.DefiAction.extras` already use. Without
# this, ``extras`` is a mutable ``dict`` that accepts unsupported leaves
# (raw ``bytes``, non-finite floats, arbitrary user instances) and would
# eventually crash :meth:`pydantic.BaseModel.model_dump_json` mid-export.
_ABI_CANDIDATE_EXTRAS_LABEL: Final[str] = "AbiCandidate.extras"
_RECOVERED_ABI_EXTRAS_LABEL: Final[str] = "RecoveredAbi.extras"


class AbiCandidate(BaseModel):
    """Pre-decode candidate emitted by a single tier (4byte / Sourcify / Etherscan).

    Tier orchestration in ``resolver.py`` converts the FIRST candidate that
    decodes successfully into a :class:`RecoveredAbi` (and a
    :class:`vca.types.DecodedCall`). Tier helpers emit one or more
    candidates; ranking is performed by ``rank_candidates`` before decode
    attempts.

    ``extras`` is recursively frozen by the same shared pipeline
    :class:`RecoveredAbi.extras` uses (Codex round-1 P2-4). Bytes leaves,
    non-finite floats, and arbitrary user instances are rejected at
    validation time so the DTO is always JSON-round-trippable.
    """

    model_config = _FROZEN_CONFIG

    source: AbiSource
    selector: str  # 0x + 8 lowercase hex
    signature_or_abi: str  # text sig (4byte) OR JSON-encoded ABI list
    address: str | None = None  # lowercase address, required for sourcify/etherscan
    text_signature: str | None = None
    extras: Mapping[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _freeze_extras(self) -> Self:
        """Recursively freeze ``extras`` and reject non-JSON-friendly values."""
        frozen = freeze_extras_value(dict(self.extras), label=_ABI_CANDIDATE_EXTRAS_LABEL)
        object.__setattr__(self, "extras", frozen)
        return self

    @field_serializer("extras")
    def _serialize_extras(self, value: Mapping[str, Any]) -> dict[str, Any]:
        thawed = thaw_extras_value(value)
        if not isinstance(thawed, dict):  # pragma: no cover - structural guarantee
            raise TypeError("AbiCandidate.extras must serialise to a dict at the top level")
        return thawed


class RecoveredAbi(BaseModel):
    """Successfully decoded ABI metadata for one selector / contract pair.

    Confidence semantics:
    * 4byte (any candidate that decoded) → 0.5
    * Sourcify / Etherscan ABI → 1.0

    ``extras`` is recursively frozen by the same shared pipeline
    :class:`vca.types.DecodedCall.params` uses (Codex round-1 P2-4). Bytes
    leaves and non-finite floats are rejected at validation time so the
    exported DTO is always JSON-round-trippable via
    :meth:`pydantic.BaseModel.model_dump_json` /
    :meth:`pydantic.BaseModel.model_validate_json`.
    """

    model_config = _FROZEN_CONFIG

    source: AbiSource
    selector: str
    function_signature: str  # canonical text sig: "transfer(address,uint256)"
    confidence: float = Field(ge=0.0, le=1.0)
    address_keyed: bool
    extras: Mapping[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _freeze_extras(self) -> Self:
        """Recursively freeze ``extras`` and reject non-JSON-friendly values."""
        frozen = freeze_extras_value(dict(self.extras), label=_RECOVERED_ABI_EXTRAS_LABEL)
        object.__setattr__(self, "extras", frozen)
        return self

    @field_serializer("extras")
    def _serialize_extras(self, value: Mapping[str, Any]) -> dict[str, Any]:
        thawed = thaw_extras_value(value)
        if not isinstance(thawed, dict):  # pragma: no cover - structural guarantee
            raise TypeError("RecoveredAbi.extras must serialise to a dict at the top level")
        return thawed


# ---------------------------------------------------------------------------
# Multi-candidate ranking (Appendix A.2 — in-tier ranking only)
# ---------------------------------------------------------------------------


def rank_candidates(candidates: tuple[AbiCandidate, ...]) -> tuple[AbiCandidate, ...]:
    """Sort tier candidates into attempt order. Pure function.

    For 4byte we rank by ascending ``extras["fourbyte_id"]`` (older entries
    correlate with the canonical, widely-used signature); ties break on
    ``text_signature`` lexicographic order so the result is deterministic
    for golden tests. For Sourcify / Etherscan there is at most one
    candidate, so ranking is trivial.
    """
    if not candidates:
        return ()

    def _key(candidate: AbiCandidate) -> tuple[int, str]:
        fourbyte_id_raw = candidate.extras.get("fourbyte_id", 10**18)
        try:
            fourbyte_id = int(fourbyte_id_raw)
        except (TypeError, ValueError):
            fourbyte_id = 10**18
        return fourbyte_id, candidate.text_signature or ""

    return tuple(sorted(candidates, key=_key))


# ---------------------------------------------------------------------------
# Core decode helper
# ---------------------------------------------------------------------------


def decode_calldata_with_abi(
    input_hex: str,
    abi: str | list[dict[str, Any]],
    *,
    source: AbiSource,
) -> DecodedCall:
    """Decode *input_hex* against *abi*, returning a :class:`DecodedCall`.

    *abi* may be one of:

    * A 4byte text signature, e.g. ``"transfer(address,uint256)"``.
    * A JSON-encoded ABI list (str) — Sourcify / Etherscan ABI tier shape.
    * An already-parsed ABI list (mostly for tests).

    The function locates the function entry whose 4-byte selector matches
    ``input_hex[:10]``, decodes the argument tail with ``eth_abi``, and
    returns a frozen :class:`DecodedCall` with ``decoder`` set to
    ``"abi_fallback.{source.value}"``.

    Raises:
        AbiFallbackError: malformed hex, selector not in the ABI, or
            ``eth_abi`` decode failure. Caller (``resolver.py``) catches
            this base class and tries the next candidate / next tier.
    """
    selector = _validate_selector(input_hex, source=source)
    args_hex = input_hex[10:]
    if isinstance(abi, str):
        abi_str = abi.strip()
        if abi_str.startswith(("[", "{")):
            abi_list = _parse_abi_json(abi_str, selector=selector, source=source)
            return _decode_via_abi_list(
                abi_list=abi_list,
                args_hex=args_hex,
                selector=selector,
                source=source,
            )
        # Otherwise it's a 4byte text signature.
        return _decode_via_text_sig(
            text_sig=abi_str,
            args_hex=args_hex,
            selector=selector,
            source=source,
        )
    # Already-parsed list path. Widen to ``list[Any]`` so the runtime
    # ``isinstance(..., Mapping)`` guard inside :func:`_decode_via_abi_list`
    # stays meaningful for hostile inputs.
    abi_list_any: list[Any] = list(abi)
    return _decode_via_abi_list(
        abi_list=abi_list_any,
        args_hex=args_hex,
        selector=selector,
        source=source,
    )


def _validate_selector(input_hex: str, *, source: AbiSource) -> str:
    """Pull the 4-byte selector from ``input_hex`` or raise ``AbiFallbackError``."""
    if not isinstance(input_hex, str) or not input_hex.startswith("0x") or len(input_hex) < 10:
        raise AbiFallbackError(
            f"input_hex must be 0x-prefixed and at least 10 chars, got: {input_hex!r}",
            tier=source,
            selector="0x" if not isinstance(input_hex, str) else input_hex[:10],
        )
    selector = input_hex[:10].lower()
    if not all(c in "0123456789abcdef" for c in selector[2:]):
        raise AbiFallbackError(
            f"selector must be 0x + 8 hex digits, got: {selector!r}",
            tier=source,
            selector=selector,
        )
    if (len(input_hex) - 10) % 2 != 0:
        raise AbiFallbackError(
            f"input_hex args section must be even-length, got odd-length: {input_hex!r}",
            tier=source,
            selector=selector,
        )
    return selector


def _parse_abi_json(abi_str: str, *, selector: str, source: AbiSource) -> list[Any]:
    """Decode ``abi_str`` as a JSON ABI list or raise ``AbiFallbackError``.

    Returns ``list[Any]`` (not ``list[dict[str, Any]]``) so the downstream
    ``_decode_via_abi_list`` keeps its defensive ``isinstance(..., Mapping)``
    guard live — a real upstream ABI may carry the occasional non-dict
    entry (schema variants), and we want to skip rather than crash.
    """
    try:
        decoded: Any = json.loads(abi_str)
    except json.JSONDecodeError as exc:
        raise AbiFallbackError(
            f"ABI JSON parse failed for selector={selector}: {exc.msg}",
            tier=source,
            selector=selector,
        ) from exc
    if not isinstance(decoded, list):
        raise AbiFallbackError(
            f"ABI must be a JSON list, got {type(decoded).__name__}",
            tier=source,
            selector=selector,
        )
    decoded_list: list[Any] = decoded
    return decoded_list


def _decode_via_text_sig(
    *,
    text_sig: str,
    args_hex: str,
    selector: str,
    source: AbiSource,
) -> DecodedCall:
    try:
        name, types = parse_text_signature(text_sig)
    except ValueError as exc:
        raise AbiFallbackError(
            f"could not parse 4byte text signature {text_sig!r}: {exc}",
            tier=source,
            selector=selector,
        ) from exc
    # Iteration-69: ``_selector_from_text_sig`` runs ``keccak(text=text_sig)``,
    # which UTF-8-encodes the string — a lone-surrogate signature (reachable from
    # a hostile/corrupt 4byte ``text_signature`` via ``json.loads('"\\ud800"')``)
    # raises ``UnicodeEncodeError`` (a ``ValueError`` subclass) that, unwrapped,
    # escaped the documented ``AbiFallbackError`` contract and defeated the
    # resolver's "try next candidate" loop. Mirror the parse guard above (and the
    # sibling ABI-list path at ``_decode_via_abi_list``, which already catches
    # ``ValueError``) by mapping it to ``AbiFallbackError``.
    try:
        derived = _selector_from_text_sig(text_sig)
    except ValueError as exc:
        raise AbiFallbackError(
            f"could not compute selector for 4byte text signature {text_sig!r}: {exc}",
            tier=source,
            selector=selector,
        ) from exc
    if derived != selector:
        raise AbiFallbackError(
            f"selector mismatch: text_sig {text_sig!r} does not match calldata selector {selector}",
            tier=source,
            selector=selector,
        )
    decoded_values = _decode_args(types, args_hex, selector=selector, source=source)
    params = _params_from_positional(types=types, names=(), values=decoded_values)
    return _build_decoded_call(
        decoder=f"abi_fallback.{source.value}",
        function_name=name,
        params=params,
    )


def _decode_via_abi_list(
    *,
    abi_list: list[Any],
    args_hex: str,
    selector: str,
    source: AbiSource,
) -> DecodedCall:
    matched: Mapping[str, Any] | None = None
    for entry in abi_list:
        # Defensive: a ``json.loads`` of a real Sourcify/Etherscan ABI may
        # contain non-dict members (e.g. ``null`` from a future schema
        # variant); skip them rather than crashing the whole decode.
        if not isinstance(entry, Mapping):
            continue
        try:
            entry_selector = _selector_from_abi_entry(entry)
        except (AttributeError, TypeError, ValueError, KeyError):
            # Codex round-1 P2-3: malformed ``inputs`` (e.g. ``[null]``)
            # would surface as ``AttributeError`` inside the helper. Treat
            # any structural failure as "skip this entry, try the next" so
            # one corrupt entry cannot crash :meth:`AbiFallbackResolver.resolve`.
            continue
        if entry_selector == selector:
            matched = entry
            break
    if matched is None:
        raise AbiFallbackError(
            f"no function entry in ABI matches selector {selector}",
            tier=source,
            selector=selector,
        )
    raw_inputs = matched.get("inputs") or ()
    if not isinstance(raw_inputs, (list, tuple)):
        raise AbiFallbackError(
            f"ABI entry for selector {selector} has non-list inputs",
            tier=source,
            selector=selector,
        )
    # Re-defend at the per-entry level: by construction the matched entry
    # passed ``_selector_from_abi_entry`` so every ``inputs`` member is a
    # ``Mapping``. Cast for mypy friendliness; fall through if the contract
    # were ever loosened upstream.
    inputs: tuple[Mapping[str, Any], ...] = tuple(i for i in raw_inputs if isinstance(i, Mapping))
    if len(inputs) != len(raw_inputs):
        raise AbiFallbackError(
            f"ABI entry for selector {selector} has malformed input entries",
            tier=source,
            selector=selector,
        )
    types = tuple(_canonical_abi_type(i) for i in inputs)
    names = tuple(str(i.get("name") or "") for i in inputs)
    decoded_values = _decode_args(types, args_hex, selector=selector, source=source)
    params = _params_from_positional(types=types, names=names, values=decoded_values)
    return _build_decoded_call(
        decoder=f"abi_fallback.{source.value}",
        function_name=str(matched.get("name") or ""),
        params=params,
    )


def _decode_args(
    types: tuple[str, ...],
    args_hex: str,
    *,
    selector: str,
    source: AbiSource,
) -> tuple[Any, ...]:
    """Decode ``args_hex`` against ``types`` and reject any trailing calldata.

    Codex round-2 P2-1: ``eth_abi.codec.ABICodec.decode`` does NOT require
    that the input byte stream be fully consumed. When 4byte returns a
    colliding signature with FEWER args than the actual calldata carries
    (for instance ``name()`` for a selector whose calldata has 64 bytes of
    payload), :func:`ABICodec.decode` happily decodes the prefix and
    silently ignores the rest. The resolver would then accept the bogus
    candidate and stop walking the fallback chain. Roundtrip-encode the
    decoded values and compare lengths so any leftover bytes surface as a
    typed :class:`AbiFallbackError` (caught by the resolver as "candidate
    doesn't fit, try the next one").

    For the empty-types case we additionally require ``args_hex == ""``;
    a zero-arg signature is only a fit when the calldata carries no
    payload after the selector.
    """
    if not types:
        if args_hex != "":
            raise AbiFallbackError(
                f"calldata for selector {selector} carries trailing bytes after a "
                f"zero-arg signature; expected empty args, got {len(args_hex) // 2} bytes",
                tier=source,
                selector=selector,
            )
        return ()
    try:
        args_bytes = bytes.fromhex(args_hex)
    except ValueError as exc:
        raise AbiFallbackError(
            f"eth_abi decode failed for selector {selector}: malformed hex args ({exc})",
            tier=source,
            selector=selector,
        ) from exc
    try:
        decoded = _CODEC.decode(types, args_bytes)
    except (EthAbiDecodingError, ValueError, OverflowError) as exc:
        raise AbiFallbackError(
            f"eth_abi decode failed for selector {selector}: {exc}",
            tier=source,
            selector=selector,
        ) from exc
    decoded_tuple = tuple(decoded)
    # Reject candidates that decode a *prefix* of ``args_bytes`` and leave
    # trailing data behind. A canonical ABI encoding round-trips byte-for-
    # byte; any length delta signals that ``types`` is the wrong shape for
    # this calldata.
    try:
        re_encoded = _eth_abi_encode(list(types), list(decoded_tuple))
    except (TypeError, ValueError, OverflowError) as exc:
        raise AbiFallbackError(
            f"eth_abi roundtrip failed for selector {selector}: {exc}",
            tier=source,
            selector=selector,
        ) from exc
    if len(re_encoded) != len(args_bytes):
        raise AbiFallbackError(
            f"calldata for selector {selector} has trailing bytes after decoding "
            f"as {types!r}: consumed {len(re_encoded)} of {len(args_bytes)}",
            tier=source,
            selector=selector,
        )
    return decoded_tuple


# Codex round-5 P2-2: synthetic key prefix used when an unnamed positional
# arg's natural ``arg{i}`` form would collide with a real ABI input name
# elsewhere in the same signature. The double-underscore + ``unnamed``
# form is not a valid Solidity identifier under any reasonable convention,
# and the helper still bumps a suffix on the vanishingly unlikely case
# that a real input legitimately uses the synthetic name.
_UNNAMED_PREFIX = "__unnamed_"


def _params_from_positional(
    *,
    types: tuple[str, ...],
    names: tuple[str, ...],
    values: tuple[Any, ...],
) -> Mapping[str, Any]:
    """Build the ``params`` dict for :class:`DecodedCall`.

    Empty / missing argument names are filled with ``arg{i}`` so the resulting
    dict has unique keys and remains deterministic.

    Codex round-4 P2-1: previously this helper also shadowed each argument
    with an ``f"{key}_type"`` entry carrying the ABI type hint. That broke
    when an ABI legitimately named an input ``amount_type`` (or any
    ``<key>_type`` collision with a real preceding argument), or when an
    unnamed positional arg at index ``0`` shared the synthetic ``arg0`` key
    with a real argument named ``arg0``: the synthetic shadow overwrote
    a real decoded value (or vice versa). The shadow keys had no
    downstream consumer in the P1-001 / P1-014 / P1-016 surface, so they
    are dropped from ``params`` entirely. If a future call site needs the
    ABI types alongside the values, surface them via a separate field on
    :class:`DecodedCall` rather than polluting the ``params`` namespace.

    Codex round-5 P2-1: ``_normalise_decoded`` is now type-aware. Each
    value is normalised against the matching ABI type from ``types`` so
    that, for example, a Solidity ``string`` input whose decoded value
    happens to match the address shape (``0x`` + 40 hex) is preserved
    verbatim instead of being lowercased.

    Codex round-5 P2-2: the previous synthesis of ``arg{i}`` for an
    unnamed positional silently overwrote a real ABI input named
    ``arg{i}`` further down the signature (e.g. ``f(uint256, uint256
    arg0)``). The helper now does a two-pass scan: first collect every
    real (non-empty) name, then synthesise unique fallback keys for the
    unnamed slots that cannot collide with any real name. Real-name
    duplicates (rare but legal in hand-written ABIs) are similarly
    suffixed so every decoded value reaches the output dict.
    """
    real_names: set[str] = {n for n in names if n}
    used: set[str] = set()
    out: dict[str, Any] = {}
    for idx, val in enumerate(values):
        name = names[idx] if idx < len(names) else ""
        type_str = types[idx] if idx < len(types) else None
        if name:
            key = _ensure_unique(name, used=used)
        else:
            key = _synthesise_unnamed_key(idx=idx, real_names=real_names, used=used)
        used.add(key)
        out[key] = _normalise_decoded(val, type_str)
    return out


def _ensure_unique(name: str, *, used: set[str]) -> str:
    """Return ``name`` if unused, otherwise ``name`` with the smallest unique
    ``_pos{i}`` suffix.

    Hand-written ABIs occasionally repeat an input name (legal but
    unusual); without a suffix the second occurrence would silently
    overwrite the first in :class:`DecodedCall.params`. The suffix is
    chosen to be human-readable and to play nicely with the round-4 P2-1
    drop of synthetic ``<key>_type`` shadows (no ``_type`` suffix is
    introduced here).
    """
    if name not in used:
        return name
    counter = 1
    while True:
        candidate = f"{name}_pos{counter}"
        if candidate not in used:
            return candidate
        counter += 1


def _synthesise_unnamed_key(*, idx: int, real_names: set[str], used: set[str]) -> str:
    """Return the synthetic key for an unnamed positional arg at index *idx*.

    Tries ``arg{idx}`` first (preserves the historical contract for the
    common all-unnamed case). If that form would collide with a real ABI
    input name elsewhere in the same signature, falls back to
    ``__unnamed_{idx}``; if even that synthetic happens to collide it
    bumps a numeric suffix until uniqueness holds.
    """
    natural = f"arg{idx}"
    if natural not in real_names and natural not in used:
        return natural
    base = f"{_UNNAMED_PREFIX}{idx}"
    if base not in real_names and base not in used:
        return base
    counter = 1
    while True:
        candidate = f"{base}_{counter}"
        if candidate not in real_names and candidate not in used:
            return candidate
        counter += 1


def _build_decoded_call(
    *,
    decoder: str,
    function_name: str,
    params: Mapping[str, Any],
) -> DecodedCall:
    """Construct a :class:`DecodedCall` after pre-validating the params payload.

    The ``DecodedCall`` model recursively freezes ``params`` itself; we run
    a pre-flight ``freeze_extras_value`` pass here too so any leaf type
    that ``DecodedCall`` would reject surfaces as a typed
    :class:`AbiFallbackError` rather than a Pydantic ``ValidationError``.
    """
    # Pre-flight freeze raises ``ValueError`` on bad leaves; we want the
    # AbiFallbackError shape so callers can catch the base class.
    try:
        freeze_extras_value(dict(params), label="abi_fallback.decode.params")
    except ValueError as exc:
        raise AbiFallbackError(
            f"decoded params contain unsupported leaf: {exc}",
            tier=AbiSource(decoder.removeprefix("abi_fallback.")),
            selector="",
        ) from exc
    return DecodedCall(decoder=decoder, function_name=function_name, params=dict(params))


def canonical_signature_for_candidate(
    candidate: AbiCandidate,
    *,
    selector: str,
) -> str | None:
    """Return the canonical ``"name(t1,...)"`` signature carried by *candidate*.

    Codex round-2 P3-1: the Sourcify / Etherscan tier helpers emit a
    candidate whose ``signature_or_abi`` is a full JSON ABI list and whose
    ``text_signature`` is ``None``. The resolver builds
    :class:`RecoveredAbi` *after* a successful decode and needs the
    canonical signature for the matched function (e.g.
    ``"transfer(address,uint256)"``) so the recovered DTO advertises the
    contract-verified shape rather than just the function name.

    For 4byte candidates the function returns ``candidate.text_signature``
    verbatim — that field is already populated by :func:`lookup_fourbyte`.

    Returns ``None`` if no entry in the ABI matches *selector*; the caller
    falls back to ``candidate.text_signature`` or the decoded function
    name.
    """
    if candidate.text_signature is not None:
        return candidate.text_signature
    payload = candidate.signature_or_abi.strip()
    if not payload.startswith(("[", "{")):
        # Free-form text signature fell through to ``signature_or_abi``;
        # surface it as-is so callers don't need to special-case the shape.
        return payload or None
    try:
        decoded: Any = json.loads(payload)
    except json.JSONDecodeError:
        return None
    if not isinstance(decoded, list):
        return None
    for entry in decoded:
        if not isinstance(entry, Mapping):
            continue
        try:
            entry_selector = _selector_from_abi_entry(entry)
        except (AttributeError, TypeError, ValueError, KeyError):
            continue
        if entry_selector == selector:
            return _canonical_signature_from_abi_entry(entry)
    return None


__all__ = [
    "AbiCandidate",
    "AbiSource",
    "RecoveredAbi",
    "canonical_signature_for_candidate",
    "decode_calldata_with_abi",
    "parse_text_signature",
    "rank_candidates",
]
