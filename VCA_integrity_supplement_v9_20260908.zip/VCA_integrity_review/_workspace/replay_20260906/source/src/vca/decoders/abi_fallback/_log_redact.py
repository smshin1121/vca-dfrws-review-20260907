"""Log-field scrubbing for the ABI-fallback resolver (scan #10 / PII-1).

The three NETWORK-tier warning sinks in
:mod:`vca.decoders.abi_fallback.resolver` interpolate ``str(exc)`` for a
caught :class:`~vca.decoders.abi_fallback._errors.AbiFallbackError`. Every
OTHER error sink in the codebase composes secret redaction + control-char /
length sanitisation before an exception string reaches a log record
(``vca.tracer._run._redact_secrets``,
``vca.api.routes.cases._sanitise_log_field(redact_secrets(...))``,
``vca.web._log_sanitise.sanitise_log_field``). This module gives the decoders
package the same composition so those three sinks honour the project-wide
"redact at every error sink" invariant.

Secret redaction reuses the CANONICAL ``redact_secrets`` via the
``vca.cases.runner`` re-export shim -- the same public entry point
``vca.web.routes.auth`` imports -- rather than cloning the apikey / bearer
regexes, so the secret-redaction SSOT keeps its 3-module roster
(``tests/unit/security/test_secret_redaction_ssot_audit.py``). The import is
FUNCTION-LOCAL because ``vca.cases.runner`` transitively imports the tracer
(which imports this package), so a module-level import would form a cycle; the
scrubber only runs on the error path, so the late import is free (mirrors the
``create_app`` / ``mount_web`` function-local import convention).

``sanitise_log_field`` (control-char strip + length cap) has no shim, so it is
a byte-equal CLONE of ``vca.web._log_sanitise.sanitise_log_field`` with a
parity test -- the same convention that module used to clone the api sanitiser.
"""

from __future__ import annotations

from typing import Final

# Mirrors ``vca.web._log_sanitise._MAX_LOG_FIELD_LEN`` -- pinned equal by the
# parity test.
_MAX_LOG_FIELD_LEN: Final[int] = 1000


def _strip_non_printable(message: str) -> str:
    """Drop control chars (newline, NUL, CR, tab, ...) but keep Unicode."""
    return "".join(ch for ch in message if ch.isprintable())


def sanitise_log_field(message: str) -> str:
    """Strip non-printable chars and cap length for a structured-log field.

    Byte-equal clone of ``vca.web._log_sanitise.sanitise_log_field``.
    """
    cleaned = _strip_non_printable(message)
    if len(cleaned) <= _MAX_LOG_FIELD_LEN:
        return cleaned
    return cleaned[:_MAX_LOG_FIELD_LEN]


def scrub_exc_for_log(exc: object) -> str:
    """Compose secret redaction + sanitisation over ``str(exc)`` for a log field.

    Redacts apikeys / bearer tokens (CWE-532: sensitive info in a log file) via
    the canonical ``redact_secrets``, then strips control chars + caps length
    (CWE-117 log-injection / log flooding on an unbounded remote error string).
    Applied at every ABI-fallback network-tier warning sink so ``err=%s`` cannot
    carry a raw secret, an attacker-supplied newline, or an unbounded explorer
    body.
    """
    # Function-local import breaks the module-load cycle (see module docstring).
    from vca.cases.runner import redact_secrets

    return sanitise_log_field(redact_secrets(str(exc)))


__all__ = ["sanitise_log_field", "scrub_exc_for_log"]
