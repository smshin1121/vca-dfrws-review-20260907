"""Sourcify tier client (P1-012).

Address-keyed verified-contract metadata. Public API, no key. Returns the
contract's full ABI on hit; the decoder selects the function entry by
selector at decode time.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any, Final

import httpx

from vca.decoders.abi_fallback._errors import SourcifyError
from vca.decoders.abi_fallback.decode import AbiCandidate, AbiSource

_SOURCIFY_DEFAULT_BASE_URL: Final[str] = "https://sourcify.dev/server"


def is_sourcify_ok(payload: Any) -> bool:
    """Cache-write gate: only approve bodies that yield a usable ABI.

    Codex round-3 P2: previously this predicate accepted any list whose
    entries had a non-empty ``content`` string, which let Sourcify bodies
    that genuinely lacked ``metadata.json`` (or whose ``metadata.json``
    held bogus JSON, or had no ``output.abi`` list) sail past the cache
    gate. With ``ttl=None`` the poisoned body would replay forever from
    cache, masking upstream recovery and forcing every subsequent
    ``lookup_sourcify`` to raise from the cached entry.

    The predicate now mirrors :func:`_extract_abi_from_files`'s success
    contract: payload must be a non-empty list, contain a
    ``metadata.json`` whose ``content`` parses as a JSON object, and that
    object must have ``output.abi`` resolving to a list. If any check
    fails the predicate returns ``False`` and ``HttpClient`` skips the
    cache write (and ``cache.delete`` evicts a poisoned hit on read —
    same pattern as the Etherscan tier's round-1 P2-2).
    """
    if not isinstance(payload, list):
        return False
    if not payload:
        return False
    return _try_extract_abi_from_files(payload) is not None


async def lookup_sourcify(
    http_client: Any,
    *,
    address: str,
    chain_id: int,
    base_url: str = _SOURCIFY_DEFAULT_BASE_URL,
    ttl: int | None,
    rate_limit_source: str,
    raw_store: Any | None = None,
) -> tuple[AbiCandidate, ...]:
    """GET ``/files/<chainId>/<address>`` → up to one :class:`AbiCandidate`.

    Returns ``()`` for unverified contracts (404). Raises
    :class:`SourcifyError` on transport failure or unexpected metadata
    shape.
    """
    address_lower = address.lower()
    url = f"{base_url.rstrip('/')}/files/{chain_id}/{address_lower}"
    params: dict[str, Any] = {}
    try:
        payload = await http_client.get_json_any(
            url,
            params,
            source=rate_limit_source,
            ttl=ttl,
            validator=is_sourcify_ok,
        )
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            return ()
        raise SourcifyError(
            f"Sourcify HTTP {exc.response.status_code} for address={address_lower}",
            tier=AbiSource.SOURCIFY,
            selector="",
            address=address_lower,
            original_status=exc.response.status_code,
        ) from exc
    except httpx.HTTPError as exc:
        raise SourcifyError(
            f"Sourcify transport failure for address={address_lower}: {exc}",
            tier=AbiSource.SOURCIFY,
            selector="",
            address=address_lower,
        ) from exc
    except json.JSONDecodeError as exc:
        # Codex P2-1: a 200 response with malformed JSON body slips past
        # ``httpx.HTTPError`` because ``httpx.Response.json()`` raises
        # ``json.JSONDecodeError`` directly. Wrap into the tier-specific
        # error so :class:`AbiFallbackResolver` keeps walking the chain.
        raise SourcifyError(
            f"Sourcify response was not valid JSON for address={address_lower}: {exc.msg}",
            tier=AbiSource.SOURCIFY,
            selector="",
            address=address_lower,
        ) from exc

    if raw_store is not None:
        try:
            from vca.http.client import params_hash

            # Codex round-4 P2-2: ``RawResponseStore.put`` is typed
            # ``payload: dict[str, Any]``. Sourcify's success body is a
            # top-level JSON list of file objects, so we wrap it under
            # ``{"files": [...]}`` before persisting — mirroring the
            # mempool list-endpoint pattern in
            # :mod:`vca.adapters.btc.bitcoin._fetch_and_persist_list`
            # which wraps under ``{"items": [...]}``. The ``files`` key
            # name matches the Sourcify API noun (the body IS the list of
            # files for this contract) so the raw evidence on disk reads
            # naturally during forensic replay; the consistency the
            # contract demands is the dict shape, not the wrapper key.
            #
            # If the body is NOT a list (the explicit isinstance check
            # below raises ``SourcifyError``), wrap a shape-failure
            # envelope instead so the dict contract still holds. The BTC
            # adapter follows the same ``{"error", "body"}`` shape for
            # shape-failure raw evidence.
            if isinstance(payload, list):
                wrapped_payload: dict[str, Any] = {"files": list(payload)}
            else:
                wrapped_payload = {
                    "error": f"non-list body: {type(payload).__name__}",
                    "body": repr(payload),
                }
            await raw_store.put(
                source=rate_limit_source,
                endpoint=f"sourcify/files/{chain_id}/{address_lower}",
                params_hash=params_hash(params, url=url),
                payload=wrapped_payload,
                status_code=200,
                ttl=ttl,
            )
        except Exception:
            pass

    if not isinstance(payload, list):
        raise SourcifyError(
            f"Sourcify response must be a list, got {type(payload).__name__}",
            tier=AbiSource.SOURCIFY,
            selector="",
            address=address_lower,
        )
    abi_json = _extract_abi_from_files(payload, address=address_lower)
    return (
        AbiCandidate(
            source=AbiSource.SOURCIFY,
            selector="",  # address-keyed; per-selector matching happens at decode time
            signature_or_abi=abi_json,
            address=address_lower,
            text_signature=None,
            extras={},
        ),
    )


def _find_metadata_text(files: list[Any]) -> str | None:
    """Return the first ``metadata.json`` content string in *files*, else None.

    Shared between :func:`is_sourcify_ok` (predicate) and
    :func:`_extract_abi_from_files` (raising consumer) so both apply the
    same ``metadata.json`` selection contract — case-insensitive on the
    file ``name`` field, also matching when ``path`` ends with
    ``metadata.json``.
    """
    for entry in files:
        if not isinstance(entry, Mapping):
            continue
        name = str(entry.get("name") or "")
        path = str(entry.get("path") or "")
        if name.lower() == "metadata.json" or path.lower().endswith("metadata.json"):
            content = entry.get("content")
            if isinstance(content, str) and content:
                return content
    return None


def _try_extract_abi_from_files(files: list[Any]) -> list[Any] | None:
    """Non-raising twin of :func:`_extract_abi_from_files`.

    Returns the ABI list when *files* yields a parseable
    ``metadata.json`` whose ``output.abi`` resolves to a list; returns
    ``None`` for every failure mode (missing metadata, malformed JSON,
    metadata not an object, missing ``output``, ``output.abi`` not a
    list). The predicate :func:`is_sourcify_ok` consumes this so the
    cache-write gate enforces the same shape the consumer requires.
    """
    metadata_text = _find_metadata_text(files)
    if metadata_text is None:
        return None
    try:
        metadata = json.loads(metadata_text)
    except json.JSONDecodeError:
        return None
    if not isinstance(metadata, Mapping):
        return None
    output = metadata.get("output")
    if not isinstance(output, Mapping):
        return None
    abi = output.get("abi")
    if not isinstance(abi, list):
        return None
    return abi


def _extract_abi_from_files(files: list[Any], *, address: str) -> str:
    """Locate ``metadata.json`` in *files*, parse it, return its ABI as JSON str.

    Sourcify returns a flat list of file objects. The contract's
    ``metadata.json`` carries the canonical ABI under
    ``output.abi`` (Solidity standard JSON output shape).

    Raises :class:`SourcifyError` with a per-failure-mode message so the
    resolver routes the failure to the next tier with diagnostic context.
    The shape checks here MUST stay in sync with
    :func:`_try_extract_abi_from_files` so the predicate and the
    consumer agree on exactly which bodies are usable.
    """
    metadata_text = _find_metadata_text(files)
    if metadata_text is None:
        raise SourcifyError(
            f"Sourcify response missing metadata.json for address={address}",
            tier=AbiSource.SOURCIFY,
            selector="",
            address=address,
        )
    try:
        metadata = json.loads(metadata_text)
    except json.JSONDecodeError as exc:
        raise SourcifyError(
            f"Sourcify metadata.json invalid JSON for address={address}: {exc.msg}",
            tier=AbiSource.SOURCIFY,
            selector="",
            address=address,
        ) from exc
    if not isinstance(metadata, Mapping):
        raise SourcifyError(
            f"Sourcify metadata.json must be a JSON object for address={address}",
            tier=AbiSource.SOURCIFY,
            selector="",
            address=address,
        )
    output = metadata.get("output")
    if not isinstance(output, Mapping):
        raise SourcifyError(
            f"Sourcify metadata.json missing 'output' for address={address}",
            tier=AbiSource.SOURCIFY,
            selector="",
            address=address,
        )
    abi = output.get("abi")
    if not isinstance(abi, list):
        raise SourcifyError(
            f"Sourcify metadata.json missing 'output.abi' for address={address}",
            tier=AbiSource.SOURCIFY,
            selector="",
            address=address,
        )
    return json.dumps(abi, separators=(",", ":"))


__all__ = [
    "is_sourcify_ok",
    "lookup_sourcify",
]
