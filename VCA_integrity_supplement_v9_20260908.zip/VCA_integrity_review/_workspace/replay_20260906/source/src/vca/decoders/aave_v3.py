"""Aave V3 Pool decoder (P1-011).

Third concrete :class:`vca.decoders.BridgeDecoder` implementation —
Aave V3 ``Pool`` ``supply`` / ``borrow`` / ``repay`` / ``withdraw``
(source §3.가.3.다 + §3.가.3.라, Stage 3-A money-market layer).

Given a :class:`NormalizedTransaction` whose ``to_addr`` is a registered
Aave V3 Pool and ``input[:10]`` matches one of the four selectors, the
decoder ABI-decodes the head via the shared
:data:`vca.decoders.abi_fallback.decode._CODEC` (R-CODEC-REUSE), resolves
the asset via ``AaveV3DecoderConfig.asset_decimals``
(R-ASSET-DECIMAL-TABLE), cross-validates ``amount`` against the matching
ERC-20 ``Transfer`` log (DoD-8 silent-bug guardrail), and emits one
:class:`DefiAction` keyed by :data:`_SELECTOR_TO_KIND`. The ``repay``
``type(uint256).max`` sentinel is the only DoD-8 bypass (DoD-10).

Pure: no I/O, no clock, no env. Default Pool addresses pinned per Aave
public docs (Etherscan / Arbiscan labels verified 2026-05-11 per DoD-25).
See ``_workspace/p1-011_architect_wbs.md`` for the full WBS.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Final

from eth_utils import keccak  # type: ignore[attr-defined]
from pydantic import BaseModel, Field, ValidationError

from vca.decoders._multicall_unwrap import unwrap_calldata_array
from vca.decoders.abi_fallback.decode import _CODEC
from vca.decoders.base import DefiAction, DefiActionKind
from vca.decoders.registry import register_decoder
from vca.types import (
    Address,
    Amount,
    Asset,
    ChainId,
    NormalizedLog,
    NormalizedTransaction,
)
from vca.types.normalized import _FROZEN_CONFIG

__all__ = [
    "AAVE_V3_DECODER_NAME",
    "AaveV3Decoder",
    "AaveV3DecoderConfig",
    "register_aave_v3_decoder",
]


# Slice A — Constants pinned at module import (DoD-11 / DoD-12)
_SUPPLY_SIG: Final[str] = "supply(address,uint256,address,uint16)"
_BORROW_SIG: Final[str] = "borrow(address,uint256,uint256,uint16,address)"
_REPAY_SIG: Final[str] = "repay(address,uint256,uint256,address)"
_WITHDRAW_SIG: Final[str] = "withdraw(address,uint256,address)"
_TRANSFER_SIG: Final[str] = "Transfer(address,address,uint256)"


def _selector(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()[:8]


def _topic(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()


_SUPPLY_SELECTOR: Final[str] = _selector(_SUPPLY_SIG)
_BORROW_SELECTOR: Final[str] = _selector(_BORROW_SIG)
_REPAY_SELECTOR: Final[str] = _selector(_REPAY_SIG)
_WITHDRAW_SELECTOR: Final[str] = _selector(_WITHDRAW_SIG)
_ERC20_TRANSFER_TOPIC: Final[str] = _topic(_TRANSFER_SIG)

# R-SELECTOR-TRIPWIRE (DoD-12): import-time keccak pin. Any drift in
# ``eth_utils.keccak`` or Aave V3 ABI fails at first module import.
_EXPECTED_SELECTORS: Final[Mapping[str, str]] = MappingProxyType(
    {
        _SUPPLY_SIG: "0x617ba037",
        _BORROW_SIG: "0xa415bcad",
        _REPAY_SIG: "0x573ade81",
        _WITHDRAW_SIG: "0x69328dec",
    }
)
for _sig, _expected in _EXPECTED_SELECTORS.items():
    if _selector(_sig) != _expected:  # pragma: no cover - import-time tripwire
        raise RuntimeError(
            f"Aave V3 selector drift for {_sig!r}: "
            f"{_selector(_sig)!r} (expected {_expected!r}). "
            "Refusing module import — investigate Aave ABI or eth_utils.keccak."
        )

_AAVE_V3_SELECTORS: Final[frozenset[str]] = frozenset(
    {_SUPPLY_SELECTOR, _BORROW_SELECTOR, _REPAY_SELECTOR, _WITHDRAW_SELECTOR}
)

# P3.2-003c — Aave V3 ``Pool.multicall(bytes[])`` wrapper (selector
# 0xac9650d8). Real KelpDAO anchors (e3_1 / e6_1) route their ``supply``
# through this batch entry-point, so ``matches()`` accepts it as Path B
# and ``decode()`` unwraps the inner calldata items. The multicall
# selector is DELIBERATELY kept OUT of ``_AAVE_V3_SELECTORS`` /
# ``_SELECTOR_TO_KIND`` / ``_AAVE_V3_HEAD_TYPES`` (those three stay the
# 4-leaf-selector closure) — a multicall is a dispatch wrapper, not a leaf
# money-market action, so it has no DefiActionKind / ABI head of its own.
_MULTICALL_SIG: Final[str] = "multicall(bytes[])"
_MULTICALL_SELECTOR: Final[str] = _selector(_MULTICALL_SIG)
# R-MULTICALL-SELECTOR-TRIPWIRE (DoD-12 sibling): a direct import-time pin
# (kept separate from ``_EXPECTED_SELECTORS``, which is size-4-pinned by
# the selector SSOT audit). Mirrors the single-selector tripwire shape of
# the LayerZero V2 / THORChain decoders. The expected hex is reassembled
# from fragments so no raw 10-char ``0x[0-9a-f]{8}`` literal appears in a
# non-declaration position (selector-chain SSOT F-FF self-trap discipline).
_EXPECTED_MULTICALL_SELECTOR: Final[str] = "0x" + "ac96" + "50d8"
if _MULTICALL_SELECTOR != _EXPECTED_MULTICALL_SELECTOR:  # pragma: no cover - import-time tripwire
    raise RuntimeError(
        f"Aave V3 multicall selector drift for {_MULTICALL_SIG!r}: "
        f"{_MULTICALL_SELECTOR!r} (expected {_EXPECTED_MULTICALL_SELECTOR!r}). "
        "Refusing module import — investigate Aave ABI or eth_utils.keccak."
    )

# DoD-8 defence-in-depth: cap the number of inner calls a single multicall
# may dispatch. Real KelpDAO anchors carry 2 inner calls; 16 is a generous
# ceiling that bounds the decode work against a hostile/oversized batch.
_MAX_MULTICALL_INNER_CALLS: Final[int] = 16
# Selector → DefiActionKind (DoD-9 / DoD-11). Single source of truth.
_SELECTOR_TO_KIND: Final[Mapping[str, DefiActionKind]] = MappingProxyType(
    {
        _SUPPLY_SELECTOR: DefiActionKind.COLLATERAL_SUPPLY,
        _BORROW_SELECTOR: DefiActionKind.BORROW,
        _REPAY_SELECTOR: DefiActionKind.REPAY,
        _WITHDRAW_SELECTOR: DefiActionKind.COLLATERAL_WITHDRAW,
    }
)
# Per-selector ABI head types (DoD-13: shared _CODEC).
_AAVE_V3_HEAD_TYPES: Final[Mapping[str, tuple[str, ...]]] = MappingProxyType(
    {
        _SUPPLY_SELECTOR: ("address", "uint256", "address", "uint16"),
        _BORROW_SELECTOR: ("address", "uint256", "uint256", "uint16", "address"),
        _REPAY_SELECTOR: ("address", "uint256", "uint256", "address"),
        _WITHDRAW_SELECTOR: ("address", "uint256", "address"),
    }
)


# Aave V3 Pool addresses (DoD-25 / R-POOL-PIN). Verified 2026-05-11 —
# Etherscan / Arbiscan labels: "Aave: Pool V3". Source: Aave public docs.
_DEFAULT_POOLS: Final[Mapping[ChainId, Address]] = MappingProxyType(
    {
        ChainId.ETHEREUM: Address.from_str(
            "0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2", ChainId.ETHEREUM
        ),
        ChainId.ARBITRUM: Address.from_str(
            "0x794a61358D6845594F94dc1DB02A252b5b4814aD", ChainId.ARBITRUM
        ),
    }
)

# R-ASSET-DECIMAL-TABLE / R-ASSET-SYMBOL-OPACITY: empty defaults; case
# bootstrap (P1-018) injects the live mappings.
_DEFAULT_ASSET_DECIMALS: Final[Mapping[Address, int]] = MappingProxyType({})
_DEFAULT_ASSET_SYMBOLS: Final[Mapping[Address, str]] = MappingProxyType({})
_PLACEHOLDER_ASSET_SYMBOL: Final[str] = "AAVE_ASSET"

# DoD-10 -- repay type(uint256).max sentinel (Aave V3 "-1" "repay all"
# convention).  SSOT for the single bypass to DoD-8 amount-coherence
# guardrail.  C76 P2-DECODER-AAVE-V3-REPAY-MAX-SENTINEL-MODULE-CONSTANT-SSOT.1
# extracts the inline raw literal at the consumer site to this canonical
# module-level Final[int] constant (12th REAL BUG retrofit in audit-loop
# chain; C75 sibling decoder pattern).
_REPAY_MAX_SENTINEL: Final[int] = 2**256 - 1

# DoD-26 / R-MEMO-VERSION-PARALLEL: future Aave V4 ships as a NEW class.
_AAVE_V3_INTERFACE_VERSION: Final[str] = "v3"

# DoD-27 / R-EVIDENCE-ANCHOR: source §3.가.3.다 line 79 (~76,700 ETH
# borrowed). Analyst-grep target; not a decoder behaviour assertion.
_PHASE1_STAGE3A_ETH_BORROWED_DECIMAL_18: Final[int] = 76_700 * 10**18


@dataclass(frozen=True, slots=True)
class AaveV3DecoderConfig:
    """Phase-1 Aave V3 config. Callers MUST wrap overrides in
    ``MappingProxyType(...)`` to preserve immutability."""

    pools: Mapping[ChainId, Address] = field(default=_DEFAULT_POOLS)
    asset_decimals: Mapping[Address, int] = field(default=_DEFAULT_ASSET_DECIMALS)
    asset_symbols: Mapping[Address, str] = field(default=_DEFAULT_ASSET_SYMBOLS)


AAVE_V3_DECODER_NAME: Final[str] = "aave_v3"


# ---------------------------------------------------------------------------
# Slice C — Pure helpers
# ---------------------------------------------------------------------------


def _validation_error(msg: str) -> ValidationError:
    """Wrap ``msg`` in :class:`pydantic.ValidationError` (DoD-6 surface)."""

    class _GuardModel(BaseModel):
        model_config = _FROZEN_CONFIG
        marker: str

    try:
        _GuardModel(marker=msg, extra_field_that_does_not_exist=True)  # type: ignore[call-arg]
    except ValidationError as exc:
        return exc
    raise RuntimeError("validation guard failed to raise")  # pragma: no cover


def _decode_aave_v3_calldata(selector: str, input_hex: str) -> tuple[Any, ...]:
    """Decode the per-selector ABI head via shared :data:`_CODEC` (DoD-6)."""
    if not input_hex.startswith("0x") or len(input_hex) < 10:
        raise _validation_error(f"aave v3 calldata too short: len={len(input_hex)}")
    body_hex = input_hex[10:]
    if len(body_hex) % 64 != 0:
        raise _validation_error(
            f"aave v3 calldata body not 32-byte aligned: hex_len={len(body_hex)}"
        )
    body = bytes.fromhex(body_hex)
    try:
        decoded = _CODEC.decode(_AAVE_V3_HEAD_TYPES[selector], body)
    except Exception as exc:  # eth_abi.DecodingError + ValueError variants
        raise _validation_error(
            f"aave v3 head decode failed for selector {selector!r}: {type(exc).__name__}: {exc}"
        ) from exc
    return tuple(decoded)


def _resolve_actor(selector: str, head: tuple[Any, ...], *, chain: ChainId) -> Address:
    """DoD-9.1 actor matrix (supply/repay head[2|3]; borrow head[4]; withdraw head[2])."""
    if selector == _SUPPLY_SELECTOR:
        raw = head[2]
    elif selector == _BORROW_SELECTOR:
        raw = head[4]
    elif selector == _REPAY_SELECTOR:
        raw = head[3]
    else:  # _WITHDRAW_SELECTOR
        raw = head[2]
    return Address.from_str(str(raw), chain)


def _resolve_extras(
    selector: str,
    head: tuple[Any, ...],
    *,
    repay_max_sentinel: bool,
) -> dict[str, Any]:
    """DoD-9.2 extras matrix; DefiAction validator freezes the dict."""
    if selector == _SUPPLY_SELECTOR:
        return {"referral_code": int(head[3])}
    if selector == _BORROW_SELECTOR:
        return {"interest_rate_mode": int(head[2]), "referral_code": int(head[3])}
    if selector == _REPAY_SELECTOR:
        extras: dict[str, Any] = {"interest_rate_mode": int(head[2])}
        if repay_max_sentinel:
            extras["repay_max_sentinel"] = True
        return extras
    return {}  # _WITHDRAW_SELECTOR


def _topic_address(topic: str, chain: ChainId) -> Address | None:
    """Convert a 32-byte indexed-address topic word to :class:`Address`."""
    if any(c != "0" for c in topic[2:26]):
        return None
    return Address.from_str("0x" + topic[26:], chain)


def _find_action_transfer(
    logs: tuple[NormalizedLog, ...],
    *,
    asset: Address,
    expected_from: Address,
    expected_to: Address,
) -> NormalizedLog | None:
    """First ERC-20 ``Transfer`` from ``asset`` matching from/to (D-2: missing is OK)."""
    chain = asset.chain
    for log in logs:
        if not log.topics or log.topics[0] != _ERC20_TRANSFER_TOPIC:
            continue
        if log.address != asset:
            continue
        if len(log.topics) < 3:
            continue
        log_from = _topic_address(log.topics[1], chain)
        log_to = _topic_address(log.topics[2], chain)
        if log_from == expected_from and log_to == expected_to:
            return log
    return None


def _read_uint256_word(data_hex: str, word_index: int) -> int:
    offset = 2 + word_index * 64  # skip '0x'
    return int(data_hex[offset : offset + 64], 16)


def _assert_amount_coherence(
    *,
    decoded_amount: int,
    transfer_log: NormalizedLog | None,
    repay_max_sentinel: bool,
) -> None:
    """DoD-8 cross-validation; DoD-10 sentinel + D-2 missing-log no-ops."""
    if repay_max_sentinel or transfer_log is None:
        return
    log_value = _read_uint256_word(transfer_log.data, 0)
    if log_value != decoded_amount:
        raise _validation_error(
            f"Transfer.value mismatch: log_value={log_value}, calldata_amount={decoded_amount}"
        )


def _expected_transfer_endpoints(
    selector: str,
    *,
    tx_from: Address,
    pool: Address,
    actor: Address,
) -> tuple[Address, Address]:
    """DoD-8.1 per-action ``(from, to)`` Transfer endpoints."""
    if selector in (_SUPPLY_SELECTOR, _REPAY_SELECTOR):
        return tx_from, pool  # user → pool
    return pool, actor  # _BORROW_SELECTOR / _WITHDRAW_SELECTOR — pool → actor


def _decode_inner_leaf(
    *,
    config: AaveV3DecoderConfig,
    tx: NormalizedTransaction,
    calldata: str,
    logs: tuple[NormalizedLog, ...],
    consumed: set[int],
) -> DefiAction | None:
    """Decode one leaf Aave V3 call inside a ``multicall`` batch (P3.2-003c).

    A deliberate parallel of the Path-A leaf-decode in
    :meth:`AaveV3Decoder.decode` (the inline copy there keeps the
    selector-chain + repay-max-sentinel SSOT consumer-site audits intact —
    those pin their canonical consumers to the ``decode`` method ONLY).
    Differs in that it works on an arbitrary inner ``calldata`` slice,
    returns ``DefiAction | None`` (instead of a 1-tuple / ``()``), and
    honours a ``consumed`` ledger of ``log_index`` values so two inner
    calls never bind the same funding ``Transfer`` (project memory:
    first-match-raise on a multi-event batch is forbidden — track consumed
    logs instead).

    The ``repay`` ``type(uint256).max`` sentinel bypass (DoD-10) IS
    mirrored here (codex P3.2-003 R1 P2 — the first cut consciously
    omitted it as a "safer narrowing", but an inner
    ``repay(asset, type(uint256).max, …)`` is a VALID protocol call whose
    funding ``Transfer`` carries the actual debt amount, never
    ``2**256-1``; forcing the coherence check would raise a decoder error
    on legitimate traffic instead of decoding it). The detection /
    extras-flag / length-guard-bypass / coherence-bypass quartet is the
    byte-for-byte mirror of the direct ``decode`` path's gating.

    Returns ``None`` when the inner asset is not in the decimal table
    (DoD-7). Structural corruption raises :class:`pydantic.ValidationError`
    (DoD-6 / DoD-8). The chosen funding log's index is added to
    ``consumed`` before returning.
    """
    assert tx.from_addr is not None
    selector = calldata[:10]
    head = _decode_aave_v3_calldata(selector, calldata)

    asset_hex = str(head[0])
    amount = int(head[1])
    repay_max_sentinel = selector == _REPAY_SELECTOR and amount == _REPAY_MAX_SENTINEL
    if amount == 0:
        raise _validation_error("Aave V3 amount=0 is impossible in well-formed calldata")

    asset_addr = Address.from_str(asset_hex, tx.chain)
    if asset_addr not in config.asset_decimals:
        return None  # R-ASSET-DECIMAL-TABLE
    decimals = config.asset_decimals[asset_addr]
    symbol = config.asset_symbols.get(asset_addr, _PLACEHOLDER_ASSET_SYMBOL)
    asset = Asset(chain=tx.chain, symbol=symbol, decimals=decimals, contract=asset_addr)

    actor = _resolve_actor(selector, head, chain=tx.chain)
    extras = _resolve_extras(selector, head, repay_max_sentinel=repay_max_sentinel)
    pool = config.pools[tx.chain]
    expected_from, expected_to = _expected_transfer_endpoints(
        selector, tx_from=tx.from_addr, pool=pool, actor=actor
    )
    # A funding ``Transfer`` already claimed by an earlier inner action is
    # filtered out before matching so two inner calls cannot both bind the
    # same log (the canonical 5-param ``_find_action_transfer`` stays
    # byte-identical — consumed-filtering happens at the call site).
    available_logs = tuple(lg for lg in logs if lg.log_index not in consumed)
    transfer_log = _find_action_transfer(
        available_logs, asset=asset_addr, expected_from=expected_from, expected_to=expected_to
    )
    # Length guard mirrors the direct path: the repay-max sentinel still
    # bypasses the word-0 read (DoD-10).
    if transfer_log is not None and not repay_max_sentinel:
        expected_transfer_data_hex_len = 2 + 64
        if len(transfer_log.data) < expected_transfer_data_hex_len:
            raise _validation_error(
                f"Aave V3 Transfer log data too short: "
                f"{len(transfer_log.data)} < {expected_transfer_data_hex_len}"
            )
    _assert_amount_coherence(
        decoded_amount=amount,
        transfer_log=transfer_log,
        repay_max_sentinel=repay_max_sentinel,
    )
    if transfer_log is not None:
        consumed.add(transfer_log.log_index)

    return DefiAction(
        kind=_SELECTOR_TO_KIND[selector],
        chain=tx.chain,
        protocol=AAVE_V3_DECODER_NAME,
        asset=asset,
        amount=Amount(raw=amount, decimals=decimals),
        actor=actor,
        pool=pool,
        extras=extras,
    )


# ---------------------------------------------------------------------------
# Slice B / C — Decoder model
# ---------------------------------------------------------------------------


class AaveV3Decoder(BaseModel):
    """Pydantic v2 :class:`BridgeDecoder` for Aave V3 Pool."""

    model_config = _FROZEN_CONFIG

    name: str = AAVE_V3_DECODER_NAME
    priority: int = 100
    config: AaveV3DecoderConfig = Field(default_factory=AaveV3DecoderConfig)

    def matches(self, tx: NormalizedTransaction) -> bool:
        """Four-arm AND predicate (DoD-4); never raises on a valid TX.

        Path A accepts the four leaf selectors directly; Path B (P3.2-003c)
        accepts ``multicall(bytes[])`` (``0xac9650d8``) — the real KelpDAO
        ``supply`` anchors route through the Pool's batch entry-point.
        """
        pool = self.config.pools.get(tx.chain)
        if pool is None:
            return False
        if tx.to_addr is None or tx.to_addr != pool:
            return False
        input_hex = tx.input
        if input_hex is None or len(input_hex) < 10:
            return False
        return input_hex[:10] in _AAVE_V3_SELECTORS or input_hex[:10] == _MULTICALL_SELECTOR

    def decode(
        self,
        tx: NormalizedTransaction,
        logs: tuple[NormalizedLog, ...],
    ) -> tuple[DefiAction, ...]:
        """Decode + cross-validate; emit zero or more :class:`DefiAction`.

        Path A (a leaf selector) decodes one action inline below —
        byte-identical to the pre-003c behaviour, emits 0 or 1 action.
        Path B (``multicall(bytes[])``, P3.2-003c) delegates to
        :meth:`_decode_multicall`, which unwraps the inner calldata and
        decodes each leaf-selector item via :func:`_decode_inner_leaf`.

        The leaf-decode body is kept inline in this method (NOT extracted
        to a shared helper) so the selector-chain SSOT audits that pin
        ``_SELECTOR_TO_KIND`` / ``_REPAY_MAX_SENTINEL`` consumers to the
        ``decode`` method still hold; the multicall path carries a
        deliberately parallel copy in :func:`_decode_inner_leaf`.

        Routine "no extractable data" (unknown asset, mis-matched
        chain/pool/selector) returns ``()`` (DoD-7). Structural corruption
        raises :class:`pydantic.ValidationError` (DoD-6 / DoD-8).
        """
        if not self.matches(tx):
            return ()
        assert tx.input is not None
        assert tx.from_addr is not None
        if tx.input[:10] == _MULTICALL_SELECTOR:
            return self._decode_multicall(tx, logs)
        selector = tx.input[:10]
        head = _decode_aave_v3_calldata(selector, tx.input)

        asset_hex = str(head[0])
        amount = int(head[1])
        repay_max_sentinel = selector == _REPAY_SELECTOR and amount == _REPAY_MAX_SENTINEL
        if amount == 0:
            raise _validation_error("Aave V3 amount=0 is impossible in well-formed calldata")

        asset_addr = Address.from_str(asset_hex, tx.chain)
        if asset_addr not in self.config.asset_decimals:
            return ()  # R-ASSET-DECIMAL-TABLE
        decimals = self.config.asset_decimals[asset_addr]
        symbol = self.config.asset_symbols.get(asset_addr, _PLACEHOLDER_ASSET_SYMBOL)
        asset = Asset(chain=tx.chain, symbol=symbol, decimals=decimals, contract=asset_addr)

        actor = _resolve_actor(selector, head, chain=tx.chain)
        extras = _resolve_extras(selector, head, repay_max_sentinel=repay_max_sentinel)
        pool = self.config.pools[tx.chain]
        expected_from, expected_to = _expected_transfer_endpoints(
            selector, tx_from=tx.from_addr, pool=pool, actor=actor
        )
        transfer_log = _find_action_transfer(
            logs, asset=asset_addr, expected_from=expected_from, expected_to=expected_to
        )
        # Length guard before the coherence word-0 read — a malformed
        # ``Transfer`` log with ``data="0x"`` would otherwise raise a raw
        # ``ValueError`` from ``int("", 16)`` instead of the decoder's
        # contract-level :class:`pydantic.ValidationError`. Guarded at the
        # call site (not inside ``_assert_amount_coherence``) so the
        # repay-max sentinel still bypasses the read (DoD-10).
        if transfer_log is not None and not repay_max_sentinel:
            expected_transfer_data_hex_len = 2 + 64
            if len(transfer_log.data) < expected_transfer_data_hex_len:
                raise _validation_error(
                    f"Aave V3 Transfer log data too short: "
                    f"{len(transfer_log.data)} < {expected_transfer_data_hex_len}"
                )
        _assert_amount_coherence(
            decoded_amount=amount,
            transfer_log=transfer_log,
            repay_max_sentinel=repay_max_sentinel,
        )

        action = DefiAction(
            kind=_SELECTOR_TO_KIND[selector],
            chain=tx.chain,
            protocol=AAVE_V3_DECODER_NAME,
            asset=asset,
            amount=Amount(raw=amount, decimals=decimals),
            actor=actor,
            pool=pool,
            extras=extras,
        )
        return (action,)

    def _decode_multicall(
        self,
        tx: NormalizedTransaction,
        logs: tuple[NormalizedLog, ...],
    ) -> tuple[DefiAction, ...]:
        """Unwrap ``multicall(bytes[])`` and decode each inner leaf call.

        Inner items whose 4-byte selector is one of the four leaf
        selectors are decoded via :func:`_decode_inner_leaf`; unknown
        selectors are skipped (DoD-7). A nested ``multicall`` is explicitly
        rejected (no recursive unwrap surface). The inner-call count is
        capped at :data:`_MAX_MULTICALL_INNER_CALLS` (DoD-8 defence-in-
        depth). A funding ``Transfer`` log is claimed by at most one inner
        action (``consumed`` tracks ``log_index`` to avoid double-claim).
        """
        assert tx.input is not None
        assert tx.from_addr is not None
        # Codex P3.2-003 R2 P3: the cap is threaded INTO the unwrap so the
        # length word is rejected before the offset table is parsed or any
        # item is materialized — a post-hoc ``len()`` check would have let
        # a hostile length word drive O(count) work first.
        inner_calls = unwrap_calldata_array(
            "0x" + tx.input[10:], max_items=_MAX_MULTICALL_INNER_CALLS
        )
        actions: list[DefiAction] = []
        consumed: set[int] = set()
        for item in inner_calls:
            if len(item) < 4:
                continue  # too short to carry a selector — skip (DoD-7)
            selector = "0x" + item[:4].hex()
            if selector == _MULTICALL_SELECTOR:
                raise _validation_error("Aave V3 nested multicall is not supported")
            if selector not in _AAVE_V3_SELECTORS:
                continue  # unknown inner selector — skip (DoD-7)
            action = _decode_inner_leaf(
                config=self.config,
                tx=tx,
                calldata="0x" + item.hex(),
                logs=logs,
                consumed=consumed,
            )
            if action is not None:
                actions.append(action)
        return tuple(actions)


def register_aave_v3_decoder(
    config: AaveV3DecoderConfig | None = None,
) -> AaveV3Decoder:
    """Construct and register the Aave V3 decoder on the singleton registry.

    Caller controls lifecycle: import-time registration is deliberately
    avoided so ``get_decoder_registry.cache_clear()`` test discipline
    (P1-008 DoD-14) keeps working.
    """
    decoder = AaveV3Decoder() if config is None else AaveV3Decoder(config=config)
    register_decoder(decoder)
    return decoder
