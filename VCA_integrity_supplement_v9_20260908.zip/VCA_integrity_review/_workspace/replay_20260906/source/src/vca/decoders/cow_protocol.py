"""CoW Protocol GPv2Settlement decoder (P2-008.0a).

Fourth Group A pre-pend decoder. Mirrors P2-001.0c KyberSwap's
**event-driven** approach: calldata gates only on the ``settle`` selector
(0x13d79a0b); the canonical truth (per-order sellToken / buyToken /
sellAmount / buyAmount / feeAmount / orderUid / owner) lives in the
``Trade`` event(s) emitted by the settlement contract.

**Spec correction** (per task brief / architect WBS): the GPv2 Protocol
``createOrder`` operation is **offchain** — orders are signed by users and
submitted to the CoW Protocol REST API. The on-chain truth is the batch
``settle(...)`` call on ``0x9008D19f58AAbD9eD0D60971565AA8510560ab41``
AND one or more ``Trade`` events emitted by the same contract. Therefore
this decoder pairs ``settle`` calldata ⟷ ``Trade`` event(s), and a single
``decode`` call MAY emit multiple :class:`DefiAction`s (one per Trade
event in the same TX).

GPv2Settlement (mainnet ``0x9008D19f58AAbD9eD0D60971565AA8510560ab41``):

* ``settle(IERC20[] tokens, uint256[] clearingPrices,
   GPv2Trade.Data[] trades,
   GPv2Interaction.Data[][3] interactions)``                  → 0x13d79a0b

  ABI-canonical signature (with IERC20 → address):
  ``settle(address[],uint256[],(uint256,uint256,address,uint256,uint256,
   uint32,bytes32,uint256,uint256,uint256,bytes)[],
   (address,uint256,bytes)[][3])``

  The ``[][3]`` denotes a fixed-size length-3 outer array of dynamic inner
  arrays (pre-/intra-/post-settlement hooks). This shape change vs. the
  intuitive ``[][]`` is what produces the canonical selector
  ``0x13d79a0b`` (cross-checked against Etherscan-verified bytecode).

* Event ``Trade(address indexed owner, IERC20 sellToken, IERC20 buyToken,
   uint256 sellAmount, uint256 buyAmount, uint256 feeAmount, bytes orderUid)``
                  → 0xa07a543ab8a018198e99ca0184c93fe9050a79400a0a723441f84de1d972cc17

Action kind: closest-fit ``COLLATERAL_WITHDRAW`` (closed Phase-1 enum;
0 new values, per P2-001.0c KyberSwap precedent). Swap semantics carried
in ``extras``: ``function``, ``kind_override="swap"``,
``router="cow_protocol"``, ``sell_token``, ``buy_token``, ``buy_amount``,
``fee_amount``, ``order_uid``, ``owner``, ``valid_to`` (extracted from
trailing uint32 of orderUid). Classifier wiring for ``cow_protocol`` is
deferred to P2-008 stage vertical.

Pure: no I/O, no clock, no env. Synthetic fixture doctrine.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Final, NamedTuple

from eth_utils import keccak  # type: ignore[attr-defined]
from pydantic import BaseModel, Field, ValidationError

from vca.decoders.base import DefiAction, DefiActionKind
from vca.decoders.registry import register_decoder
from vca.types import (
    Address,
    Amount,
    Asset,
    ChainId,
    NormalizedLog,
    NormalizedTransaction,
)
from vca.types.normalized import _FROZEN_CONFIG

__all__ = [
    "COW_PROTOCOL_DECODER_NAME",
    "CowProtocolDecoder",
    "CowProtocolDecoderConfig",
    "register_cow_protocol_decoder",
]


# Slice A — Constants (R-SELECTOR-TRIPWIRE + R-EVENT-TOPIC-TRIPWIRE).
_SETTLE_SIG: Final[str] = (
    "settle(address[],uint256[],"
    "(uint256,uint256,address,uint256,uint256,uint32,bytes32,uint256,"
    "uint256,uint256,bytes)[],"
    "(address,uint256,bytes)[][3])"
)
_TRADE_EVENT_SIG: Final[str] = "Trade(address,address,address,uint256,uint256,uint256,bytes)"
_TRANSFER_SIG: Final[str] = "Transfer(address,address,uint256)"


def _selector(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()[:8]


def _topic(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()


_SETTLE_SELECTOR: Final[str] = _selector(_SETTLE_SIG)
_TRADE_TOPIC: Final[str] = _topic(_TRADE_EVENT_SIG)
_ERC20_TRANSFER_TOPIC: Final[str] = _topic(_TRANSFER_SIG)

# Import-time keccak pin (R-SELECTOR-TRIPWIRE + R-EVENT-TOPIC-TRIPWIRE).
_EXPECTED_SELECTORS: Final[Mapping[str, str]] = MappingProxyType(
    {_SETTLE_SIG: "0x13d79a0b"},
)
for _sig, _expected in _EXPECTED_SELECTORS.items():
    if _selector(_sig) != _expected:  # pragma: no cover - import-time tripwire
        raise RuntimeError(
            f"CoW Protocol selector drift for {_sig!r}: "
            f"{_selector(_sig)!r} (expected {_expected!r}). "
            "Refusing module import — investigate CoW Protocol ABI or eth_utils.keccak."
        )

_EXPECTED_EVENT_TOPICS: Final[Mapping[str, str]] = MappingProxyType(
    {
        _TRADE_EVENT_SIG: ("0xa07a543ab8a018198e99ca0184c93fe9050a79400a0a723441f84de1d972cc17"),
        _TRANSFER_SIG: ("0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"),
    },
)
for _sig, _expected in _EXPECTED_EVENT_TOPICS.items():
    if _topic(_sig) != _expected:  # pragma: no cover - import-time tripwire
        raise RuntimeError(
            f"CoW Protocol event topic drift for {_sig!r}: "
            f"{_topic(_sig)!r} (expected {_expected!r}). "
            "Refusing module import — investigate CoW Protocol ABI or eth_utils.keccak."
        )

_COW_PROTOCOL_SELECTORS: Final[frozenset[str]] = frozenset({_SETTLE_SELECTOR})

# Mainnet GPv2Settlement (Etherscan-verified, EIP-55 verbatim).
_GPV2_SETTLEMENT_ETH = Address.from_str(
    "0x9008D19f58AAbD9eD0D60971565AA8510560ab41", ChainId.ETHEREUM
)
_DEFAULT_SETTLEMENT_ADDRESSES: Final[Mapping[ChainId, frozenset[Address]]] = MappingProxyType(
    {ChainId.ETHEREUM: frozenset({_GPV2_SETTLEMENT_ETH})}
)
_DEFAULT_ASSET_DECIMALS: Final[Mapping[Address, int]] = MappingProxyType({})
_DEFAULT_ASSET_SYMBOLS: Final[Mapping[Address, str]] = MappingProxyType({})
_PLACEHOLDER_ASSET_SYMBOL: Final[str] = "COW_PROTOCOL_ASSET"
_ROUTER_TAG: Final[str] = "cow_protocol"
# P2-DECODER-KIND-OVERRIDE-LITERAL-SSOT.1 (Cycle 28): module-level Final[str]
# SSOT for the ``extras["kind_override"]`` value emitted on every settle ->
# DefiAction. MUST byte-equal one of the consumer-side values in
# :data:`vca.tracer.stage_classifier._vocab._KNOWN_KIND_OVERRIDES`; a 1-byte
# drift here silently defers the rank-4 ``is_kind_override`` heuristic and
# mis-classifies the cow_protocol settle edge into the fallback ranks.
_KIND_OVERRIDE: Final[str] = "swap"
COW_PROTOCOL_DECODER_NAME: Final[str] = "cow_protocol"


@dataclass(frozen=True, slots=True)
class CowProtocolDecoderConfig:
    """Phase-2 CoW Protocol config. Wrap overrides in ``MappingProxyType``.

    ``settlement_addresses`` ships mainnet GPv2Settlement pre-pinned
    (R-SETTLEMENT-WHITELIST-TRIPWIRE); asset tables empty until P2-008
    stage vertical injects WETH / DAI / USDC / USDT entries.
    """

    settlement_addresses: Mapping[ChainId, frozenset[Address]] = field(
        default=_DEFAULT_SETTLEMENT_ADDRESSES
    )
    asset_decimals: Mapping[Address, int] = field(default=_DEFAULT_ASSET_DECIMALS)
    asset_symbols: Mapping[Address, str] = field(default=_DEFAULT_ASSET_SYMBOLS)


# Slice C — Pure helpers.


def _validation_error(msg: str) -> ValidationError:
    """Wrap ``msg`` in :class:`pydantic.ValidationError`."""

    class _GuardModel(BaseModel):
        model_config = _FROZEN_CONFIG
        marker: str

    try:
        _GuardModel(marker=msg, extra_field_that_does_not_exist=True)  # type: ignore[call-arg]
    except ValidationError as exc:
        return exc
    raise RuntimeError("validation guard failed to raise")  # pragma: no cover


def _topic_address(topic: str, chain: ChainId) -> Address | None:
    """32-byte indexed-address topic → :class:`Address` or ``None``."""
    if any(c != "0" for c in topic[2:26]):
        return None
    return Address.from_str("0x" + topic[26:], chain)


def _read_uint256_word(data_hex: str, word_index: int) -> int:
    offset = 2 + word_index * 64  # skip '0x'
    return int(data_hex[offset : offset + 64], 16)


def _data_word_address(data_hex: str, word_index: int, chain: ChainId) -> Address:
    """Read a 32-byte zero-padded address word from event ``data``.

    Raises :class:`pydantic.ValidationError` when the top 12 bytes are not
    zero-padded — a malformed positional address word means the Trade event
    is malformed (unlike :func:`_topic_address`, which tolerates dirty topic
    padding by returning ``None``)."""
    offset = 2 + word_index * 64
    word = data_hex[offset : offset + 64]
    if any(c != "0" for c in word[:24]):
        raise _validation_error(
            f"CoW Protocol event data address word {word_index} malformed "
            f"(non-zero upper 12 bytes): {word!r}"
        )
    return Address.from_str("0x" + word[24:], chain)


def _find_trade_events(
    logs: tuple[NormalizedLog, ...],
    *,
    settlement: Address,
) -> tuple[NormalizedLog, ...]:
    """All ``Trade`` events emitted at the settlement address, in log order."""
    out: list[NormalizedLog] = []
    for log in logs:
        if not log.topics:
            continue
        if log.topics[0] != _TRADE_TOPIC:
            continue
        if log.address != settlement:
            continue
        out.append(log)
    return tuple(out)


class _TradeFields(NamedTuple):
    owner: Address
    sell_token: Address
    buy_token: Address
    sell_amount: int
    buy_amount: int
    fee_amount: int
    order_uid: str
    valid_to: int | None


def _parse_trade_payload(log: NormalizedLog, *, chain: ChainId) -> _TradeFields:
    """``Trade`` event log → structured fields.

    ABI layout (head, 6 x 32-byte words):
      0: sellToken     (address, left-padded)
      1: buyToken      (address, left-padded)
      2: sellAmount    (uint256)
      3: buyAmount     (uint256)
      4: feeAmount     (uint256)
      5: orderUid_off  (uint256 byte-offset into data)

    Tail at ``orderUid_off``:
      length (uint256) || padded bytes.

    Raises :class:`pydantic.ValidationError` if the event shape is malformed
    (missing owner topic, short data, length-overflowing data).
    """
    if len(log.topics) < 2:
        raise _validation_error("CoW Protocol Trade event missing indexed owner topic[1]")
    owner = _topic_address(log.topics[1], chain)
    if owner is None:
        raise _validation_error(
            f"CoW Protocol Trade event owner topic malformed: {log.topics[1]!r}"
        )
    # 6 head words required; head ends at hex char (2 + 6*64) = 386.
    if len(log.data) < 2 + 6 * 64:
        raise _validation_error(
            f"CoW Protocol Trade event data too short for head: {len(log.data)} < 386"
        )
    sell_token = _data_word_address(log.data, 0, chain)
    buy_token = _data_word_address(log.data, 1, chain)
    sell_amount = _read_uint256_word(log.data, 2)
    buy_amount = _read_uint256_word(log.data, 3)
    fee_amount = _read_uint256_word(log.data, 4)
    uid_offset_bytes = _read_uint256_word(log.data, 5)
    # ``data`` is hex-encoded; each byte is 2 hex chars; the byte-level
    # offset of length is uid_offset_bytes, mapped to hex char offset
    # 2 + 2 * uid_offset_bytes.
    length_pos = 2 + 2 * uid_offset_bytes
    if length_pos + 64 > len(log.data):
        raise _validation_error(
            f"CoW Protocol Trade event uid offset {uid_offset_bytes} "
            f"out of bounds for data of length {len(log.data)}"
        )
    uid_length = int(log.data[length_pos : length_pos + 64], 16)
    content_pos = length_pos + 64
    end_pos = content_pos + 2 * uid_length
    if end_pos > len(log.data):
        raise _validation_error(
            f"CoW Protocol Trade event orderUid length {uid_length} "
            f"overruns data of length {len(log.data)}"
        )
    uid_hex = log.data[content_pos:end_pos]
    order_uid = "0x" + uid_hex
    # Canonical orderUid layout: appDataHash(32) || owner(20) || validTo(4) = 56 bytes.
    # When the uid is canonical (56 bytes), cross-validate the embedded owner
    # (bytes 32:52 = hex chars 64:104) against the indexed owner topic[1]. A
    # well-formed GPv2 Trade event derives both the indexed topic and the
    # orderUid-embedded owner from the same signed order, so a disagreement
    # means the event is internally inconsistent (forged or malformed) — raise
    # the decoder-contract error rather than silently trusting the topic.
    # Also extract validTo (last 4 bytes as uint32 BE).
    valid_to: int | None = None
    if uid_length == 56:
        # owner = orderUid bytes 32:52 (raw 20-byte address) = hex chars 64:104.
        embedded_owner = Address.from_str("0x" + uid_hex[64:104], chain)
        if embedded_owner != owner:
            raise _validation_error(
                f"CoW Protocol Trade event owner topic {owner.value} disagrees "
                f"with orderUid-embedded owner {embedded_owner.value}"
            )
        valid_to = int(uid_hex[-8:], 16)
    return _TradeFields(
        owner=owner,
        sell_token=sell_token,
        buy_token=buy_token,
        sell_amount=sell_amount,
        buy_amount=buy_amount,
        fee_amount=fee_amount,
        order_uid=order_uid,
        valid_to=valid_to,
    )


def _find_action_transfer(
    logs: tuple[NormalizedLog, ...],
    *,
    asset: Address,
    expected_from: Address,
    expected_to: Address,
) -> NormalizedLog | None:
    """First ERC-20 ``Transfer`` from ``asset`` matching from/to (D-2 absent OK)."""
    chain = asset.chain
    for log in logs:
        if not log.topics or log.topics[0] != _ERC20_TRANSFER_TOPIC:
            continue
        if log.address != asset:
            continue
        if len(log.topics) < 3:
            continue
        log_from = _topic_address(log.topics[1], chain)
        log_to = _topic_address(log.topics[2], chain)
        if log_from == expected_from and log_to == expected_to:
            return log
    return None


def _assert_sell_coherence(
    *,
    sell_amount: int,
    fee_amount: int,
    transfer_log: NormalizedLog | None,
) -> None:
    """R-1: sell-side ``Transfer.value == sellAmount + feeAmount``.

    In CoW Protocol settlements, the user→vault_relayer Transfer carries
    the gross amount (sellAmount + feeAmount); the fee is captured by the
    protocol before settlement. D-2 missing Transfer is allowed (e.g.,
    native-ETH-wrapped flows where the WETH wrap is performed by the
    settlement contract inside an interaction hook).
    """
    if transfer_log is None:
        return
    # Length guard before ``int("", 16)`` so a malformed Transfer raises
    # ValidationError (decoder contract) not raw ValueError.
    expected_transfer_data_hex_len = 2 + 64
    if len(transfer_log.data) < expected_transfer_data_hex_len:
        raise _validation_error(
            f"CoW Protocol sell-side Transfer log data too short: "
            f"{len(transfer_log.data)} < {expected_transfer_data_hex_len}"
        )
    log_value = _read_uint256_word(transfer_log.data, 0)
    expected = sell_amount + fee_amount
    if log_value != expected:
        raise _validation_error(
            f"CoW Protocol sell-side Transfer.value mismatch: "
            f"log_value={log_value}, expected={expected} "
            f"(sellAmount={sell_amount}, feeAmount={fee_amount})"
        )


def _assert_buy_coherence(
    *,
    buy_amount: int,
    transfer_log: NormalizedLog | None,
) -> None:
    """R-1: buy-side ``Transfer.value == buyAmount``."""
    if transfer_log is None:
        return
    # Length guard before ``int("", 16)`` so a malformed Transfer raises
    # ValidationError (decoder contract) not raw ValueError.
    expected_transfer_data_hex_len = 2 + 64
    if len(transfer_log.data) < expected_transfer_data_hex_len:
        raise _validation_error(
            f"CoW Protocol buy-side Transfer log data too short: "
            f"{len(transfer_log.data)} < {expected_transfer_data_hex_len}"
        )
    log_value = _read_uint256_word(transfer_log.data, 0)
    if log_value != buy_amount:
        raise _validation_error(
            f"CoW Protocol buy-side Transfer.value mismatch: "
            f"log_value={log_value}, buyAmount={buy_amount}"
        )


def _select_amount_match(
    logs: tuple[NormalizedLog, ...],
    *,
    token: Address,
    expected_amount: int,
    from_addr: Address | None,
    to_addr: Address | None,
    chain: ChainId,
    consumed_log_ids: set[int],
    side: str,
) -> NormalizedLog | None:
    """Codex P2 finding 3: pick the matching candidate Transfer by amount.

    Scan ``logs`` for ERC-20 ``Transfer`` events emitted at ``token`` whose
    ``(from, to)`` matches the (optional) constraints and that have NOT
    been consumed by an earlier Trade. Return the FIRST candidate whose
    ``value`` equals ``expected_amount``.

    Returns ``None`` when no candidate Transfer log is present at all
    (D-2 absent OK — native-ETH wrap inside settle interactions, etc.).
    Raises :class:`pydantic.ValidationError` when at least one candidate
    matched the (asset, from, to) criteria but NONE matched
    ``expected_amount`` — the legacy pre-fix coherence-mismatch behaviour
    is preserved when the receipt truly has no acceptable Transfer.

    Consumed logs (already paired with a prior Trade in the same batch)
    still count toward ``candidates_seen`` so a later Trade with the
    same ``(token, from, to)`` shape but a different amount cannot
    silently degrade from "amount mismatch" to "no Transfer at all"
    when the batch lacks its own dedicated Transfer.
    """
    candidates_seen = 0
    last_value: int | None = None
    for log in logs:
        if not log.topics or log.topics[0] != _ERC20_TRANSFER_TOPIC:
            continue
        if log.address != token:
            continue
        if len(log.topics) < 3:
            continue
        log_from = _topic_address(log.topics[1], chain)
        log_to = _topic_address(log.topics[2], chain)
        if from_addr is not None and log_from != from_addr:
            continue
        if to_addr is not None and log_to != to_addr:
            continue
        # Count toward candidates_seen BEFORE the consumed-log skip — a
        # Transfer that already paired with a prior Trade still proves
        # the receipt carries a Transfer of this shape, so a missing
        # second-Trade Transfer is a malformed batch (codex P2 follow-up).
        candidates_seen += 1
        if id(log) in consumed_log_ids:
            continue
        # Length guard before ``int("", 16)`` — a candidate Transfer with
        # ``data="0x"`` (or truncated, dropping high-order bytes) would
        # otherwise raise a raw ``ValueError`` or silently mis-select on a
        # wrong-low value. Raise the decoder-contract ValidationError so a
        # malformed candidate is rejected, never silently chosen.
        expected_transfer_data_hex_len = 2 + 64
        if len(log.data) < expected_transfer_data_hex_len:
            raise _validation_error(
                f"CoW Protocol {side}-side candidate Transfer log data too "
                f"short: {len(log.data)} < {expected_transfer_data_hex_len}"
            )
        log_value = _read_uint256_word(log.data, 0)
        if log_value == expected_amount:
            return log
        last_value = log_value
    if candidates_seen == 0:
        return None
    # At least one candidate matched the (asset, from, to) constraints
    # but none had the expected amount (or the only candidates were
    # already consumed by prior Trades). Preserve the legacy mismatch
    # signal so amount-wise malformed batches still raise.
    raise _validation_error(
        f"CoW Protocol {side}-side Transfer.value mismatch: no candidate "
        f"matched expected={expected_amount} across {candidates_seen} "
        f"Transfer log(s) (last_value={last_value})"
    )


# Slice B / C — Decoder model.


class CowProtocolDecoder(BaseModel):
    """Pydantic v2 :class:`BridgeDecoder` for CoW Protocol GPv2Settlement
    batch settlements (event-driven: Trade events are the truth, and a
    single settle TX may emit multiple Trade events → multiple actions)."""

    model_config = _FROZEN_CONFIG

    name: str = COW_PROTOCOL_DECODER_NAME
    priority: int = 130
    config: CowProtocolDecoderConfig = Field(default_factory=CowProtocolDecoderConfig)

    def matches(self, tx: NormalizedTransaction) -> bool:
        """Three-arm AND predicate (R-SETTLEMENT-WHITELIST-TRIPWIRE on arm 2)."""
        settlements = self.config.settlement_addresses.get(tx.chain)
        if settlements is None or not settlements:
            return False
        if tx.to_addr is None or tx.to_addr not in settlements:
            return False
        input_hex = tx.input
        if input_hex is None or len(input_hex) < 10:
            return False
        return input_hex[:10].lower() in _COW_PROTOCOL_SELECTORS

    def decode(
        self,
        tx: NormalizedTransaction,
        logs: tuple[NormalizedLog, ...],
    ) -> tuple[DefiAction, ...]:
        """Decode + cross-validate; emit one :class:`DefiAction` per Trade event.

        Multi-Trade batches (codex P2 finding 3): each Trade event scans
        ALL candidate ``Transfer`` logs whose ``(asset, from, to)`` matches
        the trade direction, selects the one whose ``value`` matches the
        expected amount, and marks it consumed so later Trades don't
        re-pair the same log. Pre-fix, the decoder picked the first
        ``(asset, owner→*)`` Transfer and raised on amount mismatch,
        preventing Trade #N+1 from finding its own matching Transfer.
        """
        if not self.matches(tx):
            return ()
        assert tx.to_addr is not None  # proven by ``matches`` arm 2
        settlement = tx.to_addr

        trades = _find_trade_events(logs, settlement=settlement)
        if not trades:
            return ()

        # Track Transfer logs consumed by prior Trade events in this batch
        # so the same log is never paired with two Trades (codex P2 fix).
        # Identity comparison is safe because the logs come from an
        # immutable input tuple.
        consumed_log_ids: set[int] = set()

        actions: list[DefiAction] = []
        for trade_log in trades:
            fields = _parse_trade_payload(trade_log, chain=tx.chain)
            if fields.sell_amount == 0:
                raise _validation_error(
                    "CoW Protocol sellAmount=0 is impossible in well-formed Trade event"
                )
            if fields.buy_amount == 0:
                raise _validation_error(
                    "CoW Protocol buyAmount=0 is impossible in well-formed Trade event"
                )
            if fields.sell_token not in self.config.asset_decimals:
                continue
            decimals = self.config.asset_decimals[fields.sell_token]
            symbol = self.config.asset_symbols.get(fields.sell_token, _PLACEHOLDER_ASSET_SYMBOL)
            asset = Asset(
                chain=tx.chain,
                symbol=symbol,
                decimals=decimals,
                contract=fields.sell_token,
            )

            # R-1: sell-side Transfer cross-validation (owner → any
            # destination — vault_relayer in modern CoW, settlement in
            # older deployments). Scan ALL Transfer logs whose
            # ``(asset, from)`` matches; pick the one whose value equals
            # ``sellAmount + feeAmount``. Returns ``None`` when no
            # candidate matches AND none were observed at all (D-2 absent
            # OK); raises when candidates exist but none match the
            # expected amount.
            sell_match = _select_amount_match(
                logs,
                token=fields.sell_token,
                expected_amount=fields.sell_amount + fields.fee_amount,
                from_addr=fields.owner,
                to_addr=None,
                chain=tx.chain,
                consumed_log_ids=consumed_log_ids,
                side="sell",
            )
            if sell_match is not None:
                consumed_log_ids.add(id(sell_match))

            # R-1: buy-side Transfer cross-validation (any source → owner)
            # mirroring the sell-side scan: pick the candidate whose value
            # equals ``buyAmount``.
            buy_match = _select_amount_match(
                logs,
                token=fields.buy_token,
                expected_amount=fields.buy_amount,
                from_addr=None,
                to_addr=fields.owner,
                chain=tx.chain,
                consumed_log_ids=consumed_log_ids,
                side="buy",
            )
            if buy_match is not None:
                consumed_log_ids.add(id(buy_match))

            extras: dict[str, object] = {
                "function": "settle",
                "kind_override": _KIND_OVERRIDE,
                "router": _ROUTER_TAG,
                "sell_token": fields.sell_token.value,
                "buy_token": fields.buy_token.value,
                "buy_amount": str(fields.buy_amount),
                "fee_amount": str(fields.fee_amount),
                "order_uid": fields.order_uid,
                "owner": fields.owner.value,
            }
            if fields.valid_to is not None:
                extras["valid_to"] = fields.valid_to

            action = DefiAction(
                kind=DefiActionKind.COLLATERAL_WITHDRAW,
                chain=tx.chain,
                protocol=COW_PROTOCOL_DECODER_NAME,
                asset=asset,
                amount=Amount(raw=fields.sell_amount, decimals=decimals),
                actor=fields.owner,
                pool=settlement,
                extras=extras,
            )
            actions.append(action)
        return tuple(actions)


def register_cow_protocol_decoder(
    config: CowProtocolDecoderConfig | None = None,
) -> CowProtocolDecoder:
    """Construct and register the CoW Protocol decoder on the singleton registry."""
    decoder = CowProtocolDecoder() if config is None else CowProtocolDecoder(config=config)
    register_decoder(decoder)
    return decoder
