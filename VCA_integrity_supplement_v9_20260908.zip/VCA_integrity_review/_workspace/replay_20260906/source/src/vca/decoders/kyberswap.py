"""KyberSwap Meta Aggregation Router v2 decoder (P2-001.0c).

Group A pre-pend decoder #3. Mirrors P2-001.0a/0b patterns but is
**event-driven**: calldata gates only on the 2 function selectors; the
canonical truth (srcToken/dstToken/spentAmount/returnAmount/dstReceiver)
lives in the ``Swapped`` event emitted by the router.

OCR-Anchors (P2-001.1.1 audit, 2026-05-13)
------------------------------------------
The supplement PDF ``KelpDAO_rsETH_Exploit_update.pdf`` page 14 quotes
the router address as
``0x6131B5fae19EA469D964eAc0408EA408b66337b5`` (PDF OCR). The on-chain
Etherscan-verified canonical address (and the value carried by the
P1-021.1 Stage 2 dispersal cassette ``stage2_dispersal_0xbb6a_txs``)
is ``0x6131B5fae19EA4f9D964eAc0408E4408b66337b5``. The OCR drift is
two hex digits (``469``→``4f9`` at position 11, ``EA408``→``E4408`` at
position 26); self-consistent test pins replicated the typo through
100% coverage + codex review GREEN before the P2-001.1 manifest fix
surfaced it. Per the R-CASSETTE-TRUTH-OVER-PDF priority ladder, this
module pins the **cassette truth** (``EA4f9…E4408``); the PDF form is
documented here for audit-trail completeness only.

Router (mainnet) ``0x6131B5fae19EA4f9D964eAc0408E4408b66337b5``:

* ``swap(SwapExecutionParams)``                              → 0xe21fd0e9
* ``swapSimpleMode(address,SwapDescriptionV2,bytes,bytes)``  → 0x8af033fb
* Event ``Swapped(address,address,address,address,uint256,uint256)``
                                                             → 0xd6d4f568…

Action kind: closest-fit ``COLLATERAL_SUPPLY`` (closed Phase-1 enum;
0 new values). **P3.2-003a CONSCIOUS RE-PIN** (was ``COLLATERAL_WITHDRAW``
while the decoder was synthetic-only): the action models the
``spentAmount`` leg — srcToken flowing **actor → router** — and the
tracer's ``_make_defi_edge`` renders SUPPLY/REPAY as ``actor → pool``
vs BORROW/WITHDRAW as ``pool → actor``. The old WITHDRAW pin therefore
produced an INVERTED FlowEdge (``router → wallet`` rsETH) on the live
cassettes, fabricating an incoming-transfer neighbourhood for the swap
wallet (on the wired trace it pushed the wallet's Stage-2 dispersal
edge into the fan-in window — a real misclassification, not cosmetic).
Stage classification itself is unaffected by the base kind: rank-4
``is_kind_override`` claims the edge via
``extras["kind_override"]="swap"``. Swap semantics carried in
``extras``: ``function``, ``kind_override="swap"``,
``router="kyberswap_aggregator_v2"``, ``src_token``, ``dst_token``,
``dst_receiver``, ``dst_amount``.

Swapped data layout — CONSCIOUS RE-PIN (P3.2-003a, 2026-06-13)
--------------------------------------------------------------
The original synthetic fixtures (P2-001.0c) assumed ``sender`` was an
*indexed* event parameter (``topics = (sig, sender)``) and the ``data``
payload was 5 non-indexed words
``(srcToken, dstToken, dstReceiver, spentAmount, returnAmount)``. The
live cassette truth (R-CASSETTE-TRUTH-OVER-PDF / P1-009 doctrine:
cassette bytes > synthetic guess) contradicts this: across all 4 Stage
3-A anchors the ``Swapped`` log carries ``topics = (sig,)`` — **nothing
is indexed** — and ``data`` is 6 words with ``sender`` at word 0:

    w0 = sender        w1 = srcToken     w2 = dstToken
    w3 = dstReceiver   w4 = spentAmount  w5 = returnAmount

Source of truth (4 cassette pairs): ``tests/fixtures/kelpdao/cassettes/
ethereum/stage3a_e2_{1..4}_{tx,logs}.yaml`` — TXs
``0x9d71b08a…fa01`` / ``0xd4dcf23f…2dd3`` / ``0xb052c5c7…b287d`` /
``0xad8716d1…0d7e``, emitter = router, selector ``0xe21fd0e9``. The
prior synthetic layout is no longer tolerated (a 5-word log now fails
the short-data length guard). ``sender`` (w0) is intentionally skipped
(actor is sourced from ``tx.from_addr``, which equals the on-chain
sender in every anchor).

Pure: no I/O, no clock, no env.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Final

from eth_utils import keccak  # type: ignore[attr-defined]
from pydantic import BaseModel, Field, ValidationError

from vca.decoders.base import DefiAction, DefiActionKind
from vca.decoders.registry import register_decoder
from vca.types import (
    Address,
    Amount,
    Asset,
    ChainId,
    NormalizedLog,
    NormalizedTransaction,
)
from vca.types.normalized import _FROZEN_CONFIG

__all__ = [
    "KYBERSWAP_DECODER_NAME",
    "KyberSwapDecoder",
    "KyberSwapDecoderConfig",
    "register_kyberswap_decoder",
]


# Slice A — Constants (R-SELECTOR-TRIPWIRE; Etherscan-verified).
_SWAP_SIG: Final[str] = (
    "swap((address,address,bytes,"
    "(address,address,address[],uint256[],address[],uint256[],"
    "address,uint256,uint256,uint256,bytes),bytes))"
)
_SWAP_SIMPLE_MODE_SIG: Final[str] = (
    "swapSimpleMode(address,"
    "(address,address,address[],uint256[],address[],uint256[],"
    "address,uint256,uint256,uint256,bytes),bytes,bytes)"
)
_SWAPPED_EVENT_SIG: Final[str] = "Swapped(address,address,address,address,uint256,uint256)"
_TRANSFER_SIG: Final[str] = "Transfer(address,address,uint256)"


def _selector(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()[:8]


def _topic(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()


_SWAP_SELECTOR: Final[str] = _selector(_SWAP_SIG)
_SWAP_SIMPLE_MODE_SELECTOR: Final[str] = _selector(_SWAP_SIMPLE_MODE_SIG)
_SWAPPED_TOPIC: Final[str] = _topic(_SWAPPED_EVENT_SIG)
_ERC20_TRANSFER_TOPIC: Final[str] = _topic(_TRANSFER_SIG)

# Import-time keccak pin; any ABI/keccak drift fails at first import.
_EXPECTED_SELECTORS: Final[Mapping[str, str]] = MappingProxyType(
    {
        _SWAP_SIG: "0xe21fd0e9",
        _SWAP_SIMPLE_MODE_SIG: "0x8af033fb",
    }
)
for _sig, _expected in _EXPECTED_SELECTORS.items():
    if _selector(_sig) != _expected:  # pragma: no cover - import-time tripwire
        raise RuntimeError(
            f"KyberSwap selector drift for {_sig!r}: "
            f"{_selector(_sig)!r} (expected {_expected!r}). "
            "Refusing module import — investigate KyberSwap ABI or eth_utils.keccak."
        )

_KYBERSWAP_SELECTORS: Final[frozenset[str]] = frozenset(
    {_SWAP_SELECTOR, _SWAP_SIMPLE_MODE_SELECTOR}
)

# Selector → human-readable function name for ``extras["function"]``.
_SELECTOR_TO_FUNCTION_NAME: Final[Mapping[str, str]] = MappingProxyType(
    {_SWAP_SELECTOR: "swap", _SWAP_SIMPLE_MODE_SELECTOR: "swapSimpleMode"}
)

# Mainnet router — cassette truth (P2-001.1.1 audit; see module docstring
# § OCR-Anchors for the PDF OCR drift contrast). Etherscan-verified.
_KYBER_ROUTER_V2_ETH: Final[Address] = Address.from_str(
    "0x6131B5fae19EA4f9D964eAc0408E4408b66337b5", ChainId.ETHEREUM
)
_DEFAULT_ROUTER_ADDRESSES: Final[Mapping[ChainId, frozenset[Address]]] = MappingProxyType(
    {ChainId.ETHEREUM: frozenset({_KYBER_ROUTER_V2_ETH})}
)
_DEFAULT_ASSET_DECIMALS: Final[Mapping[Address, int]] = MappingProxyType({})
_DEFAULT_ASSET_SYMBOLS: Final[Mapping[Address, str]] = MappingProxyType({})
_PLACEHOLDER_ASSET_SYMBOL: Final[str] = "KYBERSWAP_ASSET"
_ROUTER_TAG: Final[str] = "kyberswap_aggregator_v2"
# P2-DECODER-KIND-OVERRIDE-LITERAL-SSOT.1 (Cycle 28): module-level Final[str]
# SSOT for the ``extras["kind_override"]`` value emitted on every swap ->
# DefiAction. MUST byte-equal one of the consumer-side values in
# :data:`vca.tracer.stage_classifier._vocab._KNOWN_KIND_OVERRIDES`; a 1-byte
# drift here silently defers the rank-4 ``is_kind_override`` heuristic and
# mis-classifies the KyberSwap edge into the fallback ranks.
_KIND_OVERRIDE: Final[str] = "swap"
KYBERSWAP_DECODER_NAME: Final[str] = "kyberswap"


@dataclass(frozen=True, slots=True)
class KyberSwapDecoderConfig:
    """Phase-2 KyberSwap config. Wrap overrides in ``MappingProxyType``.
    ``router_addresses`` ships mainnet router pre-pinned
    (R-ROUTER-WHITELIST-TRIPWIRE); asset tables empty until P2-001 stage
    vertical injects rsETH/ETH/DAI/USDC entries."""

    router_addresses: Mapping[ChainId, frozenset[Address]] = field(
        default=_DEFAULT_ROUTER_ADDRESSES
    )
    asset_decimals: Mapping[Address, int] = field(default=_DEFAULT_ASSET_DECIMALS)
    asset_symbols: Mapping[Address, str] = field(default=_DEFAULT_ASSET_SYMBOLS)


# Slice C — Pure helpers.


def _validation_error(msg: str) -> ValidationError:
    """Wrap ``msg`` in :class:`pydantic.ValidationError`."""

    class _GuardModel(BaseModel):
        model_config = _FROZEN_CONFIG
        marker: str

    try:
        _GuardModel(marker=msg, extra_field_that_does_not_exist=True)  # type: ignore[call-arg]
    except ValidationError as exc:
        return exc
    raise RuntimeError("validation guard failed to raise")  # pragma: no cover


def _topic_address(topic: str, chain: ChainId) -> Address | None:
    """32-byte indexed-address topic word → :class:`Address`. Returns
    ``None`` when the top 12 bytes are not zero-padded."""
    if any(c != "0" for c in topic[2:26]):
        return None
    return Address.from_str("0x" + topic[26:], chain)


def _read_uint256_word(data_hex: str, word_index: int) -> int:
    offset = 2 + word_index * 64  # skip '0x'
    return int(data_hex[offset : offset + 64], 16)


def _data_word_address(data_hex: str, word_index: int, chain: ChainId) -> Address:
    """Read a 32-byte zero-padded address word from event ``data``.

    Raises :class:`pydantic.ValidationError` when the top 12 bytes are not
    zero-padded — a malformed positional address word means the Swapped
    event is malformed (unlike :func:`_topic_address`, which tolerates dirty
    topic padding by returning ``None``)."""
    offset = 2 + word_index * 64
    word = data_hex[offset : offset + 64]
    if any(c != "0" for c in word[:24]):
        raise _validation_error(
            f"KyberSwap event data address word {word_index} malformed "
            f"(non-zero upper 12 bytes): {word!r}"
        )
    return Address.from_str("0x" + word[24:], chain)


def _find_swapped_event(
    logs: tuple[NormalizedLog, ...],
    *,
    router: Address,
) -> NormalizedLog | None:
    """First ``Swapped`` event emitted at the router address (D-2 absent OK)."""
    for log in logs:
        if not log.topics:
            continue
        if log.topics[0] != _SWAPPED_TOPIC:
            continue
        if log.address != router:
            continue
        return log
    return None


def _parse_swapped_payload(
    log: NormalizedLog, *, chain: ChainId
) -> tuple[Address, Address, Address, int, int]:
    """``Swapped`` data → ``(srcToken, dstToken, dstReceiver,
    spentAmount, returnAmount)``.

    Cassette truth (P3.2-003a re-pin; see module docstring § Swapped data
    layout): the ``Swapped`` event indexes **nothing** — ``topics = (sig,)``
    — and ``data`` is six 32-byte words ``(sender, srcToken, dstToken,
    dstReceiver, spentAmount, returnAmount)``. Word 0 (``sender``) is
    intentionally skipped (the actor is taken from ``tx.from_addr``). Raises
    :class:`pydantic.ValidationError` on short data — the prior synthetic
    5-word layout is no longer tolerated."""
    expected_hex_len = 2 + 6 * 64
    if len(log.data) < expected_hex_len:
        raise _validation_error(
            f"KyberSwap Swapped event data too short: {len(log.data)} < {expected_hex_len}"
        )
    src_token = _data_word_address(log.data, 1, chain)
    dst_token = _data_word_address(log.data, 2, chain)
    dst_receiver = _data_word_address(log.data, 3, chain)
    spent_amount = _read_uint256_word(log.data, 4)
    return_amount = _read_uint256_word(log.data, 5)
    return src_token, dst_token, dst_receiver, spent_amount, return_amount


def _find_action_transfer(
    logs: tuple[NormalizedLog, ...],
    *,
    asset: Address,
    expected_from: Address,
    expected_to: Address,
) -> NormalizedLog | None:
    """First ERC-20 ``Transfer`` from ``asset`` matching from/to (D-2 absent OK)."""
    chain = asset.chain
    for log in logs:
        if not log.topics or log.topics[0] != _ERC20_TRANSFER_TOPIC:
            continue
        if log.address != asset:
            continue
        if len(log.topics) < 3:
            continue
        log_from = _topic_address(log.topics[1], chain)
        log_to = _topic_address(log.topics[2], chain)
        if log_from == expected_from and log_to == expected_to:
            return log
    return None


def _assert_amount_coherence(
    *,
    event_amount: int,
    transfer_log: NormalizedLog | None,
) -> None:
    """R-1: Transfer.value == Swapped.spentAmount; D-2 missing-log no-ops
    (native-ETH swaps emit no source-side ERC-20 Transfer)."""
    if transfer_log is None:
        return
    log_value = _read_uint256_word(transfer_log.data, 0)
    if log_value != event_amount:
        raise _validation_error(
            f"KyberSwap Transfer.value mismatch: "
            f"log_value={log_value}, swapped.spentAmount={event_amount}"
        )


# Slice B / C — Decoder model.


class KyberSwapDecoder(BaseModel):
    """Pydantic v2 :class:`BridgeDecoder` for KyberSwap Meta Aggregation
    Router v2 swaps (event-driven: Swapped event is the truth)."""

    model_config = _FROZEN_CONFIG

    name: str = KYBERSWAP_DECODER_NAME
    priority: int = 130
    config: KyberSwapDecoderConfig = Field(default_factory=KyberSwapDecoderConfig)

    def matches(self, tx: NormalizedTransaction) -> bool:
        """Four-arm AND predicate (R-ROUTER-WHITELIST-TRIPWIRE on arm 2)."""
        routers = self.config.router_addresses.get(tx.chain)
        if routers is None or not routers:
            return False
        if tx.to_addr is None or tx.to_addr not in routers:
            return False
        input_hex = tx.input
        if input_hex is None or len(input_hex) < 10:
            return False
        return input_hex[:10].lower() in _KYBERSWAP_SELECTORS

    def decode(
        self,
        tx: NormalizedTransaction,
        logs: tuple[NormalizedLog, ...],
    ) -> tuple[DefiAction, ...]:
        """Decode + cross-validate; emit one :class:`DefiAction` or ``()``."""
        if not self.matches(tx):
            return ()
        assert tx.input is not None
        assert tx.from_addr is not None
        assert tx.to_addr is not None
        selector = tx.input[:10].lower()
        router = tx.to_addr

        swapped = _find_swapped_event(logs, router=router)
        if swapped is None:
            raise _validation_error(
                f"KyberSwap swap TX missing required Swapped event at router {router.value}"
            )

        src_token, dst_token, dst_receiver, spent_amount, return_amount = _parse_swapped_payload(
            swapped, chain=tx.chain
        )
        if spent_amount == 0:
            raise _validation_error(
                "KyberSwap spentAmount=0 is impossible in well-formed Swapped event"
            )
        if return_amount == 0:
            raise _validation_error(
                "KyberSwap returnAmount=0 is impossible in well-formed Swapped event"
            )

        if src_token not in self.config.asset_decimals:
            return ()
        decimals = self.config.asset_decimals[src_token]
        symbol = self.config.asset_symbols.get(src_token, _PLACEHOLDER_ASSET_SYMBOL)
        asset = Asset(chain=tx.chain, symbol=symbol, decimals=decimals, contract=src_token)

        # R-1: cross-validate src-side ERC-20 Transfer against
        # Swapped.spentAmount. D-2: missing Transfer is allowed (native
        # ETH source via msg.value emits no ERC-20 log).
        transfer_log = _find_action_transfer(
            logs,
            asset=src_token,
            expected_from=tx.from_addr,
            expected_to=router,
        )
        # Length guard before the coherence word-0 read — a malformed
        # ``Transfer`` log with ``data="0x"`` would otherwise raise a raw
        # ``ValueError`` from ``int("", 16)`` instead of the decoder's
        # contract-level :class:`pydantic.ValidationError`. Guarded at the
        # call site (the ``_assert_amount_coherence`` body is SSOT-pinned).
        if transfer_log is not None:
            expected_transfer_data_hex_len = 2 + 64
            if len(transfer_log.data) < expected_transfer_data_hex_len:
                raise _validation_error(
                    f"KyberSwap Transfer log data too short: "
                    f"{len(transfer_log.data)} < {expected_transfer_data_hex_len}"
                )
        _assert_amount_coherence(event_amount=spent_amount, transfer_log=transfer_log)

        function_name = _SELECTOR_TO_FUNCTION_NAME[selector]
        action = DefiAction(
            # P3.2-003a conscious re-pin (see module docstring): SUPPLY
            # renders the FlowEdge actor -> router, matching the
            # spentAmount leg's real direction; WITHDRAW inverted it.
            kind=DefiActionKind.COLLATERAL_SUPPLY,
            chain=tx.chain,
            protocol=KYBERSWAP_DECODER_NAME,
            asset=asset,
            amount=Amount(raw=spent_amount, decimals=decimals),
            actor=tx.from_addr,
            pool=router,
            extras={
                "function": function_name,
                "kind_override": _KIND_OVERRIDE,
                "router": _ROUTER_TAG,
                "src_token": src_token.value,
                "dst_token": dst_token.value,
                "dst_receiver": dst_receiver.value,
                "dst_amount": str(return_amount),
            },
        )
        return (action,)


def register_kyberswap_decoder(
    config: KyberSwapDecoderConfig | None = None,
) -> KyberSwapDecoder:
    """Construct and register the KyberSwap decoder on the singleton registry."""
    decoder = KyberSwapDecoder() if config is None else KyberSwapDecoder(config=config)
    register_decoder(decoder)
    return decoder
