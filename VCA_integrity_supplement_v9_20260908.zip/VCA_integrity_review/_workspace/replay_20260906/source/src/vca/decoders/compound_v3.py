"""Compound V3 (Comet) decoder (P2-001.0a).

First Group A pre-pend decoder for Phase 2 (Option C Hybrid critical path).

OCR-Anchors (P2-001.1.1 audit, 2026-05-13)
------------------------------------------
The supplement PDF ``KelpDAO_rsETH_Exploit_update.pdf`` page 11 quotes the
``cWETHv3`` market address as
``0xa17581a9c3356d9a858b789d68b4d866e503ae94`` (PDF OCR). The on-chain
Etherscan-verified canonical address (and the value carried by every
P1-021.1 Stage 2 dispersal cassette) is
``0xa17581a9e3356d9a858b789d68b4d866e593ae94``. The OCR drift is two
hex digits (``c3``→``e3`` at position 8, ``503``→``593`` at position 33);
self-consistent test pins replicated the typo through 100% coverage +
codex review GREEN before the P2-001.1 manifest fix surfaced it. Per
the R-CASSETTE-TRUTH-OVER-PDF priority ladder, this module pins the
**cassette truth** (``e3…e593ae94``); the PDF form is documented here
for audit-trail completeness only. Mirrors the same pattern used in
:mod:`vca.decoders.lz_multicall` for ``AcdDAC6C77318D615``.
Mirrors the P1-011 :mod:`vca.decoders.aave_v3` pattern: import-time keccak
tripwire, shared :data:`vca.decoders.abi_fallback.decode._CODEC`, ERC-20
``Transfer`` log cross-validation against synthetic fixtures (DoD-8 silent-
bug guardrail), frozen Pydantic config + :class:`DefiAction` emission.

R-FILE-CAP 350 WAIVE: this module ships a 5-selector + 3-event-topic
matrix and is therefore allowed to exceed the 350-LoC guideline. Precedent:
:mod:`vca.decoders.aave_v3` (P1-011, 386 LoC) covers 4 selectors;
:mod:`vca.decoders.thorchain` (P1-010, 444 LoC) covers 1 selector + a
memo grammar; Compound V3 has more selectors and an event-driven kind
discriminator, so a similar LoC budget is justified.

Compound III (Comet) is a single-base-asset money market deployed per
market (one Comet contract per base asset). Public functions decoded:

* ``supply(address asset, uint256 amount)``                              0xf2b9fdb8
* ``supplyTo(address dst, address asset, uint256 amount)``                0x4232cd63
* ``withdraw(address asset, uint256 amount)``                             0xf3fef3a3
* ``withdrawTo(address to, address asset, uint256 amount)``               0xc3b35a7e
* ``withdrawFrom(address src, address to, address asset, uint256 amount)`` 0x26441318

Event-driven action kind discrimination (silent-bug guardrail):

* ``Supply(address,address,uint256)``                   → COLLATERAL_SUPPLY
* ``Withdraw(address,address,uint256)``                 → BORROW
* ``WithdrawCollateral(address,address,address,uint256)`` → COLLATERAL_WITHDRAW

The ``Withdraw`` vs ``WithdrawCollateral`` event split tells us whether
the withdraw selector is operating on the base asset (``Withdraw``,
semantically a borrow when the account balance crosses zero) or on
collateral (``WithdrawCollateral``). PDF page 11 row 3 (``0x8ab3…``)
confirms: selector was ``withdraw(...)`` but the event was
``WithdrawCollateral`` because rsETH is collateral on cWETHv3.

Pure: no I/O, no clock, no env. Default markets pinned per Compound
public docs (Etherscan-verified labels).
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Final

from eth_utils import keccak  # type: ignore[attr-defined]
from pydantic import BaseModel, Field, ValidationError

from vca.decoders.abi_fallback.decode import _CODEC
from vca.decoders.base import DefiAction, DefiActionKind
from vca.decoders.registry import register_decoder
from vca.types import (
    Address,
    Amount,
    Asset,
    ChainId,
    NormalizedLog,
    NormalizedTransaction,
)
from vca.types.normalized import _FROZEN_CONFIG

__all__ = [
    "COMPOUND_V3_DECODER_NAME",
    "CompoundV3Decoder",
    "CompoundV3DecoderConfig",
    "register_compound_v3_decoder",
]


# ---------------------------------------------------------------------------
# Slice A — Constants pinned at module import (R-SELECTOR-TRIPWIRE)
# ---------------------------------------------------------------------------

_SUPPLY_SIG: Final[str] = "supply(address,uint256)"
_SUPPLY_TO_SIG: Final[str] = "supplyTo(address,address,uint256)"
_WITHDRAW_SIG: Final[str] = "withdraw(address,uint256)"
_WITHDRAW_TO_SIG: Final[str] = "withdrawTo(address,address,uint256)"
_WITHDRAW_FROM_SIG: Final[str] = "withdrawFrom(address,address,address,uint256)"

_SUPPLY_EVENT_SIG: Final[str] = "Supply(address,address,uint256)"
_WITHDRAW_EVENT_SIG: Final[str] = "Withdraw(address,address,uint256)"
_WITHDRAW_COLLATERAL_EVENT_SIG: Final[str] = "WithdrawCollateral(address,address,address,uint256)"
_TRANSFER_SIG: Final[str] = "Transfer(address,address,uint256)"


def _selector(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()[:8]


def _topic(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()


_SUPPLY_SELECTOR: Final[str] = _selector(_SUPPLY_SIG)
_SUPPLY_TO_SELECTOR: Final[str] = _selector(_SUPPLY_TO_SIG)
_WITHDRAW_SELECTOR: Final[str] = _selector(_WITHDRAW_SIG)
_WITHDRAW_TO_SELECTOR: Final[str] = _selector(_WITHDRAW_TO_SIG)
_WITHDRAW_FROM_SELECTOR: Final[str] = _selector(_WITHDRAW_FROM_SIG)

_SUPPLY_TOPIC: Final[str] = _topic(_SUPPLY_EVENT_SIG)
_WITHDRAW_TOPIC: Final[str] = _topic(_WITHDRAW_EVENT_SIG)
_WITHDRAW_COLLATERAL_TOPIC: Final[str] = _topic(_WITHDRAW_COLLATERAL_EVENT_SIG)
_ERC20_TRANSFER_TOPIC: Final[str] = _topic(_TRANSFER_SIG)

# R-SELECTOR-TRIPWIRE: import-time keccak pin. Any drift in
# ``eth_utils.keccak`` or the Compound V3 ABI fails at first module import.
_EXPECTED_SELECTORS: Final[Mapping[str, str]] = MappingProxyType(
    {
        _SUPPLY_SIG: "0xf2b9fdb8",
        _SUPPLY_TO_SIG: "0x4232cd63",
        _WITHDRAW_SIG: "0xf3fef3a3",
        _WITHDRAW_TO_SIG: "0xc3b35a7e",
        _WITHDRAW_FROM_SIG: "0x26441318",
    }
)
for _sig, _expected in _EXPECTED_SELECTORS.items():
    if _selector(_sig) != _expected:  # pragma: no cover - import-time tripwire
        raise RuntimeError(
            f"Compound V3 selector drift for {_sig!r}: "
            f"{_selector(_sig)!r} (expected {_expected!r}). "
            "Refusing module import — investigate Compound ABI or eth_utils.keccak."
        )

_COMPOUND_V3_SELECTORS: Final[frozenset[str]] = frozenset(
    {
        _SUPPLY_SELECTOR,
        _SUPPLY_TO_SELECTOR,
        _WITHDRAW_SELECTOR,
        _WITHDRAW_TO_SELECTOR,
        _WITHDRAW_FROM_SELECTOR,
    }
)

# Selector → ABI head types (shared :data:`_CODEC`).
_COMPOUND_V3_HEAD_TYPES: Final[Mapping[str, tuple[str, ...]]] = MappingProxyType(
    {
        _SUPPLY_SELECTOR: ("address", "uint256"),
        _SUPPLY_TO_SELECTOR: ("address", "address", "uint256"),
        _WITHDRAW_SELECTOR: ("address", "uint256"),
        _WITHDRAW_TO_SELECTOR: ("address", "address", "uint256"),
        _WITHDRAW_FROM_SELECTOR: ("address", "address", "address", "uint256"),
    }
)

# Selector → human-readable function name for the ``extras["function"]`` tag.
_SELECTOR_TO_FUNCTION_NAME: Final[Mapping[str, str]] = MappingProxyType(
    {
        _SUPPLY_SELECTOR: "supply",
        _SUPPLY_TO_SELECTOR: "supplyTo",
        _WITHDRAW_SELECTOR: "withdraw",
        _WITHDRAW_TO_SELECTOR: "withdrawTo",
        _WITHDRAW_FROM_SELECTOR: "withdrawFrom",
    }
)

# Selector families — supply* group has different default kind than withdraw*.
_SUPPLY_FAMILY: Final[frozenset[str]] = frozenset({_SUPPLY_SELECTOR, _SUPPLY_TO_SELECTOR})

# Compound V3 Comet market addresses — verified from supplement PDF page 11
# (Etherscan labels: "Compound: cWETHv3" / "Compound: cWstETHv3").
_CWETHV3: Final[Address] = Address.from_str(
    "0xa17581a9e3356d9a858b789d68b4d866e593ae94", ChainId.ETHEREUM
)
_CWSTETHV3: Final[Address] = Address.from_str(
    "0x3D0bb1ccaB520A66e607822fC55BC921738fAFE3", ChainId.ETHEREUM
)
_WETH: Final[Address] = Address.from_str(
    "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2", ChainId.ETHEREUM
)
_WSTETH: Final[Address] = Address.from_str(
    "0x7f39C581F595B53c5cb19bD0b3f8dA6c935E2Ca0", ChainId.ETHEREUM
)

_DEFAULT_MARKETS: Final[Mapping[ChainId, frozenset[Address]]] = MappingProxyType(
    {ChainId.ETHEREUM: frozenset({_CWETHV3, _CWSTETHV3})}
)

# Per-market base asset. ``Withdraw`` (vs ``WithdrawCollateral``) events fire
# only when the asset being withdrawn equals the market's base asset, in
# which case the action is semantically a BORROW.
_DEFAULT_MARKET_BASE_ASSETS: Final[Mapping[ChainId, Mapping[Address, Address]]] = MappingProxyType(
    {
        ChainId.ETHEREUM: MappingProxyType(
            {
                _CWETHV3: _WETH,
                _CWSTETHV3: _WSTETH,
            }
        )
    }
)

_DEFAULT_ASSET_DECIMALS: Final[Mapping[Address, int]] = MappingProxyType({})
_DEFAULT_ASSET_SYMBOLS: Final[Mapping[Address, str]] = MappingProxyType({})
_PLACEHOLDER_ASSET_SYMBOL: Final[str] = "COMPOUND_V3_ASSET"

COMPOUND_V3_DECODER_NAME: Final[str] = "compound_v3"


@dataclass(frozen=True, slots=True)
class CompoundV3DecoderConfig:
    """Phase-2 Compound V3 config. Callers MUST wrap overrides in
    ``MappingProxyType(...)`` to preserve immutability."""

    markets: Mapping[ChainId, frozenset[Address]] = field(default=_DEFAULT_MARKETS)
    market_base_assets: Mapping[ChainId, Mapping[Address, Address]] = field(
        default=_DEFAULT_MARKET_BASE_ASSETS
    )
    asset_decimals: Mapping[Address, int] = field(default=_DEFAULT_ASSET_DECIMALS)
    asset_symbols: Mapping[Address, str] = field(default=_DEFAULT_ASSET_SYMBOLS)


# ---------------------------------------------------------------------------
# Slice C — Pure helpers
# ---------------------------------------------------------------------------


def _validation_error(msg: str) -> ValidationError:
    """Wrap ``msg`` in :class:`pydantic.ValidationError`."""

    class _GuardModel(BaseModel):
        model_config = _FROZEN_CONFIG
        marker: str

    try:
        _GuardModel(marker=msg, extra_field_that_does_not_exist=True)  # type: ignore[call-arg]
    except ValidationError as exc:
        return exc
    raise RuntimeError("validation guard failed to raise")  # pragma: no cover


def _decode_compound_v3_calldata(selector: str, input_hex: str) -> tuple[Any, ...]:
    """Decode the per-selector ABI head via shared :data:`_CODEC`."""
    if not input_hex.startswith("0x") or len(input_hex) < 10:
        raise _validation_error(f"compound v3 calldata too short: len={len(input_hex)}")
    body_hex = input_hex[10:]
    if len(body_hex) % 64 != 0:
        raise _validation_error(
            f"compound v3 calldata body not 32-byte aligned: hex_len={len(body_hex)}"
        )
    try:
        body = bytes.fromhex(body_hex)
    except ValueError as exc:
        raise _validation_error(f"compound v3 calldata body is not valid hex: {exc}") from exc
    try:
        decoded = _CODEC.decode(_COMPOUND_V3_HEAD_TYPES[selector], body)
    except Exception as exc:
        raise _validation_error(
            f"compound v3 head decode failed for selector {selector!r}: {type(exc).__name__}: {exc}"
        ) from exc
    return tuple(decoded)


def _parse_head(
    selector: str, head: tuple[Any, ...], *, chain: ChainId, tx_from: Address
) -> tuple[str, int, Address]:
    """Return ``(asset_hex, amount, actor)`` for a Compound V3 calldata head.

    * ``supply(asset, amount)``                              → actor = tx.from_addr
    * ``supplyTo(dst, asset, amount)``                       → actor = dst
    * ``withdraw(asset, amount)``                            → actor = tx.from_addr
    * ``withdrawTo(to, asset, amount)``                      → actor = to
    * ``withdrawFrom(src, to, asset, amount)``               → actor = to
    """
    if selector in (_SUPPLY_SELECTOR, _WITHDRAW_SELECTOR):
        return str(head[0]), int(head[1]), tx_from
    if selector in (_SUPPLY_TO_SELECTOR, _WITHDRAW_TO_SELECTOR):
        return str(head[1]), int(head[2]), Address.from_str(str(head[0]), chain)
    # _WITHDRAW_FROM_SELECTOR: src, to, asset, amount
    return str(head[2]), int(head[3]), Address.from_str(str(head[1]), chain)


def _topic_address(topic: str, chain: ChainId) -> Address | None:
    """Convert a 32-byte indexed-address topic word to :class:`Address`."""
    if any(c != "0" for c in topic[2:26]):
        return None
    return Address.from_str("0x" + topic[26:], chain)


def _find_action_transfer(
    logs: tuple[NormalizedLog, ...],
    *,
    asset: Address,
    expected_from: Address,
    expected_to: Address,
) -> NormalizedLog | None:
    """First ERC-20 ``Transfer`` from ``asset`` matching from/to (D-2 absent OK)."""
    chain = asset.chain
    for log in logs:
        if not log.topics or log.topics[0] != _ERC20_TRANSFER_TOPIC:
            continue
        if log.address != asset:
            continue
        if len(log.topics) < 3:
            continue
        log_from = _topic_address(log.topics[1], chain)
        log_to = _topic_address(log.topics[2], chain)
        if log_from == expected_from and log_to == expected_to:
            return log
    return None


def _read_uint256_word(data_hex: str, word_index: int) -> int:
    offset = 2 + word_index * 64  # skip '0x'
    return int(data_hex[offset : offset + 64], 16)


def _assert_amount_coherence(
    *,
    decoded_amount: int,
    transfer_log: NormalizedLog | None,
) -> None:
    """R-1 cross-validation; D-2 missing-log no-ops."""
    if transfer_log is None:
        return
    log_value = _read_uint256_word(transfer_log.data, 0)
    if log_value != decoded_amount:
        raise _validation_error(
            f"Transfer.value mismatch: log_value={log_value}, calldata_amount={decoded_amount}"
        )


def _expected_transfer_endpoints(
    selector: str,
    *,
    tx_from: Address,
    market: Address,
    actor: Address,
) -> tuple[Address, Address]:
    """Per-action ``(from, to)`` Transfer endpoints.

    * supply / supplyTo  → user → market
    * withdraw* family   → market → actor (recipient)
    """
    if selector in _SUPPLY_FAMILY:
        return tx_from, market
    return market, actor


def _classify_action_kind(
    *,
    selector: str,
    logs: tuple[NormalizedLog, ...],
    market: Address,
) -> DefiActionKind:
    """Event-driven action kind discrimination.

    Inspects the emitted Compound V3 events on the ``market`` address:

    * ``Supply``               → :data:`DefiActionKind.COLLATERAL_SUPPLY`
    * ``WithdrawCollateral``   → :data:`DefiActionKind.COLLATERAL_WITHDRAW`
    * ``Withdraw`` (base only) → :data:`DefiActionKind.BORROW`

    Selector-only fallback when no matching event is present:

    * supply / supplyTo                         → COLLATERAL_SUPPLY
    * withdraw / withdrawTo / withdrawFrom      → COLLATERAL_WITHDRAW (safer
      than silently BORROW — downstream stage classifier treats the two
      differently and the absence of an event is the conservative path)
    """
    for log in logs:
        if log.address != market:
            continue
        if not log.topics:
            continue
        topic0 = log.topics[0]
        if topic0 == _SUPPLY_TOPIC:
            return DefiActionKind.COLLATERAL_SUPPLY
        if topic0 == _WITHDRAW_COLLATERAL_TOPIC:
            return DefiActionKind.COLLATERAL_WITHDRAW
        if topic0 == _WITHDRAW_TOPIC:
            return DefiActionKind.BORROW
    # Selector-only default.
    if selector in _SUPPLY_FAMILY:
        return DefiActionKind.COLLATERAL_SUPPLY
    return DefiActionKind.COLLATERAL_WITHDRAW


# ---------------------------------------------------------------------------
# Slice B / C — Decoder model
# ---------------------------------------------------------------------------


class CompoundV3Decoder(BaseModel):
    """Pydantic v2 :class:`BridgeDecoder` for Compound V3 (Comet) markets."""

    model_config = _FROZEN_CONFIG

    name: str = COMPOUND_V3_DECODER_NAME
    priority: int = 110
    config: CompoundV3DecoderConfig = Field(default_factory=CompoundV3DecoderConfig)

    def matches(self, tx: NormalizedTransaction) -> bool:
        """Four-arm AND predicate; never raises on a valid TX."""
        markets = self.config.markets.get(tx.chain)
        if markets is None or not markets:
            return False
        if tx.to_addr is None or tx.to_addr not in markets:
            return False
        input_hex = tx.input
        if input_hex is None or len(input_hex) < 10:
            return False
        return input_hex[:10] in _COMPOUND_V3_SELECTORS

    def decode(
        self,
        tx: NormalizedTransaction,
        logs: tuple[NormalizedLog, ...],
    ) -> tuple[DefiAction, ...]:
        """Decode + cross-validate; emit one :class:`DefiAction` or ``()``."""
        if not self.matches(tx):
            return ()
        assert tx.input is not None
        assert tx.from_addr is not None
        assert tx.to_addr is not None
        selector = tx.input[:10]
        head = _decode_compound_v3_calldata(selector, tx.input)

        asset_hex, amount, actor = _parse_head(selector, head, chain=tx.chain, tx_from=tx.from_addr)
        if amount == 0:
            raise _validation_error("Compound V3 amount=0 is impossible in well-formed calldata")

        asset_addr = Address.from_str(asset_hex, tx.chain)
        if asset_addr not in self.config.asset_decimals:
            return ()
        decimals = self.config.asset_decimals[asset_addr]
        symbol = self.config.asset_symbols.get(asset_addr, _PLACEHOLDER_ASSET_SYMBOL)
        asset = Asset(chain=tx.chain, symbol=symbol, decimals=decimals, contract=asset_addr)

        market = tx.to_addr
        expected_from, expected_to = _expected_transfer_endpoints(
            selector, tx_from=tx.from_addr, market=market, actor=actor
        )
        transfer_log = _find_action_transfer(
            logs,
            asset=asset_addr,
            expected_from=expected_from,
            expected_to=expected_to,
        )
        # Length guard before the coherence word-0 read — a malformed
        # ``Transfer`` log with ``data="0x"`` would otherwise raise a raw
        # ``ValueError`` from ``int("", 16)`` instead of the decoder's
        # contract-level :class:`pydantic.ValidationError`. Guarded at the
        # call site (the ``_assert_amount_coherence`` body is SSOT-pinned).
        if transfer_log is not None:
            expected_transfer_data_hex_len = 2 + 64
            if len(transfer_log.data) < expected_transfer_data_hex_len:
                raise _validation_error(
                    f"Compound V3 Transfer log data too short: "
                    f"{len(transfer_log.data)} < {expected_transfer_data_hex_len}"
                )
        _assert_amount_coherence(decoded_amount=amount, transfer_log=transfer_log)

        kind = _classify_action_kind(selector=selector, logs=logs, market=market)
        function_name = _SELECTOR_TO_FUNCTION_NAME[selector]
        action = DefiAction(
            kind=kind,
            chain=tx.chain,
            protocol=COMPOUND_V3_DECODER_NAME,
            asset=asset,
            amount=Amount(raw=amount, decimals=decimals),
            actor=actor,
            pool=market,
            extras={"function": function_name},
        )
        return (action,)


def register_compound_v3_decoder(
    config: CompoundV3DecoderConfig | None = None,
) -> CompoundV3Decoder:
    """Construct and register the Compound V3 decoder on the singleton registry."""
    decoder = CompoundV3Decoder() if config is None else CompoundV3Decoder(config=config)
    register_decoder(decoder)
    return decoder
