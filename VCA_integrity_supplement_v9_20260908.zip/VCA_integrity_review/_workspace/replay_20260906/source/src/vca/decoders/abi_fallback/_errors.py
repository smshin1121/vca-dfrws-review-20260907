"""Typed ``AbiFallbackError`` hierarchy (P1-012).

Mirrors :class:`vca.adapters.evm._errors.EtherscanError` shape — every
instance carries enough context (``tier``, ``selector``, ``address``,
``original_status``) for an operator to replay the failed request from
``raw_store``. Each tier raises the matching subclass so call-site
``except`` blocks stay legible.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from vca.decoders.abi_fallback.decode import AbiSource


class AbiFallbackError(Exception):
    """Base class for all ABI-fallback tier failures.

    Constructed positionally (``message``) plus keyword-only context. The
    resolver catches this base class and proceeds to the next tier; a
    concrete subclass identifies the offending tier so log filters can
    target a single tier without sniffing strings.
    """

    def __init__(
        self,
        message: str,
        *,
        tier: AbiSource,
        selector: str,
        address: str | None = None,
        original_status: int | None = None,
    ) -> None:
        super().__init__(message)
        self.tier = tier
        self.selector = selector
        self.address = address
        self.original_status = original_status


class FourByteError(AbiFallbackError):
    """Raised by the 4byte tier on hard failures (5xx after retry / malformed JSON)."""


class SourcifyError(AbiFallbackError):
    """Raised by the Sourcify tier on hard failures (5xx after retry / malformed metadata)."""


class EtherscanAbiError(AbiFallbackError):
    """Raised by the Etherscan ABI tier on auth / rate-limit / shape errors."""


__all__ = [
    "AbiFallbackError",
    "EtherscanAbiError",
    "FourByteError",
    "SourcifyError",
]
