"""BridgeDecoder Protocol + registry (P1-008).

In-process plug-in surface that downstream decoder PRs (P1-009 LayerZero,
P1-010 THORChain, P1-011 Aave V3, P1-012 ABI fallback) bind to. The Flow
Tracer (P1-014) iterates the registry once per TX to detect cross-chain
hops and DeFi actions.
"""

from vca.decoders.aave_v3 import (
    AAVE_V3_DECODER_NAME,
    AaveV3Decoder,
    AaveV3DecoderConfig,
    register_aave_v3_decoder,
)
from vca.decoders.base import BridgeDecoder, DefiAction, DefiActionKind
from vca.decoders.compound_v3 import (
    COMPOUND_V3_DECODER_NAME,
    CompoundV3Decoder,
    CompoundV3DecoderConfig,
    register_compound_v3_decoder,
)
from vca.decoders.cow_protocol import (
    COW_PROTOCOL_DECODER_NAME,
    CowProtocolDecoder,
    CowProtocolDecoderConfig,
    register_cow_protocol_decoder,
)
from vca.decoders.euler import (
    EULER_DECODER_NAME,
    EulerDecoder,
    EulerDecoderConfig,
    register_euler_decoder,
)
from vca.decoders.kyberswap import (
    KYBERSWAP_DECODER_NAME,
    KyberSwapDecoder,
    KyberSwapDecoderConfig,
    register_kyberswap_decoder,
)
from vca.decoders.layerzero_v2 import (
    LAYERZERO_V2_DECODER_NAME,
    LayerZeroV2Decoder,
    LayerZeroV2DecoderConfig,
    register_layerzero_v2_decoder,
)
from vca.decoders.lz_multicall import (
    LZ_MULTICALL_DECODER_NAME,
    LzMultiCallDecoder,
    LzMultiCallDecoderConfig,
    register_lz_multicall_decoder,
)
from vca.decoders.mayan_forwarder import (
    MAYAN_FORWARDER_DECODER_NAME,
    MayanForwarderDecoder,
    MayanForwarderDecoderConfig,
    register_mayan_forwarder_decoder,
)
from vca.decoders.polygon_pos_bridge import (
    POLYGON_POS_BRIDGE_DECODER_NAME,
    PolygonPosBridgeDecoder,
    PolygonPosBridgeDecoderConfig,
    register_polygon_pos_bridge_decoder,
)
from vca.decoders.registry import (
    DecoderRegistry,
    get_decoder_registry,
    register_decoder,
)
from vca.decoders.sky_litepsm import (
    SKY_LITEPSM_DECODER_NAME,
    SkyLitePsmDecoder,
    SkyLitePsmDecoderConfig,
    register_sky_litepsm_decoder,
)
from vca.decoders.thorchain import (
    THORCHAIN_DECODER_NAME,
    ThorchainDecoder,
    ThorchainDecoderConfig,
    register_thorchain_decoder,
)
from vca.decoders.thorchain_vault import (
    THORCHAIN_VAULT_DECODER_NAME,
    ThorchainVaultDecoder,
    ThorchainVaultDecoderConfig,
    register_thorchain_vault_decoder,
)

__all__ = [
    "AAVE_V3_DECODER_NAME",
    "COMPOUND_V3_DECODER_NAME",
    "COW_PROTOCOL_DECODER_NAME",
    "EULER_DECODER_NAME",
    "KYBERSWAP_DECODER_NAME",
    "LAYERZERO_V2_DECODER_NAME",
    "LZ_MULTICALL_DECODER_NAME",
    "MAYAN_FORWARDER_DECODER_NAME",
    "POLYGON_POS_BRIDGE_DECODER_NAME",
    "SKY_LITEPSM_DECODER_NAME",
    "THORCHAIN_DECODER_NAME",
    "THORCHAIN_VAULT_DECODER_NAME",
    "AaveV3Decoder",
    "AaveV3DecoderConfig",
    "BridgeDecoder",
    "CompoundV3Decoder",
    "CompoundV3DecoderConfig",
    "CowProtocolDecoder",
    "CowProtocolDecoderConfig",
    "DecoderRegistry",
    "DefiAction",
    "DefiActionKind",
    "EulerDecoder",
    "EulerDecoderConfig",
    "KyberSwapDecoder",
    "KyberSwapDecoderConfig",
    "LayerZeroV2Decoder",
    "LayerZeroV2DecoderConfig",
    "LzMultiCallDecoder",
    "LzMultiCallDecoderConfig",
    "MayanForwarderDecoder",
    "MayanForwarderDecoderConfig",
    "PolygonPosBridgeDecoder",
    "PolygonPosBridgeDecoderConfig",
    "SkyLitePsmDecoder",
    "SkyLitePsmDecoderConfig",
    "ThorchainDecoder",
    "ThorchainDecoderConfig",
    "ThorchainVaultDecoder",
    "ThorchainVaultDecoderConfig",
    "get_decoder_registry",
    "register_aave_v3_decoder",
    "register_compound_v3_decoder",
    "register_cow_protocol_decoder",
    "register_decoder",
    "register_euler_decoder",
    "register_kyberswap_decoder",
    "register_layerzero_v2_decoder",
    "register_lz_multicall_decoder",
    "register_mayan_forwarder_decoder",
    "register_polygon_pos_bridge_decoder",
    "register_sky_litepsm_decoder",
    "register_thorchain_decoder",
    "register_thorchain_vault_decoder",
]
