"""ABI fallback resolver package (P1-012).

NOT registered as a :class:`vca.decoders.BridgeDecoder`. The resolver is
imported explicitly by P1-014 Flow Tracer; the explicit subpath
``vca.decoders.abi_fallback`` flags the different surface.
"""

from vca.decoders.abi_fallback._errors import AbiFallbackError
from vca.decoders.abi_fallback.decode import (
    AbiCandidate,
    AbiSource,
    RecoveredAbi,
    decode_calldata_with_abi,
)
from vca.decoders.abi_fallback.resolver import AbiFallbackResolver

__all__ = [
    "AbiCandidate",
    "AbiFallbackError",
    "AbiFallbackResolver",
    "AbiSource",
    "RecoveredAbi",
    "decode_calldata_with_abi",
]
