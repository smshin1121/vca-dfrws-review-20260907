"""Sky LitePSM (DAI ⟷ USDC 1:1 peg) decoder (P2-008.0b).

Fifth and final Group A pre-pend decoder. Mirrors P2-008.0a CoW Protocol
+ P2-001.0c KyberSwap event-driven pattern: calldata gates on the 2
function selectors; the canonical truth (gem value + DAI-denominated fee)
lives in the ``BuyGem`` / ``SellGem`` event emitted by the PSM contract.

Sky USDC LitePSM (mainnet ``0xf6e72Db5454dd049d0788e411b06CfAF16853042``):

* ``sellGem(address usr, uint256 gemAmt)``                  → 0x95991276
  User provides USDC ("gem"), receives DAI 1:1 minus ``tin`` fee.
* ``buyGem(address usr, uint256 gemAmt)``                   → 0x8d7ef9bb
  User burns DAI 1:1 plus ``tout`` fee, receives USDC ("gem").

  Note: ``gemAmt`` is denominated in USDC's native 6-decimal units. The
  DAI side scales by 1e12 (``_GEM_TO_DAI_SCALE``) to match DAI's 18-
  decimal precision.

* Event ``BuyGem(address indexed owner, uint256 value, uint256 fee)``
  → 0x085d06ecf4c34b237767a31c0888e121d89546a77f186f1987c6b8715e1a8caa
* Event ``SellGem(address indexed owner, uint256 value, uint256 fee)``
  → 0xef75f5a47cc9a929968796ceb84f19e7541617b4577f2c228ea95200e1572081

Action kind: closest-fit ``COLLATERAL_WITHDRAW`` (closed Phase-1 enum;
0 new values, per P2-001.0c / P2-008.0a precedent). Peg-conversion
semantics carried in ``extras``: ``function``, ``operation``,
``kind_override="swap"``, ``router="sky_litepsm"``, ``output_token``,
``output_amount``, ``fee_amount``, ``psm_address``, ``usr``.
Classifier wiring for ``sky_litepsm`` is deferred to P2-008 stage vertical.

R-PEG-SLIP-TOLERANCE: 0.1% (1 promille) of input amount is allowed on
the strict 1:1 invariant (peg slip / fee accumulation tolerance).

Pure: no I/O, no clock, no env. Synthetic fixture doctrine.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Final

from eth_utils import keccak  # type: ignore[attr-defined]
from pydantic import BaseModel, Field, ValidationError

from vca.decoders.base import DefiAction, DefiActionKind
from vca.decoders.registry import register_decoder
from vca.types import (
    Address,
    Amount,
    Asset,
    ChainId,
    NormalizedLog,
    NormalizedTransaction,
)
from vca.types.normalized import _FROZEN_CONFIG

__all__ = [
    "SKY_LITEPSM_DECODER_NAME",
    "SkyLitePsmDecoder",
    "SkyLitePsmDecoderConfig",
    "register_sky_litepsm_decoder",
]


# Slice A — Constants (R-SELECTOR-TRIPWIRE + R-EVENT-TOPIC-TRIPWIRE).
_SELL_GEM_SIG: Final[str] = "sellGem(address,uint256)"
_BUY_GEM_SIG: Final[str] = "buyGem(address,uint256)"
_BUY_GEM_EVENT_SIG: Final[str] = "BuyGem(address,uint256,uint256)"
_SELL_GEM_EVENT_SIG: Final[str] = "SellGem(address,uint256,uint256)"
_TRANSFER_SIG: Final[str] = "Transfer(address,address,uint256)"


def _selector(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()[:8]


def _topic(sig: str) -> str:
    return "0x" + keccak(text=sig).hex()


_SELL_GEM_SELECTOR: Final[str] = _selector(_SELL_GEM_SIG)
_BUY_GEM_SELECTOR: Final[str] = _selector(_BUY_GEM_SIG)
_BUY_GEM_TOPIC: Final[str] = _topic(_BUY_GEM_EVENT_SIG)
_SELL_GEM_TOPIC: Final[str] = _topic(_SELL_GEM_EVENT_SIG)
_ERC20_TRANSFER_TOPIC: Final[str] = _topic(_TRANSFER_SIG)

# Import-time keccak pin (R-SELECTOR-TRIPWIRE).
_EXPECTED_SELECTORS: Final[Mapping[str, str]] = MappingProxyType(
    {
        _SELL_GEM_SIG: "0x95991276",
        _BUY_GEM_SIG: "0x8d7ef9bb",
    }
)
for _sig, _expected in _EXPECTED_SELECTORS.items():
    if _selector(_sig) != _expected:  # pragma: no cover - import-time tripwire
        raise RuntimeError(
            f"Sky LitePSM selector drift for {_sig!r}: "
            f"{_selector(_sig)!r} (expected {_expected!r}). "
            "Refusing module import — investigate Sky LitePSM ABI or eth_utils.keccak."
        )

# Import-time keccak pin (R-EVENT-TOPIC-TRIPWIRE).
_EXPECTED_EVENT_TOPICS: Final[Mapping[str, str]] = MappingProxyType(
    {
        _BUY_GEM_EVENT_SIG: ("0x085d06ecf4c34b237767a31c0888e121d89546a77f186f1987c6b8715e1a8caa"),
        _SELL_GEM_EVENT_SIG: ("0xef75f5a47cc9a929968796ceb84f19e7541617b4577f2c228ea95200e1572081"),
    }
)
for _sig, _expected in _EXPECTED_EVENT_TOPICS.items():
    if _topic(_sig) != _expected:  # pragma: no cover - import-time tripwire
        raise RuntimeError(
            f"Sky LitePSM event topic drift for {_sig!r}: "
            f"{_topic(_sig)!r} (expected {_expected!r}). "
            "Refusing module import — investigate Sky LitePSM ABI or eth_utils.keccak."
        )

_SKY_LITEPSM_SELECTORS: Final[frozenset[str]] = frozenset({_SELL_GEM_SELECTOR, _BUY_GEM_SELECTOR})

# Mainnet Sky USDC LitePSM (Etherscan-verified, EIP-55 verbatim).
_SKY_USDC_LITEPSM_ETH: Final[Address] = Address.from_str(
    "0xf6e72Db5454dd049d0788e411b06CfAF16853042", ChainId.ETHEREUM
)
# Mainnet DAI + USDC (EIP-55 verbatim, Etherscan-verified). These pin the
# PSM token pair explicitly so the decoder no longer guesses by decimals
# iteration (codex P2 finding 2). Wrap in :class:`Address` here so the
# default carries the EIP-55 normalised form.
_DAI_MAINNET: Final[Address] = Address.from_str(
    "0x6B175474E89094C44Da98b954EedeAC495271d0F", ChainId.ETHEREUM
)
_USDC_MAINNET: Final[Address] = Address.from_str(
    "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", ChainId.ETHEREUM
)
_DEFAULT_PSM_ADDRESSES: Final[Mapping[ChainId, frozenset[Address]]] = MappingProxyType(
    {ChainId.ETHEREUM: frozenset({_SKY_USDC_LITEPSM_ETH})}
)
_DEFAULT_ASSET_DECIMALS: Final[Mapping[Address, int]] = MappingProxyType({})
_DEFAULT_ASSET_SYMBOLS: Final[Mapping[Address, str]] = MappingProxyType({})
_PLACEHOLDER_ASSET_SYMBOL: Final[str] = "SKY_LITEPSM_ASSET"
_ROUTER_TAG: Final[str] = "sky_litepsm"
# P2-DECODER-KIND-OVERRIDE-LITERAL-SSOT.1 (Cycle 28): module-level Final[str]
# SSOT for the ``extras["kind_override"]`` value emitted on every buyGem /
# sellGem -> DefiAction. MUST byte-equal one of the consumer-side values in
# :data:`vca.tracer.stage_classifier._vocab._KNOWN_KIND_OVERRIDES`; a 1-byte
# drift here silently defers the rank-4 ``is_kind_override`` heuristic and
# mis-classifies the Sky LitePSM edge into the fallback ranks.
_KIND_OVERRIDE: Final[str] = "swap"
SKY_LITEPSM_DECODER_NAME: Final[str] = "sky_litepsm"

# USDC ("gem") has 6 decimals; DAI has 18. The PSM does strict 1:1 peg
# arithmetic by scaling gemAmt x 1e12 to reach DAI's 18-decimal precision.
_GEM_TO_DAI_SCALE: Final[int] = 10**12

# 0.1% (1 promille) peg slip tolerance — R-PEG-SLIP-TOLERANCE.
# Implemented as: |dai_side - usdc_side_scaled - fee| <= dai_side // _PEG_SLIP_DIVISOR.
_PEG_SLIP_DIVISOR: Final[int] = 1000


@dataclass(frozen=True, slots=True)
class SkyLitePsmDecoderConfig:
    """Phase-2 Sky LitePSM config. Wrap overrides in ``MappingProxyType``.

    ``psm_addresses`` ships the mainnet Sky USDC LitePSM pre-pinned
    (R-PSM-WHITELIST-TRIPWIRE); asset tables empty until P2-008 stage
    vertical injects DAI + USDC entries.

    ``dai_contract`` / ``gem_contract`` pin the PSM token pair explicitly
    (codex P2 finding 2). Pre-fix the decoder iterated ``asset_decimals``
    and grabbed the first 18-decimal entry as DAI / first 6-decimal entry
    as USDC, which silently corrupted whenever the shared asset table was
    reordered or extended (e.g. WETH 18-decimal or USDT 6-decimal preceded
    DAI/USDC). The decoder now resolves the token pair from these fields;
    ``asset_decimals`` is retained ONLY for decimal/symbol lookup.
    """

    psm_addresses: Mapping[ChainId, frozenset[Address]] = field(default=_DEFAULT_PSM_ADDRESSES)
    asset_decimals: Mapping[Address, int] = field(default=_DEFAULT_ASSET_DECIMALS)
    asset_symbols: Mapping[Address, str] = field(default=_DEFAULT_ASSET_SYMBOLS)
    dai_contract: Address = field(default=_DAI_MAINNET)
    gem_contract: Address = field(default=_USDC_MAINNET)


# Slice C — Pure helpers.


def _validation_error(msg: str) -> ValidationError:
    """Wrap ``msg`` in :class:`pydantic.ValidationError`."""

    class _GuardModel(BaseModel):
        model_config = _FROZEN_CONFIG
        marker: str

    try:
        _GuardModel(marker=msg, extra_field_that_does_not_exist=True)  # type: ignore[call-arg]
    except ValidationError as exc:
        return exc
    raise RuntimeError("validation guard failed to raise")  # pragma: no cover


def _topic_address(topic: str, chain: ChainId) -> Address | None:
    """32-byte indexed-address topic → :class:`Address` or ``None``."""
    if any(c != "0" for c in topic[2:26]):
        return None
    return Address.from_str("0x" + topic[26:], chain)


def _read_uint256_word(data_hex: str, word_index: int) -> int:
    offset = 2 + word_index * 64  # skip '0x'
    return int(data_hex[offset : offset + 64], 16)


def _parse_psm_calldata(input_hex: str, *, chain: ChainId) -> tuple[Address, int]:
    """Decode ``(usr, gemAmt)`` from sellGem/buyGem calldata.

    Layout: 4-byte selector + 2 head words of 32 bytes (address + uint256).
    Raises :class:`pydantic.ValidationError` on short input.
    """
    # Need selector (10 hex chars including 0x) + 2 x 64 hex chars = 138.
    expected_len = 10 + 2 * 64
    if len(input_hex) < expected_len:
        raise _validation_error(
            f"Sky LitePSM calldata too short: {len(input_hex)} < {expected_len}"
        )
    usr_word = input_hex[10 : 10 + 64]
    if any(c != "0" for c in usr_word[:24]):
        raise _validation_error(
            f"Sky LitePSM usr param topic malformed (non-zero upper 12 bytes): {usr_word!r}"
        )
    usr = Address.from_str("0x" + usr_word[24:], chain)
    gem_amt = int(input_hex[10 + 64 : 10 + 2 * 64], 16)
    return usr, gem_amt


def _find_psm_event(
    logs: tuple[NormalizedLog, ...],
    *,
    psm: Address,
    topic: str,
) -> NormalizedLog | None:
    """First event with ``topic`` emitted at ``psm`` (D-2 absent OK)."""
    for log in logs:
        if not log.topics:
            continue
        if log.topics[0] != topic:
            continue
        if log.address != psm:
            continue
        return log
    return None


def _parse_psm_event_payload(log: NormalizedLog, *, chain: ChainId) -> tuple[Address, int, int]:
    """``BuyGem`` / ``SellGem`` event log → ``(owner, value, fee)``.

    Both events share the layout: indexed ``owner`` topic + 2 non-indexed
    uint256 words in data (``value`` + ``fee``).
    """
    if len(log.topics) < 2:
        raise _validation_error("Sky LitePSM event missing indexed owner topic[1]")
    owner = _topic_address(log.topics[1], chain)
    if owner is None:
        raise _validation_error(f"Sky LitePSM event owner topic malformed: {log.topics[1]!r}")
    expected_hex_len = 2 + 2 * 64
    if len(log.data) < expected_hex_len:
        raise _validation_error(
            f"Sky LitePSM event data too short: {len(log.data)} < {expected_hex_len}"
        )
    value = _read_uint256_word(log.data, 0)
    fee = _read_uint256_word(log.data, 1)
    return owner, value, fee


def _find_action_transfer(
    logs: tuple[NormalizedLog, ...],
    *,
    asset: Address,
    expected_from: Address,
    expected_to: Address,
) -> NormalizedLog | None:
    """First ERC-20 ``Transfer`` from ``asset`` matching from/to (D-2 absent OK)."""
    chain = asset.chain
    for log in logs:
        if not log.topics or log.topics[0] != _ERC20_TRANSFER_TOPIC:
            continue
        if log.address != asset:
            continue
        if len(log.topics) < 3:
            continue
        log_from = _topic_address(log.topics[1], chain)
        log_to = _topic_address(log.topics[2], chain)
        if log_from == expected_from and log_to == expected_to:
            return log
    return None


def _assert_peg_coherence(
    *,
    dai_amount: int,
    gem_amount: int,
    fee_amount: int,
    is_buy_gem: bool,
) -> None:
    """R-PEG-SLIP-TOLERANCE + R-1: direction-aware 1:1 invariant.

    Math: gem 6-decimal x 1e12 == DAI 18-decimal expected; tolerance is
    ``dai_amount // 1000`` (1 promille of the DAI side). Fee is taken on
    the DAI side, but the sign depends on direction (codex P2 finding 1):

    * ``buyGem`` (DAI in, USDC out): user pays ``dai_in = gem_scaled + fee``::

          |dai_amount - gem_scaled - fee_amount| <= dai_amount // 1000

    * ``sellGem`` (USDC in, DAI out): user receives ``dai_out = gem_scaled - fee``::

          |dai_amount - gem_scaled + fee_amount| <= dai_amount // 1000

    The pre-fix helper subtracted ``fee_amount`` regardless of direction,
    so valid sellGem TX with non-zero fees were rejected while accidental
    overpays passed. Raises :class:`pydantic.ValidationError` if the slip
    exceeds tolerance.
    """
    gem_scaled = gem_amount * _GEM_TO_DAI_SCALE
    if is_buy_gem:
        slip = abs(dai_amount - gem_scaled - fee_amount)
    else:
        slip = abs(dai_amount - gem_scaled + fee_amount)
    tolerance = dai_amount // _PEG_SLIP_DIVISOR
    if slip > tolerance:
        direction = "buyGem" if is_buy_gem else "sellGem"
        raise _validation_error(
            f"Sky LitePSM {direction} peg-slip tolerance exceeded: slip={slip}, "
            f"tolerance={tolerance} (dai_amount={dai_amount}, "
            f"gem_amount={gem_amount}, fee_amount={fee_amount})"
        )


# Slice B / C — Decoder model.


class SkyLitePsmDecoder(BaseModel):
    """Pydantic v2 :class:`BridgeDecoder` for Sky LitePSM DAI ⟷ USDC peg
    conversions (event-driven: BuyGem/SellGem events are the truth)."""

    model_config = _FROZEN_CONFIG

    name: str = SKY_LITEPSM_DECODER_NAME
    priority: int = 130
    config: SkyLitePsmDecoderConfig = Field(default_factory=SkyLitePsmDecoderConfig)

    def matches(self, tx: NormalizedTransaction) -> bool:
        """Four-arm AND predicate (R-PSM-WHITELIST-TRIPWIRE on arm 2)."""
        psms = self.config.psm_addresses.get(tx.chain)
        if psms is None or not psms:
            return False
        if tx.to_addr is None or tx.to_addr not in psms:
            return False
        input_hex = tx.input
        if input_hex is None or len(input_hex) < 10:
            return False
        return input_hex[:10].lower() in _SKY_LITEPSM_SELECTORS

    def decode(
        self,
        tx: NormalizedTransaction,
        logs: tuple[NormalizedLog, ...],
    ) -> tuple[DefiAction, ...]:
        """Decode + cross-validate; emit one :class:`DefiAction` or ``()``."""
        if not self.matches(tx):
            return ()
        assert tx.input is not None
        assert tx.to_addr is not None
        psm = tx.to_addr
        selector = tx.input[:10].lower()
        is_buy_gem = selector == _BUY_GEM_SELECTOR

        usr, _gem_amt_calldata = _parse_psm_calldata(tx.input, chain=tx.chain)

        topic = _BUY_GEM_TOPIC if is_buy_gem else _SELL_GEM_TOPIC
        event = _find_psm_event(logs, psm=psm, topic=topic)
        if event is None:
            raise _validation_error(
                f"Sky LitePSM {selector} TX missing required "
                f"{'BuyGem' if is_buy_gem else 'SellGem'} event at PSM {psm.value}"
            )

        owner, value, fee = _parse_psm_event_payload(event, chain=tx.chain)
        if value == 0:
            raise _validation_error("Sky LitePSM event value=0 is impossible in well-formed event")

        # buyGem: input is DAI (burned), output is USDC (gem delivered).
        # sellGem: input is USDC (gem provided), output is DAI (minted).
        # Codex P2 finding 2: token pair MUST come from explicit config
        # (``dai_contract`` / ``gem_contract``), not by iterating
        # ``asset_decimals`` for the first 18/6-decimal entries — that path
        # silently corrupted whenever the shared asset table was reordered
        # or extended (e.g. WETH 18-decimal or USDT 6-decimal preceded
        # DAI/USDC). asset_decimals is now used only for decimal scaling
        # and symbol lookup.
        dai_addr = self.config.dai_contract
        usdc_addr = self.config.gem_contract
        if dai_addr.chain is not tx.chain or usdc_addr.chain is not tx.chain:
            return ()
        if dai_addr not in self.config.asset_decimals:
            return ()
        if usdc_addr not in self.config.asset_decimals:
            return ()

        if is_buy_gem:
            input_token, output_token = dai_addr, usdc_addr
        else:
            input_token, output_token = usdc_addr, dai_addr

        # R-1 bidirectional Transfer cross-validation.
        # Input-side: user → PSM in input_token.
        input_xfer = _find_action_transfer(
            logs,
            asset=input_token,
            expected_from=owner,
            expected_to=psm,
        )
        if input_xfer is None:
            raise _validation_error(
                f"Sky LitePSM {selector} TX missing input-side ERC-20 Transfer "
                f"({input_token.value} from {owner.value} to {psm.value})"
            )
        # Length guard before ``int("", 16)`` to ensure a malformed Transfer
        # raises ValidationError (decoder contract) not raw ValueError.
        expected_transfer_data_hex_len = 2 + 64
        if len(input_xfer.data) < expected_transfer_data_hex_len:
            raise _validation_error(
                f"Sky LitePSM input-side Transfer log data too short: "
                f"{len(input_xfer.data)} < {expected_transfer_data_hex_len}"
            )
        input_amount = _read_uint256_word(input_xfer.data, 0)

        # Output-side: PSM → user in output_token.
        output_xfer = _find_action_transfer(
            logs,
            asset=output_token,
            expected_from=psm,
            expected_to=owner,
        )
        if output_xfer is None:
            raise _validation_error(
                f"Sky LitePSM {selector} TX missing output-side ERC-20 Transfer "
                f"({output_token.value} from {psm.value} to {owner.value})"
            )
        if len(output_xfer.data) < expected_transfer_data_hex_len:
            raise _validation_error(
                f"Sky LitePSM output-side Transfer log data too short: "
                f"{len(output_xfer.data)} < {expected_transfer_data_hex_len}"
            )
        output_amount = _read_uint256_word(output_xfer.data, 0)

        # Sky LitePSM ``BuyGem`` / ``SellGem`` events both emit ``value``
        # as the **gem-side (USDC, 6-decimal)** amount, regardless of
        # direction:
        #   - buyGem: gem amount delivered TO user  ⇒ event.value == output_amount
        #   - sellGem: gem amount received FROM user ⇒ event.value == input_amount
        gem_xfer_amount = output_amount if is_buy_gem else input_amount
        if gem_xfer_amount != value:
            side = "output" if is_buy_gem else "input"
            raise _validation_error(
                f"Sky LitePSM {side}-side Transfer.value mismatch: "
                f"log_value={gem_xfer_amount}, event.value={value}"
            )

        # Peg-slip tolerance: 1:1 invariant with 0.1% allowance.
        # Identify DAI side + USDC side regardless of direction.
        if is_buy_gem:
            dai_amount, gem_amount = input_amount, output_amount
        else:
            dai_amount, gem_amount = output_amount, input_amount
        _assert_peg_coherence(
            dai_amount=dai_amount,
            gem_amount=gem_amount,
            fee_amount=fee,
            is_buy_gem=is_buy_gem,
        )

        decimals = self.config.asset_decimals[input_token]
        symbol = self.config.asset_symbols.get(input_token, _PLACEHOLDER_ASSET_SYMBOL)
        asset = Asset(chain=tx.chain, symbol=symbol, decimals=decimals, contract=input_token)

        operation = "buy_gem" if is_buy_gem else "sell_gem"
        action = DefiAction(
            kind=DefiActionKind.COLLATERAL_WITHDRAW,
            chain=tx.chain,
            protocol=SKY_LITEPSM_DECODER_NAME,
            asset=asset,
            amount=Amount(raw=input_amount, decimals=decimals),
            actor=owner,
            pool=psm,
            extras={
                "function": operation,
                "operation": operation,
                "kind_override": _KIND_OVERRIDE,
                "router": _ROUTER_TAG,
                "output_token": output_token.value,
                "output_amount": str(output_amount),
                "fee_amount": str(fee),
                "psm_address": psm.value,
                "usr": usr.value,
            },
        )
        return (action,)


def register_sky_litepsm_decoder(
    config: SkyLitePsmDecoderConfig | None = None,
) -> SkyLitePsmDecoder:
    """Construct and register the Sky LitePSM decoder on the singleton registry."""
    decoder = SkyLitePsmDecoder() if config is None else SkyLitePsmDecoder(config=config)
    register_decoder(decoder)
    return decoder
