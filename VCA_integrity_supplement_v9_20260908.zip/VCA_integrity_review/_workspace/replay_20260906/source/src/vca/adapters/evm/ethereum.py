"""EthereumAdapter — Ethereum mainnet pin of EvmBaseAdapter (P1-004).

Wraps :class:`vca.adapters.evm.base.EvmBaseAdapter` with
``chain_id=ChainId.ETHEREUM`` and ``scanner_chainid=1`` fixed at construction
time. Subclasses cannot override either pin — see ``_workspace/
P1-004_architect_wbs.md`` §6 R-PIN-MECHANISM.

Bootstrap helpers
-----------------
* :func:`build_ethereum_adapter` — :class:`Settings` + injected
  :class:`HttpClient` / :class:`RawResponseStore` → fresh adapter instance.
* :func:`register_ethereum_adapter` — same, plus :class:`AdapterRegistry`
  binding via the P1-002 ``register`` Protocol.

Both helpers are symmetric with the future ``arbitrum.py``/``bitcoin.py``
modules (P1-005/P1-006); P1-018 will assemble all three from the same shape.

Decisions
---------
The base URL string ``https://api.etherscan.io/v2/api`` lives in
:mod:`vca.adapters.evm._etherscan_v2` as the public
``ETHERSCAN_V2_BASE_URL`` constant. P1-005 promoted it from three
module-private duplicates (R-BASE-URL-DUP resolution); this module now
imports the shared object so a future host change touches one line.
"""

from __future__ import annotations

from typing import Final

from pydantic import SecretStr

from vca.adapters.evm._etherscan_v2 import ETHERSCAN_V2_BASE_URL
from vca.adapters.evm.base import _DEFAULT_TXLIST_OFFSET, EvmBaseAdapter
from vca.adapters.registry import AdapterRegistry
from vca.config import Settings
from vca.http.client import HttpClient
from vca.persistence.raw_store import RawResponseStore
from vca.types import ChainId

_ETHEREUM_SCANNER_CHAINID: Final[int] = 1
# Re-bind under the original module-private name so downstream code paths
# (and the S9 single-source-of-truth identity check in
# :mod:`tests.unit.adapters.evm.test_arbitrum`) still reach the shared
# object via :data:`vca.adapters.evm.ethereum._ETHERSCAN_V2_BASE_URL`.
_ETHERSCAN_V2_BASE_URL: Final[str] = ETHERSCAN_V2_BASE_URL


class EthereumAdapter(EvmBaseAdapter):
    """Ethereum mainnet :class:`ChainAdapter`; chain pins are non-overridable.

    The constructor deliberately does NOT accept ``chain_id`` or
    ``scanner_chainid`` — they are bound to ``ChainId.ETHEREUM`` and ``1``
    respectively in the ``super().__init__`` call. A caller that passes
    either kwarg sees ``TypeError: unexpected keyword argument`` from
    Python's normal arg dispatch (and ``mypy --strict`` rejects the call
    before runtime).
    """

    def __init__(
        self,
        *,
        http_client: HttpClient,
        raw_store: RawResponseStore,
        api_key: SecretStr,
        base_url: str = _ETHERSCAN_V2_BASE_URL,
        historical_ttl_sec: int | None = None,
        balance_ttl_sec: int | None = 120,
        latest_block_ttl_sec: int = 12,
        txlist_offset: int = _DEFAULT_TXLIST_OFFSET,
    ) -> None:
        super().__init__(
            chain_id=ChainId.ETHEREUM,
            scanner_chainid=_ETHEREUM_SCANNER_CHAINID,
            http_client=http_client,
            raw_store=raw_store,
            api_key=api_key,
            base_url=base_url,
            historical_ttl_sec=historical_ttl_sec,
            balance_ttl_sec=balance_ttl_sec,
            latest_block_ttl_sec=latest_block_ttl_sec,
            txlist_offset=txlist_offset,
        )


def build_ethereum_adapter(
    settings: Settings,
    *,
    http_client: HttpClient,
    raw_store: RawResponseStore,
    base_url: str | None = None,
) -> EthereumAdapter:
    """Construct an :class:`EthereumAdapter` from ``Settings`` + injected I/O.

    ``settings.etherscan_api_key_primary`` is read as-is. The
    ``Settings._require_real_secrets`` validator (P0-003) already
    fail-fasts on placeholder/empty values, so this helper does not
    re-implement that check (R-FACTORY-PLACEHOLDER-DELEGATE).

    Args:
        settings: Loaded :class:`Settings`. ``etherscan_api_key_primary``
            plus the two cache-TTL fields (``vca_cache_ttl_historical_sec``
            / ``vca_cache_ttl_balance_sec``) are consumed; the Arbiscan key
            is never read here (R-FACTORY-ROLE).
        http_client: Externally-owned :class:`HttpClient`. Lifecycle and
            limiter wiring are the caller's responsibility.
        raw_store: Externally-owned :class:`RawResponseStore` for evidence
            persistence (R-RAW-PERSIST-ON-ERROR is enforced by the base).
        base_url: Override the production Etherscan v2 host. ``None``
            (default) preserves the production endpoint; tests pass a stub
            host (R-FACTORY-OVERRIDE-BASE-URL).

    Returns:
        A fresh :class:`EthereumAdapter` bound to the supplied I/O. The
        instance is **not** registered on any :class:`AdapterRegistry` —
        use :func:`register_ethereum_adapter` for that.
    """
    return EthereumAdapter(
        http_client=http_client,
        raw_store=raw_store,
        api_key=settings.etherscan_api_key_primary,
        base_url=base_url if base_url is not None else _ETHERSCAN_V2_BASE_URL,
        # P3.4-002 #23: wire the formerly-dead cache-TTL Settings. ``historical``
        # uses the int(0)->None "unbounded" sentinel; ``balance`` is bounded
        # positive (config ge=1 -- the cache maps ttl<=0 to no-expiry/freeze).
        historical_ttl_sec=settings.vca_cache_ttl_historical_sec or None,
        balance_ttl_sec=settings.vca_cache_ttl_balance_sec,
    )


def register_ethereum_adapter(
    registry: AdapterRegistry,
    settings: Settings,
    *,
    http_client: HttpClient,
    raw_store: RawResponseStore,
    replace: bool = False,
) -> EthereumAdapter:
    """Build + register on the supplied :class:`AdapterRegistry`.

    Re-raises P1-002's ``ValueError("chain 'eth' already registered ...")``
    when ``replace=False`` and ``ChainId.ETHEREUM`` is already registered.

    Args:
        registry: Target :class:`AdapterRegistry`. Bootstrap callers
            (P1-018) typically pass the singleton from
            :func:`vca.adapters.registry.get_registry`.
        settings: Loaded :class:`Settings` — see
            :func:`build_ethereum_adapter`.
        http_client: Externally-owned :class:`HttpClient`.
        raw_store: Externally-owned :class:`RawResponseStore`.
        replace: When ``True``, overwrite an existing
            ``ChainId.ETHEREUM`` binding. Default ``False`` mirrors
            P1-002's safe default.

    Returns:
        The newly-built and just-registered :class:`EthereumAdapter`.
    """
    adapter = build_ethereum_adapter(settings, http_client=http_client, raw_store=raw_store)
    registry.register(ChainId.ETHEREUM, adapter, replace=replace)
    return adapter


__all__ = [
    "EthereumAdapter",
    "build_ethereum_adapter",
    "register_ethereum_adapter",
]
