"""Pure coercibility-predicate helpers for Etherscan v2 account/proxy responses.

Extracted verbatim from :mod:`vca.adapters.evm._etherscan_v2` (re-exported there
for import compat) so neither module exceeds the 800-line cap (WBS R-FILE-CAP) —
the same leaf-extraction pattern used for :mod:`vca.adapters.evm._normalizers`
and :mod:`vca.adapters.evm._params`.

Each helper answers "would the normaliser's numeric coercion throw on this
value?" by mirroring the consumer EXACTLY (``int(str(x))`` for decimal,
``int(str(x), 16)`` for hex), never a regex — so it accepts precisely what the
normaliser accepts and rejects precisely what would leak a bare ``ValueError``
past the typed :class:`vca.adapters.evm._errors.EtherscanError` boundary
(cache-poison). Pure functions only — no I/O; the only imports are ``typing``,
the stdlib ``datetime`` (the ITER-75 range predicate mirrors the consumer's pure
``datetime.fromtimestamp``), the pure ``vca.types`` domain types
(:class:`Address` / :class:`ChainId`), and the pure ``vca.types`` value-domain
validators the format predicates mirror their consumers with
(:func:`_validate_chain_tx_hash`, :func:`_validate_hex_lowercase`,
:func:`_validate_optional_calldata`).
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from vca.types import Address, ChainId
from vca.types._adapter_io import _validate_hex_lowercase
from vca.types.normalized import _validate_chain_tx_hash, _validate_optional_calldata


def _decimal_str_problem(value: Any) -> str | None:
    """Return ``None`` if *value* is ``int``-coercible; else a problem string.

    Iteration-16 defensive-hardening twin of :func:`_account_balance_problem`,
    applied per-row to the required numeric fields (``timeStamp`` /
    ``blockNumber`` / ``value``) instead of to the lone balance string. Closes
    the per-row numeric-coercibility leak + cache-poison left open after
    Iteration-6 (present+str only): the normalisers coerce these fields via
    ``int(str(value))`` / ``datetime.fromtimestamp(int(str(value)))``, so a
    present+str-but-non-decimal value (``"abc"`` / ``""`` / ``"0x1f"``) would
    otherwise leak a bare ``ValueError`` deep in the normaliser. Mirrors the
    consumer's ``int(str(value))`` coercion (not a regex) so it never over-rejects
    a real Etherscan decimal-string row → the happy path stays byte-identical
    (golden determinism).

    Iteration-48 ALSO rejects a negative-but-int-coercible value (``"-5"``): every
    consumer of these fields is a pydantic ``Field(ge=0)`` (``Amount.raw`` /
    ``BlockRef.number``), so a negative passed the ``int()``-only gate, was cached
    under ``historical_ttl=None`` and then leaked a raw ``pydantic.ValidationError``
    past the typed boundary — the SIGN-half of the ITER-16/17 coercibility class
    deferred there. Real Etherscan wei/heights/unix-times are never negative, so
    the guard fires only on never-in-golden malformed input (still golden-safe).
    """
    try:
        parsed = int(str(value))
    except (ValueError, TypeError):
        return f"non-decimal value: {str(value)!r}"
    if parsed < 0:
        return f"negative value: {str(value)!r}"
    return None


def _hex_str_problem(value: Any) -> str | None:
    """Return ``None`` if *value* is ``int(.,16)``-coercible; else a problem string.

    Iteration-17 defensive-completeness twin of :func:`_decimal_str_problem`, but
    base-16. The single source of truth for the proxy/log fields the normalisers
    coerce via ``int(str(x), 16)`` — proxy tx ``value``, block ``number`` /
    ``timestamp``, receipt-log ``logIndex``. Their shape gates previously
    validated only present+str, so a present-but-non-hex value passed the
    cache-write gate, was cached under ``historical_ttl=None`` and then crashed
    with a bare ``ValueError`` in the normaliser (cache-poison). Mirrors the
    consumer EXACTLY — ``int(str(value), 16)``, not a regex — so it never
    over-rejects a real hex response → happy path byte-identical.

    Iteration-48 ALSO rejects a negative-but-coercible value (``"-0x1"`` / ``"-1"``):
    the ``ge=0`` consumers (proxy tx ``value`` → ``Amount.raw``; block ``number`` →
    ``BlockRef.number``) leaked a raw ``pydantic.ValidationError`` on a negative,
    and the remaining consumers (block ``timestamp`` / receipt-log ``logIndex``)
    are nonsensical when negative. Real hex responses are ``0x``-prefixed (never
    negative), so the guard fires only on never-in-golden malformed input.
    """
    try:
        parsed = int(str(value), 16)
    except (ValueError, TypeError):
        return f"non-hex value: {str(value)!r}"
    if parsed < 0:
        return f"negative value: {str(value)!r}"
    return None


def _account_balance_problem(result: Any) -> str | None:
    """Return ``None`` if *result* is an ``int``-coercible balance; else a problem.

    Iteration-7 defensive-hardening twin of :func:`_account_rows_shape_problem`.
    The ``module=account&action=balance``/``tokenbalance`` ``result`` is a
    base-10 wei/token-unit string that ``get_balance``/``get_token_balance``
    feed to the normaliser as ``int(str(result))`` (see
    :func:`vca.adapters.evm._normalizers.normalize_balance_native` /
    ``normalize_balance_token``). ``assert_account_ok`` only narrows the
    ``module=account`` envelope to a non-error ``result``; it can NOT assert
    numeric-ness because the SAME handler serves the row endpoints (whose
    ``result`` is a list). A status==1-but-non-numeric ``result`` (``None`` →
    ``int("None")``, ``"Max rate limit reached"``, ``{}`` → ``int("{}")``,
    ``""``) therefore reaches the normaliser and leaks a bare ``ValueError`` —
    NOT a typed :class:`EtherscanError` at the boundary. (status==0 error
    envelopes are already handled by ``assert_account_ok``; the gap closed here
    is the status==1-but-non-numeric case.)

    The guard mirrors the consumer EXACTLY — ``int(str(result))``, not a regex —
    so it accepts precisely what the normaliser accepts (a decimal string OR an
    int-coercible value) and rejects precisely what would throw. It therefore
    never fires on a real Etherscan decimal balance → the happy path stays
    byte-identical (golden determinism). Single source of truth shared by
    :func:`is_account_balance_ok` (cache-write gate — closes the cache-poison
    hole under ``balance_ttl``) and :func:`assert_account_balance_ok`
    (post-fetch asserter) so they agree by construction.

    Iteration-48 ALSO rejects a negative balance: the consumer ``Amount.raw`` is
    ``Field(ge=0)``, so a negative-but-coercible ``result`` passed the
    ``int()``-only gate and then leaked a raw ``pydantic.ValidationError`` past
    the typed boundary. A real wei/token balance is never negative.
    """
    try:
        parsed = int(str(result))
    except (ValueError, TypeError):
        return f"non-numeric balance result: {str(result)!r}"
    if parsed < 0:
        return f"negative balance result: {str(result)!r}"
    return None


def _evm_address_format_problem(value: str) -> str | None:
    """Return a problem suffix if *value* is not a valid EVM address; else ``None``.

    Iteration-42 EVM sibling of the BTC
    :func:`vca.adapters.btc._mempool._btc_address_format_problem` (ITER-36). The
    receipt-log / proxy-tx shape gates already enforce ``isinstance(value, str)``
    (present+str); this is the FORMAT layer. :func:`normalize_log` feeds
    ``log.address`` straight to :func:`Address.from_str`
    (:mod:`vca.adapters.evm._normalizers`), so a present+str-but-malformed
    (non-hex) address would otherwise pass the cache-write gate, be cached under
    the unbounded ``historical_ttl`` (permanent cache-poison), then crash with a
    raw ``ValueError`` on every replay — the exact result-parsing/cache-poison
    class the numeric guards (ITER-16/17) and the BTC guard (ITER-36) close.

    Mirror the consumer EXACTLY — :meth:`Address.from_str` with
    :attr:`ChainId.ETHEREUM` (EIP-55 hex is identical across every EVM chain so
    ``ETHEREUM`` is a faithful proxy) — so a real address passes unchanged
    (golden-safe: real receipts always carry hex addresses) and only
    never-in-golden malformed input is rejected. The message omits the raw value
    (house style echoes the field, not the value).

    CRITICAL divergence from the BTC sibling: the empty string is NOT skipped.
    :func:`normalize_log` feeds ``address`` directly (unlike
    :func:`vca.adapters.btc._mempool._maybe_btc_address`, which treats ``""`` as
    "no address"), so ``""`` reaches :func:`Address.from_str` and raises — it
    MUST be rejected here, not short-circuited.
    """
    try:
        Address.from_str(value, ChainId.ETHEREUM)
    except ValueError:
        return "must be a valid EVM address"
    return None


def _evm_tx_hash_format_problem(value: str) -> str | None:
    """Return a problem suffix if *value* is not a valid EVM tx hash; else ``None``.

    Iteration-67 hex-FORMAT sibling of :func:`_evm_address_format_problem`. The
    receipt-log / proxy-tx / account-tx shape gates enforce present+str; this is
    the FORMAT layer. :func:`vca.types.normalized.NormalizedTransaction` /
    ``NormalizedLog`` feed the tx-hash field to an after-validator
    (:func:`_validate_chain_tx_hash`, ``0x`` + 64 case-insensitive hex), so a
    present+str-but-malformed hash would otherwise pass the cache-write gate, be
    cached under the unbounded ``historical_ttl`` (permanent cache-poison), then
    raise a raw ``pydantic.ValidationError`` on every replay — escaping the typed
    :class:`vca.adapters.evm._errors.EtherscanError` boundary. Mirror the consumer
    EXACTLY by REUSING the validator (its regex is case-insensitive, so real
    UPPERCASE hex passes unchanged) — golden-safe; the message omits the value.
    """
    try:
        _validate_chain_tx_hash(ChainId.ETHEREUM, value)
    except ValueError:
        return "must be a valid EVM tx hash"
    return None


def _evm_data_hex_problem(value: str) -> str | None:
    """Return a problem suffix if *value* is not ``0x`` + even-length hex; else ``None``.

    Iteration-67 mirror of :class:`NormalizedLog`'s ``data`` after-validator
    (:func:`_validate_hex_lowercase` with no length pin — ``0x`` + even-length hex,
    zero bytes ok). The validator ``.lower()``-s first, so real UPPERCASE hex
    passes unchanged. Closes the data-hex cache-poison + raw-``ValidationError``
    leak the present+str gate left open.
    """
    try:
        _validate_hex_lowercase(value, field="data")
    except ValueError:
        return "must be 0x-prefixed even-length hex"
    return None


def _evm_topic_hex_problem(value: str) -> str | None:
    """Return a problem suffix if *value* is not a ``0x`` + 64-hex topic; else ``None``.

    Iteration-67 mirror of :class:`NormalizedLog`'s ``topics[i]`` after-validator
    (:func:`_validate_hex_lowercase` with ``length=66`` — ``0x`` + 64 hex). The
    validator ``.lower()``-s first, so real UPPERCASE hex passes unchanged. Closes
    the per-topic cache-poison + raw-``ValidationError`` leak.
    """
    try:
        _validate_hex_lowercase(value, field="topic", length=66)
    except ValueError:
        return "must be a 0x + 64 hex topic"
    return None


def _evm_calldata_problem(value: Any) -> str | None:
    """Return a problem suffix if *value* is malformed calldata; else ``None``.

    Iteration-68 mirror of :class:`vca.types.normalized.NormalizedTransaction`'s
    ``input`` ``BeforeValidator`` (:func:`_validate_optional_calldata`). The
    proxy-tx / account-tx normalisers read ``input`` via ``_maybe_calldata``,
    which returns ``None`` for a missing / non-``str`` value (short-circuit) and
    passes a present ``str`` verbatim to the validator — so only a PRESENT
    ``str`` malformed input (no ``0x`` prefix / odd-length / non-hex) leaks a raw
    ``pydantic.ValidationError`` past the typed
    :class:`vca.adapters.evm._errors.EtherscanError` boundary (cache-poison).

    REUSE the validator directly so the mirror is EXACT: ``None`` and a non-``str``
    value return verbatim WITHOUT raising — matching ``_maybe_calldata``'s
    short-circuit (which nulls them) so they are NOT a problem; ``""`` / ``"0x"`` /
    even-length ``0x``-hex pass; and only a present ``str`` malformed value raises
    → a problem. Case-insensitive (the validator lower-cases its accepted form),
    so real UPPERCASE calldata passes unchanged → golden-safe; the message omits
    the value (house style echoes the field, not the value).
    """
    try:
        _validate_optional_calldata(value)
    except ValueError:
        return "must be 0x-prefixed even-length hex calldata"
    return None


def _unix_timestamp_range_problem(value: Any, *, base: int = 10) -> str | None:
    """Return ``None`` if *value* is a platform-representable unix timestamp; else a problem.

    Iteration-75 UPPER-range twin of the ITER-48 negative-sign guard. The row/block
    coercibility gates (:func:`_decimal_str_problem` / :func:`_hex_str_problem`)
    accept any ``int``-coercible non-negative value, but Python ints are unbounded
    while the consumer :func:`datetime.fromtimestamp` (fed the ``timeStamp`` /
    ``timestamp`` field by ``normalize_account_tx`` / ``normalize_internal_tx`` /
    ``normalize_block_ref``) raises ``OverflowError`` / ``OSError`` ("Invalid
    argument") on a value outside the platform ``time_t`` range. So a coercible-but-
    out-of-range timestamp passed every gate, was cached under ``historical_ttl=None``
    and then leaked a bare ``OverflowError`` past the typed
    :class:`vca.adapters.evm._errors.EtherscanError` boundary (cache-poison).

    Mirror the consumer EXACTLY — ``datetime.fromtimestamp(int(str(value), base),
    tz=UTC)`` — so it accepts every real unix-second timestamp and rejects only the
    never-in-golden out-of-range case. *base* is 10 for the decimal ``timeStamp``
    rows and 16 for the hex block ``timestamp`` (the coercibility gate upstream has
    already validated the field's format for that base). Applied ONLY to the
    timestamp field — NOT folded into the shared decimal/hex predicates, which also
    gate ``value`` / ``blockNumber`` / balance (legitimately huge → a global range
    check would over-reject). The ``ValueError`` arm is defensive (the coercibility
    gate runs first); the message omits the field (the caller prefixes it).
    """
    try:
        datetime.fromtimestamp(int(str(value), base), tz=UTC)
    except (OverflowError, OSError, ValueError):
        return f"timestamp out of platform range: {str(value)!r}"
    return None
