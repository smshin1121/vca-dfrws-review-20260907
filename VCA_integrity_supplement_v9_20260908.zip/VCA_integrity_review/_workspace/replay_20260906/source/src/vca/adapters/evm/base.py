"""EvmBaseAdapter — Etherscan v2 wrapper implementing :class:`ChainAdapter` (P1-003).

Concrete adapter; subclasses (EthereumAdapter P1-004, ArbitrumAdapter P1-005)
pin ``chain_id``/``scanner_chainid``/``api_key`` via the constructor — there
is no need to override methods. The class is "abstract by convention":
direct instantiation works, but a chain-specific subclass with sensible
defaults is preferred.

Decisions live in ``_workspace/P1-003_architect_wbs.md`` §6.
"""

from __future__ import annotations

import json
from collections.abc import Callable, Mapping
from types import MappingProxyType
from typing import Any, Final

from pydantic import SecretStr

from vca.adapters.evm._errors import EtherscanError
from vca.adapters.evm._etherscan_v2 import (
    ETHERSCAN_V2_BASE_URL,
    assert_account_balance_ok,
    assert_account_rows_ok,
    assert_proxy_block_ok,
    assert_proxy_ok,
    assert_proxy_receipt_ok,
    assert_proxy_tx_ok,
    is_account_balance_ok,
    is_account_rows_ok,
    is_proxy_block_ok,
    is_proxy_ok,
    is_proxy_receipt_ok,
    is_proxy_tx_ok,
    normalize_account_tx,
    normalize_balance_native,
    normalize_balance_token,
    normalize_block_ref,
    normalize_internal_tx,
    normalize_log,
    normalize_tx_from_proxy,
)
from vca.adapters.evm._params import (
    build_params_balance_native,
    build_params_balance_token,
    build_params_eth_block_number,
    build_params_get_block,
    build_params_get_receipt,
    build_params_get_tx,
    build_params_txlist,
    build_params_txlistinternal,
)
from vca.http.client import params_hash
from vca.types import (
    Address,
    Asset,
    Balance,
    BlockRef,
    ChainId,
    Cursor,
    DecodedCall,
    NormalizedLog,
    NormalizedTransaction,
    Page,
)
from vca.types.normalized import _validate_chain_tx_hash

# P1-005 R-BASE-URL-DUP: re-bind under the original module-private name so
# legacy references (and the S9 single-source-of-truth identity check in
# :mod:`tests.unit.adapters.evm.test_arbitrum`) still reach the shared
# object via :data:`vca.adapters.evm.base._DEFAULT_BASE_URL`.
_DEFAULT_BASE_URL: Final[str] = ETHERSCAN_V2_BASE_URL
_DEFAULT_TXLIST_OFFSET: Final[int] = 10000  # Etherscan max items per page
_DEFAULT_START_BLOCK: Final[int] = 0
# Codex P2-4 (round 3): a bounded short TTL for ``proxy.eth_blockNumber``.
# 12s is roughly one Ethereum block; conservative for the faster-block chains
# we support today (Arbitrum / Optimism / BSC). The cap keeps "latest" from
# freezing forever when ``balance_ttl_sec`` is configured to ``None``.
_DEFAULT_LATEST_BLOCK_TTL_SEC: Final[int] = 12
# Codex P2-8 (round 6): pin the ``(chain_id, scanner_chainid)`` pair the
# adapter accepts. A mismatched pair (e.g. ``ETHEREUM`` + ``42161``) silently
# stamped Arbitrum data with ``chain=eth`` — drift through the entire
# pipeline. Only the chains in scope for P1-003 are listed here; OPTIMISM /
# BSC etc. land in a follow-up PR (P1-004+) so the rejection set explicitly
# names the supported chains in error messages.
_CHAIN_TO_SCANNER_CHAINID: Final[Mapping[ChainId, int]] = MappingProxyType(
    {
        ChainId.ETHEREUM: 1,
        ChainId.ARBITRUM: 42161,
    }
)
# NB: there is no longer a hard-coded default end_block. When the cursor
# does not carry one, the adapter resolves it dynamically via
# :meth:`EvmBaseAdapter._resolve_latest_block`. Etherscan's documented
# "latest" sentinel of 99_999_999 was already too small for Arbitrum
# (Codex P1-1 round-1 review).

# Iteration-6 P2-EVM-ADAPTER-ROWS-PER-ITEM-BOUNDARY: the per-item field sets
# the rows cache-write gate / asserter enforce on each ``module=account`` row.
# These MUST mirror the DIRECT (non-``.get``) subscripts in the relocated
# normalizers in :mod:`vca.adapters.evm._normalizers`: ``normalize_account_tx``
# subscripts ``hash`` / ``timeStamp`` / ``blockNumber`` / ``value``;
# ``normalize_internal_tx`` subscripts only ``timeStamp`` / ``blockNumber`` /
# ``value`` (the txlistinternal-by-txhash endpoint OMITS ``hash`` — commit
# 7fb1831 — so requiring it here would wrongly reject every real internal row).
_TXLIST_ROW_FIELDS: Final[tuple[str, ...]] = ("hash", "timeStamp", "blockNumber", "value")
_TXLISTINTERNAL_ROW_FIELDS: Final[tuple[str, ...]] = ("timeStamp", "blockNumber", "value")

# Iteration-16 P2-EVM-ADAPTER-ROW-NUMERIC-COERCIBILITY-BOUNDARY: the SUBSET of
# the required row fields the normalisers coerce via ``int(str(raw[field]))`` /
# ``datetime.fromtimestamp(int(str(raw["timeStamp"])))``. Iteration-6 validated
# these as present + ``str`` but NOT int-coercible, so a status==1 row like
# ``{"timeStamp":"abc", ...}`` passed the gate, was cached (cache-poison) and
# then crashed with a bare ``ValueError`` in the normaliser. These tuples thread
# the numeric-coercibility check through the rows SSOT pair. ``hash`` is NOT
# numeric.
_TXLIST_NUMERIC_FIELDS: Final[tuple[str, ...]] = ("timeStamp", "blockNumber", "value")
_TXLISTINTERNAL_NUMERIC_FIELDS: Final[tuple[str, ...]] = ("timeStamp", "blockNumber", "value")

# Iteration-25 P2-EVM-ADAPTER-ROW-OPTIONAL-NUMERIC-COERCIBILITY-BOUNDARY: the
# OPTIONAL numeric row fields the normalisers coerce only when present + non-empty
# (``g = raw.get("gasUsed"); int(str(g)) if g not in (None, "") else None``).
# ``gasUsed`` cannot join the required ``*_NUMERIC_FIELDS`` tuples above because it
# is OPTIONAL (absent on some rows) — the numeric gate there assumes present+str
# (``numeric_fields ⊆ required_fields``). Iteration-16 therefore left it OUT OF
# SCOPE, so a present, non-empty, non-decimal ``gasUsed`` (``"abc"``) still leaked
# a bare ``ValueError`` past the typed boundary (cache-poison). These tuples thread
# the sentinel-aware optional-numeric check through the rows SSOT pair.
_TXLIST_OPTIONAL_NUMERIC_FIELDS: Final[tuple[str, ...]] = ("gasUsed",)
_TXLISTINTERNAL_OPTIONAL_NUMERIC_FIELDS: Final[tuple[str, ...]] = ("gasUsed",)

# Iteration-62 P2-EVM-ADAPTER-ROW-ADDRESS-FORMAT-BOUNDARY: the row fields the
# normalisers feed to ``Address.from_str`` via ``_maybe_address`` (``from`` /
# ``to``). Neither is in the required/numeric tuples above, so a status==1 row
# whose ``from``/``to`` is present-but-malformed (``"0xZZZ.."`` / a non-hex str /
# a truthy non-str) passed every prior gate, was cached under
# ``historical_ttl=None`` (cache-poison) and then leaked a bare ``ValueError``
# from ``Address.from_str`` past the typed boundary on every replay — the
# multi-row twin of the single-tx proxy ``from``/``to`` guard (Iteration-44).
# ``_maybe_address`` short-circuits on falsy, so missing/empty/None stay legal
# (the gate truthiness-gates each field to match).
_TXLIST_ADDRESS_FIELDS: Final[tuple[str, ...]] = ("from", "to")
_TXLISTINTERNAL_ADDRESS_FIELDS: Final[tuple[str, ...]] = ("from", "to")

# Iteration-68 P2-EVM-ADAPTER-ROW-TX-HASH-FORMAT-BOUNDARY: the row field the
# normalisers feed to ``NormalizedTransaction``'s tx-hash after-validator. ``hash``
# is a REQUIRED present+str field (in ``_TXLIST_ROW_FIELDS``) but its FORMAT was
# never checked, so a status==1 row whose ``hash`` is present+str-but-malformed
# (``"0xZZ.."`` / wrong length) passed every prior gate, was cached under
# ``historical_ttl=None`` (cache-poison) and then leaked a raw
# ``pydantic.ValidationError`` from ``normalize_account_tx`` — the multi-row twin
# of the single-tx proxy ``hash`` FORMAT guard. ``txlist`` carries its OWN result
# ``hash``; ``txlistinternal``-by-txhash uses the authoritative PARENT canonical
# hash (commit 7fb1831) — never the item's — so it is NOT format-checked here
# (empty tuple).
_TXLIST_TX_HASH_FIELDS: Final[tuple[str, ...]] = ("hash",)
_TXLISTINTERNAL_TX_HASH_FIELDS: Final[tuple[str, ...]] = ()

# Iteration-68 P2-EVM-ADAPTER-ROW-INPUT-FORMAT-BOUNDARY: the OPTIONAL row field
# the normalisers feed to ``NormalizedTransaction``'s ``input`` BeforeValidator
# via ``_maybe_calldata`` (missing / non-str → ``None``). A present-str malformed
# ``input`` (non-``0x`` / odd-length / non-hex) passed every prior gate, was
# cached (poison) and then leaked a raw ``pydantic.ValidationError``. Both row
# endpoints carry ``input``, so both supply the tuple; the gate mirrors
# ``_maybe_calldata`` (absent / non-str stay legal).
_TXLIST_INPUT_FIELDS: Final[tuple[str, ...]] = ("input",)
_TXLISTINTERNAL_INPUT_FIELDS: Final[tuple[str, ...]] = ("input",)

# Iteration-75 P2-EVM-ADAPTER-ROW-TIMESTAMP-RANGE-BOUNDARY: the row field the
# normalisers feed to ``datetime.fromtimestamp`` (``int(str(timeStamp))``). It is
# already in the required + numeric tuples (present + str + decimal-coercible), but
# Python ints are unbounded while ``fromtimestamp`` raises ``OverflowError`` /
# ``OSError`` outside the platform ``time_t`` range — so a coercible-but-out-of-
# range ``timeStamp`` passed every gate, was cached under ``historical_ttl=None``
# (cache-poison) and then leaked a bare ``OverflowError`` past the typed boundary.
# Both row endpoints carry a decimal ``timeStamp``; the upper-range twin of the
# ITER-48 negative guard. (The hex block ``timestamp`` is range-checked directly in
# ``_proxy_block_shape_problem``, not via this row-threaded tuple.)
_TXLIST_TIMESTAMP_FIELDS: Final[tuple[str, ...]] = ("timeStamp",)
_TXLISTINTERNAL_TIMESTAMP_FIELDS: Final[tuple[str, ...]] = ("timeStamp",)


class EvmBaseAdapter:
    """Concrete :class:`vca.adapters.ChainAdapter` for any Etherscan v2 EVM chain."""

    def __init__(
        self,
        *,
        chain_id: ChainId,
        http_client: Any,
        raw_store: Any,
        api_key: SecretStr,
        scanner_chainid: int,
        rate_limit_source: str = "etherscan",
        base_url: str = _DEFAULT_BASE_URL,
        historical_ttl_sec: int | None = None,
        balance_ttl_sec: int | None = 120,
        latest_block_ttl_sec: int = _DEFAULT_LATEST_BLOCK_TTL_SEC,
        txlist_offset: int = _DEFAULT_TXLIST_OFFSET,
    ) -> None:
        # Codex P2-8 (round 6): chain pairing guard runs FIRST so the more
        # diagnostic "wrong subclass init args" failure surfaces ahead of
        # secondary validations (e.g. ``latest_block_ttl_sec``). Subsumes the
        # previous ``is_evm`` rejection — the supported set is explicitly
        # named in the error message so a future maintainer adding OPTIMISM /
        # BSC sees both the offending chain AND the mapping that must grow.
        expected_scanner_chainid = _CHAIN_TO_SCANNER_CHAINID.get(chain_id)
        if expected_scanner_chainid is None:
            supported = ", ".join(sorted(c.value for c in _CHAIN_TO_SCANNER_CHAINID))
            raise ValueError(
                f"chain_id {chain_id.value!r} not supported by EvmBaseAdapter "
                f"(supported: {supported})"
            )
        if scanner_chainid != expected_scanner_chainid:
            raise ValueError(
                f"scanner_chainid mismatch: chain_id={chain_id.value!r} expects "
                f"scanner_chainid={expected_scanner_chainid}, got {scanner_chainid}"
            )
        if latest_block_ttl_sec <= 0:
            # Codex P2-4: an unbounded (None) or zero TTL on eth_blockNumber
            # would freeze the upper bound of every get_address_txs call for
            # the worker's lifetime — silent data loss on a long-running job.
            raise ValueError(f"latest_block_ttl_sec must be > 0 (got {latest_block_ttl_sec!r})")
        self.chain_id = chain_id
        self._http = http_client
        self._raw = raw_store
        self._api_key = api_key
        self._scanner_chainid = scanner_chainid
        self._source = rate_limit_source
        self._base_url = base_url
        self._historical_ttl = historical_ttl_sec
        self._balance_ttl = balance_ttl_sec
        self._latest_block_ttl = latest_block_ttl_sec
        self._txlist_offset = txlist_offset

    # ------------------------------------------------------------------
    # ChainAdapter Protocol
    # ------------------------------------------------------------------

    async def get_tx(self, tx_hash: str) -> NormalizedTransaction:
        # Cycle 17 P2-EVM-ADAPTER-TX-HASH-BOUNDARY.1: field-named, specific
        # error message via :func:`_validate_chain_tx_hash`. NO HTTP request
        # is issued for malformed input — the boundary check fires *before*
        # ``build_params_get_tx`` composition + wire I/O so a token like
        # ``"foo/bar?evil=1"`` cannot burn a rate-limit token or pollute
        # raw_store. The helper's canonical lowercase return value is what
        # we pass downstream so a mixed-case caller cannot drift cassette /
        # raw_store cache keys (BTC adapter ``get_tx`` line 195 twin).
        canonical_tx_hash = _validate_chain_tx_hash(self.chain_id, tx_hash, field="tx_hash")
        params = build_params_get_tx(
            tx_hash=canonical_tx_hash,
            scanner_chainid=self._scanner_chainid,
            api_key=self._api_key,
        )
        endpoint = "proxy/eth_getTransactionByHash"
        # Codex P2-9 (round 6): pending tx (``blockNumber=null``) must not be
        # cached and must not feed the normaliser. ``is_proxy_tx_ok`` is the
        # cache-write gate; ``assert_proxy_tx_ok`` surfaces ``EtherscanError``
        # AFTER raw persistence (R-RAW-PERSIST-ON-ERROR unchanged).
        payload, raw_uri = await self._fetch_and_persist(
            params=params,
            endpoint=endpoint,
            ttl=self._historical_ttl,
            validator=is_proxy_tx_ok,
        )
        result = assert_proxy_tx_ok(payload, endpoint=endpoint)
        block = await self._resolve_block(str(result["blockNumber"]))
        return normalize_tx_from_proxy(
            raw_tx=result, block=block, chain=self.chain_id, raw_uri=raw_uri
        )

    async def get_logs(self, tx_hash: str) -> tuple[NormalizedLog, ...]:
        # Cycle 17 P2-EVM-ADAPTER-TX-HASH-BOUNDARY.1: see ``get_tx`` for the
        # rationale — boundary check before wire I/O; canonical lowercase form
        # used downstream so cassette / raw_store keys stay byte-equal.
        canonical_tx_hash = _validate_chain_tx_hash(self.chain_id, tx_hash, field="tx_hash")
        params = build_params_get_receipt(
            tx_hash=canonical_tx_hash,
            scanner_chainid=self._scanner_chainid,
            api_key=self._api_key,
        )
        endpoint = "proxy/eth_getTransactionReceipt"
        # Codex P2-9 (round 6): receipt for a pending tx also returns
        # ``blockNumber=null`` and must not be cached. Same pattern as
        # ``get_tx`` but on the receipt-specific predicate / asserter.
        payload, _ = await self._fetch_and_persist(
            params=params,
            endpoint=endpoint,
            ttl=self._historical_ttl,
            validator=is_proxy_receipt_ok,
        )
        result = assert_proxy_receipt_ok(payload, endpoint=endpoint)
        raw_logs = result.get("logs") or ()
        if not raw_logs:
            return ()
        block = await self._resolve_block(str(result["blockNumber"]))
        return tuple(normalize_log(raw_log=rl, block=block, chain=self.chain_id) for rl in raw_logs)

    async def get_tx_status(self, tx_hash: str) -> int | None:
        """Return the receipt status for ``tx_hash`` (1 success / 0 reverted).

        Round 28 codex P2 fix: ``get_tx`` is built from
        ``eth_getTransactionByHash`` whose response has no ``status``
        field, so ``NormalizedTransaction.status`` is always ``None`` for
        EVM seeds fetched via that endpoint. The Flow Tracer's
        reverted-seed guard would otherwise silently fall through. This
        method consults the receipt endpoint and returns the parsed
        status. Re-uses the same TTL / validator path as :meth:`get_logs`
        so the receipt fetch is cached.
        """
        # Cycle 17 P2-EVM-ADAPTER-TX-HASH-BOUNDARY.1: see ``get_tx`` for the
        # rationale — boundary check before wire I/O; canonical lowercase form
        # used downstream so cassette / raw_store keys stay byte-equal.
        canonical_tx_hash = _validate_chain_tx_hash(self.chain_id, tx_hash, field="tx_hash")
        params = build_params_get_receipt(
            tx_hash=canonical_tx_hash,
            scanner_chainid=self._scanner_chainid,
            api_key=self._api_key,
        )
        endpoint = "proxy/eth_getTransactionReceipt"
        payload, _ = await self._fetch_and_persist(
            params=params,
            endpoint=endpoint,
            ttl=self._historical_ttl,
            validator=is_proxy_receipt_ok,
        )
        result = assert_proxy_receipt_ok(payload, endpoint=endpoint)
        status_hex = result.get("status")
        if status_hex is None:
            return None
        return int(str(status_hex), 16)

    async def get_internal_txs(self, tx_hash: str) -> tuple[NormalizedTransaction, ...]:
        # Cycle 17 P2-EVM-ADAPTER-TX-HASH-BOUNDARY.1: see ``get_tx`` for the
        # rationale — boundary check before wire I/O; canonical lowercase form
        # used downstream so cassette / raw_store keys stay byte-equal.
        canonical_tx_hash = _validate_chain_tx_hash(self.chain_id, tx_hash, field="tx_hash")
        params = build_params_txlistinternal(
            tx_hash=canonical_tx_hash,
            scanner_chainid=self._scanner_chainid,
            api_key=self._api_key,
        )
        endpoint = "account/txlistinternal"
        payload, raw_uri = await self._fetch_account(
            params=params,
            endpoint=endpoint,
            ttl=self._historical_ttl,
            allow_empty=True,
            rows=True,
            row_fields=_TXLISTINTERNAL_ROW_FIELDS,
            row_numeric_fields=_TXLISTINTERNAL_NUMERIC_FIELDS,
            row_optional_numeric_fields=_TXLISTINTERNAL_OPTIONAL_NUMERIC_FIELDS,
            row_address_fields=_TXLISTINTERNAL_ADDRESS_FIELDS,
            row_tx_hash_fields=_TXLISTINTERNAL_TX_HASH_FIELDS,
            row_input_fields=_TXLISTINTERNAL_INPUT_FIELDS,
            row_timestamp_fields=_TXLISTINTERNAL_TIMESTAMP_FIELDS,
        )
        result = assert_account_rows_ok(
            payload,
            endpoint=endpoint,
            allow_empty=True,
            required_fields=_TXLISTINTERNAL_ROW_FIELDS,
            numeric_fields=_TXLISTINTERNAL_NUMERIC_FIELDS,
            optional_numeric_fields=_TXLISTINTERNAL_OPTIONAL_NUMERIC_FIELDS,
            address_fields=_TXLISTINTERNAL_ADDRESS_FIELDS,
            tx_hash_fields=_TXLISTINTERNAL_TX_HASH_FIELDS,
            input_fields=_TXLISTINTERNAL_INPUT_FIELDS,
            timestamp_fields=_TXLISTINTERNAL_TIMESTAMP_FIELDS,
        )
        # ITER-78: ``normalize_internal_tx`` carries a defensive cross-field guard
        # — a txlistinternal row whose ``hash``/``transactionHash`` disagrees with
        # the authoritative parent ``tx_hash`` raises a bare ``ValueError``
        # (``_normalizers.py``). ``assert_account_rows_ok`` above validates field
        # presence / coercibility / hash FORMAT but NOT this cross-field VALUE
        # consistency, so without this wrap a raw ``ValueError`` would leak past
        # the adapter's typed ``EtherscanError`` boundary on the live-captured
        # txlistinternal path (the ``KeyError`` sibling fixed in ``7fb1831``).
        # Narrow ``ValueError`` catch (NOT ``Exception``) preserves the typed
        # contract without masking unrelated faults.
        try:
            return tuple(
                normalize_internal_tx(
                    raw_internal=item,
                    chain=self.chain_id,
                    raw_uri=raw_uri,
                    tx_hash=canonical_tx_hash,
                )
                for item in result
            )
        except ValueError as exc:
            raise EtherscanError(
                f"internal tx normalization failed for endpoint={endpoint!r}",
                endpoint=endpoint,
                original_result=str(exc),
            ) from exc

    async def get_address_txs(
        self, addr: Address, cursor: Cursor | None
    ) -> Page[NormalizedTransaction]:
        if addr.chain is not self.chain_id:
            raise ValueError(
                f"addr.chain mismatch: adapter.chain={self.chain_id.value!r}, "
                f"addr.chain={addr.chain.value!r}"
            )
        page_n, offset, sort = self._page_params_from_cursor(cursor)
        start_block, end_block = await self._block_range_from_cursor(cursor)
        params = build_params_txlist(
            address=addr.value,
            start_block=start_block,
            end_block=end_block,
            page=page_n,
            offset=offset,
            sort=sort,
            scanner_chainid=self._scanner_chainid,
            api_key=self._api_key,
        )
        endpoint = "account/txlist"
        payload, raw_uri = await self._fetch_account(
            params=params,
            endpoint=endpoint,
            ttl=self._historical_ttl,
            allow_empty=True,
            rows=True,
            row_fields=_TXLIST_ROW_FIELDS,
            row_numeric_fields=_TXLIST_NUMERIC_FIELDS,
            row_optional_numeric_fields=_TXLIST_OPTIONAL_NUMERIC_FIELDS,
            row_address_fields=_TXLIST_ADDRESS_FIELDS,
            row_tx_hash_fields=_TXLIST_TX_HASH_FIELDS,
            row_input_fields=_TXLIST_INPUT_FIELDS,
            row_timestamp_fields=_TXLIST_TIMESTAMP_FIELDS,
        )
        result = assert_account_rows_ok(
            payload,
            endpoint=endpoint,
            allow_empty=True,
            required_fields=_TXLIST_ROW_FIELDS,
            numeric_fields=_TXLIST_NUMERIC_FIELDS,
            optional_numeric_fields=_TXLIST_OPTIONAL_NUMERIC_FIELDS,
            address_fields=_TXLIST_ADDRESS_FIELDS,
            tx_hash_fields=_TXLIST_TX_HASH_FIELDS,
            input_fields=_TXLIST_INPUT_FIELDS,
            timestamp_fields=_TXLIST_TIMESTAMP_FIELDS,
        )
        items = tuple(
            normalize_account_tx(raw_tx=item, chain=self.chain_id, raw_uri=raw_uri)
            for item in result
        )
        has_more = len(items) >= offset
        next_cursor: Cursor | None = None
        if has_more:
            next_token = json.dumps(
                {"page": page_n + 1, "offset": offset, "sort": sort},
                sort_keys=True,
                separators=(",", ":"),
            )
            next_cursor = Cursor(
                page_token=next_token, start_block=start_block, end_block=end_block
            )
        return Page[NormalizedTransaction](items=items, next_cursor=next_cursor, has_more=has_more)

    async def get_balance(self, addr: Address, at: BlockRef | None) -> Balance:
        if addr.chain is not self.chain_id:
            raise ValueError(
                f"addr.chain mismatch: adapter.chain={self.chain_id.value!r}, "
                f"addr.chain={addr.chain.value!r}"
            )
        # Codex P2-6 (round 5): mirror the round-1 ``addr.chain`` guard for
        # ``at.chain``. Without this pre-fetch check the adapter (a) issues
        # an Etherscan call, (b) persists the raw payload, and (c) only fails
        # inside ``Balance(at_block=...)`` Pydantic chain-coherence — leaking
        # a ``ValidationError`` instead of a typed ``ValueError`` and burning
        # an external request on a guaranteed-to-fail call.
        if at is not None and at.chain is not self.chain_id:
            raise ValueError(
                f"at.chain mismatch: adapter.chain={self.chain_id.value!r}, "
                f"at.chain={at.chain.value!r}"
            )
        params = build_params_balance_native(
            address=addr.value,
            scanner_chainid=self._scanner_chainid,
            api_key=self._api_key,
        )
        endpoint = "account/balance"
        payload, _ = await self._fetch_account(
            params=params, endpoint=endpoint, ttl=self._balance_ttl
        )
        result = assert_account_balance_ok(payload, endpoint=endpoint)
        return normalize_balance_native(
            raw_balance_str=str(result), addr=addr, chain=self.chain_id, at=at
        )

    async def decode_input(self, tx: NormalizedTransaction) -> DecodedCall | None:
        del tx  # decoder layer (P1-008+) owns calldata decoding
        return None

    # ------------------------------------------------------------------
    # ERC-20 balance — Protocol-adjacent
    # ------------------------------------------------------------------

    async def get_token_balance(
        self, addr: Address, token: Asset, at: BlockRef | None = None
    ) -> Balance:
        if addr.chain is not self.chain_id:
            raise ValueError(
                f"addr.chain mismatch: adapter.chain={self.chain_id.value!r}, "
                f"addr.chain={addr.chain.value!r}"
            )
        if token.chain is not self.chain_id:
            raise ValueError(
                f"token.chain mismatch: adapter.chain={self.chain_id.value!r}, "
                f"token.chain={token.chain.value!r}"
            )
        # Codex P2-7 (round 5): mirror the ``addr.chain`` / ``token.chain``
        # guards for ``at.chain``. Same rationale as ``get_balance``: avoid
        # the Etherscan call + raw persist on a guaranteed-to-fail input.
        if at is not None and at.chain is not self.chain_id:
            raise ValueError(
                f"at.chain mismatch: adapter.chain={self.chain_id.value!r}, "
                f"at.chain={at.chain.value!r}"
            )
        if token.contract is None:
            raise ValueError(
                f"get_token_balance requires an ERC-20 asset (contract != None), "
                f"got native asset: {token.symbol}"
            )
        params = build_params_balance_token(
            address=addr.value,
            contract=token.contract.value,
            scanner_chainid=self._scanner_chainid,
            api_key=self._api_key,
        )
        endpoint = "account/tokenbalance"
        payload, _ = await self._fetch_account(
            params=params, endpoint=endpoint, ttl=self._balance_ttl
        )
        result = assert_account_balance_ok(payload, endpoint=endpoint)
        return normalize_balance_token(raw_balance_str=str(result), addr=addr, token=token, at=at)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _resolve_block(self, block_number_hex: str) -> BlockRef:
        """``eth_getBlockByNumber`` for the supplied hex block number.

        The HttpClient cache (P0-008, ``historical_ttl_sec=None`` → unbounded)
        absorbs repeated calls for the same block, so the per-block cost is
        amortised across the worker's lifetime.

        Iteration-5: the block ``result`` reaches :func:`normalize_block_ref`,
        which subscripts ``number``/``timestamp`` via ``int(str(...), 16)``. The
        envelope-only ``assert_proxy_ok`` did NOT assert that shape, so a
        malformed-but-envelope-ok block body (non-Mapping result, missing or
        null ``number``/``timestamp``) leaked a bare ``TypeError`` / ``KeyError``
        / ``ValueError`` instead of a typed :class:`EtherscanError` — and, worse,
        under the unbounded historical cache the envelope-only ``is_proxy_ok``
        write-gate would persist that body once and re-throw forever on replay.
        We therefore call :meth:`_fetch_and_persist` directly with the stricter
        :func:`is_proxy_block_ok` cache-write gate (mirroring ``get_tx`` /
        ``get_logs``, NOT the envelope-only ``_fetch_proxy``) and surface the
        typed error via :func:`assert_proxy_block_ok`. ``_resolve_latest_block``
        keeps ``_fetch_proxy`` because its ``result`` is a hex STRING where the
        envelope-only gate + trailing ``isinstance(result, str)`` check is
        correct.
        """
        params = build_params_get_block(
            block_number_hex=block_number_hex,
            scanner_chainid=self._scanner_chainid,
            api_key=self._api_key,
        )
        endpoint = "proxy/eth_getBlockByNumber"
        payload, _ = await self._fetch_and_persist(
            params=params,
            endpoint=endpoint,
            ttl=self._historical_ttl,
            validator=is_proxy_block_ok,
        )
        result = assert_proxy_block_ok(payload, endpoint=endpoint)
        return normalize_block_ref(raw_block=result, chain=self.chain_id)

    def _page_params_from_cursor(self, cursor: Cursor | None) -> tuple[int, int, str]:
        """Decode page_token JSON; defaults page=1, offset=self._txlist_offset, sort='asc'.

        Codex P2-1: when the cursor carries an explicit ``offset`` it MUST take
        precedence over the adapter's default. Etherscan pagination is keyed on
        ``(page, offset)``; mismatching the offset between consecutive pages
        skips or duplicates rows. ``self._txlist_offset`` is only used as the
        first-page (cursor=None / no-offset-key) default.
        """
        if cursor is None or cursor.page_token is None:
            return 1, self._txlist_offset, "asc"
        # ITER-37: cursor.page_token is a resume trust boundary — a crashed worker
        # resumes exactly from it (types/_adapter_io.py). Mirror the rigorous BTC
        # _last_seen_txid_from_cursor twin: a corrupted / manually-edited /
        # cross-version token must raise a CLEAR ValueError, NOT leak a raw
        # json.JSONDecodeError (non-JSON), AttributeError ('int' has no .get) /
        # TypeError ("'offset' in 123") on a non-dict, or an opaque int() ValueError
        # on a non-int page/offset — so a corrupt resume token never silently
        # regresses. The token carries only {page, offset, sort} (no secrets).
        try:
            decoded = json.loads(cursor.page_token)
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"Cursor.page_token must encode a JSON object, got: {cursor.page_token!r}"
            ) from exc
        if not isinstance(decoded, dict):
            raise ValueError(  # noqa: TRY004 - corrupt resume token is a value-domain error (sibling-parity with BTC _last_seen_txid_from_cursor)
                f"Cursor.page_token must encode a JSON object, got: {cursor.page_token!r}"
            )
        try:
            page_n = int(decoded.get("page", 1))
            offset = int(decoded["offset"]) if "offset" in decoded else self._txlist_offset
        except (ValueError, TypeError) as exc:
            raise ValueError(
                f"Cursor.page_token page/offset must be int-coercible, got: {cursor.page_token!r}"
            ) from exc
        sort = str(decoded.get("sort", "asc"))
        return page_n, offset, sort

    async def _block_range_from_cursor(self, cursor: Cursor | None) -> tuple[int, int]:
        """Resolve ``(start_block, end_block)``; fetch latest block when missing.

        Codex P1-1: the previous hard-coded ``end=99_999_999`` was already too
        small for Arbitrum (chain head > 268M). When the cursor lacks
        ``end_block``, query :meth:`_resolve_latest_block` for the chain's
        current head — keeps Ethereum, Arbitrum, BSC, Optimism all correct.
        """
        start = (
            cursor.start_block
            if cursor is not None and cursor.start_block is not None
            else _DEFAULT_START_BLOCK
        )
        if cursor is not None and cursor.end_block is not None:
            return start, cursor.end_block
        latest = await self._resolve_latest_block()
        return start, latest

    async def _resolve_latest_block(self) -> int:
        """``proxy.eth_blockNumber`` → int; raw payload preserved via raw_store.

        Issued at most once per ``get_address_txs`` call when the caller did
        not supply an ``end_block``. The HttpClient cache absorbs repeats
        within :attr:`_latest_block_ttl` (Codex P2-4 round 3 — bounded short
        TTL ensures "latest" stays fresh even when ``balance_ttl_sec`` is
        configured to ``None``); we still record every call as evidence so a
        later replay can reproduce the exact upper bound used.

        Codex P2-3 (round 2): the previous implementation skipped
        :func:`assert_proxy_ok`, so an Etherscan auth/rate-limit envelope
        ``{"status":"0","message":"NOTOK","result":"Error! Invalid API Key"}``
        leaked a raw ``ValueError`` through ``int(result, 16)``. We now share
        the same envelope-detection helper every other proxy method uses
        (raw payload is already persisted by ``_fetch_proxy`` before this
        runs — R-RAW-PERSIST-ON-ERROR). The trailing ``isinstance`` guard
        catches the residual case where the JSON-RPC layer returns a
        non-string result without an Etherscan error envelope.
        """
        params = build_params_eth_block_number(
            scanner_chainid=self._scanner_chainid,
            api_key=self._api_key,
        )
        endpoint = "proxy/eth_blockNumber"
        payload, _ = await self._fetch_proxy(
            params=params, endpoint=endpoint, ttl=self._latest_block_ttl
        )
        result = assert_proxy_ok(payload, endpoint=endpoint)
        if not isinstance(result, str):
            raise EtherscanError(
                f"eth_blockNumber returned non-string result for endpoint={endpoint!r}",
                endpoint=endpoint,
                original_result=str(result),
            )
        # Iteration-28/17 hex-coercibility class, asserter-side: the isinstance
        # guard above catches a non-string result, but a present-but-non-hex
        # STRING ('latest' / '') still slips through and would leak a bare
        # ValueError from ``int(result, 16)`` — a value-wrong inconsistency vs the
        # function's typed shape-wrong error. The envelope-only ``is_proxy_ok``
        # cache gate (via ``_fetch_proxy``) does not check hex-ness, so such a
        # payload is cached under the bounded ``_latest_block_ttl`` and re-thrown
        # until expiry. Wrap the actual coercion (cannot drift from the consumer).
        try:
            return int(result, 16)
        except ValueError as exc:
            raise EtherscanError(
                f"eth_blockNumber returned non-hex result for endpoint={endpoint!r}",
                endpoint=endpoint,
                original_result=str(result),
            ) from exc

    async def _fetch_proxy(
        self, *, params: dict[str, Any], endpoint: str, ttl: int | None
    ) -> tuple[dict[str, Any], str]:
        """Fetch + persist for ``module=proxy`` endpoints.

        The error envelope detection runs **after** persistence so the raw
        response is on disk before :class:`EtherscanError` propagates
        (R-RAW-PERSIST-ON-ERROR). A pure-inspection ``is_proxy_ok`` predicate
        is handed to ``HttpClient.get_json`` as the cache-write gate so
        Etherscan's 200-OK error envelope does not poison the historical
        cache (Codex P1-2 round 3).
        """
        return await self._fetch_and_persist(
            params=params, endpoint=endpoint, ttl=ttl, validator=is_proxy_ok
        )

    async def _fetch_account(
        self,
        *,
        params: dict[str, Any],
        endpoint: str,
        ttl: int | None,
        allow_empty: bool = False,
        rows: bool = False,
        row_fields: tuple[str, ...] = (),
        row_numeric_fields: tuple[str, ...] = (),
        row_optional_numeric_fields: tuple[str, ...] = (),
        row_address_fields: tuple[str, ...] = (),
        row_tx_hash_fields: tuple[str, ...] = (),
        row_input_fields: tuple[str, ...] = (),
        row_timestamp_fields: tuple[str, ...] = (),
    ) -> tuple[dict[str, Any], str]:
        """Fetch + persist for ``module=account`` endpoints.

        ``allow_empty=True`` for ``txlist``/``txlistinternal`` so the legitimate
        "No transactions found" envelope is not mis-classified as an error.
        Codex P1-2 (round 3): the same flag is threaded through the cache-
        write predicate so the empty-page envelope is cacheable while genuine
        ``status="0"`` errors are not.

        Iteration 3: ``rows=True`` for the two row-iterating endpoints
        (``txlist`` / ``txlistinternal``) so the cache-write gate additionally
        rejects a non-list ``result`` (cache-poison hole) via
        :func:`is_account_rows_ok`. ``get_balance`` keeps ``rows=False`` because
        it consumes ``result`` as a STRING. The two concepts (empty-page
        tolerance vs list-ness) stay explicit even though they currently
        correlate.

        Iteration 6: ``row_fields`` (the per-endpoint required-field set:
        :data:`_TXLIST_ROW_FIELDS` / :data:`_TXLISTINTERNAL_ROW_FIELDS`) is
        threaded into the rows cache-write gate so a list carrying a MALFORMED
        item (``[{}]`` / ``["0x.."]`` / ``[None]``) is also rejected — closing
        the per-item cache-poison hole, not just the non-list one. Ignored when
        ``rows=False`` (the balance/tokenbalance string path).

        Iteration 7: ``rows=False`` ALWAYS means a balance endpoint
        (``get_balance``/``get_token_balance`` are the only ``rows=False``
        callers — verified at the four ``_fetch_account`` call sites). Its
        cache-write gate is now :func:`is_account_balance_ok`, which additionally
        rejects a non-numeric status==1 ``result`` (``None`` / ``{}`` /
        ``"Max rate limit reached"`` / ``""``) so it is not cache-poisoned under
        ``balance_ttl`` and re-thrown forever on replay.

        Iteration 16: ``row_numeric_fields`` (the per-endpoint numeric-field
        subset: :data:`_TXLIST_NUMERIC_FIELDS` / :data:`_TXLISTINTERNAL_NUMERIC_FIELDS`)
        is threaded into the rows cache-write gate so a list carrying a row whose
        numeric field is present+str but non-decimal (``{"timeStamp":"abc", ...}``)
        is also rejected — closing the per-row numeric-coercibility cache-poison
        hole the Iteration-6 present+str gate left open. Ignored when
        ``rows=False`` (the balance string path).

        Iteration 25: ``row_optional_numeric_fields`` (the per-endpoint OPTIONAL
        numeric subset: :data:`_TXLIST_OPTIONAL_NUMERIC_FIELDS` /
        :data:`_TXLISTINTERNAL_OPTIONAL_NUMERIC_FIELDS` — ``gasUsed``) is threaded
        into the rows cache-write gate so a row whose ``gasUsed`` is present +
        non-empty but non-decimal (``{"gasUsed":"abc", ...}``) is also rejected,
        closing the lone optional-numeric cache-poison hole Iteration-16 left open
        (``gasUsed`` cannot join the required numeric tuple — it is ``.get`` behind
        a ``not in (None, "")`` guard). Ignored when ``rows=False``.

        Iteration 62: ``row_address_fields`` (the per-endpoint ``from``/``to`` set:
        :data:`_TXLIST_ADDRESS_FIELDS` / :data:`_TXLISTINTERNAL_ADDRESS_FIELDS`) is
        threaded into the rows cache-write gate so a row whose ``from``/``to`` is
        present-but-malformed is rejected — closing the multi-row ``Address.from_str``
        cache-poison hole (the twin of the single-tx proxy guard). Ignored when
        ``rows=False``.

        Iteration 68: ``row_tx_hash_fields`` (the per-endpoint ``hash`` FORMAT set:
        :data:`_TXLIST_TX_HASH_FIELDS` — ``("hash",)`` for txlist;
        :data:`_TXLISTINTERNAL_TX_HASH_FIELDS` — EMPTY for txlistinternal, whose
        parent canonical hash is authoritative) and ``row_input_fields`` (the
        ``input`` FORMAT set: :data:`_TXLIST_INPUT_FIELDS` /
        :data:`_TXLISTINTERNAL_INPUT_FIELDS` — ``("input",)``) are threaded into the
        rows cache-write gate so a row whose ``hash`` / ``input`` is present-but-
        malformed is rejected — closing the multi-row ``NormalizedTransaction``
        tx-hash / calldata cache-poison hole (the twin of the single-tx proxy
        guard). Ignored when ``rows=False``.

        Iteration 75: ``row_timestamp_fields`` (the per-endpoint ``timeStamp`` set:
        :data:`_TXLIST_TIMESTAMP_FIELDS` / :data:`_TXLISTINTERNAL_TIMESTAMP_FIELDS`)
        adds the platform-range check so a coercible-but-out-of-``time_t``-range
        ``timeStamp`` (``datetime.fromtimestamp`` ``OverflowError``) is rejected.
        Ignored when ``rows=False``.
        """

        def _validator(payload: dict[str, Any]) -> bool:
            return (
                is_account_rows_ok(
                    payload,
                    allow_empty=allow_empty,
                    required_fields=row_fields,
                    numeric_fields=row_numeric_fields,
                    optional_numeric_fields=row_optional_numeric_fields,
                    address_fields=row_address_fields,
                    tx_hash_fields=row_tx_hash_fields,
                    input_fields=row_input_fields,
                    timestamp_fields=row_timestamp_fields,
                )
                if rows
                else is_account_balance_ok(payload, allow_empty=allow_empty)
            )

        return await self._fetch_and_persist(
            params=params, endpoint=endpoint, ttl=ttl, validator=_validator
        )

    async def _fetch_and_persist(
        self,
        *,
        params: dict[str, Any],
        endpoint: str,
        ttl: int | None,
        validator: Callable[[dict[str, Any]], bool] | None = None,
    ) -> tuple[dict[str, Any], str]:
        payload = await self._http.get_json(
            self._base_url,
            params,
            source=self._source,
            ttl=ttl,
            validator=validator,
        )
        # Codex round-5 P2-10: ``HttpClient._get_any`` builds its cache key
        # via ``params_hash(params, url=url, ...)`` (round-3 P2-6). The
        # raw_store fingerprint here MUST mirror that contribution so a
        # diagnostic query joining the response cache and raw_store by hash
        # returns the same row. Etherscan v2 routes every chain through the
        # same ``self._base_url``, so the URL contribution is constant within
        # an adapter instance — the alignment matters for cross-source joins
        # (e.g. an arbiscan-source adapter reusing the same Etherscan v2 host
        # would still differ in ``source`` but share ``params_hash`` cleanly).
        storage_uri = await self._raw.put(
            source=self._source,
            endpoint=endpoint,
            params_hash=params_hash(params, url=self._base_url),
            payload=payload,
            status_code=200,
            ttl=ttl,
        )
        return payload, storage_uri


__all__ = ["EvmBaseAdapter"]
