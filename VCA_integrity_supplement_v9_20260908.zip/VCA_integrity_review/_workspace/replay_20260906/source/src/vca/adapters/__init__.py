"""ChainAdapter Protocol + registry (P1-002).

Public surface
--------------
* :class:`ChainAdapter` — async Protocol every adapter implements.
* :data:`NormalizedTx` — alias for :class:`~vca.types.NormalizedTransaction`.
* :class:`AdapterRegistry` — chain → adapter binding.
* :func:`get_registry` — lru_cache singleton.
* :func:`register_adapter` — convenience wrapper around the singleton.
* Re-exported helper types from :mod:`vca.types`: :class:`Cursor`,
  :class:`Page`, :class:`Balance`, :class:`NormalizedLog`.
"""

from vca.adapters.base import ChainAdapter, NormalizedTx
from vca.adapters.registry import AdapterRegistry, get_registry, register_adapter
from vca.types import Balance, Cursor, NormalizedLog, Page

__all__ = [
    "AdapterRegistry",
    "Balance",
    "ChainAdapter",
    "Cursor",
    "NormalizedLog",
    "NormalizedTx",
    "Page",
    "get_registry",
    "register_adapter",
]
