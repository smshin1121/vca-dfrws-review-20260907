"""ArbitrumAdapter — Arbitrum One pin of EvmBaseAdapter (P1-005).

Wraps :class:`vca.adapters.evm.base.EvmBaseAdapter` with
``chain_id=ChainId.ARBITRUM`` and ``scanner_chainid=42161`` fixed at
construction time. Subclasses cannot override either pin — see
``_workspace/P1-005_architect_wbs.md`` §6 R-PIN-MECHANISM.

Bootstrap helpers
-----------------
* :func:`build_arbitrum_adapter` — :class:`Settings` + injected
  :class:`HttpClient` / :class:`RawResponseStore` → fresh adapter instance.
* :func:`register_arbitrum_adapter` — same, plus :class:`AdapterRegistry`
  binding via the P1-002 ``register`` Protocol.

Decalcomania of :mod:`vca.adapters.evm.ethereum` (P1-004) — only the
chain pin / scanner chainid / settings field change. Methods are
inherited verbatim from :class:`EvmBaseAdapter` (no overrides);
:class:`ArbitrumAdapter` shares one ``rate_limit_source = "etherscan"``
limiter bucket with :class:`EthereumAdapter` because Etherscan v2
enforces a single per-key budget across chains (R-RATE-LIMIT-NAME).

Decisions
---------
The base URL constant lives in :mod:`vca.adapters.evm._etherscan_v2`
as the public ``ETHERSCAN_V2_BASE_URL`` symbol — single source of truth
shared with :mod:`base` and :mod:`ethereum` (P1-005 R-BASE-URL-DUP
resolution).
"""

from __future__ import annotations

from typing import Final

from pydantic import SecretStr

from vca.adapters.evm._etherscan_v2 import ETHERSCAN_V2_BASE_URL
from vca.adapters.evm.base import _DEFAULT_TXLIST_OFFSET, EvmBaseAdapter
from vca.adapters.registry import AdapterRegistry
from vca.config import Settings
from vca.http.client import HttpClient
from vca.persistence.raw_store import RawResponseStore
from vca.types import ChainId

_ARBITRUM_SCANNER_CHAINID: Final[int] = 42161


class ArbitrumAdapter(EvmBaseAdapter):
    """Arbitrum One :class:`ChainAdapter`; chain pins are non-overridable.

    The constructor deliberately does NOT accept ``chain_id`` or
    ``scanner_chainid`` — they are bound to ``ChainId.ARBITRUM`` and
    ``42161`` respectively in the ``super().__init__`` call. A caller
    that passes either kwarg sees ``TypeError: unexpected keyword
    argument`` from Python's normal arg dispatch (and ``mypy --strict``
    rejects the call before runtime).
    """

    def __init__(
        self,
        *,
        http_client: HttpClient,
        raw_store: RawResponseStore,
        api_key: SecretStr,
        base_url: str = ETHERSCAN_V2_BASE_URL,
        historical_ttl_sec: int | None = None,
        balance_ttl_sec: int | None = 120,
        latest_block_ttl_sec: int = 12,
        txlist_offset: int = _DEFAULT_TXLIST_OFFSET,
    ) -> None:
        super().__init__(
            chain_id=ChainId.ARBITRUM,
            scanner_chainid=_ARBITRUM_SCANNER_CHAINID,
            http_client=http_client,
            raw_store=raw_store,
            api_key=api_key,
            base_url=base_url,
            historical_ttl_sec=historical_ttl_sec,
            balance_ttl_sec=balance_ttl_sec,
            latest_block_ttl_sec=latest_block_ttl_sec,
            txlist_offset=txlist_offset,
        )


def build_arbitrum_adapter(
    settings: Settings,
    *,
    http_client: HttpClient,
    raw_store: RawResponseStore,
    base_url: str | None = None,
) -> ArbitrumAdapter:
    """Construct an :class:`ArbitrumAdapter` from ``Settings`` + injected I/O.

    ``settings.arbiscan_api_key_primary`` is read as-is. The
    ``Settings._require_real_secrets`` validator (P0-003) already
    fail-fasts on placeholder/empty values, so this helper does not
    re-implement that check (R-FACTORY-PLACEHOLDER-DELEGATE).

    Args:
        settings: Loaded :class:`Settings`. ``arbiscan_api_key_primary``
            plus the two cache-TTL fields (``vca_cache_ttl_historical_sec``
            / ``vca_cache_ttl_balance_sec``) are consumed; the Etherscan key
            is never read here (R-FACTORY-ROLE).
        http_client: Externally-owned :class:`HttpClient`. Lifecycle and
            limiter wiring are the caller's responsibility.
        raw_store: Externally-owned :class:`RawResponseStore` for evidence
            persistence (R-RAW-PERSIST-ON-ERROR is enforced by the base).
        base_url: Override the production Etherscan v2 host. ``None``
            (default) preserves the production endpoint; tests pass a stub
            host (R-FACTORY-OVERRIDE-BASE-URL).

    Returns:
        A fresh :class:`ArbitrumAdapter` bound to the supplied I/O. The
        instance is **not** registered on any :class:`AdapterRegistry` —
        use :func:`register_arbitrum_adapter` for that.
    """
    return ArbitrumAdapter(
        http_client=http_client,
        raw_store=raw_store,
        api_key=settings.arbiscan_api_key_primary,
        base_url=base_url if base_url is not None else ETHERSCAN_V2_BASE_URL,
        # P3.4-002 #23: wire the formerly-dead cache-TTL Settings. ``historical``
        # uses the int(0)->None "unbounded" sentinel; ``balance`` is bounded
        # positive (config ge=1 -- the cache maps ttl<=0 to no-expiry/freeze).
        historical_ttl_sec=settings.vca_cache_ttl_historical_sec or None,
        balance_ttl_sec=settings.vca_cache_ttl_balance_sec,
    )


def register_arbitrum_adapter(
    registry: AdapterRegistry,
    settings: Settings,
    *,
    http_client: HttpClient,
    raw_store: RawResponseStore,
    replace: bool = False,
) -> ArbitrumAdapter:
    """Build + register on the supplied :class:`AdapterRegistry`.

    Re-raises P1-002's ``ValueError("chain 'arb' already registered ...")``
    when ``replace=False`` and ``ChainId.ARBITRUM`` is already registered.

    Args:
        registry: Target :class:`AdapterRegistry`. Bootstrap callers
            (P1-018) typically pass the singleton from
            :func:`vca.adapters.registry.get_registry`.
        settings: Loaded :class:`Settings` — see
            :func:`build_arbitrum_adapter`.
        http_client: Externally-owned :class:`HttpClient`.
        raw_store: Externally-owned :class:`RawResponseStore`.
        replace: When ``True``, overwrite an existing
            ``ChainId.ARBITRUM`` binding. Default ``False`` mirrors
            P1-002's safe default.

    Returns:
        The newly-built and just-registered :class:`ArbitrumAdapter`.
    """
    adapter = build_arbitrum_adapter(settings, http_client=http_client, raw_store=raw_store)
    registry.register(ChainId.ARBITRUM, adapter, replace=replace)
    return adapter


__all__ = [
    # Re-exported so the S9 single-source-of-truth identity check
    # (``tests/unit/adapters/evm/test_arbitrum.py``) can reach the shared
    # constant via :data:`vca.adapters.evm.arbitrum.ETHERSCAN_V2_BASE_URL`
    # without tripping mypy's ``attr-defined`` strictness on implicit
    # re-exports.
    "ETHERSCAN_V2_BASE_URL",
    "ArbitrumAdapter",
    "build_arbitrum_adapter",
    "register_arbitrum_adapter",
]
