"""ChainAdapter Protocol — chain-agnostic adapter surface (P1-002).

Concrete adapters (P1-003+) implement this Protocol; consumers (Tracer,
Decoder, Labeler) depend ONLY on this surface. The Protocol is
``runtime_checkable`` so misconfiguration surfaces as ``isinstance`` ``False``
at registry-bind time rather than as ``AttributeError`` mid-trace.

The Protocol matches ARCHITECTURE.md §3.1 with two strengthenings:

1. ``list[...]`` becomes ``tuple[...]`` everywhere so the surface stays
   immutable (consistent with ``NormalizedTransaction.transfers``).
2. ``chain_id: ChainId`` (P1-001 enum) replaces the design-doc's
   ``chain_id: str``.

The ``NormalizedTx`` alias bridges the design-doc name and the P1-001 type
:class:`vca.types.NormalizedTransaction`. It's a plain module-level binding
(not :class:`typing.TypeAlias`) so ``NormalizedTx is NormalizedTransaction``
holds at runtime — see DoD-4.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from vca.types import (
    Address,
    Balance,
    BlockRef,
    ChainId,
    Cursor,
    DecodedCall,
    NormalizedLog,
    NormalizedTransaction,
    Page,
)

# Module-local alias so the design-doc name resolves to the P1-001 type.
# A direct binding (not :class:`typing.TypeAlias`) so ``NormalizedTx is
# NormalizedTransaction`` holds at runtime — see DoD-4.
NormalizedTx = NormalizedTransaction


@runtime_checkable
class ChainAdapter(Protocol):
    """Seven-method async surface every chain adapter must expose.

    See ARCHITECTURE.md §3.1. ``runtime_checkable`` lets the registry verify
    method presence at register time; signatures are not introspected.
    """

    chain_id: ChainId

    async def get_tx(self, tx_hash: str) -> NormalizedTransaction: ...

    async def get_tx_status(self, tx_hash: str) -> int | None: ...

    async def get_logs(self, tx_hash: str) -> tuple[NormalizedLog, ...]: ...

    async def get_internal_txs(self, tx_hash: str) -> tuple[NormalizedTransaction, ...]: ...

    async def get_address_txs(
        self, addr: Address, cursor: Cursor | None
    ) -> Page[NormalizedTransaction]: ...

    async def get_balance(self, addr: Address, at: BlockRef | None) -> Balance: ...

    async def decode_input(self, tx: NormalizedTransaction) -> DecodedCall | None: ...


__all__ = ["ChainAdapter", "NormalizedTx"]
