"""Etherscan v2 API errors (P1-003)."""

from __future__ import annotations


class EtherscanError(Exception):
    """Etherscan v2 response is an error envelope or violates the expected shape.

    Etherscan's ``{"status":"0","message":"NOTOK","result":"Error! ..."}``
    envelope and JSON shape mismatches (e.g. missing ``"result"`` key) both
    surface through this exception. ``httpx`` transport errors are out of
    scope — :class:`vca.http.client.HttpClient` already handles retry/raise
    for them.
    """

    def __init__(
        self,
        message: str,
        *,
        endpoint: str,
        original_result: str | None = None,
    ) -> None:
        super().__init__(message)
        self.endpoint = endpoint
        self.original_result = original_result


__all__ = ["EtherscanError"]
