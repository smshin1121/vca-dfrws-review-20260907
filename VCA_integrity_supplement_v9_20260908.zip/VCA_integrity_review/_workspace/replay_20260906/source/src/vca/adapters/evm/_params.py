"""Etherscan v2 URL/params builders (P1-003, relocated ITER-16).

Pure request-parameter constructors for the ``module=proxy`` / ``module=account``
Etherscan v2 endpoints. Extracted verbatim from
:mod:`vca.adapters.evm._etherscan_v2` so neither module exceeds the 800-line cap
(WBS R-FILE-CAP); :mod:`vca.adapters.evm.base` imports the public builders
directly from here. Pure functions only — no I/O, no caches, no rate limits.
"""

from __future__ import annotations

from typing import Any

from pydantic import SecretStr


def _with_key(params: dict[str, Any], api_key: SecretStr) -> dict[str, Any]:
    """Attach the API key — kept out of the cache key by HttpClient defaults."""
    return {**params, "apikey": api_key.get_secret_value()}


def build_params_get_tx(
    *, tx_hash: str, scanner_chainid: int, api_key: SecretStr
) -> dict[str, Any]:
    """``module=proxy&action=eth_getTransactionByHash&txhash=...&chainid=N``."""
    return _with_key(
        {
            "module": "proxy",
            "action": "eth_getTransactionByHash",
            "txhash": tx_hash,
            "chainid": scanner_chainid,
        },
        api_key,
    )


def build_params_get_block(
    *, block_number_hex: str, scanner_chainid: int, api_key: SecretStr
) -> dict[str, Any]:
    """``module=proxy&action=eth_getBlockByNumber&tag=<hex>&boolean=false``."""
    return _with_key(
        {
            "module": "proxy",
            "action": "eth_getBlockByNumber",
            "tag": block_number_hex,
            "boolean": "false",
            "chainid": scanner_chainid,
        },
        api_key,
    )


def build_params_eth_block_number(*, scanner_chainid: int, api_key: SecretStr) -> dict[str, Any]:
    """``module=proxy&action=eth_blockNumber&chainid=N`` — returns the latest block as hex.

    Used by :class:`vca.adapters.evm.EvmBaseAdapter` to resolve the upper bound
    of a block range when the caller does not supply one. Per-chain because
    Arbitrum / BSC / Optimism block heights diverge wildly from Ethereum's.
    """
    return _with_key(
        {
            "module": "proxy",
            "action": "eth_blockNumber",
            "chainid": scanner_chainid,
        },
        api_key,
    )


def build_params_get_receipt(
    *, tx_hash: str, scanner_chainid: int, api_key: SecretStr
) -> dict[str, Any]:
    return _with_key(
        {
            "module": "proxy",
            "action": "eth_getTransactionReceipt",
            "txhash": tx_hash,
            "chainid": scanner_chainid,
        },
        api_key,
    )


def build_params_txlistinternal(
    *, tx_hash: str, scanner_chainid: int, api_key: SecretStr
) -> dict[str, Any]:
    return _with_key(
        {
            "module": "account",
            "action": "txlistinternal",
            "txhash": tx_hash,
            "chainid": scanner_chainid,
        },
        api_key,
    )


def build_params_txlist(
    *,
    address: str,
    start_block: int,
    end_block: int,
    page: int,
    offset: int,
    sort: str,
    scanner_chainid: int,
    api_key: SecretStr,
) -> dict[str, Any]:
    return _with_key(
        {
            "module": "account",
            "action": "txlist",
            "address": address,
            "startblock": start_block,
            "endblock": end_block,
            "page": page,
            "offset": offset,
            "sort": sort,
            "chainid": scanner_chainid,
        },
        api_key,
    )


def build_params_balance_native(
    *, address: str, scanner_chainid: int, api_key: SecretStr
) -> dict[str, Any]:
    return _with_key(
        {
            "module": "account",
            "action": "balance",
            "address": address,
            "tag": "latest",
            "chainid": scanner_chainid,
        },
        api_key,
    )


def build_params_balance_token(
    *, address: str, contract: str, scanner_chainid: int, api_key: SecretStr
) -> dict[str, Any]:
    return _with_key(
        {
            "module": "account",
            "action": "tokenbalance",
            "contractaddress": contract,
            "address": address,
            "tag": "latest",
            "chainid": scanner_chainid,
        },
        api_key,
    )


__all__ = [
    "build_params_balance_native",
    "build_params_balance_token",
    "build_params_eth_block_number",
    "build_params_get_block",
    "build_params_get_receipt",
    "build_params_get_tx",
    "build_params_txlist",
    "build_params_txlistinternal",
]
