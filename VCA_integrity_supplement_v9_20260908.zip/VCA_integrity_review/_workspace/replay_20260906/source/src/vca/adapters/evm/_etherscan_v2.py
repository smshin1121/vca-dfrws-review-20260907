"""Etherscan v2 multi-chain API helpers (P1-003).

Response-envelope handlers (predicate/asserter SSOT pairs over the
``module=proxy`` / ``module=account`` response envelopes). The URL/params
builders now live in :mod:`vca.adapters.evm._params`, the JSON-shape →
:mod:`vca.types` normalizers in :mod:`vca.adapters.evm._normalizers`, and the
pure coercibility-predicate helpers (``_decimal_str_problem`` /
``_hex_str_problem`` / ``_account_balance_problem``) in
:mod:`vca.adapters.evm._problems` (all re-exported here for import compat) —
each module was pulled out of :mod:`vca.adapters.evm.base` /
:mod:`vca.adapters.evm._etherscan_v2` so none exceeds the 800-line cap (WBS
R-FILE-CAP). Pure functions only — no I/O, no caches, no rate limits.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Final, cast

from vca.adapters.evm._errors import EtherscanError
from vca.adapters.evm._normalizers import (
    normalize_account_tx,
    normalize_balance_native,
    normalize_balance_token,
    normalize_block_ref,
    normalize_internal_tx,
    normalize_log,
    normalize_tx_from_proxy,
)
from vca.adapters.evm._problems import (
    _account_balance_problem,
    _decimal_str_problem,
    _evm_address_format_problem,
    _evm_calldata_problem,
    _evm_data_hex_problem,
    _evm_topic_hex_problem,
    _evm_tx_hash_format_problem,
    _hex_str_problem,
    _unix_timestamp_range_problem,
)

# ---------------------------------------------------------------------------
# Public constants
# ---------------------------------------------------------------------------

ETHERSCAN_V2_BASE_URL: Final[str] = "https://api.etherscan.io/v2/api"
"""Single source of truth for the Etherscan v2 multi-chain host.

Imported by :mod:`vca.adapters.evm.base` (aliased to ``_DEFAULT_BASE_URL``),
:mod:`vca.adapters.evm.ethereum` (aliased to ``_ETHERSCAN_V2_BASE_URL``),
and :mod:`vca.adapters.evm.arbitrum`. P1-005 promoted this constant from
three module-private duplicates per WBS R-BASE-URL-DUP. Etherscan v2 is
single-host (chainid is a query param, not a host prefix), so a single
public string is the right shape.
"""


# ---------------------------------------------------------------------------
# Response envelope handlers
# ---------------------------------------------------------------------------


def is_proxy_ok(payload: Mapping[str, Any]) -> bool:
    """Return ``True`` iff *payload* is a non-error ``module=proxy`` response.

    Pure structural inspection — never raises. Used by
    :class:`vca.http.client.HttpClient` as the cache-write gate so an Etherscan
    auth/rate-limit envelope (200 OK with ``status="0"``) is not stored under a
    historical (``ttl=None``) cache row. ``assert_proxy_ok`` runs after
    ``get_json`` returns to surface the typed :class:`EtherscanError`; the
    predicate here only decides whether to write to cache.

    A proxy response is considered cacheable when:

    * it does NOT carry the Etherscan error envelope (``status=="0"``);
    * the ``result`` key is present;
    * ``result`` is not ``None`` (``null`` proxy results are real "not found"
      answers and could be cached, but they can also indicate a stale lookup
      window — caching ``null`` is conservative-skip as well).
    """
    if "status" in payload and str(payload.get("status")) == "0":
        return False
    if "result" not in payload:
        return False
    return payload["result"] is not None


def _is_settled_blocknumber_hex(value: Any) -> bool:
    """Return True iff *value* is a non-null ``0x``-prefixed hex string.

    Codex P2-9 (round 6): pending transactions and pending receipts return
    ``blockNumber=null`` from JSON-RPC. ``"0x0"`` (genesis) is valid for
    receipt/tx semantics, so we only require the ``0x`` prefix and a non-null
    value — not a numeric > 0 check.
    """
    return isinstance(value, str) and value.startswith("0x")


def _proxy_settledness_problem(result: Any, *, kind: str) -> str | None:
    """Return ``None`` if *result* is a settled tx/receipt body; else a problem string.

    Codex P2-10 (round 7): single source of truth shared by predicate
    (:func:`is_proxy_tx_ok` / :func:`is_proxy_receipt_ok`) and asserter
    (:func:`assert_proxy_tx_ok` / :func:`assert_proxy_receipt_ok`). Round 6
    inlined these checks separately in the predicate and asserter, which let
    them drift — the asserter accepted half-settled responses
    (``blockNumber`` set, ``blockHash=null``) that the predicate rejected,
    so a payload the validator refused to cache could still slip through to
    the normaliser and crash with ``TypeError`` / ``AttributeError``.

    *kind* is the noun spliced into the message — ``"transaction"`` for
    tx-by-hash, ``"transaction receipt"`` for receipts. The full vocabulary
    of problem strings:

    * ``f"unexpected result type: expected dict, got {type(result).__name__}"``
    * ``f"pending {kind} (blockNumber=null)"``
    * ``f"inconsistent {kind} (blockNumber set but blockHash null)"``
    * (tx only) tx ``hash`` / ``value`` problems — see
      :func:`_proxy_tx_value_hash_problem`.
    * (receipt only) ``f"receipt.status {hex_problem}"`` — Iteration-28
      hex-coercibility guard on the receipt-level ``status`` flag (see
      :func:`_hex_str_problem`).

    Iteration-17 (tx-by-hash ONLY): :func:`normalize_tx_from_proxy` subscripts
    ``hash`` + ``value`` DIRECTLY (neither previously validated here), so a
    settled tx MISSING ``value`` / MISSING ``hash`` leaked a bare ``KeyError``
    and a non-hex ``value`` leaked a bare ``ValueError``. Scoped to
    ``kind == "transaction"`` because receipts carry NEITHER field — the receipt
    path (``kind == "transaction receipt"``) is unaffected.
    """
    if not isinstance(result, Mapping):
        return f"unexpected result type: expected dict, got {type(result).__name__}"
    if not _is_settled_blocknumber_hex(result.get("blockNumber")):
        return f"pending {kind} (blockNumber=null)"
    if not _is_settled_blocknumber_hex(result.get("blockHash")):
        return f"inconsistent {kind} (blockNumber set but blockHash null)"
    if kind == "transaction":
        tx_problem = _proxy_tx_value_hash_problem(result)
        if tx_problem is not None:
            return tx_problem
    # Receipts (and only receipts) carry a ``logs`` array that ``normalize_log``
    # subscripts field-by-field. The tx-by-hash result has no logs, so the
    # per-log shape gate is receipt-scoped. The ``logs`` value itself must be a
    # list before enumerating: a malformed ``"logs": null`` (or any non-list)
    # would otherwise raise a bare ``TypeError`` from ``enumerate`` — breaking
    # the no-throw cache predicate and bypassing this typed boundary. Absent
    # ``logs`` defaults to an empty tuple (legitimate empty receipt). Walk in
    # declared order so the lowest index drives the surfaced message.
    if kind == "transaction receipt":
        # Receipt-level success/revert flag (Iteration-25/17 hex-coercibility
        # class): ``base.py`` ``get_tx_status`` coerces it via
        # ``int(str(status), 16)``. It is OPTIONAL — absent for pending /
        # pre-Byzantium receipts (``get_tx_status`` returns ``None``) — so an
        # absent ``status`` is skipped; but a PRESENT non-hex ``status``
        # (``"zz"`` / ``""``) would otherwise pass this cache-write gate, be
        # cached under ``historical_ttl=None`` and then leak a bare
        # ``ValueError`` from ``base.py`` (cache-poison). Mirror the consumer
        # exactly via :func:`_hex_str_problem` (present-and-not-None ==
        # ``int(str(status), 16)`` is attempted). ``""`` is non-hex so the guard
        # fires, matching the consumer which only short-circuits on ``None``.
        status = result.get("status")
        if status is not None:
            status_problem = _hex_str_problem(status)
            if status_problem is not None:
                return f"receipt.status {status_problem}"
            # Scan #8 BV-1 (value-domain sibling of ITER-28/ITER-48): EIP-658
            # receipts carry ONLY ``0x0``/``0x1``. A coercible out-of-domain
            # value (``'0x2'``) passed the hex gate above, was cached
            # permanently (``historical_ttl=None``) and ``get_tx_status``
            # then handed the tracer a status the frozen
            # ``NormalizedTransaction`` forbids ({0, 1, None}) — injected
            # UNVALIDATED via ``model_copy`` (``_run.py``), so every
            # ``status == 0`` reverted check silently classified the
            # malformed receipt as SUCCESS. Reject at the shared gate so
            # both the cache-write predicate and the asserter close it.
            if int(str(status), 16) not in (0, 1):
                return f"receipt.status must be 0x0 or 0x1 (EIP-658), got {status!r}"
        logs = result.get("logs", ())
        if not isinstance(logs, (list, tuple)):
            return f"logs must be list, got {type(logs).__name__}"
        for idx, log in enumerate(logs):
            log_problem = _receipt_log_shape_problem(log)
            if log_problem is not None:
                return f"logs[{idx}]: {log_problem}"
    return None


def _proxy_tx_value_hash_problem(result: Mapping[str, Any]) -> str | None:
    """Return ``None`` if tx ``hash``/``value``/``from``/``to``/``input`` are well-formed.

    Iteration-17 tx-by-hash field gate, factored out of
    :func:`_proxy_settledness_problem`. :func:`normalize_tx_from_proxy` subscripts
    ``hash`` via ``str(...).lower()`` (present+str) and ``value`` via
    ``int(str(...), 16)`` (present+str+hex). Iteration-44 adds a ``from``/``to``
    FORMAT check (shared :func:`_evm_address_format_problem`) gated on truthiness,
    so missing/empty + contract-creation ``to=null`` stay legal.

    Iteration-68 closes the tx-side hex twin of the ITER-42/44/62 address-format
    family: ``normalize_tx_from_proxy`` feeds ``hash`` to
    :class:`NormalizedTransaction`'s ``_validate_tx_hash`` after-validator and
    ``input`` (via ``_maybe_calldata``) to its ``_validate_optional_calldata``
    ``BeforeValidator`` — so a present+str-but-malformed ``hash`` (non-``0x`` +
    64-hex) or a present-str malformed ``input`` (non-``0x`` / odd-length /
    non-hex) passed the present+str gate, was cached under ``historical_ttl=None``
    (cache-poison) and then leaked a raw ``pydantic.ValidationError`` past the
    typed boundary. The shared :func:`_evm_tx_hash_format_problem` (case-insensitive
    — uppercase hash passes) and :func:`_evm_calldata_problem` (which short-circuits
    missing / non-str ``input`` to "no problem", mirroring ``_maybe_calldata``)
    close both. Declared order: hash (presence/str/FORMAT), value, from, to, input.
    """
    if "hash" not in result:
        return "missing field 'tx.hash'"
    if not isinstance(result["hash"], str):
        return f"tx.hash must be str, got {type(result['hash']).__name__}"
    if "value" not in result:
        return "missing field 'tx.value'"
    if not isinstance(result["value"], str):
        return f"tx.value must be str, got {type(result['value']).__name__}"
    hex_problem = _hex_str_problem(result["value"])
    if hex_problem is not None:
        return f"tx.value {hex_problem}"
    hash_problem = _evm_tx_hash_format_problem(result["hash"])
    if hash_problem is not None:
        return f"tx.hash {hash_problem}"
    if (addr := result.get("from")) and (prob := _evm_address_format_problem(addr)):
        return f"tx.from {prob}"
    if (addr := result.get("to")) and (prob := _evm_address_format_problem(addr)):
        return f"tx.to {prob}"
    input_problem = _evm_calldata_problem(result.get("input"))
    if input_problem is not None:
        return f"tx.input {input_problem}"
    return None


def _receipt_log_shape_problem(raw_log: Any) -> str | None:
    """Return ``None`` if *raw_log* is a structurally-valid receipt log entry.

    Defensive-hardening twin of the BTC
    :func:`vca.adapters.btc._mempool._status_shape_problem`: the single source
    of truth for the fields :func:`normalize_log` subscripts without a per-field
    guard (``transactionHash`` / ``logIndex`` / ``address`` / ``data`` /
    ``topics``). Wired into :func:`_proxy_settledness_problem` so both the
    cache-write predicate (:func:`is_proxy_receipt_ok`) and the post-fetch
    asserter (:func:`assert_proxy_receipt_ok`) reject a malformed
    ``receipt.logs[i]`` with a typed :class:`EtherscanError` at the boundary
    instead of leaking a bare ``KeyError`` / ``TypeError`` deep in
    ``normalize_log``.

    These fields are JSON-RPC-spec-guaranteed, so this is consistency /
    defensive hardening — it never fires on a well-formed receipt and so leaves
    the happy path byte-identical (golden determinism).

    Invariants checked in declared order so the most diagnostic message wins:

    * ``raw_log`` itself is a ``Mapping``.
    * ``transactionHash`` is present and ``str`` (parsed via ``str(...).lower()``).
    * ``logIndex`` is present and ``str`` (parsed via ``int(str(...), 16)``).
    * ``address`` is present, ``str``, AND a well-formed EVM address (the
      ``Address.from_str`` FORMAT check; ITER-42).
    * ``data`` is present and ``str`` (parsed via ``str(...).lower()``).
    * ``topics`` — if PRESENT — is a list/tuple (anonymous events legitimately
      omit it; ``normalize_log`` defaults absent ``topics`` to ``()``, but
      ``.get`` returns a present ``null``/scalar verbatim, which would raise a
      bare ``TypeError`` from ``for t in <value>``). Mirrors the ``logs must be
      list`` envelope gate.

    Iteration-17 adds a HEX-coercibility check for ``logIndex`` ONLY: it is the
    sole log field ``normalize_log`` coerces via ``int(str(...), 16)`` (the other
    three are str-consumed via ``.lower()`` / ``Address.from_str``), so a
    present+str-but-non-hex ``logIndex`` (``"zz"`` / ``""`` / ``"0xZZ"``) passed
    the present+str gate and then leaked a bare ``ValueError`` deep in the
    normaliser + cache-poisoned under the historical TTL. The shared
    :func:`_hex_str_problem` (twin of :func:`_decimal_str_problem`, base-16)
    closes that hole and never fires on a real hex receipt.

    Iteration-42 adds a FORMAT check for ``address`` ONLY via the shared
    :func:`_evm_address_format_problem` (EVM sibling of the BTC ITER-36 guard;
    full rationale on that helper). It rejects a present+str-but-malformed
    address — and, unlike the BTC sibling, ``""`` too, since
    :func:`normalize_log` feeds ``address`` directly with no empty-skip.

    Iteration-67 closes the LAST hex-format siblings: the three fields the older
    prose called "str-consumed" (``transactionHash`` / ``data`` / each
    ``topics[i]``) are in fact HEX-validated by :class:`NormalizedLog`'s
    after-validators, so a present+str-but-malformed value passed the gate, was
    cache-poisoned and then leaked a raw ``pydantic.ValidationError``. The shared
    :func:`_evm_tx_hash_format_problem` / :func:`_evm_data_hex_problem` /
    :func:`_evm_topic_hex_problem` predicates mirror those validators exactly
    (case-insensitive — uppercase hex passes) and never fire on a real receipt.
    """
    if not isinstance(raw_log, Mapping):
        return f"log must be dict, got {type(raw_log).__name__}"
    for field in ("transactionHash", "logIndex", "address", "data"):
        if field not in raw_log:
            return f"missing field 'log.{field}'"
        value = raw_log[field]
        if not isinstance(value, str):
            return f"log.{field} must be str, got {type(value).__name__}"
    hex_problem = _hex_str_problem(raw_log["logIndex"])
    if hex_problem is not None:
        return f"log.logIndex {hex_problem}"
    address_problem = _evm_address_format_problem(raw_log["address"])
    if address_problem is not None:
        return f"log.address {address_problem}"
    tx_hash_problem = _evm_tx_hash_format_problem(raw_log["transactionHash"])
    if tx_hash_problem is not None:
        return f"log.transactionHash {tx_hash_problem}"
    data_problem = _evm_data_hex_problem(raw_log["data"])
    if data_problem is not None:
        return f"log.data {data_problem}"
    topics = raw_log.get("topics", ())
    if not isinstance(topics, (list, tuple)):
        return f"log.topics must be list, got {type(topics).__name__}"
    for i, topic in enumerate(topics):
        topic_problem = _evm_topic_hex_problem(topic)
        if topic_problem is not None:
            return f"log.topics[{i}] {topic_problem}"
    return None


def _proxy_block_shape_problem(result: Any) -> str | None:
    """Return ``None`` if *result* is a structurally-valid block body; else a problem.

    Single source of truth for the two fields :func:`normalize_block_ref` subscripts
    via ``int(str(raw_block[field]), 16)`` (``number`` / ``timestamp``) — wired into
    :func:`_proxy_block_problem` so the cache-write gate (:func:`is_proxy_block_ok`)
    and asserter (:func:`assert_proxy_block_ok`) agree by construction.
    ``assert_proxy_ok`` only narrows the proxy envelope to a non-null ``result`` and
    can NOT assert the block shape (the same handler serves ``eth_blockNumber``,
    whose ``result`` is a hex STRING), so without this gate a non-Mapping / missing /
    ``null`` / non-hex field leaks a bare ``TypeError`` / ``KeyError`` / ``ValueError``
    deep in :func:`normalize_block_ref` instead of a typed :class:`EtherscanError`.

    Declared order: Mapping, present + ``str`` (ITER-5), HEX-coercibility via
    :func:`_hex_str_problem` (ITER-17), then ``timestamp`` platform-range via
    :func:`_unix_timestamp_range_problem` (ITER-75 — ``timestamp`` alone is fed to
    ``datetime.fromtimestamp``; ``number`` is not). ``hash`` is read via ``.get(...)``
    behind an ``if block_hash else None`` guard so it is already safe. These fields
    are JSON-RPC-spec-guaranteed, so the gate never fires on a well-formed result →
    happy path byte-identical (golden determinism).
    """
    if not isinstance(result, Mapping):
        return f"unexpected result type: expected dict, got {type(result).__name__}"
    for field in ("number", "timestamp"):
        if field not in result:
            return f"missing field 'block.{field}'"
        value = result[field]
        if not isinstance(value, str):
            return f"block.{field} must be str, got {type(value).__name__}"
        hex_problem = _hex_str_problem(value)
        if hex_problem is not None:
            return f"block.{field} {hex_problem}"
    # Iteration-75: ``timestamp`` is additionally fed to ``datetime.fromtimestamp``
    # in ``normalize_block_ref``; a hex value coercible-but-out-of-platform-range
    # passed the hex gate then leaked a bare ``OverflowError`` (cache-poison).
    # ``number`` is NOT range-checked (it is only ``int(...)``, never a timestamp).
    range_problem = _unix_timestamp_range_problem(result["timestamp"], base=16)
    if range_problem is not None:
        return f"block.timestamp {range_problem}"
    return None


def _proxy_block_problem(payload: Mapping[str, Any]) -> str | None:
    """Return ``None`` if *payload* is a structurally-valid block response; else a problem.

    Block twin of :func:`_proxy_tx_problem`: envelope OK first
    (:func:`is_proxy_ok`), then the result-level block shape
    (:func:`_proxy_block_shape_problem`). Used by both
    :func:`is_proxy_block_ok` and :func:`assert_proxy_block_ok` so the
    cache-write gate and the post-fetch asserter cannot drift apart.
    """
    if not is_proxy_ok(payload):
        return "non-ok envelope"
    return _proxy_block_shape_problem(payload["result"])


def is_proxy_block_ok(payload: Mapping[str, Any]) -> bool:
    """Return ``True`` iff *payload* is a cacheable ``eth_getBlockByNumber`` response.

    The block-specific cache-write gate: composes :func:`is_proxy_ok` (envelope
    OK) with :func:`_proxy_block_shape_problem` (number/timestamp presence + str)
    so a malformed-but-envelope-ok block body — which ``is_proxy_ok`` alone
    would accept — is never written to the historical (``ttl=None``) cache. That
    closes the cache-poison hole: without this gate a malformed block payload
    would be stored once and re-thrown forever on every replay. Agrees with
    :func:`assert_proxy_block_ok` by construction.
    """
    return _proxy_block_problem(payload) is None


def assert_proxy_block_ok(payload: Mapping[str, Any], *, endpoint: str) -> Any:
    """Return the block ``result`` or raise :class:`EtherscanError`.

    Iteration-5 twin of :func:`assert_proxy_tx_ok`: wraps :func:`assert_proxy_ok`
    (envelope-level OK / error discrimination) and additionally rejects a
    malformed block body (non-Mapping ``result`` / missing or non-str
    ``number``/``timestamp``) via the shared :func:`_proxy_block_shape_problem`,
    surfacing a typed :class:`EtherscanError` at the boundary instead of leaking
    a bare ``TypeError`` / ``KeyError`` / ``ValueError`` deep inside
    :func:`normalize_block_ref`.
    """
    result = assert_proxy_ok(payload, endpoint=endpoint)
    problem = _proxy_block_shape_problem(result)
    if problem is not None:
        raise EtherscanError(
            f"{problem} for endpoint={endpoint!r}",
            endpoint=endpoint,
            original_result=problem,
        )
    return result


def _proxy_tx_problem(payload: Mapping[str, Any]) -> str | None:
    """Return ``None`` if *payload* is a settled tx response; else a problem string.

    Composition: envelope OK first (``is_proxy_ok``), then settledness
    invariants (:func:`_proxy_settledness_problem`). Used by both
    :func:`is_proxy_tx_ok` and :func:`assert_proxy_tx_ok` so the cache-write
    gate and the post-fetch raise-with-context cannot drift apart.
    """
    if not is_proxy_ok(payload):
        # Envelope-level rejection: the asserter (``assert_proxy_ok``) raises
        # a more specific message, so the predicate path returning a generic
        # marker here is fine — the asserter never reaches this branch.
        return "non-ok envelope"
    return _proxy_settledness_problem(payload["result"], kind="transaction")


def _proxy_receipt_problem(payload: Mapping[str, Any]) -> str | None:
    """Return ``None`` if *payload* is a settled receipt response; else a problem.

    Receipt twin of :func:`_proxy_tx_problem`; the only divergence is the
    ``kind`` noun used in problem strings — receipts say
    ``"pending transaction receipt (blockNumber=null)"``.
    """
    if not is_proxy_ok(payload):
        return "non-ok envelope"
    return _proxy_settledness_problem(payload["result"], kind="transaction receipt")


def is_proxy_tx_ok(payload: Mapping[str, Any]) -> bool:
    """Return ``True`` iff *payload* is a settled (mined) ``eth_getTransactionByHash``.

    Codex P2-9 (round 6): pending transactions return ``blockNumber=null`` /
    ``blockHash=null``. Caching that snapshot under a historical (``ttl=None``)
    cache row would freeze stale pending data forever — every subsequent read
    would return the pre-mining payload even after the tx mines.

    Codex P2-10 (round 7): delegates to :func:`_proxy_tx_problem` so the
    cache-write gate and :func:`assert_proxy_tx_ok` agree by construction.
    """
    return _proxy_tx_problem(payload) is None


def is_proxy_receipt_ok(payload: Mapping[str, Any]) -> bool:
    """Return ``True`` iff *payload* is a settled ``eth_getTransactionReceipt``.

    Codex P2-9 (round 6) / P2-10 (round 7): same rationale as
    :func:`is_proxy_tx_ok`; delegates to :func:`_proxy_receipt_problem`.
    """
    return _proxy_receipt_problem(payload) is None


def is_account_ok(payload: Mapping[str, Any], *, allow_empty: bool = False) -> bool:
    """Return ``True`` iff *payload* is a non-error ``module=account`` response.

    Pure structural inspection — never raises. Mirrors :func:`assert_account_ok`
    semantics (the legitimate "No transactions found" envelope is cacheable
    when ``allow_empty=True``) but returns a bool instead of raising. Used by
    :class:`vca.http.client.HttpClient` as the cache-write gate.
    """
    if "result" not in payload:
        return False
    if str(payload.get("status")) == "1":
        return True
    # status != "1": either an error or the empty-list edge case
    return allow_empty and str(payload.get("message", "")) == "No transactions found"


def assert_proxy_ok(payload: Mapping[str, Any], *, endpoint: str) -> Any:
    """Return ``payload['result']`` or raise :class:`EtherscanError`.

    ``module=proxy`` responses follow JSON-RPC shape ``{"jsonrpc","id","result"}``.
    The Etherscan error envelope ``{"status":"0","message":"NOTOK","result":"..."}``
    can also surface from proxy endpoints when authentication or rate limiting
    fails — the ``status`` key is the discriminator.
    """
    if "status" in payload and str(payload.get("status")) == "0":
        result = payload.get("result")
        # Distinguish empty proxy result from error envelope: error envelopes
        # carry a stringy result starting with "Error!"; proxy null results
        # never set status="0" (they only set result=null with no status key).
        message = str(result) if result is not None else str(payload.get("message"))
        raise EtherscanError(
            f"Etherscan v2 error for endpoint={endpoint!r}: {message}",
            endpoint=endpoint,
            original_result=str(result) if result is not None else None,
        )
    if "result" not in payload:
        raise EtherscanError(
            f"missing field 'result' for endpoint={endpoint!r}",
            endpoint=endpoint,
        )
    result = payload["result"]
    if result is None:
        raise EtherscanError(
            f"transaction not found for endpoint={endpoint!r}",
            endpoint=endpoint,
        )
    return result


def assert_proxy_tx_ok(payload: Mapping[str, Any], *, endpoint: str) -> Any:
    """Return the settled tx ``result`` or raise :class:`EtherscanError`.

    Codex P2-9 (round 6): mirrors :func:`assert_proxy_ok` and additionally
    rejects pending transactions (``blockNumber=null``).

    Codex P2-10 (round 7): also rejects half-settled responses
    (``blockNumber`` set but ``blockHash=null``) and non-Mapping ``result``
    shapes (e.g. ``eth_blockNumber``-shaped payload reaching the wrong
    handler — would otherwise leak a ``TypeError`` from string indexing).
    Single source of truth shared with :func:`is_proxy_tx_ok` via
    :func:`_proxy_settledness_problem`.
    """
    result = assert_proxy_ok(payload, endpoint=endpoint)
    problem = _proxy_settledness_problem(result, kind="transaction")
    if problem is not None:
        raise EtherscanError(
            f"{problem} for endpoint={endpoint!r}",
            endpoint=endpoint,
            original_result=problem,
        )
    return result


def assert_proxy_receipt_ok(payload: Mapping[str, Any], *, endpoint: str) -> Any:
    """Return the settled receipt ``result`` or raise :class:`EtherscanError`.

    Codex P2-9 (round 6): same pending-tx rationale as
    :func:`assert_proxy_tx_ok`.

    Codex P2-10 (round 7): also rejects half-settled receipts and non-Mapping
    ``result`` shapes via the shared :func:`_proxy_settledness_problem`
    helper — predicate and asserter agree by construction.
    """
    result = assert_proxy_ok(payload, endpoint=endpoint)
    problem = _proxy_settledness_problem(result, kind="transaction receipt")
    if problem is not None:
        raise EtherscanError(
            f"{problem} for endpoint={endpoint!r}",
            endpoint=endpoint,
            original_result=problem,
        )
    return result


def assert_account_ok(
    payload: Mapping[str, Any], *, endpoint: str, allow_empty: bool = False
) -> Any:
    """Return ``payload['result']`` or raise :class:`EtherscanError`.

    ``module=account`` responses follow envelope ``{"status","message","result"}``.
    ``status=="0"`` is an error **except** for the legitimate "no rows" case
    (``message=="No transactions found"``) when ``allow_empty=True``.
    """
    if "result" not in payload:
        raise EtherscanError(
            f"missing field 'result' for endpoint={endpoint!r}",
            endpoint=endpoint,
        )
    if str(payload.get("status")) == "1":
        return payload["result"]
    # status != "1" → either error or empty-list edge case
    message = str(payload.get("message", ""))
    if allow_empty and message == "No transactions found":
        return payload["result"]
    raise EtherscanError(
        f"Etherscan v2 error for endpoint={endpoint!r}: {payload.get('result')}",
        endpoint=endpoint,
        original_result=str(payload.get("result")) if payload.get("result") is not None else None,
    )


def _account_rows_shape_problem(
    result: Any,
    *,
    required_fields: tuple[str, ...] = (),
    numeric_fields: tuple[str, ...] = (),
    optional_numeric_fields: tuple[str, ...] = (),
    address_fields: tuple[str, ...] = (),
    tx_hash_fields: tuple[str, ...] = (),
    input_fields: tuple[str, ...] = (),
    timestamp_fields: tuple[str, ...] = (),
) -> str | None:
    """Return ``None`` if *result* is a list of well-formed rows; else a problem.

    Shared SSOT for :func:`is_account_rows_ok` (cache-write gate) and
    :func:`assert_account_rows_ok` (asserter) so they agree by construction.
    ``assert_account_ok`` narrows the ``module=account`` envelope but can NOT
    assert list-ness (``get_balance`` reads ``result`` as a STRING), so without
    this gate a non-list / malformed-item ``result`` reaches the row normalisers
    and leaks a bare ``TypeError`` / ``KeyError`` / ``ValueError`` — and the
    malformed payload passes the list-only cache-write gate, is cached under
    ``historical_ttl=None`` and re-thrown forever (cache-poison). Etherscan
    returns JSON arrays as ``list``; only ``list`` is accepted.

    Each optional gate is keyed off a per-endpoint field tuple and mirrors the
    consumer EXACTLY, so it never rejects a real captured row → happy path
    byte-identical (golden determinism); every default ``()`` preserves the
    prior contract. All per-item gates use a declared-order,
    ``rows[{idx}]:``-prefixed message so the lowest bad index wins:

    * *required_fields* (Iteration-6) — each item is a ``Mapping`` carrying every
      named field present + ``str`` (twin of :func:`_receipt_log_shape_problem`).
      The two endpoints carry DISTINCT sets (``get_address_txs`` requires ``hash``;
      ``get_internal_txs`` does NOT — txlistinternal-by-txhash omits it, 7fb1831).
    * *numeric_fields* (Iteration-16, ⊆ *required_fields*) — each named field is
      ``int(str(value))``-coercible via :func:`_decimal_str_problem` (the
      ``timeStamp`` / ``blockNumber`` / ``value`` coercion the normalisers run).
    * *optional_numeric_fields* (Iteration-25) — sentinel-aware: ``gasUsed`` is
      ``.get`` behind a ``not in (None, "")`` guard, so absent / ``None`` / ``""``
      SKIP and only a present-non-empty value is checked via
      :func:`_decimal_str_problem`.
    * *address_fields* (Iteration-62, multi-row twin of the proxy ``from`` / ``to``
      guard) — ``from`` / ``to`` feed :func:`Address.from_str` via ``_maybe_address``
      (never in any required/numeric tuple), so a present-but-malformed value
      passed every prior gate, was cached (poison) and leaked a bare ``ValueError``.
      Checked via :func:`_evm_address_format_problem` ONLY when truthy
      (``_maybe_address`` short-circuits on falsy → missing/empty stay legal).
    * *tx_hash_fields* (Iteration-68, multi-row twin of the proxy ``hash`` FORMAT
      guard) — ``hash`` feeds :class:`NormalizedTransaction`'s ``_validate_tx_hash``
      after-validator in ``normalize_account_tx``, which raises a raw
      ``pydantic.ValidationError`` on a malformed value (cache-poison). Checked via
      :func:`_evm_tx_hash_format_problem` for any present ``str`` (incl. ``""``) —
      NOT truthiness-skipped, since (unlike ``from``/``to``) ``hash`` is a REQUIRED
      field the normaliser feeds verbatim. ``txlist`` carries its OWN result
      ``hash``; ``txlistinternal`` does NOT (the parent canonical hash is
      authoritative — commit 7fb1831) so it passes an EMPTY tuple here.
    * *input_fields* (Iteration-68, multi-row twin of the proxy ``input`` FORMAT
      guard) — ``input`` feeds :class:`NormalizedTransaction`'s
      ``_validate_optional_calldata`` ``BeforeValidator`` via ``_maybe_calldata``,
      which short-circuits missing / non-``str`` to ``None`` — so a present-``str``
      malformed ``input`` (non-``0x`` / odd-length / non-hex) leaked a raw
      ``pydantic.ValidationError`` (cache-poison). Checked via
      :func:`_evm_calldata_problem`, which mirrors that short-circuit (absent /
      non-``str`` → "no problem"; ``""`` / ``"0x"`` / even-hex pass).
    * *timestamp_fields* (Iteration-75, ⊆ *numeric_fields*, decimal) — ``timeStamp``
      is additionally fed to ``datetime.fromtimestamp`` by the row normalisers; a
      coercible-but-out-of-platform-range value passed the decimal coercibility gate
      then leaked a bare ``OverflowError`` / ``OSError`` (cache-poison). Checked via
      :func:`_unix_timestamp_range_problem` (``base=10``) — applied ONLY to
      ``timeStamp`` (NOT ``blockNumber`` / ``value``, which are legitimately huge).
    """
    if not isinstance(result, list):
        return f"account rows must be list, got {type(result).__name__}"
    if required_fields:
        for idx, item in enumerate(result):
            if not isinstance(item, Mapping):
                return f"rows[{idx}]: row must be dict, got {type(item).__name__}"
            for field in required_fields:
                if field not in item:
                    return f"rows[{idx}]: missing field 'row.{field}'"
                value = item[field]
                if not isinstance(value, str):
                    return f"rows[{idx}]: row.{field} must be str, got {type(value).__name__}"
    if numeric_fields:
        for idx, item in enumerate(result):
            # numeric_fields ⊆ required_fields → each is already present + str
            # (the required loop above ran first), so no presence re-check here.
            for field in numeric_fields:
                problem = _decimal_str_problem(item[field])
                if problem is not None:
                    return f"rows[{idx}]: row.{field} {problem}"
    if optional_numeric_fields:
        for idx, item in enumerate(result):
            # optional_numeric_fields are NOT a subset of required_fields, so the
            # item may not have been Mapping-checked above — guard defensively.
            if not isinstance(item, Mapping):
                return f"rows[{idx}]: row must be dict, got {type(item).__name__}"
            for field in optional_numeric_fields:
                value = item.get(field)
                if value in (None, ""):
                    # absent / None / "" → normaliser coerces to None (optional).
                    continue
                problem = _decimal_str_problem(value)
                if problem is not None:
                    return f"rows[{idx}]: row.{field} {problem}"
    if address_fields:
        for idx, item in enumerate(result):
            # Defensive Mapping re-check (address_fields ⊄ required_fields).
            if not isinstance(item, Mapping):
                return f"rows[{idx}]: row must be dict, got {type(item).__name__}"
            for field in address_fields:
                # Truthiness-gated to match ``_maybe_address`` (falsy → no address;
                # a truthy non-str raises ValueError in the helper too, so it is safe).
                if (addr := item.get(field)) and (problem := _evm_address_format_problem(addr)):
                    return f"rows[{idx}]: row.{field} {problem}"
    if tx_hash_fields:
        for idx, item in enumerate(result):
            # Defensive Mapping re-check (tx_hash_fields ⊆ required_fields in
            # practice, but the loop must not assume the required loop ran).
            if not isinstance(item, Mapping):
                return f"rows[{idx}]: row must be dict, got {type(item).__name__}"
            for field in tx_hash_fields:
                # NOT truthiness-gated: ``hash`` is a REQUIRED present+str field the
                # normaliser feeds verbatim, so a present ``""``/malformed hash must
                # be rejected. Absent (None) / present-non-str are handled by the
                # required loop above (txlist requires ``hash``); skip them here.
                value = item.get(field)
                if isinstance(value, str) and (problem := _evm_tx_hash_format_problem(value)):
                    return f"rows[{idx}]: row.{field} {problem}"
    if input_fields:
        for idx, item in enumerate(result):
            # Defensive Mapping re-check (input_fields ⊄ required_fields).
            if not isinstance(item, Mapping):
                return f"rows[{idx}]: row must be dict, got {type(item).__name__}"
            for field in input_fields:
                # ``_evm_calldata_problem`` mirrors ``_maybe_calldata``: absent /
                # non-str ``input`` → "no problem"; only a present-str malformed
                # value is rejected (so missing ``input`` stays legal).
                problem = _evm_calldata_problem(item.get(field))
                if problem is not None:
                    return f"rows[{idx}]: row.{field} {problem}"
    if timestamp_fields:
        for idx, item in enumerate(result):
            # timestamp_fields ⊆ numeric_fields ⊆ required_fields → each is already
            # present + str + decimal-coercible (the loops above ran first), so this
            # only adds the platform-range check (the consumer's fromtimestamp).
            for field in timestamp_fields:
                problem = _unix_timestamp_range_problem(item[field], base=10)
                if problem is not None:
                    return f"rows[{idx}]: row.{field} {problem}"
    return None


def assert_account_rows_ok(
    payload: Mapping[str, Any],
    *,
    endpoint: str,
    allow_empty: bool = False,
    required_fields: tuple[str, ...] = (),
    numeric_fields: tuple[str, ...] = (),
    optional_numeric_fields: tuple[str, ...] = (),
    address_fields: tuple[str, ...] = (),
    tx_hash_fields: tuple[str, ...] = (),
    input_fields: tuple[str, ...] = (),
    timestamp_fields: tuple[str, ...] = (),
) -> list[Any]:
    """Return the account ``result`` rows as a ``list`` or raise :class:`EtherscanError`.

    Wraps :func:`assert_account_ok` (envelope-level OK / error discrimination)
    and additionally rejects a non-list ``result`` (and, when *required_fields*
    is supplied, a malformed item; when *numeric_fields* is supplied, a row whose
    named numeric field is present+str but not int-coercible; when
    *optional_numeric_fields* is supplied, a row whose named optional field is
    present+non-empty but not int-coercible) via the shared
    :func:`_account_rows_shape_problem`. The ``list[Any]`` return annotation is
    load-bearing: it is the single source of truth narrowing the two rows call
    sites (:meth:`get_internal_txs` / :meth:`get_address_txs`) so their
    ``tuple(... for item in result)`` comprehensions are guaranteed iterable.
    """
    result = assert_account_ok(payload, endpoint=endpoint, allow_empty=allow_empty)
    problem = _account_rows_shape_problem(
        result,
        required_fields=required_fields,
        numeric_fields=numeric_fields,
        optional_numeric_fields=optional_numeric_fields,
        address_fields=address_fields,
        tx_hash_fields=tx_hash_fields,
        input_fields=input_fields,
        timestamp_fields=timestamp_fields,
    )
    if problem is not None:
        raise EtherscanError(
            f"{problem} for endpoint={endpoint!r}",
            endpoint=endpoint,
            original_result=str(result),
        )
    # ``_account_rows_shape_problem`` returning None guarantees ``isinstance(result, list)``;
    # ``assert_account_ok`` returns ``Any``, so narrow it here for the load-bearing annotation.
    return cast(list[Any], result)


def is_account_rows_ok(
    payload: Mapping[str, Any],
    *,
    allow_empty: bool = False,
    required_fields: tuple[str, ...] = (),
    numeric_fields: tuple[str, ...] = (),
    optional_numeric_fields: tuple[str, ...] = (),
    address_fields: tuple[str, ...] = (),
    tx_hash_fields: tuple[str, ...] = (),
    input_fields: tuple[str, ...] = (),
    timestamp_fields: tuple[str, ...] = (),
) -> bool:
    """Return ``True`` iff *payload* is a cacheable account-rows response.

    The rows-specific cache-write gate: composes :func:`is_account_ok`
    (envelope OK) with :func:`_account_rows_shape_problem` (list-ness, plus the
    per-item shape when *required_fields* is supplied, plus the per-row
    numeric-coercibility check when *numeric_fields* is supplied, plus the
    sentinel-aware optional numeric check when *optional_numeric_fields* is
    supplied) so a non-list status==1 payload — or a list carrying a malformed /
    non-decimal-numeric item — which ``is_account_ok`` alone would accept is
    never written to the
    historical cache (closing the cache-poison hole). Agrees with
    :func:`assert_account_rows_ok` by construction.
    """
    return (
        is_account_ok(payload, allow_empty=allow_empty)
        and _account_rows_shape_problem(
            payload.get("result"),
            required_fields=required_fields,
            numeric_fields=numeric_fields,
            optional_numeric_fields=optional_numeric_fields,
            address_fields=address_fields,
            tx_hash_fields=tx_hash_fields,
            input_fields=input_fields,
            timestamp_fields=timestamp_fields,
        )
        is None
    )


def assert_account_balance_ok(payload: Mapping[str, Any], *, endpoint: str) -> Any:
    """Return the numeric balance ``result`` or raise :class:`EtherscanError`.

    Iteration-7 twin of :func:`assert_account_rows_ok`: wraps
    :func:`assert_account_ok` (envelope-level OK / error discrimination — a
    balance is never ``allow_empty``) and additionally rejects a non-numeric
    status==1 ``result`` via the shared :func:`_account_balance_problem`,
    surfacing a typed :class:`EtherscanError` at the boundary instead of leaking
    a bare ``ValueError`` from ``int(str(result))`` deep inside the normaliser.
    """
    result = assert_account_ok(payload, endpoint=endpoint)
    problem = _account_balance_problem(result)
    if problem is not None:
        raise EtherscanError(
            f"{problem} for endpoint={endpoint!r}",
            endpoint=endpoint,
            original_result=str(result),
        )
    return result


def is_account_balance_ok(payload: Mapping[str, Any], *, allow_empty: bool = False) -> bool:
    """Return ``True`` iff *payload* is a cacheable numeric-balance response.

    The balance-specific cache-write gate: composes :func:`is_account_ok`
    (envelope OK) with :func:`_account_balance_problem` (int-coercibility) so a
    non-numeric status==1 payload — which ``is_account_ok`` alone would accept —
    is never written to the balance cache (closing the cache-poison hole).
    Agrees with :func:`assert_account_balance_ok` by construction. *allow_empty*
    is kept for signature uniformity with the sibling account gates; balance
    callers pass the default ``False``.
    """
    return (
        is_account_ok(payload, allow_empty=allow_empty)
        and _account_balance_problem(payload.get("result")) is None
    )


__all__ = [
    "ETHERSCAN_V2_BASE_URL",
    "assert_account_balance_ok",
    "assert_account_ok",
    "assert_account_rows_ok",
    "assert_proxy_block_ok",
    "assert_proxy_ok",
    "assert_proxy_receipt_ok",
    "assert_proxy_tx_ok",
    "is_account_balance_ok",
    "is_account_ok",
    "is_account_rows_ok",
    "is_proxy_block_ok",
    "is_proxy_ok",
    "is_proxy_receipt_ok",
    "is_proxy_tx_ok",
    "normalize_account_tx",
    "normalize_balance_native",
    "normalize_balance_token",
    "normalize_block_ref",
    "normalize_internal_tx",
    "normalize_log",
    "normalize_tx_from_proxy",
]
