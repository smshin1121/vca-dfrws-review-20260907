"""AdapterRegistry — process-wide ``ChainId → ChainAdapter`` binding (P1-002).

The registry is intentionally minimal: a frozen dict from chain to adapter
plus four query helpers. Concurrency policy lives at the call-site — see
WBS §6 R-CONC. The :func:`get_registry` lru_cache singleton mirrors the
:func:`vca.config.get_settings` pattern; tests must call
:func:`get_registry.cache_clear` between cases.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Final

from vca.adapters.base import ChainAdapter
from vca.types import ChainId

# Definition order on :class:`ChainId` is the canonical sort order surfaced by
# :meth:`AdapterRegistry.chains`. Materialise it once at import time.
_CHAIN_DEFINITION_ORDER: Final[tuple[ChainId, ...]] = tuple(ChainId)


class AdapterRegistry:
    """``ChainId → ChainAdapter`` registry.

    Concurrency: register calls must run on a single thread before any async
    consumer starts (typically application bootstrap). The registry does not
    take internal locks — see WBS §6 R-CONC.
    """

    __slots__ = ("_by_chain",)

    def __init__(self) -> None:
        self._by_chain: dict[ChainId, ChainAdapter] = {}

    def register(
        self,
        chain: ChainId,
        adapter: ChainAdapter,
        *,
        replace: bool = False,
    ) -> None:
        """Register ``adapter`` under ``chain``.

        Args:
            chain: Target chain enum.
            adapter: Concrete :class:`ChainAdapter` implementation.
                ``adapter.chain_id`` must equal ``chain``.
            replace: If ``True``, overwrite an existing binding silently;
                otherwise the second register call for the same chain
                raises :class:`ValueError`.

        Raises:
            TypeError: ``adapter`` does not satisfy the
                :class:`ChainAdapter` Protocol's attribute probe.
            ValueError: ``adapter.chain_id != chain`` or ``replace=False``
                and ``chain`` is already registered.
        """
        if not isinstance(adapter, ChainAdapter):
            raise TypeError(
                f"adapter must implement ChainAdapter Protocol "
                f"(missing required methods or chain_id), got "
                f"{type(adapter).__name__}"
            )
        # ``runtime_checkable`` only inspects attribute *presence*, so a fake
        # adapter that exposes ``chain_id`` as ``str``/``None``/``int`` slips
        # past the previous ``isinstance`` and would crash with
        # ``AttributeError`` on ``.value`` below. Surface the documented
        # :class:`TypeError` instead (codex round-1 P2-2).
        if not isinstance(adapter.chain_id, ChainId):
            raise TypeError(
                f"adapter.chain_id must be ChainId, got "
                f"{type(adapter.chain_id).__name__}: {adapter.chain_id!r}"
            )
        if adapter.chain_id is not chain:
            raise ValueError(
                f"adapter.chain_id mismatch: register(chain={chain.value}) "
                f"received adapter.chain_id={adapter.chain_id.value}"
            )
        if not replace and chain in self._by_chain:
            raise ValueError(
                f"chain {chain.value!r} already registered; pass replace=True to override"
            )
        self._by_chain[chain] = adapter

    def get(self, chain: ChainId) -> ChainAdapter:
        """Return the adapter for ``chain``.

        Raises:
            KeyError: ``chain`` is not registered. The error message
                includes the list of currently-registered chains.
        """
        try:
            return self._by_chain[chain]
        except KeyError as exc:
            known = ", ".join(c.value for c in self.chains()) or "<none>"
            raise KeyError(
                f"chain {chain.value!r} not registered; known chains: [{known}]"
            ) from exc

    def has(self, chain: ChainId) -> bool:
        return chain in self._by_chain

    def chains(self) -> tuple[ChainId, ...]:
        """Return registered chains in :class:`ChainId` definition order."""
        return tuple(c for c in _CHAIN_DEFINITION_ORDER if c in self._by_chain)


@lru_cache(maxsize=1)
def get_registry() -> AdapterRegistry:
    """Process-wide singleton :class:`AdapterRegistry`.

    Mirrors :func:`vca.config.get_settings`. Tests must call
    :func:`get_registry.cache_clear` between cases.
    """
    return AdapterRegistry()


def register_adapter(
    chain: ChainId,
    adapter: ChainAdapter,
    *,
    replace: bool = False,
) -> None:
    """Convenience: register ``adapter`` on the singleton registry."""
    get_registry().register(chain, adapter, replace=replace)


__all__ = ["AdapterRegistry", "get_registry", "register_adapter"]
