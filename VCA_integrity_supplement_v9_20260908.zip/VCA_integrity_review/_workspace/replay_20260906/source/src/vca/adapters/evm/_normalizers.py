"""Etherscan v2 JSON-shape → vca.types normalizers.

Extracted from :mod:`vca.adapters.evm._etherscan_v2` for R-FILE-CAP headroom;
re-exported there for import compat.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Any

from vca.types import (
    Address,
    Amount,
    Asset,
    Balance,
    BlockRef,
    ChainId,
    NormalizedLog,
    NormalizedTransaction,
)


def normalize_block_ref(*, raw_block: Mapping[str, Any], chain: ChainId) -> BlockRef:
    """``eth_getBlockByNumber.result`` → :class:`BlockRef` (tz-aware UTC)."""
    number = int(str(raw_block["number"]), 16)
    block_hash = raw_block.get("hash")
    timestamp = datetime.fromtimestamp(int(str(raw_block["timestamp"]), 16), tz=UTC)
    return BlockRef(
        chain=chain,
        number=number,
        hash=str(block_hash).lower() if block_hash else None,
        timestamp=timestamp,
    )


def _maybe_address(value: str | None, chain: ChainId) -> Address | None:
    """Normalise an EVM address string; return ``None`` for empty/missing input."""
    if not value:
        return None
    return Address.from_str(value, chain)


def _maybe_calldata(value: Any) -> str | None:
    """Pass calldata through to :class:`NormalizedTransaction.input` (P1-012).

    Returns:
    * ``None`` when *value* is missing or non-string (the upstream payload
      omits the field — defensive: every Etherscan endpoint we use carries
      it, but Etherscan's "internal tx" envelope occasionally elides it).
    * The string verbatim otherwise — :class:`NormalizedTransaction`'s
      pre-validator handles lowercase normalisation and hex format
      enforcement, so the adapter does not duplicate those checks.
    """
    if value is None or not isinstance(value, str):
        return None
    # The ``isinstance`` narrows the static type to ``str`` for the type
    # checker, but the surrounding ``Any`` annotation widens the return
    # value back. ``str(value)`` is a no-op at runtime and keeps mypy happy.
    return str(value)


def normalize_tx_from_proxy(
    *,
    raw_tx: Mapping[str, Any],
    block: BlockRef,
    chain: ChainId,
    raw_uri: str,
) -> NormalizedTransaction:
    """``eth_getTransactionByHash.result`` → :class:`NormalizedTransaction`."""
    value_hex = str(raw_tx["value"])
    value_native = Amount(raw=int(value_hex, 16), decimals=chain.native_decimals)
    return NormalizedTransaction(
        chain=chain,
        tx_hash=str(raw_tx["hash"]).lower(),
        block=block,
        from_addr=_maybe_address(raw_tx.get("from"), chain),
        to_addr=_maybe_address(raw_tx.get("to"), chain),
        value_native=value_native,
        gas_used=None,
        status=None,
        transfers=(),
        raw_uri=raw_uri,
        input=_maybe_calldata(raw_tx.get("input")),
    )


def normalize_log(
    *,
    raw_log: Mapping[str, Any],
    block: BlockRef,
    chain: ChainId,
) -> NormalizedLog:
    """receipt.logs[i] → :class:`NormalizedLog` (lowercase enforced)."""
    topics = tuple(str(t).lower() for t in raw_log.get("topics", ()))
    return NormalizedLog(
        chain=chain,
        block=block,
        tx_hash=str(raw_log["transactionHash"]).lower(),
        log_index=int(str(raw_log["logIndex"]), 16),
        address=Address.from_str(str(raw_log["address"]), chain),
        topics=topics,
        data=str(raw_log["data"]).lower(),
        removed=bool(raw_log.get("removed", False)),
    )


def normalize_internal_tx(
    *,
    raw_internal: Mapping[str, Any],
    chain: ChainId,
    raw_uri: str,
    tx_hash: str,
) -> NormalizedTransaction:
    """``txlistinternal.result[i]`` → :class:`NormalizedTransaction`.

    Etherscan v2 ``action=txlistinternal&txhash=<tx>`` items omit ``hash`` /
    ``transactionHash`` — every result is a child of the queried parent, so the
    caller (``get_internal_txs``) supplies that already-validated parent
    ``tx_hash`` and it is authoritative for every item.

    ``isError`` semantics from the Etherscan account API are inverted relative
    to the EVM receipt ``status``: ``"0"`` (no error) → 1 (success);
    ``"1"`` (error) → 0 (fail).
    """
    parent_hash = tx_hash.lower()
    # defensive: items currently never carry a hash, but if a future endpoint
    # shape (or a by-address reuse) reintroduces one that disagrees with the
    # authoritative parent, fail loudly rather than silently mislabel the edge.
    item_hash = raw_internal.get("hash") or raw_internal.get("transactionHash")
    if item_hash is not None and str(item_hash).lower() != parent_hash:
        raise ValueError(
            f"internal tx hash mismatch: parent={parent_hash}, item={str(item_hash).lower()}"
        )
    timestamp = datetime.fromtimestamp(int(str(raw_internal["timeStamp"])), tz=UTC)
    block = BlockRef(
        chain=chain,
        number=int(str(raw_internal["blockNumber"])),
        hash=None,
        timestamp=timestamp,
    )
    is_error = str(raw_internal.get("isError", "0"))
    status = 0 if is_error == "1" else 1
    gas_used_raw = raw_internal.get("gasUsed")
    gas_used = int(str(gas_used_raw)) if gas_used_raw not in (None, "") else None
    value_native = Amount(raw=int(str(raw_internal["value"])), decimals=chain.native_decimals)
    return NormalizedTransaction(
        chain=chain,
        tx_hash=parent_hash,
        block=block,
        from_addr=_maybe_address(raw_internal.get("from"), chain),
        to_addr=_maybe_address(raw_internal.get("to"), chain),
        value_native=value_native,
        gas_used=gas_used,
        status=status,
        transfers=(),
        raw_uri=raw_uri,
        input=_maybe_calldata(raw_internal.get("input")),
    )


def normalize_account_tx(
    *,
    raw_tx: Mapping[str, Any],
    chain: ChainId,
    raw_uri: str,
) -> NormalizedTransaction:
    """``txlist.result[i]`` → :class:`NormalizedTransaction`.

    Shares most of its shape with :func:`normalize_internal_tx` but uses the
    receipt-style ``txreceipt_status`` field (``"0"`` → 0, ``"1"`` → 1),
    which is the inverse polarity of ``isError`` and therefore deserves a
    dedicated normaliser.
    """
    timestamp = datetime.fromtimestamp(int(str(raw_tx["timeStamp"])), tz=UTC)
    block = BlockRef(
        chain=chain,
        number=int(str(raw_tx["blockNumber"])),
        hash=str(raw_tx.get("blockHash") or "").lower() or None,
        timestamp=timestamp,
    )
    receipt_status = raw_tx.get("txreceipt_status")
    if receipt_status in ("0", "1"):
        status: int | None = 1 if receipt_status == "1" else 0
    else:
        is_error = str(raw_tx.get("isError", "0"))
        status = 0 if is_error == "1" else 1
    gas_used_raw = raw_tx.get("gasUsed")
    gas_used = int(str(gas_used_raw)) if gas_used_raw not in (None, "") else None
    value_native = Amount(raw=int(str(raw_tx["value"])), decimals=chain.native_decimals)
    return NormalizedTransaction(
        chain=chain,
        tx_hash=str(raw_tx["hash"]).lower(),
        block=block,
        from_addr=_maybe_address(raw_tx.get("from"), chain),
        to_addr=_maybe_address(raw_tx.get("to"), chain),
        value_native=value_native,
        gas_used=gas_used,
        status=status,
        transfers=(),
        raw_uri=raw_uri,
        input=_maybe_calldata(raw_tx.get("input")),
    )


def normalize_balance_native(
    *,
    raw_balance_str: str,
    addr: Address,
    chain: ChainId,
    at: BlockRef | None,
) -> Balance:
    """``account.balance.result`` (wei decimal string) → native :class:`Balance`."""
    asset = Asset.native(chain)
    return Balance(
        chain=chain,
        address=addr,
        at_block=at,
        amount=Amount(raw=int(raw_balance_str), decimals=chain.native_decimals),
        asset=asset,
    )


def normalize_balance_token(
    *,
    raw_balance_str: str,
    addr: Address,
    token: Asset,
    at: BlockRef | None,
) -> Balance:
    """``account.tokenbalance.result`` (raw decimal string) → ERC-20 :class:`Balance`."""
    return Balance(
        chain=token.chain,
        address=addr,
        at_block=at,
        amount=Amount(raw=int(raw_balance_str), decimals=token.decimals),
        asset=token,
    )


__all__ = [
    "normalize_account_tx",
    "normalize_balance_native",
    "normalize_balance_token",
    "normalize_block_ref",
    "normalize_internal_tx",
    "normalize_log",
    "normalize_tx_from_proxy",
]
