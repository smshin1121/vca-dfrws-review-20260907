"""Bybit Cold Wallet Exploit case bootstrap (P3.4-002, VCA case #2).

Encodes the source-doc verbatim identifiers from
``docs/source/bybit/bybit_hack_source.md`` as ``Final[]`` constants and
exposes :func:`bootstrap_bybit_case`, an idempotent ``Case`` / ``Chain``
/ ``Address`` / ``Transaction`` upserter that prepares the foreign-key
targets the tracer + :class:`vca.persistence.GraphRepository` need before
they can save the flow graph.

Mirrors :mod:`vca.cases.kelpdao_seed` (P1-018) field-for-field; the same
design tenets apply:

* **R-SOURCE-DOC-VERBATIM** — every public string constant is byte-equal
  to the frozen source-doc line it cites. Tests pin the contract via a
  UTF-8 substring scan of ``docs/source/bybit/bybit_hack_source.md``.
* **R-IDEMPOTENT-BOOTSTRAP** — :func:`bootstrap_bybit_case` uses
  ``Session.get(Model, pk)`` then ``Session.add`` only when absent.
  Re-running produces zero net DB delta on SQLite and PostgreSQL.
* **R-NO-IO-IMPORTS** — module imports stdlib + ``sqlalchemy.orm`` +
  ``vca.persistence.models`` + ``vca.types`` + ``vca.tracer.graph``
  (TxRef ONLY) + ``vca.reporting`` (AttributionFacts + SourceCitation
  ONLY). No HTTP clients, adapters, decoders, tracer runner, CLI / API.
* **R-EVM-CHECKSUM-CASE** — every EVM constant is stored in EIP-55
  checksum form (matches explorer rendering). The persistence-layer
  ``Address.address_id`` PK keeps the mixed-case form;
  :func:`vca.tracer.graph.canonical_address_key` lowercases EVM hex for
  the tracer's dedup logic — distinct helpers, distinct layers.

**On-chain provenance (frozen 2026-06-24).** Every identifier here was
re-derived byte-exact on keyless explorers (mempool.space +
eth.blockscout.com) by an adversarial re-verification workflow and upheld
by an independent skeptic. See ``docs/source/bybit/bybit_hack_source.md``
§2 for the corrections applied (delegatecall target, reused-address vs
"3-input consolidation", sweep vs "peel") and the CITED_SECONDARY markers.

**Seed shape — Stage-1 envelope only.** Like KelpDAO (whose Stage 2-7
wallet tables are ``원문에 표 데이터 미기재`` and discovered at run time),
this module encodes only the Stage-1 theft envelope + attribution + the
verified THORChain/BTC forensic anchors. The ~40 dispersal wallets, DEX
swaps, and BTC peel chain are discovered at trace time. The theft tx
(:data:`BYBIT_THEFT_TX_HASH`) carries **no value/token transfer** (it only
overwrote the proxy implementation), so it is the theft *event anchor*,
not a funds-flow BFS root — the laundering trace effectively roots at
:data:`BYBIT_SEED_EXPLOITER` ("Bybit Exploiter 1").

**Landed with the P3.4-002 golden slice.** The per-case decoder /
labeler / policy / adapter / glossary builders + ``methodology`` facts,
the VCR-cassette deep-capture, and the golden trace fixtures are all
wired: ``vca.cli.commands.case._CASE_REGISTRY`` registers this case with
all six optional per-case seams populated, so ``vca case run bybit``
renders the Bybit flow graph (golden: 1991 nodes / 3127 edges). KelpDAO
stays byte-identical (INV-2) because its own CaseSpec leaves those seams
unset; ``--dry-run`` still bootstraps only the Stage-1 rows below.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC, datetime
from decimal import Decimal
from types import MappingProxyType
from typing import Final

from sqlalchemy.orm import Session

from vca.cases.kelpdao_seed import KELPDAO_CHAIN_SEEDS
from vca.observability.logging import get_logger
from vca.persistence.models import Address, Case, Chain, Transaction
from vca.reporting import AttributionFacts, SourceCitation
from vca.tracer.graph import TxRef
from vca.types import Address as DomainAddress
from vca.types import ChainId

_LOGGER = get_logger(__name__)


# ---------------------------------------------------------------------------
# Case identity (matches CLI arg ``vca case run bybit``)
# ---------------------------------------------------------------------------

BYBIT_CASE_ID: Final[str] = "bybit"
BYBIT_CASE_TITLE: Final[str] = "Bybit Cold Wallet Exploit"
BYBIT_VICTIM: Final[str] = "Bybit (Ethereum cold wallet, Safe{Wallet} multisig)"

# Source-doc §1 (사건 개요). Truncated to fit ``Case.summary`` cleanly.
# Each distinctive anchor below is present verbatim in the frozen source
# doc (pinned by ``test_bybit_seed`` substring scan).
BYBIT_SUMMARY: Final[str] = (
    "2025년 2월 21일(UTC) Bybit의 이더리움 콜드월렛(Safe{Wallet} 멀티시그)이 침해되어 "
    "401,346 ETH(약 $14억~15억) 등이 탈취되었다. 공격자는 멀티시그 프록시 구현체를 악성 "
    "컨트랙트로 delegatecall 교체하여 콜드월렛을 비웠다. 탈취 자산은 ~40개 지갑으로 "
    "10,000 ETH씩 분산된 뒤 DEX 집결 → THORChain ETH→BTC 스왑 → Bitcoin 소분·집결 → "
    "CoinJoin 믹서를 거쳐 세탁되었다. FBI/IC3는 본 사건을 북한 연계 TraderTraitor(Lazarus)로 "
    "귀속하였다."
)


# ---------------------------------------------------------------------------
# Stage 1 — Theft event anchor (source-doc §5 Stage 1)
# ---------------------------------------------------------------------------

BYBIT_THEFT_TX_HASH: Final[str] = (
    "0x46deef0f52e3a983b67abf4714448a41dd7ffd6d32d32da69d62081c68ad7882"
)
BYBIT_THEFT_BLOCK: Final[int] = 21_895_238
BYBIT_THEFT_BLOCK_TIME_UTC: Final[datetime] = datetime(2025, 2, 21, 14, 13, 35, tzinfo=UTC)
BYBIT_SEED_FUNCTION: Final[str] = "execTransaction"

# EVM addresses (EIP-55 checksum form). The Stage-1 theft envelope:
# submitter → cold-wallet proxy → malicious delegatecall target → drainer
# implementation, plus the laundering seed EOA.
BYBIT_THEFT_SUBMITTER: Final[str] = "0x0fa09C3A328792253f8dee7116848723b72a6d2e"
BYBIT_SAFE_PROXY: Final[str] = "0x1Db92e2EeBC8E0c075a02BeA49a2935BcD2dFCF4"
# Corrected per source-doc §2: the decoded execTransaction delegatecall
# target (slot-0 storage-writer), NOT the drainer implementation below.
BYBIT_DELEGATECALL_TARGET: Final[str] = "0x96221423681A6d52E184D440a8eFCEbB105C7242"
BYBIT_DRAINER_IMPL: Final[str] = "0xbDd077f651EBe7f7b3cE16fe5F2b025BE2969516"
# "Bybit Exploiter 1" — the EOA that received and dispersed proceeds. The
# laundering BFS effective seed (the theft tx has no value edge).
BYBIT_SEED_EXPLOITER: Final[str] = "0x47666Fab8bd0Ac7003bce3f5C3585383F09486E2"


# ---------------------------------------------------------------------------
# Stage 2-4 forensic anchors (discovered at trace time; documented here)
# ---------------------------------------------------------------------------

# DEX consolidation hub "Bybit Exploiter 2".
BYBIT_DEX_HUB: Final[str] = "0xA4B2Fd68593B6F34E51cB9eDB66E71c1B4Ab449e"
# Single-use relay between Exploiter 1 and the THORChain feeder (backward
# walk: 0x47666Fab -> 0x6591c653 -> 0x8Ab1D1d3, CLOSED on-chain).
BYBIT_ETH_RELAY: Final[str] = "0x6591c65321E3c5749A2A0ecb7E9F1aEb4FA3e3ab"
# THORChain feeder EOA (2-tx single-use pass-through: inbound then deposit).
BYBIT_THORCHAIN_FEEDER: Final[str] = "0x8Ab1D1d3E7db399835172576CcE0bD1C200a1Ce8"
# One representative FBI-listed dispersal wallet (Exploiter 18); the full
# ~40-wallet roster is discovered at trace time.
BYBIT_DISPERSAL_WALLET_18: Final[str] = "0x5Af75eAB6BEC227657fA3E749a8BFd55f02e4b1D"


# ---------------------------------------------------------------------------
# Stage 5 — THORChain ETH→BTC core hop (source-doc §5 Stage 5)
# ---------------------------------------------------------------------------

BYBIT_THORCHAIN_TX_HASH: Final[str] = (
    "0x16ed29f9bf9914ea3b62e4e94829eaef10118d04e82849a285ef8a5700defa1a"
)
BYBIT_THORCHAIN_ROUTER: Final[str] = "0xD37BbE5744D730a1d98d8DC97c42F0Ca46aD7146"
BYBIT_THORCHAIN_VAULT: Final[str] = "0x9b3F783E80751a64cc38B5613267e097274ba091"
BYBIT_THORCHAIN_MEMO: Final[str] = "=:b:191du9ivk3k5YekuXFgtkoVei6pK76wZmf:0/1/0:dx:10"
# THORChain ``=:b:`` swap-out memo prefix (the existing decoder pattern).
BYBIT_THORCHAIN_MEMO_PREFIX: Final[str] = "=:b:"
# 257.26903778 ETH (top-level value + single internal tx to the vault).
BYBIT_THORCHAIN_ETH_AMOUNT_RAW: Final[int] = 257_269_037_780_000_000_000
BYBIT_THORCHAIN_BLOCK: Final[int] = 21_967_334


# ---------------------------------------------------------------------------
# Stage 6-7 — Bitcoin spine (source-doc §5 Stage 6-7; mempool.space)
# ---------------------------------------------------------------------------

# THORChain BTC swap-out destination (memo target).
BYBIT_BTC_SWAPOUT_ADDR: Final[str] = "191du9ivk3k5YekuXFgtkoVei6pK76wZmf"
BYBIT_BTC_SWAPOUT_SAT: Final[int] = 647_120_774  # 6.47120774 BTC
# The tx whose output #1 funds the swap-out address.
BYBIT_BTC_VAULT_OUTBOUND_TX: Final[str] = (
    "ee555b433b7d30f8f132132dd20242812bc5750ae5a494b0c93422f97789f829"
)
# 1-in/1-out full sweep of the swap-out output (NOT a multi-output peel).
BYBIT_BTC_SWEEP_TX: Final[str] = "1b4ba9a1e352db6ae60d97fe470df6b965ba7355e3e96b94471344012987771f"
# Reused address funded by 3 SEPARATE deposit txs (NOT a 3-input
# consolidation — corrected per source-doc §2).
BYBIT_BTC_REUSE_HUB_ADDR: Final[str] = "bc1qfhtlude6e3kn8td84ry6q487555kupfmemyfle"
BYBIT_BTC_REUSE_HUB_SAT: Final[int] = 1_193_119_485  # 11.93119485 BTC


# ---------------------------------------------------------------------------
# Stage 3-4 backbone tx — the laundering BFS effective seed (P3.4-002 wiring)
# ---------------------------------------------------------------------------

# The first leg of the THORChain-feeding backbone: Bybit Exploiter 1
# (:data:`BYBIT_SEED_EXPLOITER`) -> relay (:data:`BYBIT_ETH_RELAY`). Source-doc
# §5 Stage 3-4 (line 158) re-derives it byte-exact (from=Exploiter 1,
# 257.269242761643 ETH, block 21967253). The tracer's ``_expand_seed``
# (``vca.tracer._run``) fetches ``seed_tx`` via ``adapter.get_tx`` and roots the
# BFS at the seed tx's ``from_addr`` — so a seed tx SENT BY Exploiter 1 roots
# the laundering walk at Exploiter 1, which is the desired flow. The theft tx
# (:data:`BYBIT_THEFT_TX_HASH`) carries no value edge (pure proxy-impl
# overwrite), so it stays the bootstrap ``Case.exploit_tx`` *event* anchor and
# is deliberately NOT the BFS root. NO amount constant is encoded here: the doc
# renders the leg amount only truncated (``257.269242761643 ETH``), never the
# exact integer wei, and ``TxRef`` carries no amount anyway.
BYBIT_BACKBONE_TX_HASH: Final[str] = (
    "0xf4a3ab131af116fd9bbe7b3484019e4d32850737c01ec1c45be6ba7608a9cd92"
)
BYBIT_BACKBONE_BLOCK: Final[int] = 21_967_253


# ---------------------------------------------------------------------------
# Stage 2 dispersal seed — deep-capture BFS root (P3.4-002 deep-capture; LIVE-DERIVED)
# ---------------------------------------------------------------------------

# The FIRST dispersal tx: Bybit Exploiter 1 (:data:`BYBIT_SEED_EXPLOITER`) ->
# dispersal wallet #1 (``0x36ed3c02…``), 10,000 ETH, block 21895451
# (2025-02-21, immediately after the theft). Used as :data:`BYBIT_SEED_TX` so
# the tracer's forward-walk floor drops to the dispersal era (see that
# constant's docstring for the floor mechanics).
#
# PROVENANCE — LIVE-DERIVED, NOT source-doc-verbatim. The frozen source doc
# (``bybit_hack_source.md`` §3) declares the forward dispersal seam an OPEN
# frontier and pins only ONE representative wallet (Exploiter 18,
# :data:`BYBIT_DISPERSAL_WALLET_18`); the per-tx dispersal roster is
# "discovered at trace time" (CITED_SECONDARY). This tx hash + block were
# re-derived byte-exact from a LIVE Etherscan ``get_address_txs`` capture of
# Exploiter 1 from the theft block forward (roster: 40 x exactly 10,000 ETH,
# blocks 21895451-21895739 — matching the doc's "~40 x 10,000 ETH" EXACTLY).
# Deliberately NOT added to the R-SOURCE-DOC-VERBATIM ``expected_substrings``
# scan (it is a live-derived anchor, not a frozen-doc identifier).
BYBIT_DISPERSAL_SEED_TX_HASH: Final[str] = (
    "0x0359814b48479156b804c8330878214943204c597d88affcb164d04907fa2b25"
)
BYBIT_DISPERSAL_SEED_BLOCK: Final[int] = 21_895_451


# ---------------------------------------------------------------------------
# Seed TxRef — the BFS starting point the CLI consumes
# ---------------------------------------------------------------------------

# The laundering BFS effective seed: the FIRST dispersal tx (Exploiter 1 ->
# dispersal wallet #1). Its ``from_addr`` is Bybit Exploiter 1, so
# ``_expand_seed`` roots the trace at Exploiter 1 — the SAME BFS root the
# backbone tx gave, but its EARLIER block (:data:`BYBIT_DISPERSAL_SEED_BLOCK`,
# 21895451) LOWERS the tracer's forward-walk floor to the dispersal era.
# Because the floor is the seed block, Exploiter 1's outbound history is now
# walked FROM the dispersal block forward — capturing BOTH the ~40 x 10,000-ETH
# dispersal fan-out (blocks 21895451-21895739) AND the later on-chain-CLOSED
# THORChain->BTC spine (backbone tx :data:`BYBIT_BACKBONE_TX_HASH` at block
# 21967253 -> relay -> feeder -> THORChain -> BTC, all forward of the floor).
#
# DEEP-CAPTURE RE-ROOT (P3.4-002, 2026-07-10). The previous seed was the
# backbone tx (block 21967253); its floor sat ABOVE the dispersal, so the
# fan-out — the source doc's declared OPEN forward frontier
# (``bybit_hack_source.md`` §3) — was documented but not traced, leaving Bybit
# a thin 7-node THORChain spine. This re-root DELIBERATELY extends the trace
# PAST that declared frontier using LIVE-DERIVED anchors (see
# :data:`BYBIT_DISPERSAL_SEED_TX_HASH` provenance) so Case #2 becomes a genuine
# multi-hop fan-out comparable to KelpDAO. Forensic-scope decision recorded in
# ``docs/plan/BYBIT_DEEP_CAPTURE_PLAN.md`` + the CLAUDE ledger. The theft tx
# (:data:`BYBIT_THEFT_TX_HASH`) remains the bootstrap event anchor (no value
# edge) and is NOT the BFS root.
BYBIT_SEED_TX: Final[TxRef] = TxRef(
    chain=ChainId.ETHEREUM,
    tx_hash=BYBIT_DISPERSAL_SEED_TX_HASH,
)


# ---------------------------------------------------------------------------
# Attribution (FBI/IC3 PSA 250226 + corroborating vendors)
# ---------------------------------------------------------------------------

BYBIT_ATTRIBUTION: Final[AttributionFacts] = AttributionFacts(
    actor="TraderTraitor",
    actor_aliases=("Lazarus Group", "DPRK"),
    confidence="high",
    sources=(
        # Errata E-007: the frozen source doc says "50 ETH addresses"; the PSA
        # actually publishes 51. The frozen doc stays byte-identical
        # (R-NO-FREEZE-CHANGE) and the corrected count lives here, where it
        # reaches the rendered report. Pinned against the in-repo roster SSOT
        # ``tests/fixtures/bybit/fbi_psa_250226.json`` by
        # ``tests/unit/cases/test_bybit_fbi_psa_crosscheck.py`` so the citation
        # and the roster can never disagree.
        SourceCitation(
            label="FBI / IC3 PSA 250226",
            quote=(
                "FBI는 본 사건을 북한 연계 TraderTraitor(Lazarus Group)로 귀속하고 "
                "51개 이더리움 주소를 공개하였다."
            ),
        ),
        SourceCitation(
            label="Elliptic / Chainalysis / TRM Labs on-chain analysis",
            quote=(
                "온체인 세탁 패턴(THORChain ETH→BTC, CoinJoin)이 이전 DPRK 귀속 "
                "작전들과 일치한다고 분석하였다."
            ),
        ),
        SourceCitation(
            label="ZachXBT / Arkham attribution",
            quote=("탈취 자금 수취·분산 주소들을 Bybit Exploiter 클러스터로 라벨링하였다."),
        ),
    ),
)


# ---------------------------------------------------------------------------
# Chain row seeds — Ethereum + Bitcoin (no Arbitrum leg in this case)
# ---------------------------------------------------------------------------

# Chain metadata (name / native symbol / scanner base URL) is
# case-INDEPENDENT, so reuse the canonical KelpDAO definition for the ETH +
# BTC subset rather than re-declaring the scanner-URL literals. The
# cross-package SSOT audit
# (tests/unit/security/test_config_mempool_base_url_cross_package_ssot_audit.py)
# specifically guards against duplicating ``https://mempool.space`` across
# modules; reusing the existing Mapping honors that invariant (a 2nd raw
# literal would be a divergence hazard). KelpDAO seeds ETH/ARB/BTC; Bybit has
# no Arbitrum leg, so only ETH + BTC are selected.
BYBIT_CHAIN_SEEDS: Final[Mapping[ChainId, Mapping[str, str]]] = MappingProxyType(
    {chain_id: KELPDAO_CHAIN_SEEDS[chain_id] for chain_id in (ChainId.ETHEREUM, ChainId.BITCOIN)}
)


# ---------------------------------------------------------------------------
# Address seed table — Stage-1 envelope EVM nodes the tracer needs as FK targets
# ---------------------------------------------------------------------------

# (label, raw EIP-55 string). The bootstrap normalises via
# ``DomainAddress.from_str(value, ChainId.ETHEREUM).value`` before
# persistence — idempotent on already-checksummed input.
BYBIT_SEED_ADDRESSES: Final[tuple[tuple[str, str], ...]] = (
    ("Theft tx submitter", BYBIT_THEFT_SUBMITTER),
    ("Bybit cold wallet (GnosisSafeProxy)", BYBIT_SAFE_PROXY),
    ("Malicious delegatecall target", BYBIT_DELEGATECALL_TARGET),
    ("Drainer implementation (Bybit Exploiter 55)", BYBIT_DRAINER_IMPL),
    ("Bybit Exploiter 1 (laundering seed)", BYBIT_SEED_EXPLOITER),
)


# ---------------------------------------------------------------------------
# Bootstrap function
# ---------------------------------------------------------------------------


def _redact_address(value: str) -> str:
    """Compact display form for log lines (``head[:6]…tail[-4:]``).

    Mirrors :func:`vca.cases.kelpdao_seed._redact_address` — operates on
    the raw string so we can log seeded EVM addresses without
    re-instantiating an :class:`Address` per call site. NEVER emits the
    full hex.
    """
    if len(value) <= 12:  # pragma: no cover - defensive; seeded values are 42 chars
        return value
    return f"{value[:6]}…{value[-4:]}"


def _upsert_chains(session: Session) -> None:
    """Insert any of the 2 ``Chain`` rows that aren't already present."""
    for chain_id, payload in BYBIT_CHAIN_SEEDS.items():
        if session.get(Chain, chain_id.value) is not None:
            continue
        session.add(
            Chain(
                chain_id=chain_id.value,
                name=payload["name"],
                native_symbol=payload["native_symbol"],
                scanner_base_url=payload["scanner_base_url"],
            )
        )


def _upsert_addresses(session: Session) -> None:
    """Insert any of the 5 EVM ``Address`` rows that aren't already present."""
    for _label, raw in BYBIT_SEED_ADDRESSES:
        canonical = DomainAddress.from_str(raw, ChainId.ETHEREUM).value
        address_id = f"{ChainId.ETHEREUM.value}:{canonical}"
        if session.get(Address, address_id) is not None:
            continue
        session.add(
            Address(
                address_id=address_id,
                chain_id=ChainId.ETHEREUM.value,
                address=canonical,
            )
        )


def _upsert_case(session: Session) -> Case:
    """Insert (or fetch) the Bybit :class:`Case` row.

    ``severity_usd`` is ``None``: the loss is a USD *range* (~$1.4-1.5B),
    not a precise on-chain figure; the native 401,346 ETH is the truth
    (R-NO-USD-PRICING — no derived USD pricing).
    """
    existing = session.get(Case, BYBIT_CASE_ID)
    if existing is not None:
        return existing
    case = Case(
        case_id=BYBIT_CASE_ID,
        title=BYBIT_CASE_TITLE,
        victim=BYBIT_VICTIM,
        exploit_tx=f"{ChainId.ETHEREUM.value}:{BYBIT_THEFT_TX_HASH}",
        attribution="TraderTraitor (DPRK / Lazarus)",
        severity_usd=None,
        occurred_at=BYBIT_THEFT_BLOCK_TIME_UTC,
        summary=BYBIT_SUMMARY,
        created_by="vca-bootstrap",
    )
    session.add(case)
    return case


def _upsert_seed_transaction(session: Session) -> Transaction:
    """Insert (or fetch) the theft-event seed :class:`Transaction` row.

    ``value_native = 0``: the theft ``execTransaction`` only overwrote the
    proxy implementation (delegatecall repoint); it carries no native ETH
    transfer. The 401,346 ETH movement to the seed EOA happened in
    separate later drain txs discovered at trace time.
    """
    tx_id = f"{ChainId.ETHEREUM.value}:{BYBIT_THEFT_TX_HASH}"
    existing = session.get(Transaction, tx_id)
    if existing is not None:
        return existing
    tx = Transaction(
        tx_id=tx_id,
        chain_id=ChainId.ETHEREUM.value,
        hash=BYBIT_THEFT_TX_HASH,
        block_number=BYBIT_THEFT_BLOCK,
        block_time=BYBIT_THEFT_BLOCK_TIME_UTC,
        from_addr=DomainAddress.from_str(BYBIT_THEFT_SUBMITTER, ChainId.ETHEREUM).value,
        to_addr=DomainAddress.from_str(BYBIT_SAFE_PROXY, ChainId.ETHEREUM).value,
        value_native=Decimal(0),
    )
    session.add(tx)
    return tx


def bootstrap_bybit_case(session: Session) -> tuple[Case, Transaction]:
    """Idempotently upsert the Bybit Case + Chain + Address + Transaction rows.

    Runs entirely inside the caller's open ``session`` transaction. NEVER
    calls ``session.commit()`` (mirrors
    :func:`vca.cases.kelpdao_seed.bootstrap_kelpdao_case`); the caller
    wraps the call in ``with session.begin():`` and owns rollback.

    Order of operations (R-IDEMPOTENT-BOOTSTRAP):

    1. Two ``Chain`` rows (``eth`` / ``btc``) — leaf table, no FK deps.
    2. Five EVM ``Address`` rows for the Stage-1 theft envelope.
    3. One :class:`Case` row keyed by :data:`BYBIT_CASE_ID`.
    4. One :class:`Transaction` row for the theft event tx
       (``value_native = 0``).
    5. ``session.flush()`` so the caller sees the new rows.

    Returns the ``(Case, Transaction)`` ORM row pair — both populated
    whether inserted or pre-existing.
    """
    _LOGGER.info(
        "bootstrap_bybit_case.start",
        case_id=BYBIT_CASE_ID,
        seed_chain=ChainId.ETHEREUM.value,
        seed_address_sample=_redact_address(BYBIT_SEED_EXPLOITER),
    )
    _upsert_chains(session)
    _upsert_addresses(session)
    case = _upsert_case(session)
    transaction = _upsert_seed_transaction(session)
    session.flush()
    _LOGGER.info(
        "bootstrap_bybit_case.done",
        case_id=BYBIT_CASE_ID,
        chain_count=len(BYBIT_CHAIN_SEEDS),
        address_count=len(BYBIT_SEED_ADDRESSES),
    )
    return case, transaction


__all__ = [
    "BYBIT_ATTRIBUTION",
    "BYBIT_BACKBONE_BLOCK",
    "BYBIT_BACKBONE_TX_HASH",
    "BYBIT_BTC_REUSE_HUB_ADDR",
    "BYBIT_BTC_REUSE_HUB_SAT",
    "BYBIT_BTC_SWAPOUT_ADDR",
    "BYBIT_BTC_SWAPOUT_SAT",
    "BYBIT_BTC_SWEEP_TX",
    "BYBIT_BTC_VAULT_OUTBOUND_TX",
    "BYBIT_CASE_ID",
    "BYBIT_CASE_TITLE",
    "BYBIT_CHAIN_SEEDS",
    "BYBIT_DELEGATECALL_TARGET",
    "BYBIT_DEX_HUB",
    "BYBIT_DISPERSAL_SEED_BLOCK",
    "BYBIT_DISPERSAL_SEED_TX_HASH",
    "BYBIT_DISPERSAL_WALLET_18",
    "BYBIT_DRAINER_IMPL",
    "BYBIT_ETH_RELAY",
    "BYBIT_SAFE_PROXY",
    "BYBIT_SEED_ADDRESSES",
    "BYBIT_SEED_EXPLOITER",
    "BYBIT_SEED_FUNCTION",
    "BYBIT_SEED_TX",
    "BYBIT_SUMMARY",
    "BYBIT_THEFT_BLOCK",
    "BYBIT_THEFT_BLOCK_TIME_UTC",
    "BYBIT_THEFT_SUBMITTER",
    "BYBIT_THEFT_TX_HASH",
    "BYBIT_THORCHAIN_BLOCK",
    "BYBIT_THORCHAIN_ETH_AMOUNT_RAW",
    "BYBIT_THORCHAIN_FEEDER",
    "BYBIT_THORCHAIN_MEMO",
    "BYBIT_THORCHAIN_MEMO_PREFIX",
    "BYBIT_THORCHAIN_ROUTER",
    "BYBIT_THORCHAIN_TX_HASH",
    "BYBIT_THORCHAIN_VAULT",
    "BYBIT_VICTIM",
    "bootstrap_bybit_case",
]
