"""VCA settings and secret loader (pydantic-settings backed).

Maps the 14 keys defined in `docs/plan/PHASE0_PHASE1_PLAN.md` §6.3, plus 5
optional web keys (`docs/plan/PHASE3_UI_PLAN.md` P3-002), onto a single
`Settings` object. Required secrets fail fast with `SystemExit` (§6.4).
"""

from __future__ import annotations

from functools import lru_cache
from typing import Final, Literal

from pydantic import Field, SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Sentinel value written into `.env.example` so committing the example file
# does not accidentally provide a real-looking key.
_PLACEHOLDER: Final[str] = "__REQUIRED__"

# Required-secret tuples drive the fail-fast validator.
_REQUIRED_SECRETS: Final[tuple[str, ...]] = (
    "ETHERSCAN_API_KEY_PRIMARY",
    "ARBISCAN_API_KEY_PRIMARY",
)


class Settings(BaseSettings):
    """Root configuration object.

    Field names mirror the lowercase form of the env keys (case_sensitive=False).
    `SecretStr` fields hide their plaintext from `repr`/logs; access plaintext
    with `.get_secret_value()` only at API call sites.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # --- General ---
    vca_env: Literal["dev", "test", "prod"] = "dev"
    vca_log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"

    # --- Persistence (consumed by P0-005, P0-008) ---
    vca_db_url: str = "postgresql+psycopg://vca:vca@localhost:5432/vca"
    vca_neo4j_uri: str = "bolt://localhost:7687"
    vca_redis_url: str = "redis://localhost:6379/0"

    # --- Raw response store (P0-006) ---
    vca_raw_store: Literal["minio", "local"] = "local"
    vca_minio_endpoint: str = "http://localhost:9000"

    # --- External API keys (required secrets) ---
    etherscan_api_key_primary: SecretStr = Field(default=SecretStr(_PLACEHOLDER))
    arbiscan_api_key_primary: SecretStr = Field(default=SecretStr(_PLACEHOLDER))

    # --- External endpoints ---
    mempool_base_url: str = "https://mempool.space"

    # --- Rate limits (P0-007) ---
    vca_rps_etherscan: int = Field(default=5, ge=1, le=100)
    vca_rps_mempool: int = Field(default=5, ge=1, le=100)

    # --- Cache TTLs (P0-008) ---
    vca_cache_ttl_historical_sec: int = Field(default=0, ge=0)  # 0 = unbounded
    vca_cache_ttl_balance_sec: int = Field(default=120, ge=1)  # >=1: ttl<=0 caches forever

    # --- Web dashboard (P3-002) — optional; fail-closed at request time ---
    vca_web_session_secret: SecretStr | None = None
    vca_web_auth_password: SecretStr | None = None
    vca_web_rate_limit_per_min: int = Field(default=30, ge=1, le=100)
    vca_web_login_rate_limit_per_min: int = Field(default=5, ge=1, le=100)
    vca_web_cookie_secure: bool = True
    # Optional "back to the host platform" link target rendered in the app
    # bar (every base.html page). When VCA is embedded under a host site
    # (mounted at /ui behind a reverse proxy), the operator sets this to the
    # host home (e.g. "/") so each page shows a Home link OUT of the
    # dashboard. Unset → no link (standalone VCA has no outer home), keeping
    # the repo host-agnostic. The brand logo still links to VCA's own home.
    vca_web_home_url: str | None = None

    @model_validator(mode="after")
    def _require_real_secrets(self) -> Settings:
        """Fail fast if any required secret is empty or still the placeholder.

        Plan §6.4 demands secret enforcement at config-load time, not at the
        first API call: a missing key in production must abort the process.
        """
        missing: list[str] = []
        pairs: tuple[tuple[str, SecretStr], ...] = (
            ("ETHERSCAN_API_KEY_PRIMARY", self.etherscan_api_key_primary),
            ("ARBISCAN_API_KEY_PRIMARY", self.arbiscan_api_key_primary),
        )
        for name, value in pairs:
            # Strip whitespace before comparison so trailing-space placeholders
            # (e.g. copy-pasted ".env" values) cannot bypass the fail-fast check.
            raw = value.get_secret_value().strip()
            if not raw or raw == _PLACEHOLDER:
                missing.append(name)
        if missing:
            joined = ", ".join(missing)
            raise SystemExit(
                f"[VCA] required secrets missing or unset: {joined}. "
                "Set them in .env or as environment variables (see .env.example)."
            )
        return self


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Process-wide single entry point for settings.

    Caching defers `.env` loading to first call (avoids import-time side effects)
    and gives downstream modules a stable identity for dependency injection.
    Tests must call `get_settings.cache_clear()` between cases that mutate env vars.
    """
    return Settings()
