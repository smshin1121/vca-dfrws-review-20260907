"""Structured logging via structlog with correlation ID support (P0-010).

``configure_logging(settings)`` wires:

- stdlib ``logging`` to ``settings.vca_log_level`` (so library logs are
  filtered uniformly).
- structlog processors: contextvars merge, log level, ISO timestamp,
  custom correlation-id injector, and an environment-specific renderer.
- ``vca_env="dev"`` -> ``ConsoleRenderer`` (no colors — Windows PowerShell
  ANSI safety).
- ``vca_env`` other than ``"dev"`` -> ``JSONRenderer`` (machine-readable
  for CI/test/prod).

The function is idempotent: ``structlog.configure()`` resets prior config
and ``logging.basicConfig(force=True)`` wipes prior root handlers.

Correlation IDs propagate via :data:`correlation_id`, an asyncio-aware
``ContextVar``. Boundary code (CLI entry, FastAPI middleware) should call
``correlation_id.set(uuid)`` once; nested coroutines inherit the value
automatically (PEP 567).
"""

from __future__ import annotations

import contextvars
import logging
from collections.abc import MutableMapping
from typing import TYPE_CHECKING, Any

import structlog

if TYPE_CHECKING:
    from vca.config import Settings

# Task-local correlation id. Default is None; when None the custom
# processor omits the key entirely (less log noise).
correlation_id: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "vca_correlation_id", default=None
)


def _add_correlation_id(
    _logger: Any, _method_name: str, event_dict: MutableMapping[str, Any]
) -> MutableMapping[str, Any]:
    """structlog processor: inject ``correlation_id`` when set."""
    cid = correlation_id.get()
    if cid is not None:
        event_dict.setdefault("correlation_id", cid)
    return event_dict


def _build_renderer(*, is_dev: bool) -> Any:
    """Pick the renderer that matches the environment.

    Dev gets a colorless ConsoleRenderer plus a colorless rich traceback
    formatter so PowerShell does not see ANSI escape sequences (Codex P3).
    Other environments use JSONRenderer with format_exc_info already in the
    pipeline so JSON logs preserve traceback strings (Codex P2).
    """
    if is_dev:
        # ``color_system=None`` disables ANSI escapes from rich tracebacks.
        # ``rich``'s own type stub for ``Console.color_system`` is too narrow
        # to advertise ``None``, so we ignore the static-only mismatch here.
        plain_tb = structlog.dev.RichTracebackFormatter(
            color_system=None,  # type: ignore[arg-type]
        )
        return structlog.dev.ConsoleRenderer(
            colors=False,
            exception_formatter=plain_tb,
        )
    return structlog.processors.JSONRenderer()


_HTTPX_LIBRARY_LOGGERS: tuple[str, ...] = ("httpx", "httpcore")
"""Third-party HTTP libraries whose default INFO log line leaks runtime URLs.

``httpx._client`` logs every successful response at INFO with the runtime
``request.url`` — which includes ``apikey=<value>`` for Etherscan-style
endpoints (CWE-532: Insertion of Sensitive Information into Log File).
``httpcore`` is httpx's transport layer and has similarly chatty INFO logs.

``configure_logging`` pins both loggers to WARNING regardless of
``settings.vca_log_level`` so neither emits its INFO request line. Operators
who genuinely need wire-level visibility must opt in explicitly via
``logging.getLogger("httpx").setLevel(logging.DEBUG)`` at the entry point.

P1-021.0.3 — replaces the operator-facing apikey-in-stderr leak observed
during ``case run kelpdao --adapter-mode cassette`` reproduction.
"""


def configure_logging(settings: Settings) -> None:
    """Configure stdlib logging and structlog from a ``Settings`` object.

    Idempotent — safe to call multiple times. Earlier calls (or unrelated
    consumers of structlog inside the same process) may have set a custom
    ``logger_factory`` / ``context_class`` that ``structlog.configure``
    would otherwise inherit, so we explicitly :func:`structlog.reset_defaults`
    first (Codex P2) and then install the full processor chain we care about.

    Args:
        settings: VCA :class:`vca.config.Settings`. Reads ``vca_env`` and
            ``vca_log_level`` only.
    """
    level: int = getattr(logging, settings.vca_log_level)

    # ``force=True`` clears handlers installed by pytest / earlier callers
    # so re-configuration takes effect cleanly.
    logging.basicConfig(level=level, format="%(message)s", force=True)

    # P1-021.0.3 Fix B — pin the chatty HTTP-library loggers to WARNING so
    # ``httpx._client.logger.info("HTTP Request: %s %s ...")`` (URL includes
    # apikey=<value>) cannot leak through the root handler chain regardless
    # of ``vca_log_level``. Idempotent: ``Logger.setLevel`` overwrites any
    # prior value. We don't disable propagation so genuine WARNING/ERROR
    # entries still surface.
    for _name in _HTTPX_LIBRARY_LOGGERS:
        logging.getLogger(_name).setLevel(logging.WARNING)

    structlog.reset_defaults()

    is_dev = settings.vca_env == "dev"
    renderer: Any = _build_renderer(is_dev=is_dev)

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso", utc=True),
            _add_correlation_id,
            # ``format_exc_info`` turns ``exc_info=True`` / ``.exception()``
            # into a ``"exception"`` key with the formatted traceback, so the
            # JSONRenderer no longer drops stack info on production errors.
            structlog.processors.format_exc_info,
            renderer,
        ],
        wrapper_class=structlog.make_filtering_bound_logger(level),
        # cache_logger_on_first_use=False keeps configure_logging fully
        # idempotent — the next call's processors take effect immediately
        # rather than being stuck on the cached bound logger from before.
        cache_logger_on_first_use=False,
    )


def get_logger(name: str | None = None) -> Any:
    """Return a configured structlog logger.

    Thin facade so callers do not import ``structlog`` directly.

    Args:
        name: Optional logger name (mirrors ``logging.getLogger`` semantics).

    Returns:
        A structlog ``BoundLogger``-like object exposing
        ``.debug/.info/.warning/.error/.critical``.
    """
    if name is not None:
        return structlog.get_logger(name)
    return structlog.get_logger()
