"""VCA observability layer (P0-010).

Public surface for structured logging + correlation IDs. Callers should
not depend on ``structlog`` directly — use :func:`get_logger` so the
internal logger choice can evolve without breaking consumers.
"""

from vca.observability.logging import (
    configure_logging,
    correlation_id,
    get_logger,
)

__all__ = ["configure_logging", "correlation_id", "get_logger"]
