"""VaultDetector — flags accumulator addresses (P1-013).

A "vault" address has high fan-in, low (often zero) fan-out, and a long
residence time. KelpDAO Stage 8 BTC L2 (``bc1phz5jjk…``) fires this
heuristic — it accumulates fragmented BTC into a long-residence balance.
"""

from __future__ import annotations

from datetime import datetime
from typing import Final

from vca.labeler._types import (
    AddressActivity,
    AddressLabel,
    Evidence,
    EvidenceKind,
    LabelKind,
    LabelSource,
)
from vca.labeler.heuristics import (
    HeuristicConfig,
    ensure_utc_now,
    residence_seconds,
)
from vca.types import NormalizedAddress

_NAME: Final[str] = "vault"
_BASE_CONFIDENCE = 0.80
_NO_OUTGOING_BONUS = 0.10


class VaultDetector:
    """Pure detector — see module docstring for the algorithm."""

    name: str = _NAME
    source: LabelSource = LabelSource.HEURISTIC_VAULT
    kind: LabelKind = LabelKind.VAULT

    def __init__(self, config: HeuristicConfig) -> None:
        self._config = config

    def detect(
        self,
        activity: AddressActivity,
        *,
        now: datetime,
    ) -> tuple[AddressLabel, ...]:
        anchor = ensure_utc_now(now, detector=self.name)
        config = self._config

        if len(activity.incoming) < config.vault_min_fan_in:
            return ()
        if len(activity.outgoing) > config.vault_max_fan_out:
            return ()

        incoming_count = len(activity.incoming)
        outgoing_count = len(activity.outgoing)

        # Residence math (behaviour 41):
        #   - outgoing empty AND window_end is None  → now - max(incoming_ts)
        #   - outgoing empty AND window_end is set    → window_end - max(incoming_ts)
        #   - outgoing non-empty                      → min(outgoing_ts) - max(incoming_ts)
        incoming_timestamps = activity.transfer_timestamps[:incoming_count]
        outgoing_timestamps = activity.transfer_timestamps[incoming_count:]
        latest_incoming = max(incoming_timestamps)

        if outgoing_count == 0:
            end_anchor = activity.window_end if activity.window_end is not None else anchor
        else:
            end_anchor = min(outgoing_timestamps)

        residence = residence_seconds(start=latest_incoming, end=end_anchor)
        if residence < 0:
            # A negative residence drops the label in two distinct cases:
            #   - outgoing non-empty: an outflow timestamp precedes the latest
            #     inflow — a degenerate ordering for a pure accumulator.
            #   - no-outgoing now-anchor: the report clock ``now`` precedes the
            #     latest inflow. This is NOT "impossible by ordering" — it
            #     happens when ``now`` is a historical anchor (e.g. a case's
            #     theft-block ``default_now``) while laundering inflows are
            #     traced FORWARD in time. Such a still-accumulating address is
            #     conservatively left UNLABELED under this clock; a vault verdict
            #     for it would need a trace-horizon clock rather than the report
            #     clock. Known, currently-dormant limitation (the only Bybit
            #     no-outgoing BTC node has fan-in 1 < vault_min_fan_in and the
            #     labeler is miss-tolerant pending the BTC-dispersal capture);
            #     pinned by test_vault_now_anchor_drops_label_when_clock_precedes_accumulation.
            return ()
        if residence < config.vault_min_residence_seconds:
            return ()

        evidence = (
            Evidence(
                kind=EvidenceKind.FAN_IN_COUNT,
                count=incoming_count,
                observed_at=anchor,
            ),
            Evidence(
                kind=EvidenceKind.FAN_OUT_COUNT,
                count=outgoing_count,
                observed_at=anchor,
            ),
            Evidence(
                kind=EvidenceKind.RESIDENCE_TIME,
                window_seconds=int(residence),
                observed_at=anchor,
            ),
        )

        confidence = _BASE_CONFIDENCE + (_NO_OUTGOING_BONUS if outgoing_count == 0 else 0.0)
        confidence = min(1.0, confidence)

        label = AddressLabel(
            address=NormalizedAddress(address=activity.address),
            kind=self.kind,
            source=self.source,
            confidence=confidence,
            observed_at=anchor,
            evidence=evidence,
        )
        return (label,)


__all__ = ["VaultDetector"]
