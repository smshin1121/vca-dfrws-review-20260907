"""BatchPayoutDetector — flags uniform-unit batch dispatchers (P1-013).

A "batch payout" address sends N>=3 outgoing transfers whose minor-unit
values cluster tightly around a central unit (CV <= 5% by default).
KelpDAO Stage 8 BTC L3 (``bc1qrnuda...``, 4x 10-BTC, CV = 0) fires this
heuristic in isolation, but it is not wired into ``_detectors_for_chain``.

Algorithm:
    1. Bucket outgoing transfers by ``(asset.symbol, asset.decimals)`` so
       mixed-asset addresses don't pollute the unit math.
    2. Pick the LARGEST bucket (most transfers); break ties on alphabetical
       asset symbol for determinism.
    3. Run the CV check (population stdev ÷ mean) against the chosen
       bucket; emit a label when the threshold is met.
"""

from __future__ import annotations

from datetime import datetime
from typing import Final

from vca.labeler._types import (
    AddressActivity,
    AddressLabel,
    Evidence,
    EvidenceKind,
    LabelKind,
    LabelSource,
)
from vca.labeler.heuristics import (
    HeuristicConfig,
    ensure_utc_now,
    population_cv,
)
from vca.types import NormalizedAddress, NormalizedTransfer

_NAME: Final[str] = "batch_payout"
_BASE_CONFIDENCE = 0.60
_PER_REPEAT_CONFIDENCE_GAIN = 0.05
_MAX_CONFIDENCE_BONUS = 0.30


class BatchPayoutDetector:
    """Pure detector — see module docstring for the algorithm."""

    name: str = _NAME
    source: LabelSource = LabelSource.HEURISTIC_BATCH_PAYOUT
    kind: LabelKind = LabelKind.BATCH_PAYOUT

    def __init__(self, config: HeuristicConfig) -> None:
        self._config = config

    def detect(
        self,
        activity: AddressActivity,
        *,
        now: datetime,
    ) -> tuple[AddressLabel, ...]:
        anchor = ensure_utc_now(now, detector=self.name)
        config = self._config

        if len(activity.outgoing) < config.batch_min_unit_repeats:
            return ()

        buckets = _bucket_outgoing(activity.outgoing)
        if not buckets:
            return ()

        # Pick the LARGEST bucket; tie-break alphabetically by asset symbol
        # using ``min`` over (-count, symbol) so the chosen key is
        # (most-frequent, lexicographically-smallest-on-tie).
        chosen_key = min(buckets.keys(), key=lambda k: (-len(buckets[k]), k[0]))
        bucket = buckets[chosen_key]
        symbol, decimals = chosen_key
        values = [transfer.amount.raw for transfer in bucket]

        if len(values) < config.batch_min_unit_repeats:
            return ()

        cv = population_cv(values)
        if cv is None:
            return ()
        # μ ≥ batch_min_unit_value_minor — defensive check for dust.
        # Compare the UNROUNDED mean to the threshold using exact integer
        # arithmetic: ``total < threshold * n`` ⇔ ``total / n < threshold``
        # for positive ``n``. Comparing the rounded mean would incorrectly
        # admit batches whose actual mean is below the threshold but rounds
        # up to it — e.g. values=[99, 100, 100] with threshold=100 has μ=99.67
        # (sum=299) which the documented mean gate must reject, even though a
        # rounded mean rounds to 100. The ``rounded_mean`` is then computed
        # for evidence emission only.
        total = sum(values)
        n = len(values)
        if total < config.batch_min_unit_value_minor * n:
            return ()
        # Banker's (round-half-to-even) integer mean for the evidence value.
        # 18-decimal EVM raws routinely exceed 2^53, so float division would
        # lose minor-unit precision before rounding (a uniform batch of 1e18+1
        # wei would render as 1e18 in OUTPUT_UNIT_CLUSTER). ``rounded_mean``
        # uses ``divmod`` — pure int math, no float bridge, no Decimal
        # overhead. On exact x.5 ties (e.g. values=[100, 101, 100, 101] →
        # sum=402, n=4, raw mean=100.5) we round to the nearest even integer
        # (100), matching Python 3's built-in ``round()`` semantics.
        quotient, remainder = divmod(total, n)
        twice_remainder = 2 * remainder
        if twice_remainder > n:
            rounded_mean = quotient + 1
        elif twice_remainder < n:
            rounded_mean = quotient
        else:  # exact x.5 tie — round half to even (banker's rounding)
            rounded_mean = quotient if quotient % 2 == 0 else quotient + 1
        if cv > config.batch_unit_cv_max:
            return ()

        evidence = (
            Evidence(
                kind=EvidenceKind.OUTPUT_UNIT_CLUSTER,
                value_minor=rounded_mean,
                decimals=decimals,
                observed_at=anchor,
            ),
            Evidence(
                kind=EvidenceKind.OUTPUT_UNIT_FREQUENCY,
                count=len(values),
                observed_at=anchor,
            ),
        )

        extras: dict[str, object] = {
            "bucket_symbol": symbol,
            "bucket_decimals": decimals,
            "bucket_cv": cv,
        }

        confidence = _compute_confidence(
            repeat_count=len(values),
            min_repeats=config.batch_min_unit_repeats,
        )

        label = AddressLabel(
            address=NormalizedAddress(address=activity.address),
            kind=self.kind,
            source=self.source,
            confidence=confidence,
            observed_at=anchor,
            evidence=evidence,
            extras=extras,
        )
        return (label,)


def _bucket_outgoing(
    outgoing: tuple[NormalizedTransfer, ...],
) -> dict[tuple[str, int], list[NormalizedTransfer]]:
    """Group outgoing transfers by ``(asset.symbol, asset.decimals)``."""
    buckets: dict[tuple[str, int], list[NormalizedTransfer]] = {}
    for transfer in outgoing:
        key = (transfer.asset.symbol, transfer.asset.decimals)
        buckets.setdefault(key, []).append(transfer)
    return buckets


def _compute_confidence(*, repeat_count: int, min_repeats: int) -> float:
    """Per DoD-16: 0.60 + min(0.30, 0.05 * (count - min_repeats)). Capped at 0.90."""
    extra = max(0, repeat_count - min_repeats)
    bonus = min(_MAX_CONFIDENCE_BONUS, _PER_REPEAT_CONFIDENCE_GAIN * extra)
    return _BASE_CONFIDENCE + bonus


__all__ = ["BatchPayoutDetector"]
