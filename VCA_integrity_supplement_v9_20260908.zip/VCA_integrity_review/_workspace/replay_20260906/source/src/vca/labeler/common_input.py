"""CommonInputDetector — BTC common-input-ownership cluster (P1-013).

BTC-only. The detector consumes the pre-built :class:`AddressActivity`
PLUS constructor-supplied cospend groups and (optionally) the source TX
output values. Per DoD-15:

* CoinJoin pruning fires FIRST — when ``len(group) >=
  config.coinjoin_min_inputs`` AND the source TX outputs cluster tightly
  (uniform-output CV ≤ ``config.coinjoin_uniform_output_cv_max``), the
  detector emits a ``HEURISTIC_COINJOIN`` rejection marker (NOT a
  cluster). KelpDAO Stage 8 BTC L4 fires this exclusion.
* Otherwise the detector emits one ``CLUSTER`` label per group with a
  freshly-minted ``cluster_id = uuid.uuid4()`` and ``confidence = 0.50``.

Reconciliation across multiple TXs (connected components) is **out of
scope** — P1-013 emits per-TX edge labels and P1-016 owns the rollup
(R-CLUSTER-DB).
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from typing import Final

from vca.labeler._types import (
    AddressActivity,
    AddressLabel,
    Evidence,
    EvidenceKind,
    LabelKind,
    LabelSource,
)
from vca.labeler.heuristics import (
    HeuristicConfig,
    ensure_utc_now,
    population_cv,
)
from vca.types import Address, ChainId, NormalizedAddress

_LOG = logging.getLogger(__name__)
_NAME: Final[str] = "common_input"

_CLUSTER_CONFIDENCE = 0.50
_COINJOIN_REJECTION_CONFIDENCE = 0.95


class CommonInputDetector:
    """BTC-only cospend / CoinJoin-pruner detector.

    Constructor surface mirrors the architect's WBS §3.9: cospend groups
    and (optional) per-group output values are supplied at construction
    time so the ``detect`` method stays synchronous and pure.
    """

    name: str = _NAME
    source: LabelSource = LabelSource.HEURISTIC_COMMON_INPUT
    kind: LabelKind = LabelKind.CLUSTER

    def __init__(
        self,
        config: HeuristicConfig,
        *,
        cospend_groups: tuple[tuple[Address, ...], ...] = (),
        cospend_outputs: dict[tuple[str, ...], tuple[int, ...]] | None = None,
    ) -> None:
        self._config = config
        self._cospend_groups = cospend_groups
        self._cospend_outputs = cospend_outputs

    def detect(
        self,
        activity: AddressActivity,
        *,
        now: datetime,
    ) -> tuple[AddressLabel, ...]:
        anchor = ensure_utc_now(now, detector=self.name)
        config = self._config

        # BTC-only gate (DoD-15 / behaviour 52).
        if activity.address.chain is not ChainId.BITCOIN:
            return ()

        if not self._cospend_groups:
            return ()

        labels: list[AddressLabel] = []
        for group in self._cospend_groups:
            if len(group) < 2:
                # Single-input TX is not a cospend signal (behaviour 54).
                continue
            if not _address_in_group(activity.address, group):
                continue

            # CoinJoin pruner runs BEFORE cluster emission (behaviour 55).
            if len(group) >= config.coinjoin_min_inputs and self._cospend_outputs is not None:
                outputs_key = tuple(addr.value for addr in group)
                outputs = self._cospend_outputs.get(outputs_key)
                # Output-count guard: real CoinJoin rounds have ≥ N uniform
                # outputs (Wasabi/Whirlpool emit equal-denomination outputs).
                # A 1-output (consolidation) or 2-output transaction is NOT a
                # CoinJoin — ``population_cv`` on a length-1 list is 0 and
                # would spuriously trip the CV gate, suppressing the
                # legitimate cospend cluster.
                if outputs is not None and len(outputs) >= config.coinjoin_min_outputs:
                    cv = population_cv(list(outputs))
                    if cv is not None and cv <= config.coinjoin_uniform_output_cv_max:
                        labels.append(
                            _build_coinjoin_label(activity=activity, group=group, anchor=anchor)
                        )
                        continue

            # Degraded path — cospend_outputs missing AND threshold-eligible
            # group: log at DEBUG and fall through to CLUSTER emission
            # (behaviour 57 / R-CLUSTER-DEGRADED).
            if len(group) >= config.coinjoin_min_inputs and self._cospend_outputs is None:
                _LOG.debug("common_input: cospend_outputs missing — coinjoin pruner skipped")

            labels.append(_build_cluster_label(activity=activity, group=group, anchor=anchor))

        return tuple(labels)


def _address_in_group(address: Address, group: tuple[Address, ...]) -> bool:
    """``address`` participates in ``group`` (compared by value+chain)."""
    return any(member.value == address.value and member.chain is address.chain for member in group)


def _build_cluster_label(
    *,
    activity: AddressActivity,
    group: tuple[Address, ...],
    anchor: datetime,
) -> AddressLabel:
    """Emit a CLUSTER label with a freshly-minted UUID4 ``cluster_id``."""
    return AddressLabel(
        address=NormalizedAddress(address=activity.address),
        kind=LabelKind.CLUSTER,
        source=LabelSource.HEURISTIC_COMMON_INPUT,
        confidence=_CLUSTER_CONFIDENCE,
        observed_at=anchor,
        evidence=(
            Evidence(
                kind=EvidenceKind.BTC_INPUT_COSPEND,
                count=len(group),
                observed_at=anchor,
            ),
        ),
        cluster_id=str(uuid.uuid4()),
    )


def _build_coinjoin_label(
    *,
    activity: AddressActivity,
    group: tuple[Address, ...],
    anchor: datetime,
) -> AddressLabel:
    """Emit a HEURISTIC_COINJOIN rejection marker (UNKNOWN, no cluster)."""
    return AddressLabel(
        address=NormalizedAddress(address=activity.address),
        kind=LabelKind.UNKNOWN,
        source=LabelSource.HEURISTIC_COINJOIN,
        confidence=_COINJOIN_REJECTION_CONFIDENCE,
        observed_at=anchor,
        evidence=(
            Evidence(
                kind=EvidenceKind.BTC_COINJOIN_PRUNED,
                count=len(group),
                observed_at=anchor,
            ),
        ),
    )


__all__ = ["CommonInputDetector"]
