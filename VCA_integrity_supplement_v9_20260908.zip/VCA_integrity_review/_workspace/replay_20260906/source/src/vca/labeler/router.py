"""MetaMaskRouterLabeler — address-pin labeler for the MetaMask Swap Router (P2-001.0d).

The MetaMask Swap Router is an in-wallet DEX aggregator contract on
Ethereum mainnet that routes user funds through underlying liquidity
sources (Uniswap / 0x / Paraswap / ...). KelpDAO Stage 3-A row 6 (PDF
page 11) shows Exploiter 4 (``0xeBA786C9517a4823A5cFD9c72e4E80BF8168129B``)
swapping 3,905.849 wstETH via this router on 2026-04-18 18:07:47 UTC,
TX ``0x256117bc7e4f947766bdc8d8f607bc41adbf8989aa701dbd7c80e0065a424143``.

Design notes:

* This is the **first non-heuristic labeler** in the package — the pin
  list is operator-curated so the source is :attr:`LabelSource.OWN_DB`
  (rank 0 in the priority resolver). Heuristic-prefix evidence-required
  rule does NOT apply, so the labeler emits an empty evidence tuple.
* The closest existing :class:`LabelKind` for "fund-routing protocol
  contract" is :attr:`LabelKind.BRIDGE` (used by the LayerZero bridge
  labeler in the same WBS row). Per R-NO-NEW-LABELKIND we MUST NOT
  expand the enum.
* The labeler satisfies the :class:`HeuristicDetector` protocol so the
  tracer (P1-014) treats it identically to the four shipped detectors.
* Default pin: the EIP-55 checksum form of the canonical MetaMask Swap
  Router v1 mainnet deployment. The config takes any iterable of address
  strings and normalises via :meth:`Address.from_str` so callers may
  paste lowercase / mixed case Etherscan output.

Source pin tag ``operator_pin_2026-05-12`` traces every emission back to
the supplement PDF integration commit (db16ad2) so future operators can
locate the verbatim source from the label alone.
"""

from __future__ import annotations

from collections.abc import Iterable
from datetime import datetime
from typing import Any, Final

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from vca.labeler._types import (
    AddressActivity,
    AddressLabel,
    LabelKind,
    LabelSource,
)
from vca.labeler.heuristics import ensure_utc_now
from vca.types import Address, ChainId, NormalizedAddress

# Frozen Pydantic config — mirrors every other DTO in this package.
_FROZEN_CONFIG: Final[ConfigDict] = ConfigDict(frozen=True, strict=True, extra="forbid")

# Operator-curated provenance tag — embedded in every emitted label.extras
# so a downstream investigator can grep the codebase for the supplement
# PDF integration date (2026-05-12, commit db16ad2).
_OPERATOR_PIN_TAG: Final[str] = "operator_pin_2026-05-12"
_PROTOCOL_NAME: Final[str] = "MetaMask Swap Router"
_NAME: Final[str] = "metamask_swap_router"
_PIN_CONFIDENCE: Final[float] = 1.0
_PDF_REFERENCE: Final[str] = "KelpDAO_rsETH_Exploit_update.pdf p11"
# Cycle 56 P2-LABELER-CHAIN-LABEL-CHAIN-SSOT.1 — provenance breadcrumb so the
# reporter ``_attribution_evidence.md.j2`` template can disambiguate this
# Ethereum-mainnet router label from chain-agnostic evidence emitted by
# sibling labelers. Mainnet-only by construction (see ``detect`` chain
# guard at line 137). Mirrors :data:`exchange._CHAIN_LABEL`.
_CHAIN_LABEL: Final[str] = "ethereum_mainnet"


def _normalize_eip55_str(raw: str) -> str:
    """Run an address string through :class:`Address` so the EIP-55 form is
    returned. Wraps ``Address.from_str`` to give callers a string-in /
    string-out API for ``frozenset`` membership comparisons.
    """
    return Address.from_str(raw, ChainId.ETHEREUM).value


# Canonical MetaMask Swap Router v1 (mainnet). Pinned at module load time
# so any import-time corruption surfaces immediately instead of at first
# detection.
METAMASK_SWAP_ROUTER_DEFAULT: frozenset[str] = frozenset(
    {_normalize_eip55_str("0x881D40237659C251811CEC9c364ef91dC08D300C")}
)


class MetaMaskRouterLabelerConfig(BaseModel):
    """Frozen settings DTO carrying the address whitelist.

    ``router_addresses`` MAY hold any number of EIP-55 (or lowercase /
    mixed-case) Ethereum mainnet contract addresses. The validator
    normalises every entry to its EIP-55 checksum form so lookup uses
    canonical strings only — callers therefore never need to pre-process
    pasted Etherscan output. Empty sets are rejected because a labeler
    with no pins cannot emit anything (architecture error rather than
    silent no-op).
    """

    model_config = _FROZEN_CONFIG

    router_addresses: frozenset[str] = Field(default=METAMASK_SWAP_ROUTER_DEFAULT)

    @field_validator("router_addresses", mode="before")
    @classmethod
    def _normalize_addresses(cls, value: Any) -> Any:
        """Canonicalise every address to its EIP-55 form before the field is set.

        Accepts any iterable of strings (frozenset, set, tuple, list) and
        emits a ``frozenset`` of EIP-55 strings. Malformed addresses
        propagate as :class:`ValueError` from :meth:`Address.from_str`.
        """
        if isinstance(value, frozenset | set | tuple | list):
            return frozenset(_normalize_eip55_str(raw) for raw in value)
        return value  # let pydantic surface the type error

    @model_validator(mode="after")
    def _reject_empty(self) -> MetaMaskRouterLabelerConfig:
        if len(self.router_addresses) == 0:
            raise ValueError(
                "MetaMaskRouterLabelerConfig.router_addresses must not be empty; "
                "an address-whitelist labeler with zero pins cannot emit labels."
            )
        return self


class MetaMaskRouterLabeler:
    """Address-pin labeler. See module docstring for the algorithm."""

    name: str = _NAME
    source: LabelSource = LabelSource.OWN_DB
    kind: LabelKind = LabelKind.BRIDGE

    def __init__(self, config: MetaMaskRouterLabelerConfig) -> None:
        self._config = config

    def detect(
        self,
        activity: AddressActivity,
        *,
        now: datetime,
    ) -> tuple[AddressLabel, ...]:
        anchor = ensure_utc_now(now, detector=self.name)

        # Mainnet-only pin: ARB / BTC / Unichain addresses never match the
        # default router even when the hex bytes coincide.
        if activity.address.chain is not ChainId.ETHEREUM:
            return ()

        if activity.address.value not in self._config.router_addresses:
            return ()

        label = AddressLabel(
            address=NormalizedAddress(address=activity.address),
            kind=self.kind,
            source=self.source,
            confidence=_PIN_CONFIDENCE,
            observed_at=anchor,
            extras={
                "protocol": _PROTOCOL_NAME,
                "source_pin": _OPERATOR_PIN_TAG,
                "pdf_reference": _PDF_REFERENCE,
                "chain": _CHAIN_LABEL,
            },
        )
        return (label,)


def build_default_labeler(
    *,
    extra_addresses: Iterable[str] = (),
) -> MetaMaskRouterLabeler:
    """Helper for callers who want the default pin plus a few extras.

    Useful when an operator pastes a freshly-discovered MetaMask Swap
    Router proxy (e.g. v2 / chain-fork redeployments) without losing the
    canonical v1 anchor. ``extra_addresses`` accepts any case; the
    :class:`MetaMaskRouterLabelerConfig` validator handles normalisation.
    """
    addresses = set(METAMASK_SWAP_ROUTER_DEFAULT) | set(extra_addresses)
    config = MetaMaskRouterLabelerConfig(router_addresses=frozenset(addresses))
    return MetaMaskRouterLabeler(config)


__all__ = [
    "METAMASK_SWAP_ROUTER_DEFAULT",
    "MetaMaskRouterLabeler",
    "MetaMaskRouterLabelerConfig",
    "build_default_labeler",
]
