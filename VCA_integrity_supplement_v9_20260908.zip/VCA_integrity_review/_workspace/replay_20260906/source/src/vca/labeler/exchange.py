"""BitgetExchangeLabeler — address-pin labeler for the Bitget 37 deposit
contract (P2-008.0c).

Recognises when an :class:`AddressActivity` targets the Bitget 37
exchange deposit contract on Ethereum mainnet. Supplement PDF pages
35-36 (Stage 8 Route B) document the KelpDAO incident: on
2026-04-XX 18:48-20:28 UTC, Exploiter 8 (via mid-wallet 2) deposited
227.95 ETH across 9 transactions directly into the Bitget 37 contract
using the contract's ``receive()`` fallback, bypassing the standard
exchange-deposit KYC flow.

Design notes:

* This is the **third non-heuristic labeler** in the package after
  :class:`vca.labeler.router.MetaMaskRouterLabeler` (P2-001.0d) and
  :class:`vca.labeler.governance.GovernanceLabeler` (P2-004.0) — the pin
  list is operator-curated so the source is :attr:`LabelSource.OWN_DB`
  (rank 0 in the priority resolver). Heuristic-prefix evidence-required
  rule does NOT apply, so the labeler emits an empty evidence tuple.
* The chosen :class:`LabelKind` is :attr:`LabelKind.EXCHANGE_HOT` — the
  canonical existing enum value for "centralised-exchange hot deposit
  address" (which is exactly what Bitget 37 is operationally). The
  ``EXCHANGE_HOT``/``EXCHANGE_COLD`` macro-class is the existing CEX
  surface (``LabelKind.is_cex`` returns True for both); per
  R-NO-NEW-LABELKIND no new enum member is added.
* The labeler satisfies the :class:`HeuristicDetector` protocol so the
  tracer (P1-014) treats it identically to the shipped detectors.
* The labeler is **chain-aware**: the Bitget 37 contract is deployed
  on Ethereum mainnet (chain_id 1). Even if a contract happens to share
  the same hex on Arbitrum / Unichain / BTC, the pin MUST NOT fire —
  addresses are EVM-chain-segregated in :class:`vca.types.Address` so
  this restriction is a one-liner check against
  :attr:`ChainId.ETHEREUM`.
* **receive()/fallback() observability filter**: the WBS describes the
  Stage 8 Route B pattern as ``receive()`` ETH transfers — pure native
  ETH movements with no calldata. The labeler protocol consumes a
  pre-built :class:`AddressActivity` (R-PURE-ANALYZER) which does NOT
  expose raw tx-level ``input`` bytes; the closest observable signal in
  the normalised model is "at least one incoming native-ETH transfer
  with ``log_index is None``" (token transfers carry a ``log_index``
  from their Transfer event; native ETH ``receive()`` transfers do
  not). The labeler therefore requires at least one such incoming
  transfer before firing — a Bitget 37 address with only token-transfer
  incomings or with NO incomings is not yet a confirmed deposit and the
  labeler stays silent. This is a meaningful behavioural filter rather
  than a calldata inspection (which the protocol disallows).

Source pin tag ``operator_pin_2026-05-12`` traces every emission back to
the supplement PDF integration commit (db16ad2).
"""

from __future__ import annotations

from collections.abc import Iterable
from datetime import datetime
from typing import Any, Final

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from vca.labeler._types import (
    AddressActivity,
    AddressLabel,
    LabelKind,
    LabelSource,
)
from vca.labeler.heuristics import ensure_utc_now
from vca.types import Address, ChainId, NormalizedAddress

# Frozen Pydantic config — mirrors every other DTO in this package.
_FROZEN_CONFIG: Final[ConfigDict] = ConfigDict(frozen=True, strict=True, extra="forbid")

# Operator-curated provenance tag — embedded in every emitted label.extras
# so a downstream investigator can grep the codebase for the supplement
# PDF integration date (2026-05-12, commit db16ad2).
_OPERATOR_PIN_TAG: Final[str] = "operator_pin_2026-05-12"
_PROTOCOL_NAME: Final[str] = "Bitget 37 (deposit contract)"
_PDF_REFERENCE: Final[str] = "KelpDAO_rsETH_Exploit_update.pdf p35-36"
_CHAIN_LABEL: Final[str] = "ethereum_mainnet"
_DEPLOYED_ON: Final[str] = "2025-12-17"
_NAME: Final[str] = "bitget_37_deposit_contract"
_PIN_CONFIDENCE: Final[float] = 1.0
_DEPOSIT_NOTE: Final[str] = (
    "smart-contract deposit pattern; bypasses KYC, no automatic account "
    "credit per Bitget official docs"
)

# ---------------------------------------------------------------------------
# Address constants
# ---------------------------------------------------------------------------

# Canonical 20-byte EIP-55 form of the Bitget 37 deposit contract on
# Ethereum mainnet. Verified via ``eth_utils.to_checksum_address``: the
# operator-supplied form is already canonical EIP-55, so the EIP-55
# round-trip is byte-for-byte identical. The contract was deployed on
# 2025-12-17 per the WBS § 4.9 verbatim entry.
BITGET_37_DEPOSIT_ADDRESS: Final[str] = "0xd96aE67955De94cAaC04efc8EDB857557dd67C2B"


def _normalize_eip55_str(raw: str) -> str:
    """Run an address string through :class:`Address` so the EIP-55 form is
    returned. Wraps ``Address.from_str`` to give callers a string-in /
    string-out API for ``frozenset`` membership comparisons.
    """
    return Address.from_str(raw, ChainId.ETHEREUM).value


# Canonical Bitget 37 deposit contract pin, computed at module load time so
# any import-time corruption surfaces immediately instead of at first
# detection.
BITGET_37_DEPOSIT_DEFAULT: frozenset[str] = frozenset(
    {_normalize_eip55_str(BITGET_37_DEPOSIT_ADDRESS)}
)


class BitgetExchangeLabelerConfig(BaseModel):
    """Frozen settings DTO carrying the Bitget deposit-address whitelist.

    ``deposit_addresses`` MAY hold any number of EIP-55 (or lowercase /
    mixed-case) Ethereum mainnet contract addresses. The validator
    normalises every entry to its EIP-55 checksum form so lookup uses
    canonical strings only — callers therefore never need to pre-process
    pasted Etherscan output. Empty sets are rejected because a labeler
    with no pins cannot emit anything (architecture error rather than
    silent no-op).
    """

    model_config = _FROZEN_CONFIG

    deposit_addresses: frozenset[str] = Field(default=BITGET_37_DEPOSIT_DEFAULT)

    @field_validator("deposit_addresses", mode="before")
    @classmethod
    def _normalize_addresses(cls, value: Any) -> Any:
        """Canonicalise every address to its EIP-55 form before the field is set.

        Accepts any iterable of strings (frozenset, set, tuple, list) and
        emits a ``frozenset`` of EIP-55 strings. Malformed addresses
        propagate as :class:`ValueError` from :meth:`Address.from_str`.
        """
        if isinstance(value, frozenset | set | tuple | list):
            return frozenset(_normalize_eip55_str(raw) for raw in value)
        return value  # let pydantic surface the type error

    @model_validator(mode="after")
    def _reject_empty(self) -> BitgetExchangeLabelerConfig:
        if len(self.deposit_addresses) == 0:
            raise ValueError(
                "BitgetExchangeLabelerConfig.deposit_addresses must not be empty; "
                "an address-whitelist labeler with zero pins cannot emit labels."
            )
        return self


class BitgetExchangeLabeler:
    """Address-pin labeler for the Bitget 37 deposit contract.

    See module docstring for the algorithm (address pin + chain filter +
    receive()-style incoming-native-ETH observability filter).
    """

    name: str = _NAME
    source: LabelSource = LabelSource.OWN_DB
    kind: LabelKind = LabelKind.EXCHANGE_HOT

    def __init__(self, config: BitgetExchangeLabelerConfig) -> None:
        self._config = config

    def detect(
        self,
        activity: AddressActivity,
        *,
        now: datetime,
    ) -> tuple[AddressLabel, ...]:
        anchor = ensure_utc_now(now, detector=self.name)

        # Mainnet-only pin: ARB / BTC / Unichain addresses never match the
        # Bitget 37 default contract even when the hex bytes coincide.
        if activity.address.chain is not ChainId.ETHEREUM:
            return ()

        if activity.address.value not in self._config.deposit_addresses:
            return ()

        # receive()/fallback() observability filter — see module docstring.
        # The labeler protocol consumes pre-built activity snapshots and
        # cannot inspect raw tx-level ``input`` bytes; the canonical
        # native-ETH ``receive()`` signature in the normalised model is an
        # incoming transfer with ``asset.is_native`` and ``log_index is
        # None`` (token transfers carry a Transfer-event log_index;
        # native ETH movements do not). Without at least one such
        # incoming transfer the deposit is unconfirmed, so the labeler
        # stays silent rather than over-fire on a bare address ping.
        if not _has_native_eth_receive(activity):
            return ()

        label = AddressLabel(
            address=NormalizedAddress(address=activity.address),
            kind=self.kind,
            source=self.source,
            confidence=_PIN_CONFIDENCE,
            observed_at=anchor,
            extras={
                "protocol": _PROTOCOL_NAME,
                "source_pin": _OPERATOR_PIN_TAG,
                "pdf_reference": _PDF_REFERENCE,
                "chain": _CHAIN_LABEL,
                "deployed_on": _DEPLOYED_ON,
                "note": _DEPOSIT_NOTE,
            },
        )
        return (label,)


def _has_native_eth_receive(activity: AddressActivity) -> bool:
    """Return True iff ``activity`` has at least one incoming native-ETH
    transfer with ``log_index is None`` — the normalised-model signature
    of a ``receive()``/``fallback()`` pure-ETH credit.

    Pure helper (module-level, deterministic). Token transfers carry a
    ``log_index`` from their Transfer event; native ETH movements via
    ``receive()`` have ``log_index is None``. Bitget 37 deposits in the
    KelpDAO Stage 8 Route B verbatim TX table are all native-ETH
    receives — they MUST satisfy this filter.
    """
    for transfer in activity.incoming:
        if transfer.asset.is_native and transfer.log_index is None:
            return True
    return False


def build_default_labeler(
    *,
    extra_addresses: Iterable[str] = (),
) -> BitgetExchangeLabeler:
    """Helper for callers who want the default pin plus a few extras.

    Useful when an operator pastes a freshly-discovered Bitget deposit
    contract (e.g. a Bitget 38 redeployment) without losing the canonical
    anchor. ``extra_addresses`` accepts any case; the
    :class:`BitgetExchangeLabelerConfig` validator handles normalisation.
    """
    addresses = set(BITGET_37_DEPOSIT_DEFAULT) | set(extra_addresses)
    config = BitgetExchangeLabelerConfig(deposit_addresses=frozenset(addresses))
    return BitgetExchangeLabeler(config)


__all__ = [
    "BITGET_37_DEPOSIT_ADDRESS",
    "BITGET_37_DEPOSIT_DEFAULT",
    "BitgetExchangeLabeler",
    "BitgetExchangeLabelerConfig",
    "build_default_labeler",
]
