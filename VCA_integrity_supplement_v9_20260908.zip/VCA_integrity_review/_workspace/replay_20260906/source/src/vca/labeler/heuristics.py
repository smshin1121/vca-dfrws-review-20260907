"""Heuristic detector Protocol + shared configuration DTO (P1-013).

Contains:

* :class:`HeuristicDetector` — the analyzer surface every detector
  satisfies. ``runtime_checkable`` so ``isinstance(detector,
  HeuristicDetector)`` works in tests (DoD-10).
* :class:`HeuristicConfig` — frozen settings DTO supplied by the tracer
  (P1-014). Documented defaults match the architect's WBS §3.8; thresholds
  are policy not secrets, so the labeler does NOT route them through
  :class:`vca.config.Settings`.
* Pure helper functions used by multiple detectors (residence math,
  population CV).
"""

from __future__ import annotations

import re
import statistics
from collections.abc import Sequence
from datetime import datetime
from typing import Final, Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict, Field, StrictInt

from vca.labeler._types import (
    AddressActivity,
    AddressLabel,
    LabelKind,
    LabelSource,
)

# Detector ``name`` charset — pinned by ``test_each_detector_implements_protocol``.
_NAME_RE = re.compile(r"[a-z0-9_]+")

_FROZEN_CONFIG: Final[ConfigDict] = ConfigDict(frozen=True, strict=True, extra="forbid")


@runtime_checkable
class HeuristicDetector(Protocol):
    """Pure analyzer surface — no I/O, no mutation.

    Detectors consume a pre-built :class:`AddressActivity` and emit zero or
    more :class:`AddressLabel` records. The ``now`` argument is the
    tracer's wall-clock anchor; tests pin time by passing a fixed
    :class:`datetime`.
    """

    name: str
    source: LabelSource
    kind: LabelKind

    def detect(
        self,
        activity: AddressActivity,
        *,
        now: datetime,
    ) -> tuple[AddressLabel, ...]: ...


class HeuristicConfig(BaseModel):
    """Frozen settings DTO carrying every per-detector threshold.

    Defaults map to the architect's WBS §3.8 / DoD-11. Tracer (P1-014)
    constructs and passes a single instance into every detector; the
    labeler itself never reads from :class:`vca.config.Settings` because
    thresholds are policy, not secrets.
    """

    model_config = _FROZEN_CONFIG

    single_use_max_residence_seconds: StrictInt = Field(default=3600, ge=0)
    single_use_min_balance_minor: StrictInt = Field(default=0, ge=0)

    vault_min_fan_in: StrictInt = Field(default=5, ge=1)
    vault_max_fan_out: StrictInt = Field(default=1, ge=0)
    vault_min_residence_seconds: StrictInt = Field(default=7 * 24 * 3600, ge=0)

    batch_min_unit_repeats: StrictInt = Field(default=3, ge=1)
    batch_unit_cv_max: float = Field(default=0.05, ge=0.0, le=1.0)
    batch_min_unit_value_minor: StrictInt = Field(default=1, ge=1)

    coinjoin_min_inputs: StrictInt = Field(default=5, ge=2)
    # CoinJoin output-count guard: real CoinJoin patterns (Wasabi, Whirlpool)
    # emit N inputs ≈ N outputs of equal denomination, with at least 3
    # uniform outputs per round. A single-output transaction is a
    # consolidation, not a CoinJoin — population_cv on a length-1 list is
    # always 0 and would spuriously trip the CV gate. Default 3 matches the
    # smallest realistic CoinJoin round.
    coinjoin_min_outputs: StrictInt = Field(default=3, ge=2)
    coinjoin_uniform_output_cv_max: float = Field(default=0.10, ge=0.0, le=1.0)

    confidence_decay_per_extra_residence_hour: float = Field(default=0.0, ge=0.0, le=1.0)


# ---------------------------------------------------------------------------
# Shared pure helpers
# ---------------------------------------------------------------------------


def ensure_utc_now(now: datetime, *, detector: str) -> datetime:
    """Reject naive ``now`` arguments at every detector entrypoint."""
    if now.tzinfo is None or now.tzinfo.utcoffset(now) is None:
        raise ValueError(f"{detector}.detect: now must be tz-aware UTC, got naive datetime")
    return now


def population_cv(values: Sequence[int]) -> float | None:
    """Return ``stdev / mean`` (population CV), or ``None`` when undefined.

    Uses :func:`statistics.pstdev` because we are inspecting the full
    sample population, not estimating from a sample. Returns ``None`` when
    the input is empty OR ``mean == 0`` (CV is undefined / infinite).
    """
    if not values:
        return None
    mean = statistics.fmean(values)
    if mean == 0:
        return None
    sigma = statistics.pstdev(values)
    return sigma / mean


def residence_seconds(*, start: datetime, end: datetime) -> float:
    """Return ``(end - start).total_seconds()`` — pure helper for legibility."""
    return (end - start).total_seconds()


def is_valid_detector_name(name: str) -> bool:
    """Pinned by the protocol test — detector names are ``[a-z0-9_]+``."""
    return bool(_NAME_RE.fullmatch(name))


__all__ = [
    "HeuristicConfig",
    "HeuristicDetector",
    "ensure_utc_now",
    "is_valid_detector_name",
    "population_cv",
    "residence_seconds",
]
