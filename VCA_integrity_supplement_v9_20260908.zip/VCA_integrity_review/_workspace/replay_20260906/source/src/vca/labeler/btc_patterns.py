"""BTC patterns labelers — Peeling Chain + CoinJoin pool entry + Vault (P2-007.0).

Three BTC-only money-laundering pattern detectors for the Stage 8 L1-L4
critical path of the KelpDAO incident. Like the attribution module
(P2-009.0) the three classes are registered independently — operators
enable whichever subset matches the case under analysis.

Sub-detector 1: :class:`PeelingChainLabeler`
    Recognises a participant in a sequence of "peel" transactions — each
    TX has exactly two outputs, one large (>= ``large_output_ratio_min``
    of the input value, default 90%) acting as the change continuation
    and one small (<= ``max_peel_size_btc``, default 2.0 BTC) acting as
    the peel. ``min_chain_hops`` consecutive peel hops with monotonically
    decreasing input continuity are required to trigger the label.

    LabelKind: :attr:`LabelKind.UNKNOWN` (non-terminal) — the peeling
    chain is an ongoing journey; BFS must continue past the label.
    Semantic role carried in ``extras["attribution_role"]
    = "btc_peeling_chain_origin"``.

Sub-detector 2: :class:`CoinJoinPoolEntryLabeler`
    Recognises when an address acts as one of many participants entering
    a CoinJoin coordinator (Wasabi / JoinMarket / similar — the family the
    KelpDAO SSOT ``KelpDAO_rsETH_Exploit_update.pdf`` p49 attributes to the
    L4 mixing pool). The receiving TX must have ``inputs_min`` inputs AND
    ``outputs_min`` outputs AND the equal-denomination ratio
    (modal-output-count / total-outputs) must be
    >= ``uniform_denomination_ratio_min``.

    LabelKind: :attr:`LabelKind.COINJOIN` (terminal in TracePolicy
    default) — CoinJoin destroys output-side linkability, so BFS
    termination is the desired outcome.

    Coordinator inference (``_infer_coordinator``) is a DISTINCT, finer
    technical signal from the case-attribution family above: it fingerprints
    the modal output DENOMINATION — outputs around 0.1 BTC → "wasabi"; outputs
    around 0.5 BTC → "whirlpool" (those are the fixed pool sizes those two
    coordinators actually use); otherwise None. JoinMarket has no fixed
    denomination, so it is named only in the SSOT case-attribution family,
    not denomination-inferred. The KelpDAO L4 pool matches neither denom, so
    the inference returns None there and no coordinator name is surfaced.

Sub-detector 3: :class:`VaultLabeler`
    Recognises BTC vault addresses — large single-inflow (>=
    ``inflow_min_btc``, default 10 BTC) followed by N >=
    ``split_count_min`` outgoing splits within
    ``split_window_seconds`` (default 24h). When the inflow originates
    at one of the configured THORChain swap addresses, the
    ``thorchain_origin`` flag is set to True; otherwise False.

    LabelKind: :attr:`LabelKind.VAULT` (existing enum, non-terminal in
    default policy) — the trace continues through the splits.

R-NO-NEW-LABELKIND: 0 new enum values; only :attr:`LabelKind.UNKNOWN`,
:attr:`LabelKind.COINJOIN`, and :attr:`LabelKind.VAULT` are reused.

R-CHAIN-FILTER-BITCOIN: every detector silently ignores activities whose
``address.chain`` is not :attr:`ChainId.BITCOIN`. KelpDAO Stage 8 is the
sole BTC-side stage, so EVM activity must never accidentally trigger
these heuristics.

Source pin tag ``operator_pin_2026-05-12`` traces every emission back to
the supplement PDF integration commit (db16ad2).
"""

from __future__ import annotations

from collections import Counter
from collections.abc import Mapping
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Any, Final

from pydantic import BaseModel, ConfigDict, Field, field_validator

from vca.labeler._types import (
    AddressActivity,
    AddressLabel,
    Evidence,
    EvidenceKind,
    LabelKind,
    LabelSource,
)
from vca.labeler.heuristics import ensure_utc_now
from vca.types import Address, ChainId, NormalizedAddress

# ---------------------------------------------------------------------------
# Module-level constants
# ---------------------------------------------------------------------------

_FROZEN_CONFIG: Final[ConfigDict] = ConfigDict(frozen=True, strict=True, extra="forbid")

_OPERATOR_PIN_TAG: Final[str] = "operator_pin_2026-05-12"
_PIN_CONFIDENCE: Final[float] = 0.85

_PEEL_PROTOCOL_NAME: Final[str] = "BTC Peeling Chain (multi-hop change-split pattern)"
_PEEL_PDF_REFERENCE: Final[str] = "KelpDAO_rsETH_Exploit_update.pdf p44-48"
_PEEL_NAME: Final[str] = "btc_peeling_chain"
# Cycle 18 P2-LABELER-ATTRIBUTION-ROLE-SSOT.1 — pin the ``attribution_role``
# extras-key string via a module-level ``Final[str]``. The value is
# intentionally distinct from ``_PEEL_NAME`` (the ``name`` field feeds the
# priority resolver; the ``attribution_role`` feeds the reporter bucket).
_PEEL_ATTRIBUTION_ROLE: Final[str] = "btc_peeling_chain_origin"

# Case-attribution coordinator FAMILY per SSOT (update.pdf p49 "WasabiWallet,
# JoinMarket 계열 고정단위 CoinJoin 서비스"). This is the human-facing label; the
# separate ``_infer_coordinator`` denomination fingerprint (Wasabi ~0.1 BTC /
# Whirlpool ~0.5 BTC) is a finer technical signal, NOT the case attribution.
_COINJOIN_PROTOCOL_NAME: Final[str] = "BTC CoinJoin pool entry (Wasabi / JoinMarket / similar)"
_COINJOIN_PDF_REFERENCE: Final[str] = "KelpDAO_rsETH_Exploit_update.pdf p44-48"
_COINJOIN_NAME: Final[str] = "btc_coinjoin_pool_entry"
# Cycle 18 P2-LABELER-ATTRIBUTION-ROLE-SSOT.1 — pin the ``attribution_role``
# extras-key string via a module-level ``Final[str]``. This value happens
# to byte-equal ``_COINJOIN_NAME`` by coincidence (1 of 4 BTC rows; see
# Cycle 18 architect WBS §4.4 F-beta); the distinction is still
# semantically meaningful (different consumer surface).
_COINJOIN_ATTRIBUTION_ROLE: Final[str] = "btc_coinjoin_pool_entry"

_VAULT_PROTOCOL_NAME: Final[str] = "BTC Vault accumulator (THORChain swap output aggregator)"
_VAULT_PDF_REFERENCE: Final[str] = "KelpDAO_rsETH_Exploit_update.pdf p44-48"
_VAULT_NAME: Final[str] = "btc_vault"
_VAULT_CHAIN_LABEL: Final[str] = "bitcoin_mainnet"
# Cycle 56 P2-LABELER-CHAIN-LABEL-CHAIN-SSOT.1 — provenance breadcrumb constants
# for the peel-chain and CoinJoin labelers (both Bitcoin-mainnet by design,
# mirroring :data:`_VAULT_CHAIN_LABEL`). The reporter
# ``_attribution_evidence.md.j2`` template aggregates per-label ``extras``
# across all attribution roles; without these constants the peel and
# CoinJoin emissions silently rendered without a chain tag, leaving the
# reporter unable to disambiguate ETH vs BTC evidence in mixed-chain
# scenarios. Keeping the three BTC labels as separate constants (rather
# than sharing :data:`_VAULT_CHAIN_LABEL`) preserves SSOT clarity per the
# C18 attribution_role naming precedent — different consumer surfaces deserve
# distinct ``Final[str]`` symbols even when the value coincides.
_PEEL_CHAIN_LABEL: Final[str] = "bitcoin_mainnet"
_COINJOIN_CHAIN_LABEL: Final[str] = "bitcoin_mainnet"
# Cycle 18 P2-LABELER-ATTRIBUTION-ROLE-SSOT.1 — pin the ``attribution_role``
# extras-key string via a module-level ``Final[str]``. The value is
# intentionally distinct from ``_VAULT_NAME`` (suffix ``_address``).
_VAULT_ATTRIBUTION_ROLE: Final[str] = "btc_vault_address"

# Defaults — peeling chain
PEEL_LARGE_RATIO_DEFAULT: Final[float] = 0.90
PEEL_CHAIN_MIN_HOPS_DEFAULT: Final[int] = 3
PEEL_MAX_SMALL_BTC_DEFAULT: Final[Decimal] = Decimal("2.0")

# Defaults — CoinJoin
COINJOIN_INPUTS_MIN_DEFAULT: Final[int] = 7
COINJOIN_OUTPUTS_MIN_DEFAULT: Final[int] = 800
COINJOIN_UNIFORM_RATIO_DEFAULT: Final[float] = 0.95

# Defaults — Vault
VAULT_INFLOW_MIN_BTC_DEFAULT: Final[Decimal] = Decimal("10")
VAULT_SPLIT_COUNT_MIN_DEFAULT: Final[int] = 10
VAULT_SPLIT_WINDOW_SECONDS_DEFAULT: Final[int] = 24 * 3600

# Coordinator inference thresholds — typed in module scope so tests can
# import them deterministically without touching the labeler internals.
# Wasabi 1.0 pool denomination ~0.1 BTC; Whirlpool ~0.5 BTC.
_COORD_WASABI_DENOM: Final[Decimal] = Decimal("0.1")
_COORD_WHIRLPOOL_DENOM: Final[Decimal] = Decimal("0.5")
_COORD_TOLERANCE_PCT: Final[Decimal] = Decimal("0.05")  # +/- 5%

# Peel chain continuity tolerance — subsequent hop input must be within
# `_PEEL_CONTINUITY_TOLERANCE` of the previous hop's change to count as a
# continuation. 1% absorbs miner-fee rounding without admitting unrelated
# transactions.
_PEEL_CONTINUITY_TOLERANCE: Final[Decimal] = Decimal("0.01")

# ---------------------------------------------------------------------------
# Peeling Chain detector
# ---------------------------------------------------------------------------


class PeelHopObservation(BaseModel):
    """A single peel-hop observation supplied by the tracer.

    The labeler protocol forbids I/O, so peel-chain observations MUST be
    pre-built by the caller (the tracer or operator capture script) and
    handed to the labeler at construction time. Each observation records
    the input value, the change/peel split, and the immediate next
    addresses so the labeler can reconstruct the chain deterministically.
    """

    model_config = _FROZEN_CONFIG

    tx_hash: str
    input_value_btc: Decimal = Field(ge=Decimal("0"))
    change_value_btc: Decimal = Field(ge=Decimal("0"))
    peel_value_btc: Decimal = Field(ge=Decimal("0"))
    change_to_address: str
    peel_to_address: str
    observed_at: datetime


class PeelingChainLabelerConfig(BaseModel):
    """Frozen settings DTO for the peeling-chain detector."""

    model_config = _FROZEN_CONFIG

    large_output_ratio_min: float = Field(default=PEEL_LARGE_RATIO_DEFAULT, ge=0.0, le=1.0)
    min_chain_hops: int = Field(default=PEEL_CHAIN_MIN_HOPS_DEFAULT, ge=2)
    max_peel_size_btc: Decimal = Field(default=PEEL_MAX_SMALL_BTC_DEFAULT, ge=Decimal("0"))


class PeelingChainLabeler:
    """Recognises BTC peeling-chain participation. See module docstring."""

    name: str = _PEEL_NAME
    source: LabelSource = LabelSource.OWN_DB
    kind: LabelKind = LabelKind.UNKNOWN

    def __init__(
        self,
        config: PeelingChainLabelerConfig,
        *,
        peel_hops: Mapping[str, tuple[PeelHopObservation, ...]] | None = None,
    ) -> None:
        self._config = config
        self._peel_hops: Mapping[str, tuple[PeelHopObservation, ...]] = peel_hops or {}

    def detect(
        self,
        activity: AddressActivity,
        *,
        now: datetime,
    ) -> tuple[AddressLabel, ...]:
        anchor = ensure_utc_now(now, detector=self.name)

        if activity.address.chain is not ChainId.BITCOIN:
            return ()

        address_key = activity.address.value
        hops = self._peel_hops.get(address_key)
        if not hops:
            return ()

        chain_length, total_peeled, avg_peel = _evaluate_peel_chain(
            hops=hops,
            large_ratio_min=Decimal(str(self._config.large_output_ratio_min)),
            max_peel_btc=self._config.max_peel_size_btc,
            continuity_tolerance=_PEEL_CONTINUITY_TOLERANCE,
        )

        if chain_length < self._config.min_chain_hops:
            return ()

        next_link = hops[0].change_to_address

        evidence = (
            Evidence(
                kind=EvidenceKind.FAN_OUT_COUNT,
                count=chain_length,
                observed_at=anchor,
            ),
        )
        label = AddressLabel(
            address=NormalizedAddress(address=activity.address),
            kind=self.kind,
            source=self.source,
            confidence=_PIN_CONFIDENCE,
            observed_at=anchor,
            evidence=evidence,
            extras={
                "protocol": _PEEL_PROTOCOL_NAME,
                "source_pin": _OPERATOR_PIN_TAG,
                "pdf_reference": _PEEL_PDF_REFERENCE,
                "chain": _PEEL_CHAIN_LABEL,
                "attribution_role": _PEEL_ATTRIBUTION_ROLE,
                "chain_length": chain_length,
                "next_link": next_link,
                "avg_peel_size_btc": str(avg_peel),
                "small_output_total_btc": str(total_peeled),
                "current_address": address_key,
            },
        )
        return (label,)


def _evaluate_peel_chain(
    *,
    hops: tuple[PeelHopObservation, ...],
    large_ratio_min: Decimal,
    max_peel_btc: Decimal,
    continuity_tolerance: Decimal,
) -> tuple[int, Decimal, Decimal]:
    """Count consecutive peel hops + return (length, total_peeled, avg_peel).

    A hop counts as a peel when:
        * input_value_btc > 0 (defensive — avoid 0/0 division)
        * change_value_btc / input_value_btc >= large_ratio_min
        * peel_value_btc <= max_peel_btc
        * for hops beyond the first: input_value_btc is within
          ``continuity_tolerance`` of the previous hop's change_value_btc
          (i.e., the chain is continuous).

    Returns ``(length, total_peeled, avg_peel)`` where ``length`` is the
    number of consecutive valid peel hops starting at index 0. ``length``
    is 0 when even the first hop fails the gate. ``avg_peel`` is 0 when
    ``length`` is 0.
    """
    chain_length = 0
    total_peeled = Decimal("0")
    previous_change: Decimal | None = None
    for hop in hops:
        if hop.input_value_btc <= 0:
            break
        ratio = hop.change_value_btc / hop.input_value_btc
        if ratio < large_ratio_min:
            break
        if hop.peel_value_btc > max_peel_btc:
            break
        # Codex P2-007.0 round-4 P2 fix: require a strictly positive peel
        # AND change strictly less than input. A no-op hop (input ==
        # change, peel == 0) passes ratio/max checks but represents zero
        # BTC being peeled — admitting it as a chain link would emit a
        # peeling-chain label for activity where nothing was peeled.
        if hop.peel_value_btc <= 0:
            break
        if hop.change_value_btc >= hop.input_value_btc:
            break
        if previous_change is not None:
            diff = abs(hop.input_value_btc - previous_change)
            if previous_change == 0 or diff / previous_change > continuity_tolerance:
                break
        chain_length += 1
        total_peeled += hop.peel_value_btc
        previous_change = hop.change_value_btc

    avg_peel = total_peeled / Decimal(chain_length) if chain_length > 0 else Decimal("0")
    return chain_length, total_peeled, avg_peel


def build_default_peeling_labeler(
    *,
    peel_hops: Mapping[str, tuple[PeelHopObservation, ...]] | None = None,
    large_output_ratio_min: float = PEEL_LARGE_RATIO_DEFAULT,
    min_chain_hops: int = PEEL_CHAIN_MIN_HOPS_DEFAULT,
    max_peel_size_btc: Decimal = PEEL_MAX_SMALL_BTC_DEFAULT,
) -> PeelingChainLabeler:
    """Build a :class:`PeelingChainLabeler` with the documented defaults."""
    config = PeelingChainLabelerConfig(
        large_output_ratio_min=large_output_ratio_min,
        min_chain_hops=min_chain_hops,
        max_peel_size_btc=max_peel_size_btc,
    )
    return PeelingChainLabeler(config, peel_hops=peel_hops)


# ---------------------------------------------------------------------------
# CoinJoin pool entry recognizer
# ---------------------------------------------------------------------------


class CoinJoinPoolEntryLabelerConfig(BaseModel):
    """Frozen settings DTO for the CoinJoin pool entry detector."""

    model_config = _FROZEN_CONFIG

    inputs_min: int = Field(default=COINJOIN_INPUTS_MIN_DEFAULT, ge=2)
    outputs_min: int = Field(default=COINJOIN_OUTPUTS_MIN_DEFAULT, ge=2)
    uniform_denomination_ratio_min: float = Field(
        default=COINJOIN_UNIFORM_RATIO_DEFAULT, ge=0.0, le=1.0
    )


class CoinJoinPoolEntryLabeler:
    """Recognises BTC CoinJoin pool entry. See module docstring."""

    name: str = _COINJOIN_NAME
    source: LabelSource = LabelSource.OWN_DB
    kind: LabelKind = LabelKind.COINJOIN

    def __init__(
        self,
        config: CoinJoinPoolEntryLabelerConfig,
        *,
        receiving_tx_manifest: Mapping[str, Mapping[str, Any]] | None = None,
    ) -> None:
        self._config = config
        self._manifest: Mapping[str, Mapping[str, Any]] = receiving_tx_manifest or {}

    def detect(
        self,
        activity: AddressActivity,
        *,
        now: datetime,
    ) -> tuple[AddressLabel, ...]:
        anchor = ensure_utc_now(now, detector=self.name)

        if activity.address.chain is not ChainId.BITCOIN:
            return ()

        manifest_entry = self._manifest.get(activity.address.value)
        if manifest_entry is None:
            return ()

        input_count = int(manifest_entry.get("input_count", 0))
        output_count = int(manifest_entry.get("output_count", 0))
        output_values: tuple[Decimal, ...] = tuple(
            Decimal(str(v)) for v in manifest_entry.get("output_values_btc", ())
        )
        tx_hash = str(manifest_entry.get("tx_hash", ""))

        if input_count < self._config.inputs_min:
            return ()
        if output_count < self._config.outputs_min:
            return ()
        if not output_values:
            return ()
        # Codex P2-007.0 round-1 P2 fix: the equal-denomination ratio is
        # `modal_count / TOTAL_outputs`. If the manifest provides only a
        # subset of `output_values_btc` (e.g. operator captured 50 out of
        # 800 outputs), dividing the modal count by ``len(output_values)``
        # treats the subset as if it were the whole — a small uniform
        # subset would falsely classify the TX as a CoinJoin entry. We
        # reject any mismatch between declared count and provided values
        # outright; operators MUST supply the full output array.
        if len(output_values) != output_count:
            return ()

        common_value, uniform_ratio = _modal_output_signature(output_values)
        if uniform_ratio < Decimal(str(self._config.uniform_denomination_ratio_min)):
            return ()

        coordinator = _infer_coordinator(common_value)

        evidence = (
            Evidence(
                kind=EvidenceKind.FAN_IN_COUNT,
                count=input_count,
                observed_at=anchor,
            ),
            Evidence(
                kind=EvidenceKind.FAN_OUT_COUNT,
                count=output_count,
                observed_at=anchor,
            ),
        )
        label = AddressLabel(
            address=NormalizedAddress(address=activity.address),
            kind=self.kind,
            source=self.source,
            confidence=_PIN_CONFIDENCE,
            observed_at=anchor,
            evidence=evidence,
            extras={
                "protocol": _COINJOIN_PROTOCOL_NAME,
                "source_pin": _OPERATOR_PIN_TAG,
                "pdf_reference": _COINJOIN_PDF_REFERENCE,
                "chain": _COINJOIN_CHAIN_LABEL,
                "attribution_role": _COINJOIN_ATTRIBUTION_ROLE,
                "input_count": input_count,
                "output_count": output_count,
                "equal_denomination_ratio": str(uniform_ratio),
                "common_output_value_btc": str(common_value),
                "coordinator_inferred": coordinator,
                "tx_hash": tx_hash,
            },
        )
        return (label,)


def _modal_output_signature(values: tuple[Decimal, ...]) -> tuple[Decimal, Decimal]:
    """Return (modal_value, modal_count / total_count) for the equal-denom check.

    The CoinJoin heuristic measures how concentrated the output distribution
    is at a single denomination. Returns the most frequent output value
    along with its share of the total. Caller MUST ensure ``values`` is
    non-empty.
    """
    counter: Counter[Decimal] = Counter(values)
    common_value, modal_count = counter.most_common(1)[0]
    ratio = Decimal(modal_count) / Decimal(len(values))
    return common_value, ratio


def _infer_coordinator(common_value: Decimal) -> str | None:
    """Infer the CoinJoin coordinator (Wasabi / Whirlpool / None) from output denom."""
    if _within_tolerance(common_value, _COORD_WASABI_DENOM, _COORD_TOLERANCE_PCT):
        return "wasabi"
    if _within_tolerance(common_value, _COORD_WHIRLPOOL_DENOM, _COORD_TOLERANCE_PCT):
        return "whirlpool"
    return None


def _within_tolerance(observed: Decimal, target: Decimal, tolerance_pct: Decimal) -> bool:
    """``|observed - target| / target <= tolerance_pct`` with target > 0."""
    if target == 0:
        return observed == 0
    diff = abs(observed - target)
    return diff / target <= tolerance_pct


def build_default_coinjoin_labeler(
    *,
    receiving_tx_manifest: Mapping[str, Mapping[str, Any]] | None = None,
    inputs_min: int = COINJOIN_INPUTS_MIN_DEFAULT,
    outputs_min: int = COINJOIN_OUTPUTS_MIN_DEFAULT,
    uniform_denomination_ratio_min: float = COINJOIN_UNIFORM_RATIO_DEFAULT,
) -> CoinJoinPoolEntryLabeler:
    """Build a :class:`CoinJoinPoolEntryLabeler` with the documented defaults."""
    config = CoinJoinPoolEntryLabelerConfig(
        inputs_min=inputs_min,
        outputs_min=outputs_min,
        uniform_denomination_ratio_min=uniform_denomination_ratio_min,
    )
    return CoinJoinPoolEntryLabeler(config, receiving_tx_manifest=receiving_tx_manifest)


# ---------------------------------------------------------------------------
# Vault detector
# ---------------------------------------------------------------------------


def _normalize_btc_addr_str(raw: str) -> str:
    """Run a BTC address through :class:`Address` so encoding is canonical."""
    return Address.from_str(raw, ChainId.BITCOIN).value


class VaultLabelerConfig(BaseModel):
    """Frozen settings DTO for the BTC vault detector."""

    model_config = _FROZEN_CONFIG

    inflow_min_btc: Decimal = Field(default=VAULT_INFLOW_MIN_BTC_DEFAULT, ge=Decimal("0"))
    split_count_min: int = Field(default=VAULT_SPLIT_COUNT_MIN_DEFAULT, ge=1)
    split_window_seconds: int = Field(default=VAULT_SPLIT_WINDOW_SECONDS_DEFAULT, ge=0)
    thorchain_swap_addresses: frozenset[str] = Field(default_factory=frozenset)

    @field_validator("thorchain_swap_addresses", mode="before")
    @classmethod
    def _normalize_addresses(cls, value: Any) -> Any:
        if isinstance(value, frozenset | set | tuple | list):
            return frozenset(_normalize_btc_addr_str(raw) for raw in value)
        return value


class VaultLabeler:
    """Recognises BTC vault addresses. See module docstring."""

    name: str = _VAULT_NAME
    source: LabelSource = LabelSource.OWN_DB
    kind: LabelKind = LabelKind.VAULT

    def __init__(self, config: VaultLabelerConfig) -> None:
        self._config = config

    def detect(
        self,
        activity: AddressActivity,
        *,
        now: datetime,
    ) -> tuple[AddressLabel, ...]:
        anchor = ensure_utc_now(now, detector=self.name)

        if activity.address.chain is not ChainId.BITCOIN:
            return ()
        if not activity.incoming:
            return ()
        if not activity.outgoing:
            return ()

        # Codex P2-007.0 round-2 P2 fix: scan EVERY above-threshold
        # incoming transfer (descending value, then earliest timestamp)
        # and label on the first inflow whose post-inflow split window
        # contains >= split_count_min outgoing transfers. Anchoring only
        # on the global-maximum inflow could miss a valid vault when an
        # earlier qualifying inflow has the splits and a later larger
        # inflow does not.
        window_delta = timedelta(seconds=self._config.split_window_seconds)
        outgoing_offset = len(activity.incoming)

        qualifying = _select_qualifying_inflows(
            activity,
            inflow_min_btc=self._config.inflow_min_btc,
        )
        if not qualifying:
            return ()

        chosen: tuple[int, Decimal, datetime, int] | None = None
        for inflow_idx, inflow_amount, inflow_ts in qualifying:
            split_count = _count_splits_in_window(
                activity=activity,
                outgoing_offset=outgoing_offset,
                inflow_ts=inflow_ts,
                window_delta=window_delta,
            )
            if split_count >= self._config.split_count_min:
                chosen = (inflow_idx, inflow_amount, inflow_ts, split_count)
                break

        if chosen is None:
            return ()

        inflow_idx, inflow_amount, inflow_ts, split_count = chosen

        # Origin classification — was the inflow from a configured THORChain
        # swap output address?
        inflow_transfer = activity.incoming[inflow_idx]
        inflow_from = (
            inflow_transfer.from_addr.value if inflow_transfer.from_addr is not None else None
        )
        thorchain_origin = (
            inflow_from is not None and inflow_from in self._config.thorchain_swap_addresses
        )

        evidence = (
            Evidence(
                kind=EvidenceKind.SINGLE_INCOMING_TX,
                count=1,
                value_minor=inflow_transfer.amount.raw,
                decimals=inflow_transfer.amount.decimals,
                observed_at=inflow_ts,
            ),
            Evidence(
                kind=EvidenceKind.FAN_OUT_COUNT,
                count=split_count,
                window_seconds=self._config.split_window_seconds,
                observed_at=anchor,
            ),
        )
        # Codex P2-007.0 round-2 P3 fix: the previous code stored
        # `inflow_from` (a BTC address) under the misleading key
        # ``inflow_tx``. The labeler protocol doesn't surface a tx hash
        # for the inflow (only for evidence Evidence.tx_hash, which is
        # parent-chain validated). Rename to ``inflow_from_address`` so
        # downstream consumers don't mistake the source address for a
        # tx identifier.
        label = AddressLabel(
            address=NormalizedAddress(address=activity.address),
            kind=self.kind,
            source=self.source,
            confidence=_PIN_CONFIDENCE,
            observed_at=anchor,
            evidence=evidence,
            extras={
                "protocol": _VAULT_PROTOCOL_NAME,
                "source_pin": _OPERATOR_PIN_TAG,
                "pdf_reference": _VAULT_PDF_REFERENCE,
                "chain": _VAULT_CHAIN_LABEL,
                "attribution_role": _VAULT_ATTRIBUTION_ROLE,
                "inflow_btc": str(inflow_amount),
                "split_count": split_count,
                "split_window_hours": self._config.split_window_seconds // 3600,
                "thorchain_origin": thorchain_origin,
                "inflow_from_address": inflow_from if inflow_from is not None else "",
            },
        )
        return (label,)


def _select_qualifying_inflows(
    activity: AddressActivity,
    *,
    inflow_min_btc: Decimal,
) -> list[tuple[int, Decimal, datetime]]:
    """Return (idx, btc_value, timestamp) for every inflow >= threshold.

    Sorted by descending value, ascending timestamp on ties — the
    largest qualifying inflow is preferred (matches the original "single
    large inflow" semantics) but the second-largest is consulted when
    the largest's window has < split_count_min outflows.
    """
    qualifying: list[tuple[int, Decimal, datetime]] = []
    for i, transfer in enumerate(activity.incoming):
        value = _amount_to_decimal(transfer.amount.raw, transfer.amount.decimals)
        if value < inflow_min_btc:
            continue
        qualifying.append((i, value, activity.transfer_timestamps[i]))
    qualifying.sort(key=lambda triple: (-triple[1], triple[2]))
    return qualifying


def _count_splits_in_window(
    *,
    activity: AddressActivity,
    outgoing_offset: int,
    inflow_ts: datetime,
    window_delta: timedelta,
) -> int:
    """Count outgoing transfers that fall in (inflow_ts, inflow_ts + window].

    Codex P2-007.0 round-3 P2 fix: the window is OPEN on the left, so an
    outgoing transfer that shares the inflow's timestamp does NOT count.
    BTC activity is often built from block timestamps; unrelated outflows
    in the same block as the candidate inflow would otherwise be admitted
    as post-inflow splits even though they may have been spent before the
    inflow or be wholly unrelated. Without per-tx index ordering the safe
    interpretation is to require strictly later timestamps.
    """
    split_count = 0
    for i, _transfer in enumerate(activity.outgoing):
        outgoing_ts = activity.transfer_timestamps[outgoing_offset + i]
        if outgoing_ts <= inflow_ts:
            continue
        if outgoing_ts - inflow_ts > window_delta:
            continue
        split_count += 1
    return split_count


def _amount_to_decimal(raw: int, decimals: int) -> Decimal:
    """Convert minor-unit raw + decimals to a Decimal whole-unit value."""
    if decimals == 0:
        return Decimal(raw)
    scale = Decimal(10) ** decimals
    return Decimal(raw) / scale


def build_default_vault_labeler(
    *,
    inflow_min_btc: Decimal = VAULT_INFLOW_MIN_BTC_DEFAULT,
    split_count_min: int = VAULT_SPLIT_COUNT_MIN_DEFAULT,
    split_window_seconds: int = VAULT_SPLIT_WINDOW_SECONDS_DEFAULT,
    thorchain_swap_addresses: frozenset[str] | None = None,
) -> VaultLabeler:
    """Build a :class:`VaultLabeler` with the documented defaults."""
    config = VaultLabelerConfig(
        inflow_min_btc=inflow_min_btc,
        split_count_min=split_count_min,
        split_window_seconds=split_window_seconds,
        thorchain_swap_addresses=thorchain_swap_addresses or frozenset(),
    )
    return VaultLabeler(config)


__all__ = [
    "COINJOIN_INPUTS_MIN_DEFAULT",
    "COINJOIN_OUTPUTS_MIN_DEFAULT",
    "COINJOIN_UNIFORM_RATIO_DEFAULT",
    "PEEL_CHAIN_MIN_HOPS_DEFAULT",
    "PEEL_LARGE_RATIO_DEFAULT",
    "PEEL_MAX_SMALL_BTC_DEFAULT",
    "VAULT_INFLOW_MIN_BTC_DEFAULT",
    "VAULT_SPLIT_COUNT_MIN_DEFAULT",
    "VAULT_SPLIT_WINDOW_SECONDS_DEFAULT",
    "CoinJoinPoolEntryLabeler",
    "CoinJoinPoolEntryLabelerConfig",
    "PeelHopObservation",
    "PeelingChainLabeler",
    "PeelingChainLabelerConfig",
    "VaultLabeler",
    "VaultLabelerConfig",
    "build_default_coinjoin_labeler",
    "build_default_peeling_labeler",
    "build_default_vault_labeler",
]
