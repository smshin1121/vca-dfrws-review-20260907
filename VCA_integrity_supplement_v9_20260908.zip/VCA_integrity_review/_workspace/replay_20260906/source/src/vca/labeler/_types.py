"""Frozen DTOs and closed-vocabulary enums for the P1-013 labeler.

Holds the analyzer-input/output surface every detector and the priority
resolver share:

* :class:`LabelKind` / :class:`LabelSource` / :class:`EvidenceKind` —
  closed StrEnum vocabularies; adding a member is a public-API change.
* :class:`Evidence` — frozen audit record carrying the justification for
  one label decision.
* :class:`AddressActivity` — pre-built activity snapshot the tracer
  (P1-014) supplies; **the SOLE input to every detector** (R-PURE-ANALYZER).
* :class:`AddressLabel` — frozen label decision DTO emitted by detectors
  and external sources alike.

The module re-uses the recursive-freeze pipeline from
:mod:`vca.types._extras_freeze` (lifted in P1-012 R-FREEZE-LIFT) — the
labeler is the 4th and 5th caller (``Evidence.extras`` /
``AddressLabel.extras``); per R-NO-LIFT we just import the existing
helpers.

Per R-NO-PRIVATE-IMPORT the small ``_ensure_utc`` and
``_validate_chain_tx_hash`` helpers from :mod:`vca.types.normalized` are
re-declared here as private functions; we intentionally do NOT import
underscore-prefixed names across the package boundary.
"""

from __future__ import annotations

import re
import uuid
from collections.abc import Mapping
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any, Final, Self

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StrictInt,
    field_serializer,
    model_validator,
)

from vca.types import (
    Address,
    ChainId,
    NormalizedAddress,
    NormalizedTransfer,
)
from vca.types._extras_freeze import (
    freeze_extras_value,
    thaw_extras_value,
)

# ---------------------------------------------------------------------------
# Module-level config / regexes
# ---------------------------------------------------------------------------

# Frozen, strict, extras-forbidding model config — mirrors P1-001's contract.
_FROZEN_CONFIG: Final[ConfigDict] = ConfigDict(frozen=True, strict=True, extra="forbid")

# Tx-hash regexes — re-declared per R-NO-PRIVATE-IMPORT. These mirror the
# definitions in :mod:`vca.types.normalized` byte-for-byte.
_EVM_TX_HASH_RE: Final[re.Pattern[str]] = re.compile(r"0x[0-9a-fA-F]{64}")
_BTC_TX_HASH_RE: Final[re.Pattern[str]] = re.compile(r"[0-9a-fA-F]{64}")

# Extras label constants — embedded into the freeze-pipeline error messages.
_EVIDENCE_EXTRAS_LABEL: Final[str] = "Evidence.extras"
_ADDRESS_LABEL_EXTRAS_LABEL: Final[str] = "AddressLabel.extras"


# ---------------------------------------------------------------------------
# Re-declared validators (R-NO-PRIVATE-IMPORT)
# ---------------------------------------------------------------------------


def _ensure_utc(value: datetime) -> datetime:
    """Re-declared mirror of :func:`vca.types.normalized._ensure_utc`.

    Per R-NO-PRIVATE-IMPORT we duplicate by declaration rather than import
    underscore-prefixed names from another package. Behavioural equivalence
    is pinned by ``test_labeler_validates_tx_hash_same_as_normalized`` in
    the unit suite.
    """
    if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
        raise ValueError("datetime must be timezone-aware (UTC)")
    return value.astimezone(UTC)


def _validate_chain_tx_hash(chain: ChainId, value: str, *, field: str = "tx_hash") -> str:
    """Re-declared mirror of :func:`vca.types.normalized._validate_chain_tx_hash`.

    EVM (Ethereum / Arbitrum): ``0x`` + 64 hex.
    BTC: 64 hex (no ``0x`` prefix).
    Returns the lowercase canonical form. Per R-NO-PRIVATE-IMPORT we keep
    this as a private declaration in the labeler module.
    """
    if not isinstance(value, str):
        raise ValueError(  # noqa: TRY004 - value-domain validator path
            f"{field} must be str, got {type(value).__name__}"
        )
    if chain.is_evm:
        if not _EVM_TX_HASH_RE.fullmatch(value):
            raise ValueError(
                f"{field} must be 0x + 64 lowercase hex for chain={chain.value}, got: {value}"
            )
        return value.lower()
    if not _BTC_TX_HASH_RE.fullmatch(value):
        raise ValueError(
            f"{field} must be 64 lowercase hex (BTC, no 0x prefix) "
            f"for chain={chain.value}, got: {value}"
        )
    return value.lower()


def _validate_uuid4(value: str, *, field: str) -> str:
    """Mirror of :class:`NormalizedAddress` cluster_id validator (canonical UUID4)."""
    try:
        parsed = uuid.UUID(value)
    except (ValueError, AttributeError, TypeError) as exc:
        raise ValueError(f"{field} must be UUID4 string, got {value!r}") from exc
    if parsed.version != 4:
        raise ValueError(
            f"{field} must be UUID4 (version=4), got version={parsed.version} for {value!r}"
        )
    return str(parsed)


# ---------------------------------------------------------------------------
# Closed-vocabulary enums (DoD-4/5/6)
# ---------------------------------------------------------------------------


class LabelKind(StrEnum):
    """Closed vocabulary for :attr:`AddressLabel.kind`.

    Persisted by P1-016 and matched by the P1-015 Stage classifier
    termination set per ARCH §3.3 (``{CEX, MIXER, COINJOIN, GOV_FROZEN}``).
    The ``EXCHANGE_HOT``/``EXCHANGE_COLD`` split is loaded for the future
    Etherscan-label tier; both render as a "CEX" macro-class via
    :attr:`LabelKind.is_cex`.
    """

    EXCHANGE_HOT = "exchange_hot"
    EXCHANGE_COLD = "exchange_cold"
    BRIDGE = "bridge"
    MIXER = "mixer"
    SINGLE_USE = "single_use"
    VAULT = "vault"
    BATCH_PAYOUT = "batch_payout"
    COINJOIN = "coinjoin"
    CLUSTER = "cluster"
    GOV_FROZEN = "gov_frozen"
    UNKNOWN = "unknown"

    @property
    def is_cex(self) -> bool:
        """True for ``EXCHANGE_HOT`` / ``EXCHANGE_COLD`` macro-class."""
        return self in (LabelKind.EXCHANGE_HOT, LabelKind.EXCHANGE_COLD)


class LabelSource(StrEnum):
    """Closed vocabulary for :attr:`AddressLabel.source`.

    Drives the priority resolver: ``OWN_DB > ETHERSCAN ≈ ARBISCAN >
    HEURISTIC_*``. ``HEURISTIC_COINJOIN`` is the rejection-marker the BTC
    common-input detector emits when CoinJoin pruning fires.
    """

    OWN_DB = "own_db"
    ETHERSCAN = "etherscan"
    ARBISCAN = "arbiscan"
    HEURISTIC_SINGLE_USE = "heuristic_single_use"
    HEURISTIC_VAULT = "heuristic_vault"
    HEURISTIC_BATCH_PAYOUT = "heuristic_batch_payout"
    HEURISTIC_COMMON_INPUT = "heuristic_common_input"
    HEURISTIC_COINJOIN = "heuristic_coinjoin"


class EvidenceKind(StrEnum):
    """Closed vocabulary for :attr:`Evidence.kind`."""

    SINGLE_INCOMING_TX = "single_incoming_tx"
    IMMEDIATE_OUTGOING_TX = "immediate_outgoing_tx"
    BALANCE_ZERO = "balance_zero"
    FAN_IN_COUNT = "fan_in_count"
    FAN_OUT_COUNT = "fan_out_count"
    RESIDENCE_TIME = "residence_time"
    OUTPUT_UNIT_CLUSTER = "output_unit_cluster"
    OUTPUT_UNIT_FREQUENCY = "output_unit_frequency"
    BTC_INPUT_COSPEND = "btc_input_cospend"
    BTC_COINJOIN_PRUNED = "btc_coinjoin_pruned"


# ---------------------------------------------------------------------------
# Evidence DTO (DoD-7)
# ---------------------------------------------------------------------------


class Evidence(BaseModel):
    """Justification record for one label decision. Audit-log ready (P1-016).

    Cross-field rules:
        * ``value_minor is not None`` ⇒ ``decimals is not None``.
        * ``observed_at`` must be tz-aware UTC.
        * ``extras`` is recursively frozen via the shared P1-012 helper.

    Chain-aware ``tx_hash`` validation runs at the parent
    :class:`AddressLabel` level (the parent supplies the chain context);
    :class:`Evidence` is parent-agnostic and only enforces the type.
    """

    model_config = _FROZEN_CONFIG

    kind: EvidenceKind
    tx_hash: str | None = None
    count: StrictInt | None = Field(default=None, ge=0)
    value_minor: StrictInt | None = Field(default=None, ge=0)
    decimals: StrictInt | None = Field(default=None, ge=0, le=36)
    window_seconds: StrictInt | None = Field(default=None, ge=0)
    observed_at: datetime
    extras: Mapping[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_observed_at(self) -> Self:
        """Reject naive datetimes — every observed_at must be tz-aware UTC."""
        normalised = _ensure_utc(self.observed_at)
        if normalised is not self.observed_at:
            object.__setattr__(self, "observed_at", normalised)
        return self

    @model_validator(mode="after")
    def _value_decimals_paired(self) -> Self:
        """When ``value_minor`` is set, ``decimals`` must also be set (Amount parity)."""
        if self.value_minor is not None and self.decimals is None:
            raise ValueError("Evidence.value_minor requires decimals to be set")
        return self

    @model_validator(mode="after")
    def _freeze_extras(self) -> Self:
        """Recursive-freeze pipeline — re-uses :mod:`vca.types._extras_freeze`."""
        frozen = freeze_extras_value(dict(self.extras), label=_EVIDENCE_EXTRAS_LABEL)
        object.__setattr__(self, "extras", frozen)
        return self

    @field_serializer("extras")
    def _serialize_extras(self, value: Mapping[str, Any]) -> dict[str, Any]:
        thawed = thaw_extras_value(value)
        if not isinstance(thawed, dict):  # pragma: no cover - structural guarantee
            raise TypeError("Evidence.extras must serialise to a dict at the top level")
        return thawed


# ---------------------------------------------------------------------------
# AddressActivity DTO (DoD-8)
# ---------------------------------------------------------------------------


class AddressActivity(BaseModel):
    """Pre-built activity snapshot for ONE address. Tracer (P1-014) supplies it.

    The SOLE input shape every detector consumes (R-PURE-ANALYZER /
    DoD-25). Detectors NEVER fetch transfers, balances, or cospend groups
    themselves — the tracer pre-populates this DTO and the labeler runs
    pure analysis on it.

    Parallel-array layout:
        ``transfer_timestamps[i]`` aligns to ``incoming[i]`` for
        ``i < len(incoming)``, and to
        ``outgoing[i - len(incoming)]`` for the remaining indices.
    """

    model_config = _FROZEN_CONFIG

    address: Address
    incoming: tuple[NormalizedTransfer, ...] = ()
    outgoing: tuple[NormalizedTransfer, ...] = ()
    balance_minor: StrictInt | None = Field(default=None, ge=0)
    balance_decimals: StrictInt | None = Field(default=None, ge=0, le=36)
    window_start: datetime | None = None
    window_end: datetime | None = None
    transfer_timestamps: tuple[datetime, ...] = ()

    @model_validator(mode="after")
    def _validate_chain_coherence(self) -> Self:
        """Every non-null endpoint in ``incoming``/``outgoing`` must live on
        ``address.chain``; mint/burn (null endpoints) are allowed (mirrors
        :class:`NormalizedTransfer` precedent).
        """
        chain = self.address.chain
        for label, transfers in (("incoming", self.incoming), ("outgoing", self.outgoing)):
            for idx, transfer in enumerate(transfers):
                if transfer.asset.chain is not chain:
                    raise ValueError(
                        f"AddressActivity.{label}[{idx}].asset.chain mismatch: "
                        f"address.chain={chain.value}, "
                        f"asset.chain={transfer.asset.chain.value}"
                    )
        return self

    @model_validator(mode="after")
    def _validate_transfer_directions(self) -> Self:
        """Every ``incoming`` transfer must land on ``self.address``; every
        ``outgoing`` transfer must originate at ``self.address``. Detectors
        trust the ``incoming``/``outgoing`` partition to label ``self.address``,
        so a transfer that doesn't touch ``self.address`` lets a caller
        accidentally apply heuristics keyed on ANOTHER address's activity.

        The partition-defining endpoint MUST equal ``self.address``:

        * ``incoming``: ``to_addr`` defines the partition (where the transfer
          lands). ``to_addr is None`` represents a burn — a burn is never
          "incoming to A", so it must be rejected. ``from_addr`` MAY be None
          (mint-like incoming, where the source is null but the transfer
          legitimately lands on ``self.address``).
        * ``outgoing``: ``from_addr`` defines the partition (where the
          transfer originates). ``from_addr is None`` represents a mint — a
          mint is never "outgoing from A", so it must be rejected. ``to_addr``
          MAY be None (burn-like outgoing, where the destination is null but
          the transfer legitimately originates at ``self.address``).
        """
        for idx, transfer in enumerate(self.incoming):
            if transfer.to_addr is None or transfer.to_addr.value != self.address.value:
                # to_addr is None (burn — never incoming to A) OR points to a
                # different address — both invalidate the incoming partition.
                raise ValueError(
                    f"AddressActivity.incoming[{idx}].to_addr does not match "
                    f"self.address: incoming.to_addr={transfer.to_addr!r}, "
                    f"self.address={self.address.value!r}"
                )
        for idx, transfer in enumerate(self.outgoing):
            if transfer.from_addr is None or transfer.from_addr.value != self.address.value:
                # from_addr is None (mint — never outgoing from A) OR points
                # from a different address — both invalidate the outgoing
                # partition.
                raise ValueError(
                    f"AddressActivity.outgoing[{idx}].from_addr does not match "
                    f"self.address: outgoing.from_addr={transfer.from_addr!r}, "
                    f"self.address={self.address.value!r}"
                )
        return self

    @model_validator(mode="after")
    def _validate_parallel_array_length(self) -> Self:
        """``len(transfer_timestamps) == len(incoming) + len(outgoing)``."""
        expected = len(self.incoming) + len(self.outgoing)
        actual = len(self.transfer_timestamps)
        if actual != expected:
            raise ValueError(
                f"AddressActivity.transfer_timestamps length mismatch: "
                f"got {actual}, expected len(incoming)+len(outgoing)={expected}"
            )
        return self

    @model_validator(mode="after")
    def _validate_timestamp_tzs(self) -> Self:
        """Every timestamp (window + parallel array) must be tz-aware UTC."""
        normalised: list[datetime] = []
        changed = False
        for ts in self.transfer_timestamps:
            new_ts = _ensure_utc(ts)
            if new_ts is not ts:
                changed = True
            normalised.append(new_ts)
        if changed:
            object.__setattr__(self, "transfer_timestamps", tuple(normalised))
        if self.window_start is not None:
            ws = _ensure_utc(self.window_start)
            if ws is not self.window_start:
                object.__setattr__(self, "window_start", ws)
        if self.window_end is not None:
            we = _ensure_utc(self.window_end)
            if we is not self.window_end:
                object.__setattr__(self, "window_end", we)
        return self

    @model_validator(mode="after")
    def _validate_window_order(self) -> Self:
        """When both window endpoints are set: ``window_start <= window_end``."""
        if (
            self.window_start is not None
            and self.window_end is not None
            and self.window_start > self.window_end
        ):
            raise ValueError(
                f"AddressActivity.window_start > window_end: "
                f"start={self.window_start.isoformat()}, end={self.window_end.isoformat()}"
            )
        return self

    @model_validator(mode="after")
    def _validate_balance_pair(self) -> Self:
        """``balance_minor`` set ⇒ ``balance_decimals`` set; native-only semantics."""
        if self.balance_minor is not None and self.balance_decimals is None:
            raise ValueError("AddressActivity.balance_minor requires balance_decimals to be set")
        if (
            self.balance_decimals is not None
            and self.balance_decimals != self.address.chain.native_decimals
        ):
            raise ValueError(
                f"AddressActivity.balance_decimals must equal "
                f"address.chain.native_decimals="
                f"{self.address.chain.native_decimals} for native-balance "
                f"semantics, got {self.balance_decimals}"
            )
        return self


# ---------------------------------------------------------------------------
# AddressLabel DTO (DoD-9)
# ---------------------------------------------------------------------------


class AddressLabel(BaseModel):
    """Heuristic / external-source label decision for ONE address.

    Cross-field rules:
        * ``cluster_id`` ↔ ``kind == CLUSTER`` (bijection — DoD-9d).
        * ``source.startswith("heuristic_")`` ⇒ ``len(evidence) > 0``
          (DoD-9b).
        * Every Evidence with a non-null ``tx_hash`` matches the parent
          chain's regex (DoD-9c, R-NO-PRIVATE-IMPORT helper inlined).
        * ``cluster_id`` (when set) is canonical lowercase UUID4.
        * ``observed_at`` must be tz-aware UTC.
    """

    model_config = _FROZEN_CONFIG

    address: NormalizedAddress
    kind: LabelKind
    source: LabelSource
    confidence: float = Field(ge=0.0, le=1.0)
    observed_at: datetime
    evidence: tuple[Evidence, ...] = ()
    cluster_id: str | None = None
    extras: Mapping[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_observed_at(self) -> Self:
        normalised = _ensure_utc(self.observed_at)
        if normalised is not self.observed_at:
            object.__setattr__(self, "observed_at", normalised)
        return self

    @model_validator(mode="after")
    def _validate_cluster_kind_pair(self) -> Self:
        """``cluster_id`` is set iff ``kind == CLUSTER`` (bijection)."""
        is_cluster_kind = self.kind is LabelKind.CLUSTER
        has_cluster_id = self.cluster_id is not None
        if is_cluster_kind and not has_cluster_id:
            raise ValueError(
                f"AddressLabel.kind=CLUSTER requires cluster_id; got cluster_id={self.cluster_id!r}"
            )
        if has_cluster_id and not is_cluster_kind:
            raise ValueError(
                f"AddressLabel.cluster_id is exclusive to kind=CLUSTER; "
                f"got kind={self.kind.value}, cluster_id={self.cluster_id!r}"
            )
        return self

    @model_validator(mode="after")
    def _validate_cluster_id_uuid4(self) -> Self:
        if self.cluster_id is None:
            return self
        normalised = _validate_uuid4(self.cluster_id, field="AddressLabel.cluster_id")
        if normalised != self.cluster_id:
            object.__setattr__(self, "cluster_id", normalised)
        return self

    @model_validator(mode="after")
    def _validate_heuristic_evidence_nonempty(self) -> Self:
        """``HEURISTIC_*`` sources require ``len(evidence) > 0`` (DoD-9b)."""
        if self.source.value.startswith("heuristic_") and len(self.evidence) == 0:
            raise ValueError(
                f"AddressLabel.source={self.source.value} requires non-empty evidence tuple"
            )
        return self

    @model_validator(mode="after")
    def _validate_evidence_tx_hash_chain(self) -> Self:
        """Every Evidence.tx_hash (when set) must match the parent chain regex.

        The validator also stores the canonical lowercase form returned by
        ``_validate_chain_tx_hash`` so dedup/equality on tx_hash are
        case-insensitive. ``Evidence`` is frozen and may be a caller-owned
        instance reused across multiple ``AddressLabel`` constructions, so we
        MUST NOT mutate it in place. Instead, when canonicalisation changes
        the tx_hash, we ``model_copy`` the Evidence (producing a new frozen
        instance) and replace ``self.evidence`` with a new tuple — only the
        AddressLabel container itself is patched via ``object.__setattr__``.
        """
        chain = self.address.address.chain
        new_evidence: list[Evidence] = []
        changed = False
        for idx, evidence in enumerate(self.evidence):
            if evidence.tx_hash is None:
                new_evidence.append(evidence)
                continue
            canonical = _validate_chain_tx_hash(
                chain, evidence.tx_hash, field=f"AddressLabel.evidence[{idx}].tx_hash"
            )
            if canonical != evidence.tx_hash:
                new_evidence.append(evidence.model_copy(update={"tx_hash": canonical}))
                changed = True
            else:
                new_evidence.append(evidence)
        if changed:
            object.__setattr__(self, "evidence", tuple(new_evidence))
        return self

    @model_validator(mode="after")
    def _freeze_extras(self) -> Self:
        frozen = freeze_extras_value(dict(self.extras), label=_ADDRESS_LABEL_EXTRAS_LABEL)
        object.__setattr__(self, "extras", frozen)
        return self

    @field_serializer("extras")
    def _serialize_extras(self, value: Mapping[str, Any]) -> dict[str, Any]:
        thawed = thaw_extras_value(value)
        if not isinstance(thawed, dict):  # pragma: no cover - structural guarantee
            raise TypeError("AddressLabel.extras must serialise to a dict at the top level")
        return thawed


__all__ = [
    "AddressActivity",
    "AddressLabel",
    "Evidence",
    "EvidenceKind",
    "LabelKind",
    "LabelSource",
]
