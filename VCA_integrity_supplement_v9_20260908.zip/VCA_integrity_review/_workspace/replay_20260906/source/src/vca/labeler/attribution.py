"""Attribution labelers — Tornado.Cash / N1·N2 convergence / wallet sweep (P2-009.0).

Cross-stage attribution evidence detectors. Unlike per-address pin labelers
(``router`` / ``governance`` / ``exchange``), these three labelers analyse
the structural pattern of an ``AddressActivity`` to surface evidence that
downstream attribution scoring can combine into a single confidence score
(deferred to P2-009.1+).

The module ships three independent ``HeuristicDetector``-compatible
labeler classes — operators register the labelers they want enabled and
tracer P1-014 treats them identically to the shipped detectors. The
register-all-or-disable pattern matches the existing labeler package
style; no new abstract base class is introduced.

Sub-detector 1: :class:`TornadoOutputLabeler`
    Recognises when an address receives native ETH from a canonical
    Tornado.Cash pool contract (one of the four well-known immutable
    1 / 10 / 100 / 0.1 ETH mixing pools). Emits ``LabelKind.MIXER`` with
    evidence containing the received amount + the configured 9-hour
    gap-to-attack window. The downstream attribution scorer combines
    this with the actual time-gap-to-attack-TX to confirm the
    "Tornado funded the attack gas" pattern (PDF page 9 verbatim).

Sub-detector 2: :class:`ConvergenceLabeler`
    Recognises when a single destination address receives ETH inflows
    from two or more configured "branch source" wallets within a
    configurable window (default 24h). Emits ``LabelKind.CLUSTER`` with
    a deterministic UUID4 ``cluster_id`` (derived from
    sha256(destination + sorted-branch-sources) so the same convergence
    point always yields the same cluster id). Default configuration
    has empty ``branch_sources`` (operators inject the N1 + N2 wallets
    via the build helper). PDF page 24 verbatim: N1 (Exploiter 9) and
    N2 (Exploiter 10) both feed Exploiter 7.

Sub-detector 3: :class:`WalletSweepLabeler`
    Recognises the residual-sweep OPSEC pattern — sender drains ≥99%
    of its pre-balance to a configured successor address. Emits
    ``LabelKind.SINGLE_USE`` with evidence carrying the computed sweep
    ratio + pre/post balance values. PDF page 25 verbatim: attack-wallet
    (0xf8575E) → N2 (0.993 ETH residual), N1 (Exploiter 9) → Exploiter 7
    (8.989 ETH residual).

LabelKind picks (R-NO-NEW-LABELKIND):
    * Tornado output → MIXER (semantic fit: mixer-output recognition)
    * N1·N2 convergence → CLUSTER (semantic fit: two addresses share
      one downstream cluster) + deterministic UUID4 cluster_id
    * Wallet sweep → SINGLE_USE (semantic fit: wallet drained-then-
      forwarded matches the existing single-use definition)

Source pin tag ``operator_pin_2026-05-12`` traces every emission back
to the supplement PDF integration commit (db16ad2).
"""

from __future__ import annotations

import hashlib
import uuid
from collections.abc import Iterable
from datetime import datetime, timedelta
from typing import Any, Final

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from vca.labeler._types import (
    AddressActivity,
    AddressLabel,
    Evidence,
    EvidenceKind,
    LabelKind,
    LabelSource,
)
from vca.labeler.heuristics import ensure_utc_now
from vca.types import Address, ChainId, NormalizedAddress

# ---------------------------------------------------------------------------
# Module-level constants
# ---------------------------------------------------------------------------

_FROZEN_CONFIG: Final[ConfigDict] = ConfigDict(frozen=True, strict=True, extra="forbid")

# Operator-curated provenance tag — embedded in every emitted label.extras
# so a downstream investigator can grep the codebase for the supplement
# PDF integration date (2026-05-12, commit db16ad2).
_OPERATOR_PIN_TAG: Final[str] = "operator_pin_2026-05-12"
_PIN_CONFIDENCE: Final[float] = 1.0

# Tornado.Cash defaults
_TORNADO_PROTOCOL_NAME: Final[str] = "Tornado.Cash mixing pool (canonical)"
_TORNADO_PDF_REFERENCE: Final[str] = "KelpDAO_rsETH_Exploit_update.pdf p8-9"
_TORNADO_CHAIN_LABEL: Final[str] = "ethereum_mainnet"
_TORNADO_NAME: Final[str] = "tornado_cash_output"
# Cycle 18 P2-LABELER-ATTRIBUTION-ROLE-SSOT.1 — pin the ``attribution_role``
# extras-key string via a module-level ``Final[str]`` so a labeler-side
# typo cannot silently route the marker to the reporter ``"other"``
# bucket. Mirrors the existing ``_CONVERGENCE_ATTRIBUTION_ROLE`` /
# ``_SWEEP_ATTRIBUTION_ROLE`` / ``_SMURFING_SWEEP_ATTRIBUTION_ROLE``
# pattern (P2-009.4 ship). The value is intentionally distinct from
# ``_TORNADO_NAME`` — the ``name`` field feeds the priority resolver, the
# ``attribution_role`` extras key feeds the reporter bucket. See
# Cycle 18 architect WBS §1 Gap A row 1 / Candidate B veto rationale.
_TORNADO_ATTRIBUTION_ROLE: Final[str] = "tornado_output_recipient"

# Convergence defaults
_CONVERGENCE_PROTOCOL_NAME: Final[str] = "Branch-convergence point (cross-stage attribution)"
_CONVERGENCE_PDF_REFERENCE: Final[str] = "KelpDAO_rsETH_Exploit_update.pdf p24"
_CONVERGENCE_NAME: Final[str] = "branch_convergence_point"
# P2-009.4 — attribution_role string pinned via module-level Final[str] so
# the reporter whitelist (``_KNOWN_ATTRIBUTION_ROLES``) and this labeler
# can never disagree by typo. Mirrors :data:`_SMURFING_SWEEP_ATTRIBUTION_ROLE`.
_CONVERGENCE_ATTRIBUTION_ROLE: Final[str] = "branch_convergence_point"
# Verbatim PDF page-24 N1·N2 branch sources (Exploiter 9 + Exploiter 10).
_CONVERGENCE_DEFAULT_N1: Final[str] = "0xF9802c5EB6b972Ba686aFa7CA615910Ea8310b85"
_CONVERGENCE_DEFAULT_N2: Final[str] = "0xABc82C8975c922E5aa836b4AFd36FAD4511A65b8"

# Wallet sweep defaults
_SWEEP_PROTOCOL_NAME: Final[str] = "Wallet residual-sweep OPSEC pattern"
_SWEEP_PDF_REFERENCE: Final[str] = "KelpDAO_rsETH_Exploit_update.pdf p24-25"
_SWEEP_NAME: Final[str] = "wallet_residual_sweep"
# P2-009.4 — attribution_role string pinned via module-level Final[str].
_SWEEP_ATTRIBUTION_ROLE: Final[str] = "wallet_residual_sweep"
# Verbatim PDF page-25 default successor wallet (Exploiter 7 is N1's sweep target).
# Note: the canonical EIP-55 form of this address has lowercase '62c..e' +
# uppercase 'FC64E' tail. The literal here IS the canonical form; a
# round-trip via :func:`_normalize_eip55_str` is performed inside
# :func:`build_default_sweep_labeler` so any import-time corruption surfaces
# at first build call rather than silently drifting.
_SWEEP_DEFAULT_SUCCESSOR: Final[str] = "0x62c72510016732333e68177d388a8111643FC64E"

# Time windows (seconds)
GAP_TO_ATTACK_SECONDS_DEFAULT: Final[int] = 9 * 3600  # 32,400 s ≈ 9 hours
CONVERGENCE_WINDOW_SECONDS_DEFAULT: Final[int] = 24 * 3600  # 86,400 s
SWEEP_RATIO_THRESHOLD_DEFAULT: Final[float] = 0.99

# Cluster-id deterministic seed namespace — the sha256 prefix that
# distinguishes "convergence cluster" UUID4s from any other deterministic
# UUID4 namespace the project may introduce later.
_CLUSTER_NAMESPACE: Final[bytes] = b"vca.labeler.attribution.cluster:"


# ---------------------------------------------------------------------------
# Tornado.Cash canonical pool addresses (mainnet, immutable)
# ---------------------------------------------------------------------------


def _normalize_eip55_str(raw: str, chain: ChainId = ChainId.ETHEREUM) -> str:
    """Canonicalise an address string to its EIP-55 form for the given chain.

    Wraps :meth:`Address.from_str` so callers can pass lowercase / mixed
    case (e.g. pasted Etherscan output) and the labeler still uses canonical
    strings for ``frozenset`` membership.
    """
    return Address.from_str(raw, chain).value


# Canonical Tornado.Cash mixing pool contracts on Ethereum mainnet.
# These are immutable smart contracts; addresses are widely published in
# Tornado.Cash documentation and OFAC SDN listings. Pinned in EIP-55
# checksum form at module load so import-time corruption surfaces early.
TORNADO_POOL_1_ETH: Final[str] = _normalize_eip55_str("0x47CE0C6eD5B0Ce3d3A51fdb1C52DC66a7c3c2936")
TORNADO_POOL_10_ETH: Final[str] = _normalize_eip55_str("0x910Cbd523D972eb0a6f4cAe4618aD62622b39DbF")
TORNADO_POOL_100_ETH: Final[str] = _normalize_eip55_str(
    "0xA160cdAB225685dA1d56aa342Ad8841c3b53f291"
)
TORNADO_POOL_0_1_ETH: Final[str] = _normalize_eip55_str(
    "0x12D66f87A04A9E220743712cE6d9bB1B5616B8Fc"
)

# Bundled default — the four canonical pools.
TORNADO_POOL_DEFAULTS: Final[frozenset[str]] = frozenset(
    {
        TORNADO_POOL_1_ETH,
        TORNADO_POOL_10_ETH,
        TORNADO_POOL_100_ETH,
        TORNADO_POOL_0_1_ETH,
    }
)


# ---------------------------------------------------------------------------
# Tornado.Cash output labeler
# ---------------------------------------------------------------------------


class TornadoOutputLabelerConfig(BaseModel):
    """Frozen settings DTO carrying the Tornado pool whitelist + gap window.

    ``tornado_pool_addresses`` MAY hold any number of EIP-55 (or
    lowercase / mixed-case) Ethereum mainnet pool addresses. The validator
    normalises every entry to its EIP-55 checksum form. Empty sets are
    rejected — a labeler with no pins cannot emit anything, which is an
    architecture error rather than a silent no-op.

    ``gap_to_attack_seconds`` is the configurable horizon embedded in the
    emitted evidence's ``window_seconds`` field. Default 32,400 s (9 hours)
    matches the verbatim PDF page-9 narrative.
    """

    model_config = _FROZEN_CONFIG

    tornado_pool_addresses: frozenset[str] = Field(default=TORNADO_POOL_DEFAULTS)
    gap_to_attack_seconds: int = Field(default=GAP_TO_ATTACK_SECONDS_DEFAULT, ge=0)

    @field_validator("tornado_pool_addresses", mode="before")
    @classmethod
    def _normalize_addresses(cls, value: Any) -> Any:
        if isinstance(value, frozenset | set | tuple | list):
            return frozenset(_normalize_eip55_str(raw) for raw in value)
        return value  # let pydantic surface the type error

    @model_validator(mode="after")
    def _reject_empty(self) -> TornadoOutputLabelerConfig:
        if len(self.tornado_pool_addresses) == 0:
            raise ValueError(
                "TornadoOutputLabelerConfig.tornado_pool_addresses must not be empty; "
                "a labeler with zero pinned pools cannot emit labels."
            )
        return self


class TornadoOutputLabeler:
    """Recognises native-ETH inflows from canonical Tornado.Cash pools.

    See module docstring for the algorithm (address pin + chain filter +
    native-ETH-only filter + gap-to-attack evidence window).

    LabelKind discipline note (codex P2-009.0 review round-1):

        The MIXER LabelKind is in ``TracePolicy._DEFAULT_TERMINAL_LABELS``
        — labels of that kind would prune BFS expansion at the labeled
        address. This labeler labels the **output recipient** (the
        attacker's gas-funded execution wallet), NOT the Tornado.Cash
        pool contract itself. Using MIXER here would terminate the
        trace at the attack wallet, breaking the very trace this
        evidence is meant to support.

        The fix: emit :attr:`LabelKind.UNKNOWN` (non-terminal in the
        default policy) and record the Tornado-output semantic role in
        ``extras["attribution_role"]="tornado_output_recipient"``. A
        downstream attribution scorer (P2-009.1+) reads the extras
        payload — the role label is informational, not a termination
        signal.
    """

    name: str = _TORNADO_NAME
    source: LabelSource = LabelSource.OWN_DB
    kind: LabelKind = LabelKind.UNKNOWN

    def __init__(self, config: TornadoOutputLabelerConfig) -> None:
        self._config = config

    def detect(
        self,
        activity: AddressActivity,
        *,
        now: datetime,
    ) -> tuple[AddressLabel, ...]:
        anchor = ensure_utc_now(now, detector=self.name)

        # Mainnet-only: Tornado.Cash classic pools are Ethereum L1
        # contracts; same hex on ARB / BTC must not match.
        if activity.address.chain is not ChainId.ETHEREUM:
            return ()

        # Walk incoming transfers; emit at most one label per address (the
        # first qualifying inflow seeds the evidence).
        for idx, transfer in enumerate(activity.incoming):
            if transfer.from_addr is None:
                continue
            if not transfer.asset.is_native:
                continue
            sender_str = transfer.from_addr.value
            if sender_str not in self._config.tornado_pool_addresses:
                continue
            incoming_ts = activity.transfer_timestamps[idx]
            evidence = (
                Evidence(
                    kind=EvidenceKind.SINGLE_INCOMING_TX,
                    count=1,
                    value_minor=transfer.amount.raw,
                    decimals=transfer.amount.decimals,
                    window_seconds=self._config.gap_to_attack_seconds,
                    observed_at=incoming_ts,
                    extras={"pool_address": sender_str},
                ),
            )
            label = AddressLabel(
                address=NormalizedAddress(address=activity.address),
                kind=self.kind,
                source=self.source,
                confidence=_PIN_CONFIDENCE,
                observed_at=anchor,
                evidence=evidence,
                extras={
                    "protocol": _TORNADO_PROTOCOL_NAME,
                    "source_pin": _OPERATOR_PIN_TAG,
                    "pdf_reference": _TORNADO_PDF_REFERENCE,
                    "chain": _TORNADO_CHAIN_LABEL,
                    "pool_address": sender_str,
                    # Codex P2-009.0 round-1 fix: the kind is UNKNOWN
                    # (non-terminal) so the trace continues past the
                    # gas-funded attack wallet; the attribution role is
                    # carried in extras for downstream scoring (P2-009.1+).
                    # Cycle 18 P2-LABELER-ATTRIBUTION-ROLE-SSOT.1: route
                    # through the module-level ``_TORNADO_ATTRIBUTION_ROLE``
                    # constant instead of a raw string literal.
                    "attribution_role": _TORNADO_ATTRIBUTION_ROLE,
                },
            )
            return (label,)
        return ()


def build_default_tornado_labeler(
    *,
    extra_pool_addresses: Iterable[str] = (),
    gap_to_attack_seconds: int = GAP_TO_ATTACK_SECONDS_DEFAULT,
) -> TornadoOutputLabeler:
    """Build a :class:`TornadoOutputLabeler` with the canonical 4 pools + extras."""
    addresses = set(TORNADO_POOL_DEFAULTS) | set(extra_pool_addresses)
    config = TornadoOutputLabelerConfig(
        tornado_pool_addresses=frozenset(addresses),
        gap_to_attack_seconds=gap_to_attack_seconds,
    )
    return TornadoOutputLabeler(config)


# ---------------------------------------------------------------------------
# N1·N2 Convergence labeler
# ---------------------------------------------------------------------------


def _deterministic_cluster_uuid4(*, destination: str, branch_sources: frozenset[str]) -> str:
    """Compute a deterministic UUID4 string from convergence inputs.

    sha256(namespace + destination + sorted-branch-sources) → first 16 bytes
    with version=4 + variant=10 bits forced. The result is a syntactically
    valid UUID4 (passes ``uuid.UUID(...).version == 4`` so it survives the
    :class:`AddressLabel.cluster_id` validator) but it is reproducible
    across labeler invocations — the same convergence point always yields
    the same cluster id (critical for golden-test determinism).
    """
    sorted_branches = ",".join(sorted(branch_sources))
    seed = _CLUSTER_NAMESPACE + destination.encode("ascii") + b"|" + sorted_branches.encode("ascii")
    digest = bytearray(hashlib.sha256(seed).digest()[:16])
    # RFC 4122 §4.4: set the 4 most-significant bits of byte 6 to 0100
    # (version 4) and the 2 most-significant bits of byte 8 to 10 (variant).
    digest[6] = (digest[6] & 0x0F) | 0x40
    digest[8] = (digest[8] & 0x3F) | 0x80
    return str(uuid.UUID(bytes=bytes(digest)))


def _serialize_branch_sources(matched: Iterable[str]) -> str:
    """Serialize convergence in-window matched branch wallets as a
    deterministic comma-joined string.

    Mirrors the sort discipline used inside
    :func:`_deterministic_cluster_uuid4` (``",".join(sorted(...))``) so
    the same matched set serializes byte-equal cross-process and
    cross-input-order. Codex F-J (P2-009.4 round 2) — the reporter's
    ``_ROLE_EXTRAS_WHITELIST["branch_convergence_point"]`` expects this
    key on :class:`ConvergenceLabeler` output so reports surface the
    source wallets that actually proved the convergence.
    """
    return ",".join(sorted(matched))


class ConvergenceLabelerConfig(BaseModel):
    """Frozen settings DTO for the convergence detector.

    ``branch_sources`` is the configured set of "branch" wallets — when an
    activity has incoming flows from ≥2 of these within
    ``convergence_window_seconds``, the destination is labeled as a
    convergence point. Default empty so a fresh-out-of-the-box labeler is
    silent until operators inject N1+N2 (or other) wallets.
    """

    model_config = _FROZEN_CONFIG

    branch_sources: frozenset[str] = Field(default_factory=frozenset)
    convergence_window_seconds: int = Field(default=CONVERGENCE_WINDOW_SECONDS_DEFAULT, ge=0)

    @field_validator("branch_sources", mode="before")
    @classmethod
    def _normalize_branch_sources(cls, value: Any) -> Any:
        if isinstance(value, frozenset | set | tuple | list):
            return frozenset(_normalize_eip55_str(raw) for raw in value)
        return value


class ConvergenceLabeler:
    """Emits a CLUSTER label when ≥2 branch sources converge at the address.

    See module docstring for the algorithm.
    """

    name: str = _CONVERGENCE_NAME
    source: LabelSource = LabelSource.OWN_DB
    kind: LabelKind = LabelKind.CLUSTER

    def __init__(self, config: ConvergenceLabelerConfig) -> None:
        self._config = config

    def detect(
        self,
        activity: AddressActivity,
        *,
        now: datetime,
    ) -> tuple[AddressLabel, ...]:
        anchor = ensure_utc_now(now, detector=self.name)

        if not self._config.branch_sources:
            return ()

        # Collect branch inflows: (branch_address, timestamp, value_minor,
        # decimals) for every incoming transfer whose from_addr is in
        # branch_sources.
        branch_hits: list[tuple[str, datetime, int, int]] = []
        for idx, transfer in enumerate(activity.incoming):
            if transfer.from_addr is None:
                continue
            if not transfer.asset.is_native:
                # CONV-1 fix: native-ETH only, matching this class's stated
                # contract ("receives ETH inflows") and BOTH sibling detectors
                # (``TornadoOutputLabeler`` / ``WalletSweepLabeler``).
                #
                # This filter is load-bearing, not defensive.
                # :func:`vca.cases.kelpdao_labeler._native_transfers_from_tx`
                # deliberately KEEPS ERC-20 transfers in the activity and
                # documents that "the per-address detectors filter on
                # ``asset.is_native`` themselves" — this detector did not, so
                # two dust token transfers (e.g. 0.000001 USDC) from the pinned
                # branch wallets were enough to emit a full-confidence
                # ``branch_convergence_point`` label carrying a PDF citation.
                #
                # Unreachable while the labeler sat on no case roster; CONV-1
                # put it on the live KelpDAO roster against every Ethereum
                # address in the trace, which is what made it a real defect.
                continue
            sender_str = transfer.from_addr.value
            if sender_str not in self._config.branch_sources:
                continue
            ts = activity.transfer_timestamps[idx]
            branch_hits.append((sender_str, ts, transfer.amount.raw, transfer.amount.decimals))

        if len(branch_hits) < 2:
            return ()

        # Codex P2-009.0 round-1 P2 fix: sliding-window over distinct
        # branches rather than a global ``max(timestamps)-min(timestamps)``
        # span. With a multi-hit branch (or operator-added 3rd+ source)
        # the old span check rejected valid 2-branch subsets simply
        # because one outlier hit was outside the window.
        #
        # Algorithm: sort hits by timestamp; for every left-index ``i``
        # advance ``j`` until ``hits[j].ts - hits[i].ts`` exceeds the
        # configured window; track the maximum count of distinct branches
        # observed in any ``[i, j)`` window. Pick the *earliest* window
        # that hits the maximum (deterministic tie-break for golden tests).
        sorted_hits = sorted(branch_hits, key=lambda h: (h[1], h[0]))
        window_delta = timedelta(seconds=self._config.convergence_window_seconds)
        best_count = 0
        best_subset: list[tuple[str, datetime, int, int]] = []
        n_hits = len(sorted_hits)
        for i in range(n_hits):
            j = i
            window_subset: list[tuple[str, datetime, int, int]] = []
            window_branches: set[str] = set()
            while j < n_hits and (sorted_hits[j][1] - sorted_hits[i][1]) <= window_delta:
                window_subset.append(sorted_hits[j])
                window_branches.add(sorted_hits[j][0])
                j += 1
            if len(window_branches) > best_count:
                best_count = len(window_branches)
                best_subset = window_subset
        if best_count < 2:
            return ()

        distinct_branches = {hit[0] for hit in best_subset}

        # Build evidence — one per-branch SINGLE_INCOMING_TX entry +
        # one FAN_IN_COUNT summary for downstream attribution scoring.
        # Evidence is derived from the SELECTED subset (the window that
        # maximised distinct-branch count) rather than the raw hit set.
        evidence_list: list[Evidence] = []
        for branch_addr, ts, value_minor, decimals in best_subset:
            evidence_list.append(
                Evidence(
                    kind=EvidenceKind.SINGLE_INCOMING_TX,
                    count=1,
                    value_minor=value_minor,
                    decimals=decimals,
                    observed_at=ts,
                    extras={"branch_source": branch_addr},
                )
            )
        evidence_list.append(
            Evidence(
                kind=EvidenceKind.FAN_IN_COUNT,
                count=len(distinct_branches),
                window_seconds=self._config.convergence_window_seconds,
                observed_at=anchor,
            )
        )

        cluster_id = _deterministic_cluster_uuid4(
            destination=activity.address.value,
            branch_sources=frozenset(distinct_branches),
        )
        label = AddressLabel(
            address=NormalizedAddress(address=activity.address),
            kind=self.kind,
            source=self.source,
            confidence=_PIN_CONFIDENCE,
            observed_at=anchor,
            evidence=tuple(evidence_list),
            cluster_id=cluster_id,
            extras={
                "protocol": _CONVERGENCE_PROTOCOL_NAME,
                "source_pin": _OPERATOR_PIN_TAG,
                "pdf_reference": _CONVERGENCE_PDF_REFERENCE,
                "convergence_point": activity.address.value,
                # Codex F-J (P2-009.4 round 2): surface the in-window
                # subset of branch wallets that actually triggered the
                # convergence. The reporter whitelist
                # ``_ROLE_EXTRAS_WHITELIST["branch_convergence_point"]``
                # at ``_context.py:185`` already expects this key — pre-
                # fix the labeler stamped only ``convergence_point`` so
                # every real convergence report omitted the source
                # wallets that proved the convergence. Serialization
                # mirrors the sort discipline used to seed the cluster
                # UUID4 above so the two surfaces stay byte-equal
                # cross-process. R-CONVERGENCE-BRANCH-SOURCES-EMITTED +
                # R-WHITELIST-KEY-EMISSION-CLOSURE +
                # R-BRANCH-SOURCES-DETERMINISTIC-SORT.
                "branch_sources": _serialize_branch_sources(distinct_branches),
                # P2-009.4 — attribution role marker for the reporter
                # whitelist (``_KNOWN_ATTRIBUTION_ROLES``). Mirrors the
                # Tornado / Smurfing / EthBtcRatio pattern; closes the
                # emission-side asymmetry P2-009.3 left as forward-compat.
                "attribution_role": _CONVERGENCE_ATTRIBUTION_ROLE,
            },
        )
        return (label,)


def build_default_convergence_labeler(
    *,
    extra_branch_sources: Iterable[str] = (),
    convergence_window_seconds: int = CONVERGENCE_WINDOW_SECONDS_DEFAULT,
) -> ConvergenceLabeler:
    """Build a :class:`ConvergenceLabeler` pre-loaded with N1+N2 branch sources."""
    sources = {_CONVERGENCE_DEFAULT_N1, _CONVERGENCE_DEFAULT_N2} | set(extra_branch_sources)
    config = ConvergenceLabelerConfig(
        branch_sources=frozenset(sources),
        convergence_window_seconds=convergence_window_seconds,
    )
    return ConvergenceLabeler(config)


# ---------------------------------------------------------------------------
# Wallet sweep amplifier labeler
# ---------------------------------------------------------------------------


class WalletSweepLabelerConfig(BaseModel):
    """Frozen settings DTO for the residual-sweep detector.

    ``sweep_ratio_threshold`` (default 0.99) is the minimum
    ``swept_to_successor / (swept_to_successor + post_balance)`` ratio that
    triggers the label. ``successor_addresses`` is the configured set of
    "next stage" wallets — only outgoing flows to one of these addresses
    count toward the swept-value tally. Default empty so a fresh-out-of-
    the-box labeler is silent until operators inject Exploiter 7 (or
    other) addresses.
    """

    model_config = _FROZEN_CONFIG

    sweep_ratio_threshold: float = Field(default=SWEEP_RATIO_THRESHOLD_DEFAULT, ge=0.0, le=1.0)
    successor_addresses: frozenset[str] = Field(default_factory=frozenset)

    @field_validator("successor_addresses", mode="before")
    @classmethod
    def _normalize_successors(cls, value: Any) -> Any:
        if isinstance(value, frozenset | set | tuple | list):
            return frozenset(_normalize_eip55_str(raw) for raw in value)
        return value


class WalletSweepLabeler:
    """Flags the residual-sweep OPSEC pattern.

    See module docstring for the algorithm.
    """

    name: str = _SWEEP_NAME
    source: LabelSource = LabelSource.OWN_DB
    kind: LabelKind = LabelKind.SINGLE_USE

    def __init__(self, config: WalletSweepLabelerConfig) -> None:
        self._config = config

    def detect(
        self,
        activity: AddressActivity,
        *,
        now: datetime,
    ) -> tuple[AddressLabel, ...]:
        anchor = ensure_utc_now(now, detector=self.name)

        if not self._config.successor_addresses:
            return ()
        if not activity.outgoing:
            return ()
        if activity.balance_minor is None or activity.balance_decimals is None:
            return ()

        # Tally outgoing native-ETH value to configured successors.
        swept_to_successor = 0
        successor_seen: str | None = None
        total_outgoing = 0
        for transfer in activity.outgoing:
            if not transfer.asset.is_native:
                continue
            total_outgoing += transfer.amount.raw
            if transfer.to_addr is None:
                continue
            if transfer.to_addr.value in self._config.successor_addresses:
                swept_to_successor += transfer.amount.raw
                if successor_seen is None:
                    successor_seen = transfer.to_addr.value

        if swept_to_successor == 0 or successor_seen is None:
            return ()

        # Pre-balance = post-balance + total outgoing (native ETH only).
        post_balance = activity.balance_minor
        pre_balance = post_balance + total_outgoing
        if pre_balance == 0:
            return ()  # avoid zero-division on a totally empty wallet

        sweep_ratio = swept_to_successor / pre_balance
        if sweep_ratio < self._config.sweep_ratio_threshold:
            return ()

        evidence = (
            Evidence(
                kind=EvidenceKind.IMMEDIATE_OUTGOING_TX,
                count=len(activity.outgoing),
                value_minor=swept_to_successor,
                decimals=activity.balance_decimals,
                observed_at=anchor,
            ),
            Evidence(
                kind=EvidenceKind.BALANCE_ZERO,
                value_minor=post_balance,
                decimals=activity.balance_decimals,
                observed_at=anchor,
            ),
        )
        label = AddressLabel(
            address=NormalizedAddress(address=activity.address),
            kind=self.kind,
            source=self.source,
            confidence=_PIN_CONFIDENCE,
            observed_at=anchor,
            evidence=evidence,
            extras={
                "protocol": _SWEEP_PROTOCOL_NAME,
                "source_pin": _OPERATOR_PIN_TAG,
                "pdf_reference": _SWEEP_PDF_REFERENCE,
                "sweep_ratio": sweep_ratio,
                "pre_balance_minor": pre_balance,
                "post_balance_minor": post_balance,
                "value_swept_minor": swept_to_successor,
                "successor_address": successor_seen,
                # P2-009.4 — attribution role marker. SmurfingSweepLabeler
                # overwrites this value to ``_SMURFING_SWEEP_ATTRIBUTION_ROLE``
                # AFTER the delegate stamps the generic value; the overwrite
                # ordering is verified by ``test_smurfing_overwrites_wallet_sweep_role``.
                "attribution_role": _SWEEP_ATTRIBUTION_ROLE,
            },
        )
        return (label,)


def build_default_sweep_labeler(
    *,
    extra_successor_addresses: Iterable[str] = (),
    sweep_ratio_threshold: float = SWEEP_RATIO_THRESHOLD_DEFAULT,
) -> WalletSweepLabeler:
    """Build a :class:`WalletSweepLabeler` pre-loaded with Exploiter 7 + extras."""
    successors = {_SWEEP_DEFAULT_SUCCESSOR} | set(extra_successor_addresses)
    config = WalletSweepLabelerConfig(
        sweep_ratio_threshold=sweep_ratio_threshold,
        successor_addresses=frozenset(successors),
    )
    return WalletSweepLabeler(config)


# ---------------------------------------------------------------------------
# Smurfing-context residual sweep labeler (P2-005.0)
# ---------------------------------------------------------------------------

# WBS §4.6 P2-005.0: "잔여→후속 지갑 ≤0.1% loss" ⇔ swept ≥ 99.9% of pre-balance.
# Tighter than the P2-009.0 :class:`WalletSweepLabeler` default 0.99 (≤1%
# loss) so a downstream attribution scorer can distinguish (a) the
# smurfing-residual OPSEC pattern from (b) the generic single-use sweep.
SMURFING_SWEEP_RATIO_THRESHOLD_DEFAULT: Final[float] = 0.999

_SMURFING_SWEEP_PROTOCOL_NAME: Final[str] = "Smurfing-residual sweep (post-distribution)"
_SMURFING_SWEEP_PDF_REFERENCE: Final[str] = "KelpDAO_rsETH_Exploit_update.pdf p25"
_SMURFING_SWEEP_NAME: Final[str] = "smurfing_residual_sweep"
_SMURFING_SWEEP_ATTRIBUTION_ROLE: Final[str] = "smurfing_residual_sweep"


class SmurfingSweepLabelerConfig(BaseModel):
    """Frozen settings DTO for the smurfing-context residual-sweep detector.

    Mirrors :class:`WalletSweepLabelerConfig` (P2-009.0) but with a tighter
    default ``sweep_ratio_threshold`` (0.999 vs the generic 0.99) so the
    detector only fires on the documented post-smurfing residual sweep
    pattern (PDF page 25: N1 → Exploiter 7 with ≥99.9% drainage). Operators
    inject the post-smurfing successor wallets via ``successor_addresses``
    (default empty so a fresh labeler is silent).
    """

    model_config = _FROZEN_CONFIG

    sweep_ratio_threshold: float = Field(
        default=SMURFING_SWEEP_RATIO_THRESHOLD_DEFAULT, ge=0.0, le=1.0
    )
    successor_addresses: frozenset[str] = Field(default_factory=frozenset)

    @field_validator("successor_addresses", mode="before")
    @classmethod
    def _normalize_successors(cls, value: Any) -> Any:
        if isinstance(value, frozenset | set | tuple | list):
            return frozenset(_normalize_eip55_str(raw) for raw in value)
        return value


class SmurfingSweepLabeler:
    """Flags the smurfing-context residual-sweep OPSEC pattern.

    Delegates the structural sweep computation to a private
    :class:`WalletSweepLabeler` instance built from the same config (so the
    pre/post balance + sweep ratio math is the single source of truth),
    then transforms the emitted label into a smurfing-flavoured variant:

    * ``name`` becomes ``"smurfing_residual_sweep"`` so the priority
      resolver / operators can route the two labelers independently.
    * ``extras["protocol"]`` becomes the smurfing-specific protocol name.
    * ``extras["pdf_reference"]`` points at PDF page 25 (Stage 6 → 7
      residual sweep).
    * ``extras["attribution_role"]`` is stamped
      ``"smurfing_residual_sweep"`` so a downstream attribution scorer can
      distinguish the two sweep contexts without re-running the predicate.

    The :attr:`LabelKind.SINGLE_USE` choice is preserved (R-NO-NEW-LABELKIND).

    **Operational contract — codex P2-005.0 R2/R3 P2:**

    The :class:`LabelPriorityResolver` ranks by ``source`` tier first,
    then ``confidence``, then ``observed_at``, then declaration order
    of :class:`LabelKind`. Both this labeler and the generic
    :class:`WalletSweepLabeler` emit
    ``(source=OWN_DB, confidence=1.0, kind=SINGLE_USE)`` with the same
    ``observed_at`` (``now`` at detect time), so registering BOTH on
    the same activity makes the resolver's choice depend on input
    tuple order — and the generic label can silently shadow the
    smurfing-specific ``extras["attribution_role"]`` payload.

    Operators MUST therefore register **exactly one** of
    :class:`WalletSweepLabeler` / :class:`SmurfingSweepLabeler` per
    case. For investigations where post-smurfing residual sweeps are
    the focus (the KelpDAO N1 → Exploiter 7 pattern; PDF p25),
    register :class:`SmurfingSweepLabeler` ONLY. For generic OPSEC
    sweep coverage in unrelated cases, register
    :class:`WalletSweepLabeler` ONLY. Mixing the two is a configuration
    error and must be caught at the tracer / case-bootstrap layer.

    Earlier iterations of this slice (codex R2 P2 review) introduced a
    1-microsecond ``observed_at`` offset to win the tiebreak; that
    approach was rejected as it falsifies audit-log semantics and
    leaks a future-stamped label into unrelated resolver paths. The
    operator-contract approach above keeps ``observed_at`` honest.
    """

    name: str = _SMURFING_SWEEP_NAME
    source: LabelSource = LabelSource.OWN_DB
    kind: LabelKind = LabelKind.SINGLE_USE

    def __init__(self, config: SmurfingSweepLabelerConfig) -> None:
        self._config = config
        # Build a delegate :class:`WalletSweepLabeler` so the sweep-ratio
        # math is implemented once. The delegate's tighter threshold is
        # the only behavioural difference — the structural extraction
        # (pre-balance / outgoing tally / successor match) is identical.
        delegate_config = WalletSweepLabelerConfig(
            sweep_ratio_threshold=config.sweep_ratio_threshold,
            successor_addresses=config.successor_addresses,
        )
        self._delegate = WalletSweepLabeler(delegate_config)

    def detect(
        self,
        activity: AddressActivity,
        *,
        now: datetime,
    ) -> tuple[AddressLabel, ...]:
        labels = self._delegate.detect(activity, now=now)
        if not labels:
            return ()
        # Re-stamp each emitted label with the smurfing-context provenance.
        # NOTE: ``model_copy(update=...)`` skips validators in Pydantic v2,
        # which would leave ``extras`` as a mutable ``dict`` and break
        # :meth:`AddressLabel._freeze_extras` (codex P2-005.0 R1 P2 fix).
        # Re-construct the model via the full constructor so the
        # recursive-freeze pipeline runs on the merged extras dict.
        rewritten: list[AddressLabel] = []
        for base_label in labels:
            base_extras = dict(base_label.extras)
            base_extras["protocol"] = _SMURFING_SWEEP_PROTOCOL_NAME
            base_extras["pdf_reference"] = _SMURFING_SWEEP_PDF_REFERENCE
            base_extras["attribution_role"] = _SMURFING_SWEEP_ATTRIBUTION_ROLE
            rewritten.append(
                AddressLabel(
                    address=base_label.address,
                    kind=base_label.kind,
                    source=base_label.source,
                    confidence=base_label.confidence,
                    observed_at=base_label.observed_at,
                    evidence=base_label.evidence,
                    cluster_id=base_label.cluster_id,
                    extras=base_extras,
                ),
            )
        return tuple(rewritten)


def build_default_smurfing_sweep_labeler(
    *,
    extra_successor_addresses: Iterable[str] = (),
    sweep_ratio_threshold: float = SMURFING_SWEEP_RATIO_THRESHOLD_DEFAULT,
) -> SmurfingSweepLabeler:
    """Build a :class:`SmurfingSweepLabeler` pre-loaded with Exploiter 7 + extras."""
    successors = {_SWEEP_DEFAULT_SUCCESSOR} | set(extra_successor_addresses)
    config = SmurfingSweepLabelerConfig(
        sweep_ratio_threshold=sweep_ratio_threshold,
        successor_addresses=frozenset(successors),
    )
    return SmurfingSweepLabeler(config)


__all__ = [
    "CONVERGENCE_WINDOW_SECONDS_DEFAULT",
    "GAP_TO_ATTACK_SECONDS_DEFAULT",
    "SMURFING_SWEEP_RATIO_THRESHOLD_DEFAULT",
    "SWEEP_RATIO_THRESHOLD_DEFAULT",
    "TORNADO_POOL_0_1_ETH",
    "TORNADO_POOL_1_ETH",
    "TORNADO_POOL_10_ETH",
    "TORNADO_POOL_100_ETH",
    "TORNADO_POOL_DEFAULTS",
    "ConvergenceLabeler",
    "ConvergenceLabelerConfig",
    "SmurfingSweepLabeler",
    "SmurfingSweepLabelerConfig",
    "TornadoOutputLabeler",
    "TornadoOutputLabelerConfig",
    "WalletSweepLabeler",
    "WalletSweepLabelerConfig",
    "build_default_convergence_labeler",
    "build_default_smurfing_sweep_labeler",
    "build_default_sweep_labeler",
    "build_default_tornado_labeler",
]
