"""LabelPriorityResolver — pick the primary label per ARCH §3.4 (P1-013).

Source priority (lower = higher priority):
    OWN_DB           = 0
    ETHERSCAN        = 1
    ARBISCAN         = 1
    HEURISTIC_*      = 2

Within the highest-priority bucket, pick the candidate with the highest
``confidence``; tiebreak by the most recent ``observed_at``; final tiebreak
by :class:`LabelKind` declaration order in the StrEnum (deterministic for
golden tests).

The resolver is identity-preserving — it returns one of the supplied tuple
members verbatim (pinned by ``test_priority_identity_preserving``).
"""

from __future__ import annotations

import math
from collections.abc import Mapping

from vca.labeler._types import AddressLabel, LabelKind, LabelSource

_DEFAULT_RANK: Mapping[LabelSource, int] = {
    LabelSource.OWN_DB: 0,
    LabelSource.ETHERSCAN: 1,
    LabelSource.ARBISCAN: 1,
    LabelSource.HEURISTIC_SINGLE_USE: 2,
    LabelSource.HEURISTIC_VAULT: 2,
    LabelSource.HEURISTIC_BATCH_PAYOUT: 2,
    LabelSource.HEURISTIC_COMMON_INPUT: 2,
    LabelSource.HEURISTIC_COINJOIN: 2,
}

# LabelKind declaration order — the tiebreak rail of last resort.
_KIND_ORDER: dict[LabelKind, int] = {kind: idx for idx, kind in enumerate(LabelKind)}


class LabelPriorityResolver:
    """Pure function-as-class — see module docstring."""

    def __init__(
        self,
        *,
        source_rank: Mapping[LabelSource, int] | None = None,
    ) -> None:
        # Custom ranks fully override the default; missing sources fall to
        # +inf (deterministic exclusion).
        if source_rank is None:
            self._rank: Mapping[LabelSource, int] = _DEFAULT_RANK
        else:
            self._rank = dict(source_rank)

    def resolve(self, candidates: tuple[AddressLabel, ...]) -> AddressLabel | None:
        if not candidates:
            return None

        def _key(label: AddressLabel) -> tuple[float, float, float, int]:
            rank: float = self._rank.get(label.source, math.inf)
            # Higher confidence wins → invert so ``min`` picks max.
            confidence_neg = -label.confidence
            # More recent observed_at wins → invert sign on POSIX timestamp.
            observed_neg = -label.observed_at.timestamp()
            kind_idx = _KIND_ORDER.get(label.kind, len(_KIND_ORDER))
            return (rank, confidence_neg, observed_neg, kind_idx)

        ordered = sorted(candidates, key=_key)
        # Return the original instance — identity-preserving (behaviour 65).
        winner_key = _key(ordered[0])
        for candidate in candidates:
            if _key(candidate) == winner_key:
                return candidate
        return ordered[0]  # pragma: no cover - structurally unreachable


__all__ = ["LabelPriorityResolver"]
