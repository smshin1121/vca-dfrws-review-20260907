"""Address labeler package (P1-013).

Pure analysis surface — no HTTP, no DB, no asyncio. Detectors consume a
pre-built :class:`AddressActivity` and emit zero or more
:class:`AddressLabel` records. The tracer (P1-014) is the I/O orchestrator
that builds inputs and consumes outputs.

The ``EtherscanLabelClient`` HTTP fetcher is **deferred** to a follow-up
PR per R-LABEL-API. The :class:`LabelSource.ETHERSCAN`/``ARBISCAN`` enum
members and the priority resolver hooks ARE shipped now so the future
fetcher slots in without an enum churn (which would be a public-API
break).
"""

from vca.labeler._errors import LabelerError
from vca.labeler._types import (
    AddressActivity,
    AddressLabel,
    Evidence,
    EvidenceKind,
    LabelKind,
    LabelSource,
)
from vca.labeler.attribution import (
    TORNADO_POOL_DEFAULTS,
    ConvergenceLabeler,
    ConvergenceLabelerConfig,
    SmurfingSweepLabeler,
    SmurfingSweepLabelerConfig,
    TornadoOutputLabeler,
    TornadoOutputLabelerConfig,
    WalletSweepLabeler,
    WalletSweepLabelerConfig,
)
from vca.labeler.batch_payout import BatchPayoutDetector
from vca.labeler.btc_address_reuse import (
    BTC_REUSE_MIN_DEFAULT,
    BtcAddressReuseDetector,
    BtcReuseConfig,
    BtcReuseSample,
)
from vca.labeler.btc_patterns import (
    CoinJoinPoolEntryLabeler,
    CoinJoinPoolEntryLabelerConfig,
    PeelingChainLabeler,
    PeelingChainLabelerConfig,
    VaultLabeler,
    VaultLabelerConfig,
)
from vca.labeler.common_input import CommonInputDetector
from vca.labeler.eth_btc_ratio import (
    ETH_BTC_RATIO_TARGET_DEFAULT,
    EthBtcRatioConfig,
    EthBtcRatioDetector,
    EthBtcRatioSample,
)
from vca.labeler.exchange import (
    BITGET_37_DEPOSIT_DEFAULT,
    BitgetExchangeLabeler,
    BitgetExchangeLabelerConfig,
)
from vca.labeler.governance import (
    ARBOS_GOVERNANCE_SINK_DEFAULT,
    GovernanceLabeler,
    GovernanceLabelerConfig,
)
from vca.labeler.heuristics import HeuristicConfig, HeuristicDetector
from vca.labeler.priority import LabelPriorityResolver
from vca.labeler.router import (
    METAMASK_SWAP_ROUTER_DEFAULT,
    MetaMaskRouterLabeler,
    MetaMaskRouterLabelerConfig,
)
from vca.labeler.single_use import SingleUseDetector
from vca.labeler.vault import VaultDetector

__all__ = [
    "ARBOS_GOVERNANCE_SINK_DEFAULT",
    "BITGET_37_DEPOSIT_DEFAULT",
    "BTC_REUSE_MIN_DEFAULT",
    "ETH_BTC_RATIO_TARGET_DEFAULT",
    "METAMASK_SWAP_ROUTER_DEFAULT",
    "TORNADO_POOL_DEFAULTS",
    "AddressActivity",
    "AddressLabel",
    "BatchPayoutDetector",
    "BitgetExchangeLabeler",
    "BitgetExchangeLabelerConfig",
    "BtcAddressReuseDetector",
    "BtcReuseConfig",
    "BtcReuseSample",
    "CoinJoinPoolEntryLabeler",
    "CoinJoinPoolEntryLabelerConfig",
    "CommonInputDetector",
    "ConvergenceLabeler",
    "ConvergenceLabelerConfig",
    "EthBtcRatioConfig",
    "EthBtcRatioDetector",
    "EthBtcRatioSample",
    "Evidence",
    "EvidenceKind",
    "GovernanceLabeler",
    "GovernanceLabelerConfig",
    "HeuristicConfig",
    "HeuristicDetector",
    "LabelKind",
    "LabelPriorityResolver",
    "LabelSource",
    "LabelerError",
    "MetaMaskRouterLabeler",
    "MetaMaskRouterLabelerConfig",
    "PeelingChainLabeler",
    "PeelingChainLabelerConfig",
    "SingleUseDetector",
    "SmurfingSweepLabeler",
    "SmurfingSweepLabelerConfig",
    "TornadoOutputLabeler",
    "TornadoOutputLabelerConfig",
    "VaultDetector",
    "VaultLabeler",
    "VaultLabelerConfig",
    "WalletSweepLabeler",
    "WalletSweepLabelerConfig",
]
