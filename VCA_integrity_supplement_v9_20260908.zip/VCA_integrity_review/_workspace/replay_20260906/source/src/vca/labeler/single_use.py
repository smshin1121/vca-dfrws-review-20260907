"""SingleUseDetector — flags drained / immediately-forwarded receivers (P1-013).

A "single-use" address is one that received exactly one incoming transfer
AND either (b1) was drained to ``config.single_use_min_balance_minor``, or
(b2) sent at least one outgoing transfer within
``config.single_use_max_residence_seconds`` of receipt. KelpDAO Stage 2
Primary Receiver fires both forms simultaneously — b1 wins per
behaviour 37 because "drained AND fast" is more decisive than either alone.
"""

from __future__ import annotations

from datetime import datetime
from typing import Final

from vca.labeler._types import (
    AddressActivity,
    AddressLabel,
    Evidence,
    EvidenceKind,
    LabelKind,
    LabelSource,
)
from vca.labeler.heuristics import (
    HeuristicConfig,
    ensure_utc_now,
    residence_seconds,
)
from vca.types import NormalizedAddress

_NAME: Final[str] = "single_use"

# B2 confidence cap — keeps form b2 from outshining form b1 even when
# residence is near zero (DoD-16 / Appendix A).
_B2_CONFIDENCE_CAP = 0.85
_B2_CONFIDENCE_FLOOR = 0.5
_B1_CONFIDENCE = 0.85


class SingleUseDetector:
    """Pure detector — see module docstring for the algorithm."""

    name: str = _NAME
    source: LabelSource = LabelSource.HEURISTIC_SINGLE_USE
    kind: LabelKind = LabelKind.SINGLE_USE

    def __init__(self, config: HeuristicConfig) -> None:
        self._config = config

    def detect(
        self,
        activity: AddressActivity,
        *,
        now: datetime,
    ) -> tuple[AddressLabel, ...]:
        anchor = ensure_utc_now(now, detector=self.name)
        config = self._config

        if len(activity.incoming) != 1:
            return ()

        # Form b1: drained to the configured min balance.
        is_drained = (
            activity.balance_minor is not None
            and activity.balance_decimals is not None
            and activity.balance_minor == config.single_use_min_balance_minor
        )

        # Form b2: at least one outgoing within max_residence_seconds.
        incoming_ts = activity.transfer_timestamps[0]
        outgoing_offset = len(activity.incoming)
        outgoing_timestamps = activity.transfer_timestamps[outgoing_offset:]

        residence_b2: float | None = None
        if len(activity.outgoing) >= 1 and outgoing_timestamps:
            candidate = residence_seconds(start=incoming_ts, end=min(outgoing_timestamps))
            if 0 <= candidate <= config.single_use_max_residence_seconds:
                residence_b2 = candidate
        is_immediate = residence_b2 is not None

        if not (is_drained or is_immediate):
            return ()

        # Build evidence — SINGLE_INCOMING_TX is always present.
        first_incoming = activity.incoming[0]
        evidence_list: list[Evidence] = [
            Evidence(
                kind=EvidenceKind.SINGLE_INCOMING_TX,
                count=1,
                value_minor=first_incoming.amount.raw,
                decimals=first_incoming.amount.decimals,
                observed_at=incoming_ts,
            )
        ]

        if is_drained:
            assert activity.balance_minor is not None
            assert activity.balance_decimals is not None
            evidence_list.append(
                Evidence(
                    kind=EvidenceKind.BALANCE_ZERO,
                    value_minor=activity.balance_minor,
                    decimals=activity.balance_decimals,
                    observed_at=anchor,
                )
            )

        if is_immediate:
            assert residence_b2 is not None
            evidence_list.append(
                Evidence(
                    kind=EvidenceKind.IMMEDIATE_OUTGOING_TX,
                    count=len(activity.outgoing),
                    window_seconds=int(residence_b2),
                    observed_at=anchor,
                )
            )

        confidence = self._compute_confidence(
            is_drained=is_drained,
            residence_seconds_value=residence_b2,
        )

        label = AddressLabel(
            address=NormalizedAddress(address=activity.address),
            kind=self.kind,
            source=self.source,
            confidence=confidence,
            observed_at=anchor,
            evidence=tuple(evidence_list),
        )
        return (label,)

    def _compute_confidence(
        self,
        *,
        is_drained: bool,
        residence_seconds_value: float | None,
    ) -> float:
        """Per DoD-16: b1 = 0.85; b2 = clamp(1.0 - 0.5 * (t/max), [0.5, 0.85])."""
        if is_drained:
            return _B1_CONFIDENCE
        # b2 must hold when we reach this branch (caller guarantees).
        if residence_seconds_value is None:  # pragma: no cover - defensive
            return _B2_CONFIDENCE_FLOOR
        max_seconds = self._config.single_use_max_residence_seconds
        if max_seconds == 0:
            # Boundary: residence==0 (instant) — pin at the cap.
            return _B2_CONFIDENCE_CAP
        ratio = residence_seconds_value / max_seconds
        raw = 1.0 - 0.5 * ratio
        return max(_B2_CONFIDENCE_FLOOR, min(_B2_CONFIDENCE_CAP, raw))


__all__ = ["SingleUseDetector"]
