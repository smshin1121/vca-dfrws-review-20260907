"""BTC recipient-address reuse attribution detector (P3-XVAL3).

Cross-validation procedure ③ from the source analysis. Procedures ①
(``eth_btc_ratio``) and ② (wallet sweep / convergence) already exist; this
fills the gap: detect when the SAME BTC recipient (output) address is
reused as the destination of ≥2 distinct THORChain deposits. Reuse of one
BTC address across multiple deposits proves the controller continuously
holds that address's private key — a direct single-controller cluster
attribution signal.

This is a CLUSTER-AGGREGATION vertical, NOT a per-address ``fetch_label``
heuristic. The tracer assembles the deposit samples per reused BTC target
and invokes :meth:`BtcAddressReuseDetector.detect` at cluster-aggregation
time (mirroring :class:`vca.labeler.eth_btc_ratio.EthBtcRatioDetector`). It
is deliberately OUT of the per-address ``fetch_label`` seam in
:mod:`vca.cases.kelpdao_labeler` (see that module's docstring lines 20-27).

Source: ``KelpDAO_rsETH_Exploit_update.pdf`` section "(2) BTC 주소 재사용
패턴" (p30). The section heading AND the reuse table both sit on PDF p30
(verified against the source PDF; the attribution paragraph spills onto
p31). Re-confirmed byte-for-byte from the PDF (pages 30-32) before
pinning. Verbatim reuse table:

    "25건의 표본 분석 결과, 일부는 복수의 THORChain 입금 TX에 동일 BTC
    수신 주소를 반복 사용하였다."

    기호    발신 지갑       BTC 수신 주소                                재사용 횟수  합산 ETH
    ★       Exploiter 63    1A2quKSMVF7TUnirDdgnkeaLQHHTaQMTFo            2건         157.114
    ★★      Exploiter 32    bc1qky0x8yspdrf9y3an8hrn5gs3w4wz6n9wsjdum5    3건         244.608
    ★★★     Exploiter 25    bc1qc9tkq5truwlr4njvzy7l4yjr789gmzrjwswsvl    4건         907.660
    ★★★★    Exploiter 30    bc1q2ulr4h6tcmgz8r6l2u7u52x24s6mjjdpamd9wj    2건         382.741

    "BTC 주소 재사용은 단일 공격자가 해당 BTC 주소의 개인 키를 지속적으로
    보유·통제하고 있음을 직접 입증하는 귀속 증거이다. 특히 Exploiter 25는
    스머핑으로 분신되었던 ETH를 BTC 체인에서 단일 주소로 재통합하는 구조를
    취하였다. 반면 Exploiter 19·62·64·65·31·68은 매 TX마다 새로운 BTC
    주소를 사용하여 BTC 체인 추적을 어렵게 하였다."

Provenance split (P3-XVAL3 / XVAL-005): the detector fires on EVERY BTC
address reused by ≥2 distinct THORChain deposits in the live trace, but
only some of those targets are enumerated in the source PDF's 25-row
Stage-7 reuse table. A firing on a :attr:`BtcReuseConfig.paper_targets`
member is tagged ``extras["provenance"]="source_doc_verbatim"`` (paper
cross-validation, PDF p30); a firing on any other reused address is
tagged ``extras["provenance"]="graph_derived"`` (the tool applying the
paper's ``§3.5③`` recipient-address-reuse method to a target the PDF
sample did not list). The split is PROVENANCE, not certainty — reuse is a
deterministic on-chain count either way, so ``confidence`` stays ``1.0``
in both branches. The graph-measured ``reuse_count`` / ``total_eth`` are
always tagged ``extras["measure_source"]="graph_measured"`` and NEVER
claim the PDF's manually-tallied count (the two can drift: the graph sees
≥ the paper's 25-row sample).

LabelKind choice (R-NO-NEW-LABELKIND): :attr:`LabelKind.UNKNOWN`
(non-terminal). Same rationale as the :class:`EthBtcRatioDetector` twin
docstring lines 23-29: a terminal label here would prune the BFS at the
reused BTC address, defeating the downstream Stage 8 BTC layering analysis
which fans out FROM that very reused address. The semantic attribution role
is carried in ``extras["attribution_role"]="btc_address_reuse_attribution"``
for a downstream attribution scorer.

EvidenceKind choice (R-NO-NEW-ENUM): reuses the existing closed vocabulary
from :mod:`vca.labeler._types`. ``FAN_IN_COUNT`` carries the "N distinct
deposits fan into one reused BTC address" summary; one
``OUTPUT_UNIT_FREQUENCY`` per distinct deposit records that the same output
(recipient) address recurs across the deposit set — the literal meaning of
recipient-address reuse. No new enum member is introduced.

BTC addresses are compared verbatim (case-sensitive). The :class:`Address`
normalisation pipeline already lowercases bech32 and preserves base58 case,
so equality on the canonical ``Address.value`` is the correct BTC compare —
we do NOT additionally lowercase.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from datetime import UTC, datetime
from decimal import Decimal
from types import MappingProxyType
from typing import Any, Final

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    FieldSerializationInfo,
    field_serializer,
    field_validator,
    model_validator,
)

from vca.labeler._types import (
    AddressLabel,
    Evidence,
    EvidenceKind,
    LabelKind,
    LabelSource,
)
from vca.types import Address, ChainId, NormalizedAddress

# ---------------------------------------------------------------------------
# Module-level constants
# ---------------------------------------------------------------------------

_FROZEN_CONFIG: Final[ConfigDict] = ConfigDict(frozen=True, strict=True, extra="forbid")

# Minimum distinct deposits to the SAME BTC destination to flag reuse.
# The PDF reuse table's lowest "재사용 횟수" row is 2건 (★ Exploiter 63 /
# ★★★★ Exploiter 30), so 2 is the documented floor.
BTC_REUSE_MIN_DEFAULT: Final[int] = 2

# Operator-curated provenance tag. SSOT canon: every labeler module shares
# the single ``operator_pin_2026-05-12`` anchor pointing to the supplement
# PDF integration commit (db16ad2). This module integrates the SAME
# supplement PDF section, so it reuses the canonical tag rather than
# fracturing the single-anchor invariant (R-OPERATOR-PIN-TAG-CANONICAL).
_OPERATOR_PIN_TAG: Final[str] = "operator_pin_2026-05-12"
_PIN_CONFIDENCE: Final[float] = 1.0

_PROTOCOL_NAME: Final[str] = "THORChain BTC recipient-address reuse"
# SSOT canon: ``KelpDAO_rsETH_Exploit_update.pdf pNN`` (every labeler module
# shares this value shape; the descriptive section name "(2) BTC 주소 재사용
# 패턴" is recorded verbatim in the module docstring rather than embedded
# here, to preserve the R-LABELER-PDF-REFERENCE-CANONICAL value shape).
_PDF_REFERENCE: Final[str] = "KelpDAO_rsETH_Exploit_update.pdf p30"
_NAME: Final[str] = "btc_address_reuse_attribution"
_ATTRIBUTION_ROLE: Final[str] = "btc_address_reuse_attribution"

# Provenance-split extras values (P3-XVAL3 / XVAL-005). The split marks WHERE
# a reuse target came from (paper reuse table vs graph discovery), NOT how
# certain the attribution is — reuse ≥2x is a deterministic on-chain count in
# both cases, so ``_PIN_CONFIDENCE`` (1.0) is shared. ``_MEASURE_SOURCE_GRAPH``
# tags the count/amount fields as graph-measured so they never masquerade as
# the PDF's manual tally.
_PROVENANCE_SOURCE_DOC: Final[str] = "source_doc_verbatim"
_PROVENANCE_GRAPH_DERIVED: Final[str] = "graph_derived"
_MEASURE_SOURCE_GRAPH: Final[str] = "graph_measured"
_METHOD_REF: Final[str] = "§3.5③ BTC recipient-address reuse"


# ---------------------------------------------------------------------------
# Sample DTO
# ---------------------------------------------------------------------------


class BtcReuseSample(BaseModel):
    """One THORChain deposit observation for the BTC reuse detector.

    ``source_address``: EVM-side originator wallet (ETH or ARB).
    ``destination_btc_address``: BTC-side recipient (output) wallet.
    ``eth_input_amount``: ETH-side notional of this deposit (ETH units).
    ``deposit_ref``: THORChain deposit tx hash / unique id. Counts DISTINCT
        deposits so duplicate samples (e.g. the same deposit fetched from
        two cassette pages) do not inflate the reuse count.

    Cross-field rules:
        * ``eth_input_amount`` ≥ 0.
        * ``deposit_ref`` non-empty.
        * ``source_address.chain`` MUST be exactly ``ChainId.ETHEREUM`` or
          ``ChainId.ARBITRUM`` — same allow-list rationale as the
          :class:`EthBtcRatioSample` twin (a generic ``is_evm`` check would
          admit Unichain, which has no THORChain Stage 7 integration in
          Phase 1/2 scope).
        * ``destination_btc_address.chain`` MUST be BITCOIN.
    """

    model_config = _FROZEN_CONFIG

    source_address: Address
    destination_btc_address: Address
    eth_input_amount: Decimal = Field(ge=Decimal("0"))
    deposit_ref: str = Field(min_length=1)

    @field_validator("source_address")
    @classmethod
    def _validate_source_chain(cls, value: Address) -> Address:
        if value.chain not in (ChainId.ETHEREUM, ChainId.ARBITRUM):
            raise ValueError(
                f"BtcReuseSample.source_address must be ETH or ARB, got: {value.chain.value}"
            )
        return value

    @field_validator("destination_btc_address")
    @classmethod
    def _validate_destination_chain(cls, value: Address) -> Address:
        if value.chain is not ChainId.BITCOIN:
            raise ValueError(
                f"BtcReuseSample.destination_btc_address must be BITCOIN, got: {value.chain.value}"
            )
        return value


# ---------------------------------------------------------------------------
# Paper-provenance facts DTO
# ---------------------------------------------------------------------------


class PaperReuseFacts(BaseModel):
    """Paper-documented reuse facts for ONE BTC recipient address.

    Generic (case-agnostic) DTO owned by the labeler layer: a CASE module
    supplies the DATA (which BTC addresses the source PDF reuse table
    documents + the paper's manually-tallied reuse count and summed ETH),
    while this labeler stays case-neutral. Consumed via
    :attr:`BtcReuseConfig.paper_targets` to split emitted-label provenance
    between ``source_doc_verbatim`` (paper cross-validation) and
    ``graph_derived`` (a target the tool found by applying the paper's
    method).

    ``paper_count`` / ``paper_eth_sum`` are the PDF's manual figures —
    deliberately distinct from the graph-measured ``reuse_count`` /
    ``total_eth`` the detector computes, because the two can drift (the
    live graph sees ≥ the paper's 25-row Stage-7 sample). ``pdf_page``
    defaults to the reuse-table page (30).
    """

    model_config = _FROZEN_CONFIG

    paper_count: int = Field(ge=2)
    paper_eth_sum: Decimal = Field(ge=Decimal("0"))
    pdf_page: int = Field(default=30, ge=1)


# ---------------------------------------------------------------------------
# Config DTO
# ---------------------------------------------------------------------------


class BtcReuseConfig(BaseModel):
    """Frozen settings DTO for the BTC reuse attribution detector.

    Cross-field rules:
        * ``min_reuse`` ≥ 2 (a single deposit cannot evidence reuse).

    ``paper_targets`` maps a canonical BTC-address key (see
    :func:`paper_target_key`) to the :class:`PaperReuseFacts` the source
    PDF documents for that address. Empty by default (every firing is then
    ``graph_derived``); a case pass wires in its own paper roster. Only the
    labeler emits provenance — this DTO merely carries the roster. The
    validated roster is frozen to a read-only :class:`MappingProxyType`
    (see :meth:`_freeze_paper_targets`) so ``frozen=True`` — which blocks
    only attribute rebinding — cannot be side-stepped by mutating the
    mapping to flip a target's provenance after construction.
    """

    model_config = _FROZEN_CONFIG

    min_reuse: int = Field(default=BTC_REUSE_MIN_DEFAULT, ge=2)
    paper_targets: Mapping[str, PaperReuseFacts] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _freeze_paper_targets(self) -> BtcReuseConfig:
        """Deep-freeze the validated ``paper_targets`` mapping.

        Pydantic coerces the input (even a ``MappingProxyType``) to a plain
        mutable ``dict`` during validation; without this a caller holding the
        config could ``cfg.paper_targets[key] = ...`` and change a firing from
        ``graph_derived`` to ``source_doc_verbatim`` (or vice-versa). The
        values are already frozen :class:`PaperReuseFacts`; wrap the outer
        mapping via ``object.__setattr__`` (the frozen model blocks normal
        assignment).
        """
        object.__setattr__(self, "paper_targets", MappingProxyType(dict(self.paper_targets)))
        return self

    @field_serializer("paper_targets")
    def _serialize_paper_targets(
        self, value: Mapping[str, PaperReuseFacts], info: FieldSerializationInfo
    ) -> dict[str, dict[str, Any]]:
        """Project the frozen ``MappingProxyType`` roster → plain dict.

        P2-MAPPINGPROXY-JSON.1 — Pydantic v2's JSON encoder cannot serialise
        :class:`types.MappingProxyType` natively (it raises
        ``PydanticSerializationError`` on ``model_dump_json()``); the frozen
        roster installed by :meth:`_freeze_paper_targets` therefore needs a
        paired serializer. Values are nested :class:`PaperReuseFacts` models,
        so each is recursively dumped ``mode=info.mode`` — honouring the
        caller's mode preserves value types (``paper_eth_sum`` stays a
        :class:`~decimal.Decimal` under ``mode="python"`` so a ``strict=True``
        round-trip re-validates, and becomes a JSON string under
        ``mode="json"``). Iteration follows ``value.items()`` insertion order.
        """
        return {key: facts.model_dump(mode=info.mode) for key, facts in value.items()}


# ---------------------------------------------------------------------------
# Detector
# ---------------------------------------------------------------------------


def _ensure_utc(value: datetime) -> datetime:
    """Verify ``value`` is tz-aware UTC; raise ValueError otherwise."""
    if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
        raise ValueError("BtcAddressReuseDetector.detect now= must be tz-aware UTC")
    return value.astimezone(UTC)


def _btc_address_key(address: Address) -> str:
    """Chain-qualified verbatim key for a BTC :class:`Address`.

    BTC addresses are compared case-sensitively — base58 retains its case,
    bech32 is already lowercased by :func:`Address` normalisation, so the
    canonical ``value`` is the correct verbatim key. No additional
    lowercasing (which would corrupt base58 P2PKH equality).
    """
    return f"{address.chain.value}:{address.value}"


def paper_target_key(address: Address) -> str:
    """Public canonical key for a paper-reuse-target BTC :class:`Address`.

    Case modules build :attr:`BtcReuseConfig.paper_targets` maps keyed by
    THIS function so that lookups in
    :meth:`BtcAddressReuseDetector._build_label` (which key on the private
    :func:`_btc_address_key`) hit. Thin public wrapper so cross-package
    callers need not import an underscore-prefixed name (R-NO-PRIVATE-
    IMPORT). BTC addresses compare verbatim (base58 case-sensitive; bech32
    already lowercased by :class:`Address`).
    """
    return _btc_address_key(address)


class BtcAddressReuseDetector:
    """Emits an attribution label when one BTC dest is reused by ≥N deposits.

    See module docstring for the algorithm and SSOT.
    """

    name: str = _NAME
    source: LabelSource = LabelSource.OWN_DB
    kind: LabelKind = LabelKind.UNKNOWN

    def __init__(self, config: BtcReuseConfig) -> None:
        self._config = config

    def detect(
        self,
        *,
        samples: Iterable[BtcReuseSample],
        target_btc_address: Address,
        now: datetime,
    ) -> tuple[AddressLabel, ...]:
        """Emit at most one attribution label for ``target_btc_address``.

        Filters ``samples`` to deposits landing on ``target_btc_address``,
        dedupes by ``deposit_ref``, and emits one label iff the distinct
        deposit count meets ``config.min_reuse``.
        """
        anchor = _ensure_utc(now)
        if target_btc_address.chain is not ChainId.BITCOIN:
            raise ValueError(
                f"BtcAddressReuseDetector target_btc_address must be BITCOIN, got: "
                f"{target_btc_address.chain.value}"
            )

        target_key = _btc_address_key(target_btc_address)
        distinct = self._distinct_deposits(samples, target_key)
        if len(distinct) < self._config.min_reuse:
            return ()

        return (self._build_label(distinct, target_btc_address, anchor),)

    def _distinct_deposits(
        self, samples: Iterable[BtcReuseSample], target_key: str
    ) -> tuple[BtcReuseSample, ...]:
        """First-seen-wins dedupe by ``deposit_ref`` for target-bound samples."""
        seen: set[str] = set()
        distinct: list[BtcReuseSample] = []
        for sample in samples:
            if _btc_address_key(sample.destination_btc_address) != target_key:
                continue
            if sample.deposit_ref in seen:
                continue
            seen.add(sample.deposit_ref)
            distinct.append(sample)
        return tuple(distinct)

    def _build_label(
        self,
        deposits: tuple[BtcReuseSample, ...],
        target_btc_address: Address,
        anchor: datetime,
    ) -> AddressLabel:
        reuse_count = len(deposits)
        total_eth = sum((d.eth_input_amount for d in deposits), Decimal("0"))
        source_wallets = tuple(sorted({d.source_address.value for d in deposits}))

        evidence: list[Evidence] = [
            Evidence(
                kind=EvidenceKind.OUTPUT_UNIT_FREQUENCY,
                count=1,
                observed_at=anchor,
                extras={
                    "deposit_ref": deposit.deposit_ref,
                    "eth_input": str(deposit.eth_input_amount),
                    "source_wallet": deposit.source_address.value,
                },
            )
            for deposit in deposits
        ]
        evidence.append(
            Evidence(
                kind=EvidenceKind.FAN_IN_COUNT,
                count=reuse_count,
                observed_at=anchor,
            )
        )

        # Fields common to both provenance branches. reuse_count / total_eth
        # are ALWAYS ``graph_measured`` — they are the live-graph count and
        # NEVER the PDF's manual tally (which can differ; see docstring).
        extras: dict[str, object] = {
            "protocol": _PROTOCOL_NAME,
            "attribution_role": _ATTRIBUTION_ROLE,
            "reuse_count": str(reuse_count),
            "total_eth": str(total_eth),
            "source_wallets": source_wallets,
            "measure_source": _MEASURE_SOURCE_GRAPH,
        }
        # Provenance split: paper-documented target (PDF p30 reuse table) vs
        # graph-discovered reuse. Membership is keyed on the SAME canonical
        # key the case module builds :attr:`BtcReuseConfig.paper_targets` with.
        facts = self._config.paper_targets.get(_btc_address_key(target_btc_address))
        if facts is not None:
            # source_doc_verbatim: keep the operator source_pin + pdf_reference
            # breadcrumbs and attach the paper's manual count / ΣETH distinctly.
            extras.update(
                {
                    "provenance": _PROVENANCE_SOURCE_DOC,
                    "paper_documented": True,
                    "source_pin": _OPERATOR_PIN_TAG,
                    "pdf_reference": _PDF_REFERENCE,
                    "paper_count": facts.paper_count,
                    "paper_eth_sum": str(facts.paper_eth_sum),
                }
            )
        else:
            # graph_derived: NO pdf_reference, NO operator source_pin — never
            # misrepresent tool inference as paper cross-validation. Record the
            # method the tool applied instead of the operator pin.
            extras.update(
                {
                    "provenance": _PROVENANCE_GRAPH_DERIVED,
                    "paper_documented": False,
                    "source": _PROVENANCE_GRAPH_DERIVED,
                    "method_ref": _METHOD_REF,
                }
            )

        return AddressLabel(
            address=NormalizedAddress(address=target_btc_address),
            kind=self.kind,
            source=self.source,
            confidence=_PIN_CONFIDENCE,
            observed_at=anchor,
            evidence=tuple(evidence),
            extras=extras,
        )


def build_default_btc_address_reuse_detector(
    *,
    min_reuse: int = BTC_REUSE_MIN_DEFAULT,
) -> BtcAddressReuseDetector:
    """Build a :class:`BtcAddressReuseDetector` with the default ≥2 config."""
    return BtcAddressReuseDetector(BtcReuseConfig(min_reuse=min_reuse))


__all__ = [
    "BTC_REUSE_MIN_DEFAULT",
    "BtcAddressReuseDetector",
    "BtcReuseConfig",
    "BtcReuseSample",
    "PaperReuseFacts",
    "build_default_btc_address_reuse_detector",
    "paper_target_key",
]
