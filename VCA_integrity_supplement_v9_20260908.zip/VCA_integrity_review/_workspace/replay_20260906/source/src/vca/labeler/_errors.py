"""Typed ``LabelerError`` hierarchy (P1-013).

Mirrors :class:`vca.decoders.abi_fallback._errors.AbiFallbackError` shape —
each instance carries enough operator-replay context (``address``,
``detector``) for an investigator to re-run the offending detector against
the same :class:`vca.labeler.AddressActivity`. The base class is the only
catch-all consumer code should rely on; concrete subclasses identify the
failure mode so log filters can target a single class without sniffing
strings.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from vca.types import Address


class LabelerError(Exception):
    """Base class for all P1-013 labeler failures.

    Constructed positionally (``message``) plus keyword-only context. The
    detectors NEVER raise this on routine "no match" cases — they return
    ``()``. Subclasses are reserved for genuine bug-detection rails (e.g. an
    :class:`AddressActivity` that slipped past its cross-field validators
    yet is still internally inconsistent).
    """

    def __init__(
        self,
        message: str,
        *,
        address: Address | None = None,
        detector: str | None = None,
    ) -> None:
        super().__init__(message)
        self.address = address
        self.detector = detector


class HeuristicConfigError(LabelerError):
    """Raised when a :class:`HeuristicConfig` is internally inconsistent."""


class EvidenceShapeError(LabelerError):
    """Raised when an :class:`AddressActivity` is internally inconsistent.

    Defensive — the model_validators on
    :class:`vca.labeler.AddressActivity` should already have caught this.
    Surfacing the exception during ``detect`` is a bug-detection rail for
    future contributors who bypass the validator (e.g. via
    ``model_construct``).
    """


class LabelPriorityError(LabelerError):
    """Raised by :class:`LabelPriorityResolver` on contract violations."""


__all__ = [
    "EvidenceShapeError",
    "HeuristicConfigError",
    "LabelPriorityError",
    "LabelerError",
]
