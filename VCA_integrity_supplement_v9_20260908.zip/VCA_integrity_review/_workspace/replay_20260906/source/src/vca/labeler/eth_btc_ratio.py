"""ETH/BTC ratio attribution detector (P2-006.0).

Cross-stage attribution heuristic for THORChain Stage 7 swaps. When 3+
ETH→BTC swap samples converge to a consistent ratio near the configured
target (default 33.3 per supplement PDF page 47, within ±0.5% variance),
emit a single :class:`AddressLabel` attribution evidence record
confirming the swaps belong to a single laundering session.

Source: WBS §4.7 P2-006.0 — "ETH/BTC ratio = 33.3 attribution cross-
validation (~80 LoC, no new decoder) ratio variance ≤ 0.5%
R-RATIO-COHERENCE".

PDF page 47 verbatim:

    BTC 주소                                      ETH 투입   BTC 수령   ETH/BTC 비율
    bc1q58jsyfpknh5mdpdlxug5m8p90p330e0asn8swr   173.003    5.2094     33.2
    1A2quKSMVF7TUnirDdgnkeaLQHHTaQMTFo            157.114    4.7183     33.3
    bc1q5h8sx98qdks2zjp3aj37fr0qd4atzan833vtnv   175.350    5.2473     33.4

"These 3 single-source addresses' actual ETH/BTC ratio = 33.3 is
consistently observed."

LabelKind choice (R-NO-NEW-LABELKIND): :attr:`LabelKind.UNKNOWN`
(non-terminal). Same rationale as the P2-009.0 ``TornadoOutputLabeler``
codex round-1 P1 fix — a terminal label here would prune BFS at the
labeled target wallet, defeating downstream Stage 8 BTC layered analysis.
The semantic attribution role is carried in
``extras["attribution_role"]="eth_btc_ratio_attribution"`` for a
downstream attribution scorer.

API shape: ``detect(samples, target_address, *, now)`` takes a batch of
swap-level samples (not the per-address :class:`AddressActivity` that
heuristic detectors consume). The batch would be assembled per-target and
this detector invoked at cluster aggregation time, NOT per-address as part
of the heuristic detector pipeline.

DEAD-LEVER STATUS (XVAL-005 ① — honest closure). This detector is the paper's
cross-validation procedure ① (§3.5 exchange-rate check) and is DORMANT — but
NOT merely "unwired pending a future vertical". It is STRUCTURALLY dead against
the current graph model: :meth:`detect` consumes :class:`EthBtcRatioSample`
whose ``btc_output_amount`` is ``Field(gt=0)`` — a POSITIVE BTC-side output
amount. The only live-graph source of that amount for a THORChain ETH→BTC swap
is the swap hop's BTC-side output, i.e. ``CrossChainHop.amount_out``. Both
THORChain decoders emit ``amount_out=None`` (``thorchain.py`` +
``thorchain_vault.py``): the EVM deposit tx receipt carries the ETH-side INPUT
only — the BTC-side output settles on the Bitcoin chain, and there is no
authoritative ``src_tx → BTC-payout`` join to recover it. So no
:class:`EthBtcRatioSample` is buildable from the trace and this detector can
never fire; fabricating a timing/amount fixture to feed it would manufacture
evidence the chain does not contain. Contrast the twin cross-validation ③
(:class:`vca.labeler.btc_address_reuse.BtcAddressReuseDetector`), which IS
graph-derivable — source / target / tx_hash all survive on ``FlowEdge`` — and
is being wired by XVAL-005. The structural cause is pinned by
``tests/unit/labeler/test_eth_btc_ratio.py::TestEthBtcRatioDeadLever``.

Source pin tag ``operator_pin_2026-05-12`` traces every emission back
to the supplement PDF integration commit (db16ad2).
"""

from __future__ import annotations

from collections.abc import Iterable
from datetime import UTC, datetime
from decimal import Decimal
from typing import Final

from pydantic import BaseModel, ConfigDict, Field, field_validator

from vca.labeler._types import (
    AddressLabel,
    Evidence,
    EvidenceKind,
    LabelKind,
    LabelSource,
)
from vca.types import Address, ChainId, NormalizedAddress

# ---------------------------------------------------------------------------
# Module-level constants
# ---------------------------------------------------------------------------

_FROZEN_CONFIG: Final[ConfigDict] = ConfigDict(frozen=True, strict=True, extra="forbid")

# Defaults per WBS §4.7 + PDF p47.
ETH_BTC_RATIO_TARGET_DEFAULT: Final[Decimal] = Decimal("33.3")
ETH_BTC_RATIO_VARIANCE_PCT_DEFAULT: Final[Decimal] = Decimal("0.5")
ETH_BTC_RATIO_MIN_SAMPLES_DEFAULT: Final[int] = 3

# Operator-curated provenance tag.
_OPERATOR_PIN_TAG: Final[str] = "operator_pin_2026-05-12"
_PIN_CONFIDENCE: Final[float] = 1.0

_PROTOCOL_NAME: Final[str] = "THORChain ETH/BTC ratio cross-validation"
_PDF_REFERENCE: Final[str] = "KelpDAO_rsETH_Exploit_update.pdf p47"
_NAME: Final[str] = "eth_btc_ratio_attribution"
_ATTRIBUTION_ROLE: Final[str] = "eth_btc_ratio_attribution"
# Cycle 56 P2-LABELER-CHAIN-LABEL-CHAIN-SSOT.1 — provenance breadcrumb.
# The detector emits ETH-side ratio evidence anchored to the
# :attr:`EthBtcRatioSample.source_address`, which the field validator
# (line 119-137) restricts to ``ChainId.ETHEREUM`` or
# ``ChainId.ARBITRUM`` per supplement PDF p46-p47 (THORChain Stage 7
# admits both ETH mainnet and Arbitrum L2 source clusters). The
# ``_CHAIN_LABEL_DEFAULT`` constant pins the default fallback (the
# dominant cluster per PDF p47), while ``_CHAIN_LABEL_BY_TARGET_CHAIN``
# performs per-call dynamic dispatch on the ``target_address.chain``
# argument so Arbitrum-anchored evidence is correctly labelled
# ``arbitrum_one_l2`` rather than mis-stamped as Ethereum. Per codex
# F-BI (Cycle 56 round 1): a fixed constant would silently mislabel
# legitimate Arbitrum-side ratio evidence.
_CHAIN_LABEL: Final[str] = "ethereum_mainnet"
_CHAIN_LABEL_ARBITRUM: Final[str] = "arbitrum_one_l2"
# Per-target-chain dispatch table for the ``extras["chain"]`` breadcrumb.
# Keys cover the source-chain allowlist enforced by
# :meth:`EthBtcRatioSample._validate_source_chain` -- additions here MUST
# be paired with allowlist extension in the validator and a paired test
# class in the audit module.
_CHAIN_LABEL_BY_TARGET_CHAIN: Final[dict[ChainId, str]] = {
    ChainId.ETHEREUM: _CHAIN_LABEL,
    ChainId.ARBITRUM: _CHAIN_LABEL_ARBITRUM,
}


# ---------------------------------------------------------------------------
# Sample DTO
# ---------------------------------------------------------------------------


class EthBtcRatioSample(BaseModel):
    """One ETH→BTC swap sample for the ratio attribution detector.

    ``source_address``: EVM-side originator wallet.
    ``destination_btc_address``: BTC-side recipient wallet.
    ``eth_input_amount``: ETH-side notional (Decimal-exact in ETH units).
    ``btc_output_amount``: BTC-side notional (Decimal-exact in BTC units).

    Cross-field rules:
        * ``eth_input_amount`` ≥ 0.
        * ``btc_output_amount`` > 0 (zero would divide-by-zero).
        * ``source_address.chain`` MUST be exactly ``ChainId.ETHEREUM``
          or ``ChainId.ARBITRUM``. Codex round-2 P2 fix: a generic
          ``is_evm`` check would admit Unichain (also EVM) which has no
          THORChain Stage 7 integration in Phase 1/2 scope, producing
          false attribution labels.
        * ``destination_btc_address.chain`` MUST be BITCOIN.
    """

    model_config = _FROZEN_CONFIG

    source_address: Address
    destination_btc_address: Address
    eth_input_amount: Decimal = Field(ge=Decimal("0"))
    btc_output_amount: Decimal = Field(gt=Decimal("0"))

    @field_validator("source_address")
    @classmethod
    def _validate_source_chain(cls, value: Address) -> Address:
        # Codex P2-006.0 R2 P2 fix: explicit allow-list (ETH + ARB) rather
        # than broad ``is_evm`` check. THORChain Stage 7 ETH->BTC swaps
        # originate from Ethereum mainnet (the documented path); Arbitrum
        # is permitted because the supplement PDF p46 mentions the
        # ETH-side leg can also originate from ARB consolidation wallets
        # bridged back via LayerZero before THORChain. Unichain (also
        # ``is_evm``) has no THORChain integration in Phase 1/2 scope, so
        # admitting it would generate false attribution labels for
        # unrelated swap batches.
        from vca.types import ChainId

        if value.chain not in (ChainId.ETHEREUM, ChainId.ARBITRUM):
            raise ValueError(
                f"EthBtcRatioSample.source_address must be ETH or ARB, got: {value.chain.value}"
            )
        return value

    @field_validator("destination_btc_address")
    @classmethod
    def _validate_destination_chain(cls, value: Address) -> Address:
        from vca.types import ChainId

        if value.chain is not ChainId.BITCOIN:
            raise ValueError(
                f"EthBtcRatioSample.destination_btc_address must be BITCOIN, got: "
                f"{value.chain.value}"
            )
        return value

    @property
    def ratio(self) -> Decimal:
        """ETH/BTC ratio (eth_input / btc_output)."""
        return self.eth_input_amount / self.btc_output_amount


# ---------------------------------------------------------------------------
# Config DTO
# ---------------------------------------------------------------------------


class EthBtcRatioConfig(BaseModel):
    """Frozen settings DTO for the ETH/BTC ratio attribution detector.

    Cross-field rules:
        * ``target_ratio`` > 0.
        * ``max_variance_pct`` ≥ 0 (zero variance = exact match required).
        * ``min_samples`` ≥ 2.
    """

    model_config = _FROZEN_CONFIG

    target_ratio: Decimal = Field(default=ETH_BTC_RATIO_TARGET_DEFAULT, gt=Decimal("0"))
    max_variance_pct: Decimal = Field(default=ETH_BTC_RATIO_VARIANCE_PCT_DEFAULT, ge=Decimal("0"))
    min_samples: int = Field(default=ETH_BTC_RATIO_MIN_SAMPLES_DEFAULT, ge=2)


# ---------------------------------------------------------------------------
# Detector
# ---------------------------------------------------------------------------


def _ensure_utc(value: datetime) -> datetime:
    """Verify ``value`` is tz-aware UTC; raise ValueError otherwise."""
    if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
        raise ValueError("EthBtcRatioDetector.detect now= must be tz-aware UTC")
    return value.astimezone(UTC)


def _canonical_address_key(address: Address) -> str:
    """Chain-aware canonical comparison key for an :class:`Address`.

    Only used by :meth:`EthBtcRatioDetector.detect` to compare a
    target_address against per-sample ``source_address`` values. Both
    sides are constrained to EVM chains by the :class:`EthBtcRatioSample`
    field validator (``source_address`` is EVM-only), so the EVM branch
    is the structurally-reachable path. The fall-through still produces a
    correct chain-qualified key (BTC verbatim, EVM lowercased) and
    mirrors :func:`vca.tracer.graph.canonical_address_key` semantics so
    the helper remains drop-in-portable to other modules without
    surprises. The non-EVM branch is exercised indirectly via the
    :class:`EthBtcRatioSample.destination_btc_address` BTC pathway when
    embedded by the broader attribution pipeline.
    """
    if address.chain.is_evm:
        return f"{address.chain.value}:{address.value.lower()}"
    # pragma: no cover - BTC fall-through never reached for the detect()
    # call-site because the source_address validator restricts to EVM.
    return f"{address.chain.value}:{address.value}"  # pragma: no cover


def _within_variance(ratio: Decimal, target: Decimal, max_variance_pct: Decimal) -> bool:
    """``True`` iff ``|ratio - target| / target * 100`` ≤ ``max_variance_pct``.

    Precondition: ``target > 0`` — guaranteed by :class:`EthBtcRatioConfig`
    validators (``target_ratio: Decimal = Field(gt=Decimal("0"))``). No
    in-function divide-by-zero guard is needed because the only call site
    passes ``self._config.target_ratio`` which Pydantic has already
    constrained.
    """
    deviation_pct = abs(ratio - target) / target * Decimal("100")
    return deviation_pct <= max_variance_pct


class EthBtcRatioDetector:
    """Emits an attribution label when 3+ swap samples converge near a target ratio.

    See module docstring for the algorithm.
    """

    name: str = _NAME
    source: LabelSource = LabelSource.OWN_DB
    kind: LabelKind = LabelKind.UNKNOWN

    def __init__(self, config: EthBtcRatioConfig) -> None:
        self._config = config

    def detect(
        self,
        *,
        samples: Iterable[EthBtcRatioSample],
        target_address: Address,
        now: datetime,
    ) -> tuple[AddressLabel, ...]:
        """Emit at most one attribution label for ``target_address``.

        ``samples`` MUST originate from ``target_address`` — codex P2-006.0
        round-1 P2 finding. A mixed or mis-partitioned batch could
        otherwise falsely attribute ratio evidence to an unrelated target
        when the caller forgets to filter inputs. The pre-filter rejects
        samples whose ``source_address`` does not match ``target_address``
        (canonical-key compare via :class:`vca.types.NormalizedAddress`
        semantics — chain + lowercased EVM hex).
        """
        anchor = _ensure_utc(now)
        sample_tuple = tuple(samples)
        if len(sample_tuple) < self._config.min_samples:
            return ()

        # Codex P2-006.0 R1 P2 fix — drop samples whose source_address does
        # not match the requested target_address. Use a chain-aware
        # canonical comparison (EVM is case-insensitive in the hex
        # payload; the :class:`Address` value is EIP-55 mixed case, so
        # lowercase the hex for comparison).
        target_key = _canonical_address_key(target_address)
        connected: list[EthBtcRatioSample] = [
            s for s in sample_tuple if _canonical_address_key(s.source_address) == target_key
        ]
        if len(connected) < self._config.min_samples:
            return ()

        # Select the in-tolerance subset from the connected samples.
        in_tolerance: list[EthBtcRatioSample] = [
            s
            for s in connected
            if _within_variance(s.ratio, self._config.target_ratio, self._config.max_variance_pct)
        ]
        if len(in_tolerance) < self._config.min_samples:
            return ()

        ratios = tuple(s.ratio for s in in_tolerance)
        mean_ratio = sum(ratios, Decimal("0")) / Decimal(len(ratios))
        btc_destinations = tuple(s.destination_btc_address.value for s in in_tolerance)

        # Build evidence: one OUTPUT_UNIT_CLUSTER per sample + 1 FAN_IN_COUNT summary.
        evidence_list: list[Evidence] = []
        for sample in in_tolerance:
            evidence_list.append(
                Evidence(
                    kind=EvidenceKind.OUTPUT_UNIT_CLUSTER,
                    count=1,
                    observed_at=anchor,
                    extras={
                        "btc_destination": sample.destination_btc_address.value,
                        "eth_input": str(sample.eth_input_amount),
                        "btc_output": str(sample.btc_output_amount),
                        "ratio": str(sample.ratio),
                    },
                )
            )
        evidence_list.append(
            Evidence(
                kind=EvidenceKind.FAN_IN_COUNT,
                count=len(in_tolerance),
                observed_at=anchor,
            )
        )

        # Codex F-BI (C56 round 1) fix: derive ``"chain"`` breadcrumb from
        # the target_address.chain rather than a fixed constant, so
        # Arbitrum-side evidence is correctly labelled. Fallback to the
        # ETH default is documented but unreachable at the call site
        # because the connected-sample pre-filter (``source_address``
        # equality against ``target_address``) restricts target_address
        # to the EVM allowlist enforced by the sample validator.
        chain_label = _CHAIN_LABEL_BY_TARGET_CHAIN.get(target_address.chain, _CHAIN_LABEL)

        label = AddressLabel(
            address=NormalizedAddress(address=target_address),
            kind=self.kind,
            source=self.source,
            confidence=_PIN_CONFIDENCE,
            observed_at=anchor,
            evidence=tuple(evidence_list),
            extras={
                "protocol": _PROTOCOL_NAME,
                "source_pin": _OPERATOR_PIN_TAG,
                "pdf_reference": _PDF_REFERENCE,
                "chain": chain_label,
                "attribution_role": _ATTRIBUTION_ROLE,
                "target_ratio": str(self._config.target_ratio),
                "max_variance_pct": str(self._config.max_variance_pct),
                "mean_ratio": str(mean_ratio),
                "ratios": tuple(str(r) for r in ratios),
                "btc_destinations": btc_destinations,
            },
        )
        return (label,)


def build_default_eth_btc_ratio_detector(
    *,
    target_ratio: Decimal = ETH_BTC_RATIO_TARGET_DEFAULT,
    max_variance_pct: Decimal = ETH_BTC_RATIO_VARIANCE_PCT_DEFAULT,
    min_samples: int = ETH_BTC_RATIO_MIN_SAMPLES_DEFAULT,
) -> EthBtcRatioDetector:
    """Build an :class:`EthBtcRatioDetector` with the default 33.3 / ±0.5% config."""
    config = EthBtcRatioConfig(
        target_ratio=target_ratio,
        max_variance_pct=max_variance_pct,
        min_samples=min_samples,
    )
    return EthBtcRatioDetector(config)


__all__ = [
    "ETH_BTC_RATIO_MIN_SAMPLES_DEFAULT",
    "ETH_BTC_RATIO_TARGET_DEFAULT",
    "ETH_BTC_RATIO_VARIANCE_PCT_DEFAULT",
    "EthBtcRatioConfig",
    "EthBtcRatioDetector",
    "EthBtcRatioSample",
    "build_default_eth_btc_ratio_detector",
]
