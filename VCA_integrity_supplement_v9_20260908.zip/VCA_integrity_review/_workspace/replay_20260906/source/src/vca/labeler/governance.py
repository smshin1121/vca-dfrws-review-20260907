"""GovernanceLabeler — address-pin labeler for the Arbitrum arbOS sink (P2-004.0).

Recognises when an :class:`AddressActivity` targets the Arbitrum
governance sink — the destination address of Security Council Emergency
Action freezes. Supplement PDF page 22-23 (Stage 5) documents the
KelpDAO incident: on 2026-04-21 evening UTC, the Arbitrum Security
Council intervened on the L2→L1 withdrawal attempt of Exploiter 1's
30,766 ETH (~$71M, single wallet
``0x5d3919F12bCc35c26Eee5F8226A9bee90c257Ccc``) and routed the funds to
the special arbOS sink address (suffix ``DA0``).

Design notes:

* This is the **second non-heuristic labeler** in the package after
  :class:`vca.labeler.router.MetaMaskRouterLabeler` — the pin list is
  operator-curated so the source is :attr:`LabelSource.OWN_DB` (rank 0
  in the priority resolver). Heuristic-prefix evidence-required rule
  does NOT apply, so the labeler emits an empty evidence tuple.
* The chosen :class:`LabelKind` is :attr:`LabelKind.GOV_FROZEN` — the
  canonical existing enum value for "address holds funds frozen by a
  governance action". Per R-NO-NEW-LABELKIND no new enum member is
  added.
* The labeler satisfies the :class:`HeuristicDetector` protocol so the
  tracer (P1-014) treats it identically to the shipped detectors.
* The labeler is **chain-aware**: the arbOS governance sink is a
  protocol-level address on Arbitrum One (chain_id 42161). Even if a
  contract happens to share the same hex on Ethereum L1 or any other
  EVM chain, the pin MUST NOT fire — addresses are EVM-chain-segregated
  in :class:`vca.types.normalized.Address` so this restriction is a
  one-liner check against :attr:`ChainId.ARBITRUM`.
* PDF page-23 verbatim string is
  ``0x00000000000000000000000000000000000000DA0`` (41 hex chars after
  ``0x`` — one extra leading zero vs the canonical 40-char form). A
  20-byte EVM address is exactly 40 hex chars; the canonical pin we
  ship is :data:`ARBOS_GOVERNANCE_SINK_ADDRESS` and the discrepancy is
  documented by :data:`ARBOS_GOVERNANCE_SINK_PDF_FORM_LEN`.

Source pin tag ``operator_pin_2026-05-12`` traces every emission back to
the supplement PDF integration commit (db16ad2).
"""

from __future__ import annotations

from collections.abc import Iterable
from datetime import datetime
from typing import Any, Final

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from vca.labeler._types import (
    AddressActivity,
    AddressLabel,
    LabelKind,
    LabelSource,
)
from vca.labeler.heuristics import ensure_utc_now
from vca.types import Address, ChainId, NormalizedAddress

# Frozen Pydantic config — mirrors every other DTO in this package.
_FROZEN_CONFIG: Final[ConfigDict] = ConfigDict(frozen=True, strict=True, extra="forbid")

# Operator-curated provenance tag — embedded in every emitted label.extras
# so a downstream investigator can grep the codebase for the supplement
# PDF integration date (2026-05-12, commit db16ad2).
_OPERATOR_PIN_TAG: Final[str] = "operator_pin_2026-05-12"
_PROTOCOL_NAME: Final[str] = "Arbitrum Security Council Emergency Action"
_PDF_REFERENCE: Final[str] = "KelpDAO_rsETH_Exploit_update.pdf p23"
_CHAIN_LABEL: Final[str] = "arbitrum_one_l2"
_NAME: Final[str] = "arbitrum_security_council_emergency_action"
_PIN_CONFIDENCE: Final[float] = 1.0

# ---------------------------------------------------------------------------
# Address constants
# ---------------------------------------------------------------------------

# Canonical 20-byte form of the arbOS governance sink (40 hex chars after
# the ``0x`` prefix). The suffix ``DA0`` is the defining ArbOS-sink tail;
# the rest is zero-padded. EIP-55 checksum form happens to be all
# uppercase for this particular hex pattern (tested in
# ``test_default_pin_is_eip55_checksum``).
ARBOS_GOVERNANCE_SINK_ADDRESS: Final[str] = "0x0000000000000000000000000000000000000DA0"

# PDF page-23 verbatim form length (one extra leading zero, 41 chars after
# ``0x``). Documents the typo in the source material so future operators
# do not silently re-introduce it when copying from the PDF.
ARBOS_GOVERNANCE_SINK_PDF_FORM_LEN: Final[int] = 41


def _normalize_eip55_str(raw: str) -> str:
    """Run an address string through :class:`Address` so the EIP-55 form is
    returned. Wraps ``Address.from_str`` to give callers a string-in /
    string-out API for ``frozenset`` membership comparisons.
    """
    return Address.from_str(raw, ChainId.ARBITRUM).value


# Canonical arbOS sink, pinned at module load time so any import-time
# corruption surfaces immediately instead of at first detection.
ARBOS_GOVERNANCE_SINK_DEFAULT: frozenset[str] = frozenset(
    {_normalize_eip55_str(ARBOS_GOVERNANCE_SINK_ADDRESS)}
)


class GovernanceLabelerConfig(BaseModel):
    """Frozen settings DTO carrying the address whitelist.

    ``sink_addresses`` MAY hold any number of EIP-55 (or lowercase /
    mixed-case) Arbitrum-side contract addresses. The validator
    normalises every entry to its EIP-55 checksum form so lookup uses
    canonical strings only — callers therefore never need to pre-process
    pasted Arbiscan output. Empty sets are rejected because a labeler
    with no pins cannot emit anything (architecture error rather than
    silent no-op).
    """

    model_config = _FROZEN_CONFIG

    sink_addresses: frozenset[str] = Field(default=ARBOS_GOVERNANCE_SINK_DEFAULT)

    @field_validator("sink_addresses", mode="before")
    @classmethod
    def _normalize_addresses(cls, value: Any) -> Any:
        """Canonicalise every address to its EIP-55 form before the field is set.

        Accepts any iterable of strings (frozenset, set, tuple, list) and
        emits a ``frozenset`` of EIP-55 strings. Malformed addresses
        propagate as :class:`ValueError` from :meth:`Address.from_str`.
        """
        if isinstance(value, frozenset | set | tuple | list):
            return frozenset(_normalize_eip55_str(raw) for raw in value)
        return value  # let pydantic surface the type error

    @model_validator(mode="after")
    def _reject_empty(self) -> GovernanceLabelerConfig:
        if len(self.sink_addresses) == 0:
            raise ValueError(
                "GovernanceLabelerConfig.sink_addresses must not be empty; "
                "an address-whitelist labeler with zero pins cannot emit labels."
            )
        return self


class GovernanceLabeler:
    """Address-pin labeler for the Arbitrum arbOS governance sink.

    See module docstring for the algorithm.
    """

    name: str = _NAME
    source: LabelSource = LabelSource.OWN_DB
    kind: LabelKind = LabelKind.GOV_FROZEN

    def __init__(self, config: GovernanceLabelerConfig) -> None:
        self._config = config

    def detect(
        self,
        activity: AddressActivity,
        *,
        now: datetime,
    ) -> tuple[AddressLabel, ...]:
        anchor = ensure_utc_now(now, detector=self.name)

        # ARB-only pin: the arbOS governance sink is a protocol-level
        # address on Arbitrum One. Same hex on Ethereum L1 / Unichain /
        # BTC never matches, even if a contract happens to share the
        # bytes — addresses are chain-segregated in :class:`Address`.
        if activity.address.chain is not ChainId.ARBITRUM:
            return ()

        if activity.address.value not in self._config.sink_addresses:
            return ()

        label = AddressLabel(
            address=NormalizedAddress(address=activity.address),
            kind=self.kind,
            source=self.source,
            confidence=_PIN_CONFIDENCE,
            observed_at=anchor,
            extras={
                "protocol": _PROTOCOL_NAME,
                "source_pin": _OPERATOR_PIN_TAG,
                "pdf_reference": _PDF_REFERENCE,
                "chain": _CHAIN_LABEL,
            },
        )
        return (label,)


def build_default_labeler(
    *,
    extra_addresses: Iterable[str] = (),
) -> GovernanceLabeler:
    """Helper for callers who want the default pin plus a few extras.

    Useful when a future Arbitrum upgrade introduces an additional
    governance sink address without losing the canonical anchor.
    ``extra_addresses`` accepts any case; the
    :class:`GovernanceLabelerConfig` validator handles normalisation.
    """
    addresses = set(ARBOS_GOVERNANCE_SINK_DEFAULT) | set(extra_addresses)
    config = GovernanceLabelerConfig(sink_addresses=frozenset(addresses))
    return GovernanceLabeler(config)


__all__ = [
    "ARBOS_GOVERNANCE_SINK_ADDRESS",
    "ARBOS_GOVERNANCE_SINK_DEFAULT",
    "ARBOS_GOVERNANCE_SINK_PDF_FORM_LEN",
    "GovernanceLabeler",
    "GovernanceLabelerConfig",
    "build_default_labeler",
]
