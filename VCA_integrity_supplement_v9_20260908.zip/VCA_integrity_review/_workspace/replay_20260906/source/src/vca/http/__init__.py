"""VCA async HTTP layer (rate limit + retry + cache hooks).

Public re-exports for ``vca.http``. See ``_workspace/P0-007_architect_wbs.md``
and ``_workspace/P0-008_architect_wbs.md`` for the architectural decisions
behind this module.
"""

from vca.http.cache import RedisResponseCache, make_cache
from vca.http.client import (
    HttpClient,
    NoOpResponseCache,
    ResponseCache,
    params_hash,
)
from vca.http.limiter import RateLimiterRegistry

__all__ = [
    "HttpClient",
    "NoOpResponseCache",
    "RateLimiterRegistry",
    "RedisResponseCache",
    "ResponseCache",
    "make_cache",
    "params_hash",
]
