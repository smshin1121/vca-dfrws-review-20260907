"""Async HTTP client with per-source rate limit + retry + cache hooks (P0-007).

The client is **decoupled from raw-response storage** by design (decision D-B,
``_workspace/P0-007_architect_wbs.md``): only the cache is consulted here.
Raw payload persistence is the caller's job — the adapter layer (P1-003+)
explicitly invokes ``raw_store.put(...)`` after receiving a response.

The :class:`httpx.AsyncClient` is **injected from the outside** so tests
(``MockTransport``) and the future VCR.py cassette mode (P0-009,
``transport=vcr_transport``) can swap the wire layer without touching
production code.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Callable, Mapping
from types import TracebackType
from typing import Any, Final, Protocol, Self, cast, runtime_checkable

import httpx
from tenacity import (
    AsyncRetrying,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential,
)

from vca.http.limiter import RateLimiterRegistry

# Status codes worth retrying. 408 (Timeout), 425 (Too Early), 429 (Rate
# limited), and 5xx server errors are the classic transient set.
_RETRYABLE_STATUS: Final[frozenset[int]] = frozenset({408, 425, 429, 500, 502, 503, 504})

# API key parameter names that must NOT be part of the cache key — rotating a
# key would otherwise invalidate the entire cache (decision D-J).
_DEFAULT_CACHE_KEY_EXCLUDES: frozenset[str] = frozenset({"apikey", "api_key"})

_MAX_ATTEMPTS: Final[int] = 5


def params_hash(
    params: Mapping[str, Any],
    *,
    url: str | None = None,
    exclude: frozenset[str] = _DEFAULT_CACHE_KEY_EXCLUDES,
) -> str:
    """SHA-1 hex (40 chars) of canonical-JSON params, with secrets removed.

    ``sort_keys=True`` and compact separators make the encoding deterministic
    across processes; ``ensure_ascii=False`` preserves non-ASCII tokens (the
    raw_store helper, P0-006, uses the identical algorithm so cache keys and
    storage keys collide cleanly).

    The SHA-1 here is a non-cryptographic content fingerprint —
    ``usedforsecurity=False`` documents intent and silences FIPS warnings.

    Codex round-3 P2-6: the optional keyword-only *url* parameter is folded
    into the hash input so callers whose endpoints have no query string can
    rely on the URL itself to disambiguate cache rows. The mempool BTC
    adapter sets ``url=<full URL>`` and ``params={}``; pre-existing callers
    (Etherscan, anything that already passes real query params) keep
    ``url=None`` and observe identical hash output to the pre-fix
    implementation.

    The encoding is ``"<json-params>|<url-or-empty>"`` so the URL
    contribution is unambiguous and prefix-free against the JSON encoding
    of the params.
    """
    filtered = {k: v for k, v in params.items() if k not in exclude}
    blob = json.dumps(
        filtered,
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
    )
    if url is not None:
        blob = f"{blob}|{url}"
    return hashlib.sha1(blob.encode("utf-8"), usedforsecurity=False).hexdigest()


@runtime_checkable
class ResponseCache(Protocol):
    """Cache protocol consumed by :class:`HttpClient`.

    Implementations: :class:`NoOpResponseCache` (dev/tests),
    ``RedisResponseCache`` (P0-008).

    ``delete`` exists so :meth:`HttpClient.get_json` can evict a pre-existing
    poisoned entry when a caller-supplied validator rejects a cache hit
    (Codex round-4 P2-5). Failure modes follow the same "downgrade to
    miss/no-op" semantics as ``get`` / ``set``.

    **Codex round-2 P2-5 (P0-007 surface expansion)**: value typing widened
    from ``dict[str, Any]`` to ``Any`` so :meth:`HttpClient.get_json_any`
    can cache list / scalar / dict bodies through the same Protocol.
    Round-trip JSON encoding (``json.dumps`` in
    :class:`vca.http.cache.RedisResponseCache`) already accepts any
    JSON-serialisable value; the only practical change is that the
    Redis-backed get path no longer rejects non-dict roots (which were
    fatal under the old Protocol but legitimate for mempool list
    responses). Pre-existing :meth:`HttpClient.get_json` callers still
    receive ``dict[str, Any]`` because that method's own contract is
    unchanged.
    """

    async def get(self, key: str) -> Any | None: ...

    async def set(self, key: str, value: Any, ttl: int | None) -> None: ...

    async def delete(self, key: str) -> None: ...


class NoOpResponseCache:
    """Cache that never stores anything. Used in dev/test or before P0-008."""

    async def get(self, key: str) -> Any | None:
        _ = key
        return None

    async def set(self, key: str, value: Any, ttl: int | None) -> None:
        _ = (key, value, ttl)

    async def delete(self, key: str) -> None:
        _ = key


def _is_retryable(exc: BaseException) -> bool:
    """Return True iff *exc* is a transient failure worth retrying."""
    if isinstance(exc, httpx.TransportError):
        return True
    if isinstance(exc, httpx.HTTPStatusError):
        return exc.response.status_code in _RETRYABLE_STATUS
    return False


class HttpClient:
    """Async HTTP client with rate limit + tenacity retry + cache hooks.

    Lifecycle: construct with an externally-owned :class:`httpx.AsyncClient`
    (``MockTransport`` for tests; real transport in production). Use as
    ``async with`` or call :meth:`aclose` explicitly to release the underlying
    connection pool.
    """

    def __init__(
        self,
        *,
        client: httpx.AsyncClient,
        limiter: RateLimiterRegistry,
        cache: ResponseCache,
    ) -> None:
        self._client = client
        self._limiter = limiter
        self._cache = cache

    async def get_json(
        self,
        url: str,
        params: Mapping[str, Any],
        *,
        source: str,
        ttl: int | None = None,
        cache_key_excludes: frozenset[str] = _DEFAULT_CACHE_KEY_EXCLUDES,
        validator: Callable[[dict[str, Any]], bool] | None = None,
    ) -> dict[str, Any]:
        """Fetch *url* with *params*, returning the parsed JSON object.

        Cache hit:
            * No validator → return cached value as-is (no transport call,
              no token consumed). Pre-validator back-compat path.
            * Validator supplied → evaluate it against the cached entry.
              Approves → return cached. Rejects → evict the poisoned entry
              via ``cache.delete`` and fall through to the fetch path so a
              fresh response is retrieved and re-cached.

        Cache miss → acquire source token, GET, retry on transient failure,
        run *validator* if supplied, ``cache.set()`` only when the validator
        approves (or no validator is supplied).

        Args:
            url: Absolute URL or path resolved against the inner client's
                ``base_url``.
            params: Query string parameters. Secrets ought to live in headers,
                but ``cache_key_excludes`` provides a defense in depth.
            source: Rate-limit bucket name registered in the
                :class:`RateLimiterRegistry`.
            ttl: Cache time-to-live in seconds, or ``None`` for no expiry.
            cache_key_excludes: Param names dropped before hashing (default:
                ``apikey``/``api_key``).
            validator: Optional pure-inspection predicate. When supplied, it
                gates BOTH the cache.get hit path (round-4 P2-5: a pre-existing
                poisoned entry is evicted and refetched) and the cache.set
                write path (round-3 P1-2: a fresh error envelope is not
                cached). Returning ``False`` keeps the response flowing to the
                caller so the adapter can persist evidence and raise a typed
                error. Returning ``True`` (or supplying ``None``) preserves
                the pre-existing cache-everything behaviour. Any exception
                raised by the validator propagates to the caller.

        Raises:
            httpx.HTTPStatusError: Non-retryable 4xx, or retry budget exhausted
                on a retryable status.
            httpx.TransportError: Retry budget exhausted on a transport error.
            KeyError: ``source`` is not registered in the limiter.

        Notes:
            The ``dict[str, Any]`` return type is a **static contract** —
            callers' validators are responsible for verifying that the
            wire body is a JSON object. Codex round-3 P2-7 removed the
            round-2 runtime ``isinstance(payload, dict)`` guard because
            it raised BEFORE the adapter could persist raw evidence,
            breaking the raw-persist-on-error invariant. Adapters whose
            endpoints may return non-dict bodies should use
            :meth:`get_json_any` and re-narrow at the adapter boundary
            with their own validator + raw-persist + typed-error raise.
        """
        # Adapt the dict-typed validator (back-compat surface) to the
        # ``Any``-typed predicate that ``_get_any`` consumes.
        any_validator: Callable[[Any], bool] | None
        if validator is None:
            any_validator = None
        else:
            dict_validator = validator

            def any_validator(payload: Any) -> bool:
                # Codex round-6 P2-12: a non-dict cached value (scalar /
                # list / str / bool — legitimately stored by a different
                # ``get_json_any`` consumer, or written by a future bug)
                # would otherwise be handed to the dict-typed predicate
                # and crash with ``TypeError`` / ``AttributeError`` deep
                # inside the production validator. The exception would
                # short-circuit the round-4 ``cache.delete`` eviction
                # path so the poison stays cached forever. Treat the
                # entry as a False verdict here so the round-4 eviction
                # path runs and the dict validator only ever sees a
                # ``dict``. ``isinstance(..., dict)`` (not the broader
                # ``Mapping``) matches ``dict_validator``'s static
                # ``dict[str, Any]`` parameter so mypy ``--strict``
                # narrows correctly without a cast.
                if not isinstance(payload, dict):
                    return False
                return dict_validator(payload)

        payload = await self._get_any(
            url,
            params,
            source=source,
            ttl=ttl,
            cache_key_excludes=cache_key_excludes,
            validator=any_validator,
        )
        # Codex round-3 P2-7: the round-2 runtime ``isinstance(payload, dict)``
        # guard short-circuited BEFORE the adapter could persist raw
        # evidence on shape failures, breaking the raw-persist-on-error
        # invariant. The dict-typed return is now a STATIC contract
        # only; runtime enforcement is delegated to the caller's
        # validator (each production caller's validator includes an
        # ``isinstance(payload, Mapping)`` defence-in-depth check).
        # ``cast`` keeps mypy happy at the boundary without re-introducing
        # the raise.
        return cast("dict[str, Any]", payload)

    async def get_json_any(
        self,
        url: str,
        params: Mapping[str, Any],
        *,
        source: str,
        ttl: int | None = None,
        cache_key_excludes: frozenset[str] = _DEFAULT_CACHE_KEY_EXCLUDES,
        validator: Callable[[Any], bool] | None = None,
    ) -> Any:
        """Fetch *url* with *params*, returning the parsed JSON value as-is.

        Codex round-2 P2-5 (P0-007 surface expansion). The third surface
        addition — round 3 added ``validator``, round 4 added
        :meth:`ResponseCache.delete`, this round adds ``get_json_any`` so
        adapters whose endpoints return list / scalar / dict bodies can
        share the same retry / rate-limit / cache plumbing as
        :meth:`get_json` instead of reaching past the public surface (the
        pre-fix ``BitcoinAdapter._fetch_list_via_httpx`` shim that
        bypassed tenacity retry).

        Behavioural contract is identical to :meth:`get_json` — same
        cache-hit gating, same cache-write gating via *validator*, same
        retry budget via :class:`tenacity.AsyncRetrying`, same rate-limit
        bucket — but the return type is widened to :class:`typing.Any` so
        the JSON root may be a ``dict``, ``list``, ``str``, ``int``,
        ``float``, ``bool`` or ``None``. The *validator* signature is
        therefore widened to ``Callable[[Any], bool]``.
        """
        return await self._get_any(
            url,
            params,
            source=source,
            ttl=ttl,
            cache_key_excludes=cache_key_excludes,
            validator=validator,
        )

    async def _get_any(
        self,
        url: str,
        params: Mapping[str, Any],
        *,
        source: str,
        ttl: int | None,
        cache_key_excludes: frozenset[str],
        validator: Callable[[Any], bool] | None,
    ) -> Any:
        """Shared cache-gated fetch path consumed by ``get_json`` and ``get_json_any``.

        The single source of truth keeps the retry / rate-limit / validator
        plumbing identical for both methods (round-2 P2-5 invariant: any
        future fix to one method must apply to both by construction).
        """
        # Validate the source up-front so that an unknown identifier cannot
        # silently succeed by hitting a stale cache entry (Codex P2).
        # This consumes no rate-limit token; tokens are still only taken when
        # we actually go to the wire.
        self._limiter.ensure_registered(source)

        # Codex round-3 P2-6: fold the request URL into the cache key so
        # endpoints whose query string is empty (mempool path-only URLs)
        # disambiguate cleanly. Pre-existing callers with real query params
        # see no behavioural change beyond a one-time cache rotation —
        # the URL is now part of the hash for every call.
        cache_key = f"{source}:{params_hash(params, url=url, exclude=cache_key_excludes)}"
        cached = await self._cache.get(cache_key)
        if cached is not None:
            # Codex P2-5 (round 4): gate the cache.get hit path on the
            # caller-supplied validator. A poisoned entry written before
            # round 3 (or by a caller that didn't supply a validator) would
            # otherwise be served forever under ``historical_ttl_sec=None``.
            # Evict via ``cache.delete`` so a concurrent reader cannot serve
            # the poison while the refetch is in flight.
            if validator is None or validator(cached):
                return cached
            await self._cache.delete(cache_key)

        payload = await self._fetch_with_retry(url, params, source=source)
        # Codex P1-2 (round 3): gate the cache write on caller-supplied
        # validation. Etherscan returns 200 OK with status="0" for auth/rate-
        # limit failures; without this gate the error envelope poisons the
        # ``historical_ttl_sec=None`` cache permanently.
        if validator is None or validator(payload):
            await self._cache.set(cache_key, payload, ttl)
        return payload

    async def _fetch_with_retry(
        self,
        url: str,
        params: Mapping[str, Any],
        *,
        source: str,
    ) -> Any:
        """Run the rate-limited request through :class:`AsyncRetrying`.

        Using the explicit-loop form (decision D-K) instead of the decorator
        keeps the rate-limit acquisition and the response handling inside one
        readable, testable block. ``reraise=True`` lets the original exception
        surface unchanged when the budget is exhausted.

        Codex round-2 P2-5: return type widened from ``dict[str, Any]`` to
        :class:`typing.Any` so the shared path can serve list / scalar
        bodies via :meth:`get_json_any`. :meth:`get_json` re-narrows at
        its own boundary.
        """
        retrying = AsyncRetrying(
            stop=stop_after_attempt(_MAX_ATTEMPTS),
            wait=wait_exponential(multiplier=1, min=1, max=30),
            retry=retry_if_exception(_is_retryable),
            reraise=True,
        )
        payload: Any = None
        async for attempt in retrying:
            with attempt:
                payload = await self._do_request(url, params, source=source)
        return payload

    async def _do_request(
        self,
        url: str,
        params: Mapping[str, Any],
        *,
        source: str,
    ) -> Any:
        """One rate-limited GET → JSON. May raise retryable exceptions.

        Codex round-2 P2-5: ``response.json()`` may legitimately return a
        ``list`` / ``str`` / ``int`` / ``bool`` / ``None`` for callers
        routed through :meth:`get_json_any` (mempool's address-txs list
        endpoint). The helper no longer narrows here; callers re-narrow
        at the public method boundary if needed.
        """
        async with self._limiter.acquire(source):
            response = await self._client.get(url, params=dict(params))
        response.raise_for_status()
        data: Any = response.json()
        return data

    async def aclose(self) -> None:
        """Close the underlying :class:`httpx.AsyncClient`."""
        await self._client.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.aclose()
