"""Redis-backed ``ResponseCache`` implementation (P0-008).

Conforms to :class:`vca.http.client.ResponseCache` — the Protocol declared in
P0-007. The routing factory :func:`make_cache` returns a
:class:`vca.http.client.NoOpResponseCache` when ``settings.vca_redis_url`` is
empty/missing so dev and CI runs can opt out of Redis without code changes.

SQLite/in-memory fallback is intentionally **not** in scope for this PR
(architect decision D-B, ``_workspace/P0-008_architect_wbs.md``): caches are
ephemeral, and a missing Redis is best modeled as a NoOp rather than a
secondary persistent store.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Final

from redis.asyncio import Redis as AsyncRedis

from vca.http.client import NoOpResponseCache, ResponseCache

logger = logging.getLogger(__name__)

# Namespace every Redis key under a fixed prefix so VCA can share a Redis
# instance with other systems without colliding (decision D-F).
_KEY_PREFIX: Final[str] = "vca:cache:"


class RedisResponseCache:
    """Async Redis cache satisfying the ``ResponseCache`` Protocol."""

    def __init__(self, redis: AsyncRedis) -> None:
        self._redis = redis

    async def get(self, key: str) -> Any | None:
        """Fetch *key* from Redis, decoding JSON.

        Failure modes are downgraded to cache misses (decisions D-G/D-H):

        * Underlying :class:`redis.RedisError` (or any unexpected exception)
          → ``None`` + WARNING.
        * Stored bytes that fail JSON decode → ``None`` + WARNING.

        Codex round-2 P2-5 (P0-007 surface expansion): the historical
        ``isinstance(decoded, dict)`` guard was removed. The Protocol
        value typing has widened from ``dict[str, Any]`` to
        :class:`typing.Any` so :meth:`HttpClient.get_json_any` can cache
        list / scalar bodies (mempool's address-txs endpoint). Callers
        of :meth:`HttpClient.get_json` still receive a dict because that
        method re-narrows at its own boundary; the underlying cache no
        longer drops legitimate non-dict entries.
        """
        prefixed = _KEY_PREFIX + key
        try:
            raw = await self._redis.get(prefixed)
        except Exception:
            # Cache failures must never break the caller — surface as miss.
            logger.warning(
                "redis get failed, returning cache miss: key=%s",
                key,
                exc_info=True,
            )
            return None
        if raw is None:
            return None
        try:
            decoded: Any = json.loads(raw)
        except (json.JSONDecodeError, TypeError, ValueError):
            logger.warning("corrupted cache entry, dropping: key=%s", key)
            return None
        return decoded

    async def set(self, key: str, value: Any, ttl: int | None) -> None:
        """Store *value* under *key* with optional TTL.

        Encoding mirrors P0-006/P0-007 canonical JSON (``sort_keys=True``,
        ``ensure_ascii=False``, compact separators) so cache and storage keys
        remain consistent across processes (decision D-D). ``ttl <= 0`` and
        ``ttl is None`` map to "no expiration" — Redis rejects ``EX 0``, so the
        branch is required (decision D-E).
        """
        prefixed = _KEY_PREFIX + key
        # ITER-81: a cache WRITE failure must never break the caller — the
        # documented contract is "ANY failure -> cache miss" (decisions D-G/D-H,
        # class docstring), already honoured by get()/delete(). set() was the one
        # method missing this arm, so a json.dumps TypeError (unserializable value)
        # or a redis-py error (ConnectionError/TimeoutError/…) propagated into
        # HttpClient._get_any() and crashed the client. Broad ``Exception`` is
        # intentional and matches the get()/delete() arms: the contract downgrades
        # any failure to a silent no-op. ``key`` is a non-secret hash (matches the
        # get() log site); the value/payload is never logged.
        try:
            encoded = json.dumps(
                value,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8")
            if ttl is None or ttl <= 0:
                await self._redis.set(prefixed, encoded)
            else:
                await self._redis.set(prefixed, encoded, ex=ttl)
        except Exception:
            logger.warning(
                "redis set failed, skipping cache write: key=%s",
                key,
                exc_info=True,
            )

    async def delete(self, key: str) -> None:
        """Evict *key* from Redis.

        Used by :meth:`HttpClient.get_json` to drop a cached entry whose
        contents were rejected by a caller-supplied validator (Codex round-4
        P2-5). Failure modes mirror :meth:`get` / :meth:`set`: any underlying
        :class:`redis.RedisError` (or unexpected exception) is downgraded to a
        WARNING + silent no-op so a caching glitch never breaks the caller.
        Redis ``DEL`` on a missing key is itself a no-op (returns 0), so this
        method is idempotent without an explicit ``EXISTS`` round-trip.
        """
        prefixed = _KEY_PREFIX + key
        try:
            await self._redis.delete(prefixed)
        except Exception:
            logger.warning(
                "redis delete failed, treating as no-op: key=%s",
                key,
                exc_info=True,
            )

    async def aclose(self) -> None:
        """Release the underlying Redis connection pool."""
        await self._redis.aclose()


def make_cache(settings: Any) -> ResponseCache:
    """Build a ResponseCache from *settings*.

    Returns :class:`NoOpResponseCache` when ``settings.vca_redis_url`` is
    empty/missing; otherwise wraps a lazily-connecting
    :class:`redis.asyncio.Redis` in :class:`RedisResponseCache`.

    The factory accepts ``Any`` rather than ``Settings`` so adapter and CLI
    callers can pass a duck-typed stub during bootstrap without importing the
    full pydantic-settings model.
    """
    url = getattr(settings, "vca_redis_url", "") or ""
    if not url:
        return NoOpResponseCache()
    redis = AsyncRedis.from_url(url, decode_responses=False)
    return RedisResponseCache(redis)
