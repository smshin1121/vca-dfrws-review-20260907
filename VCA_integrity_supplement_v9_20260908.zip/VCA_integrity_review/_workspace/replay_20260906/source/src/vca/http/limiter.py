"""Per-source async rate limiter registry (P0-007).

Each adapter (Etherscan, mempool.space, ...) owns an independent token bucket
sized in requests-per-second. The registry hands out :class:`AsyncLimiter`
instances that callers ``async with`` to consume a token; the underlying
bucket refills automatically over its 1-second window.

Architectural decision D-F (`_workspace/P0-007_architect_wbs.md`): single
process only. Distributed rate limiting (Redis token bucket) is deferred to a
future phase.
"""

from __future__ import annotations

from collections.abc import Mapping
from contextlib import AbstractAsyncContextManager

from aiolimiter import AsyncLimiter


class RateLimiterRegistry:
    """Hold one :class:`AsyncLimiter` per source identifier.

    Args:
        source_limits: Mapping of source name → requests-per-second cap.
            Each entry's rps must be a positive integer.

    Raises:
        ValueError: ``source_limits`` is empty or contains rps < 1.
    """

    def __init__(self, source_limits: Mapping[str, int]) -> None:
        if not source_limits:
            raise ValueError("source_limits must not be empty")
        for source, rps in source_limits.items():
            if rps < 1:
                raise ValueError(f"rps for {source!r} must be >= 1, got {rps}")
        # AsyncLimiter(max_rate, time_period) — rps tokens per 1 second.
        self._limiters: dict[str, AsyncLimiter] = {
            source: AsyncLimiter(rps, 1) for source, rps in source_limits.items()
        }

    def ensure_registered(self, source: str) -> None:
        """Raise :class:`KeyError` when *source* is not registered.

        Use this to validate a source identifier before a cache lookup so that
        misconfigured callers cannot bypass the rate limiter by serving cached
        responses for unknown sources.
        """
        if source not in self._limiters:
            raise KeyError(
                f"no rate limiter registered for source={source!r} "
                f"(known: {sorted(self._limiters)})"
            )

    def acquire(self, source: str) -> AbstractAsyncContextManager[None]:
        """Return an ``async with`` token for *source*.

        Raises:
            KeyError: *source* was not registered at construction time.
        """
        self.ensure_registered(source)
        return self._limiters[source]

    def __contains__(self, source: object) -> bool:
        return isinstance(source, str) and source in self._limiters

    @property
    def sources(self) -> frozenset[str]:
        """Immutable view of registered source names."""
        return frozenset(self._limiters)
