"""Normalized, chain-agnostic domain types (P1-001 + P1-002).

Single source of truth for the immutable DTOs that flow through the VCA
pipeline. See :mod:`vca.types.normalized` for the core P1-001 surface and
:mod:`vca.types._adapter_io` for the P1-002 adapter helper types.
"""

from vca.types._adapter_io import (
    Balance,
    Cursor,
    NormalizedLog,
    Page,
)
from vca.types.normalized import (
    Address,
    Amount,
    Asset,
    BlockRef,
    ChainId,
    ContractAddr,
    CrossChainHop,
    DecodedCall,
    ExtractedTarget,
    NormalizedAddress,
    NormalizedTransaction,
    NormalizedTransfer,
    TxHash,
    stable_dump_json,
)

__all__ = [
    "Address",
    "Amount",
    "Asset",
    "Balance",
    "BlockRef",
    "ChainId",
    "ContractAddr",
    "CrossChainHop",
    "Cursor",
    "DecodedCall",
    "ExtractedTarget",
    "NormalizedAddress",
    "NormalizedLog",
    "NormalizedTransaction",
    "NormalizedTransfer",
    "Page",
    "TxHash",
    "stable_dump_json",
]
