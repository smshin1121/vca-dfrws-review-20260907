"""Recursive-freeze pipeline for ``extras`` / ``params`` mappings (P1-012 R-FREEZE-LIFT).

Lifted from :mod:`vca.decoders.base` (P1-008) and :mod:`vca.types.normalized`
(P1-001) once a third caller — :class:`vca.decoders.abi_fallback.RecoveredAbi`
— surfaced. P1-008's builder note explicitly committed to lifting on the
third call site; P1-012 is that third caller.

The helpers are pure functions; they do not depend on any specific Pydantic
model. The error messages embed a ``label`` ("DefiAction.extras",
"DecodedCall.params", "RecoveredAbi.extras") so the validator that calls
them can produce field-specific diagnostics without duplicating the
walking logic.
"""

from __future__ import annotations

import math
from collections.abc import Mapping
from types import MappingProxyType
from typing import Any, Final

# Allowed JSON-friendly leaf scalars. ``bool`` must come before ``int`` in
# any isinstance chain because ``bool`` subclasses ``int`` — but here the
# tuple membership test lets ``isinstance(value, _SCALAR_TYPES)`` accept
# both without ordering concerns.
_SCALAR_TYPES: Final[tuple[type, ...]] = (str, bool, int, float, type(None))


def check_str_keys(mapping: Mapping[Any, Any], *, label: str) -> None:
    """Enforce ``str`` keys at every nesting level of an extras/params mapping.

    Non-str keys would survive in-process equality but ``model_dump_json``
    coerces them to their string repr; ``model_validate_json`` then re-reads
    the JSON object with those stringified keys, so the round-tripped model
    is no longer equal to the original.

    The ``label`` argument is spliced into the error message so the caller's
    field name (e.g. ``"DefiAction.extras"``) appears verbatim — both the
    P1-008 ``DefiAction.extras`` validator and the P1-001 ``DecodedCall.params``
    validator already shape their messages this way; the lifted helper
    preserves that contract.
    """
    for key in mapping:
        if not isinstance(key, str):
            raise ValueError(  # noqa: TRY004 - pydantic value-domain validator
                f"{label}: dict key must be str, got {type(key).__name__!r} (key={key!r})"
            )


def freeze_extras_value(value: Any, *, label: str) -> Any:
    """Recursively freeze ``value`` into a JSON-friendly immutable form.

    * ``dict`` → :class:`types.MappingProxyType` over recursively frozen items.
    * ``list``/``tuple`` → ``tuple`` of recursively frozen items.
    * ``MappingProxyType`` → re-wrapped after recursing.
    * Allowed scalars (``str`` / ``bool`` / ``int`` / finite ``float`` / ``None``)
      pass through unchanged.
    * ``bytes`` and non-finite floats raise :class:`ValueError` because they
      do not round-trip through ``model_dump_json`` →
      ``model_validate_json``.
    * Anything else raises :class:`ValueError` so arbitrary user instances
      cannot leak into a deeply-immutable model.
    """
    if isinstance(value, MappingProxyType):
        check_str_keys(value, label=label)
        return MappingProxyType({k: freeze_extras_value(v, label=label) for k, v in value.items()})
    if isinstance(value, dict):
        check_str_keys(value, label=label)
        return MappingProxyType({k: freeze_extras_value(v, label=label) for k, v in value.items()})
    if isinstance(value, (list, tuple)):
        return tuple(freeze_extras_value(v, label=label) for v in value)
    if isinstance(value, bytes):
        raise ValueError(  # noqa: TRY004 - pydantic value-domain validator
            f"{label}: leaf type 'bytes' is not allowed "
            "(model_dump_json raises on non-utf-8 bytes; would break round-trip)"
        )
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError(
            f"{label}: non-finite float {value!r} is not allowed "
            "(serialises as null; would break round-trip equality)"
        )
    if isinstance(value, _SCALAR_TYPES):
        return value
    raise ValueError(
        f"{label}: unsupported value type {type(value).__name__!r}; "
        "only JSON-friendly scalars and nested dict/list are allowed"
    )


def thaw_extras_value(value: Any) -> Any:
    """Inverse of :func:`freeze_extras_value` for serialisation paths.

    Pydantic's JSON encoder rejects :class:`types.MappingProxyType`, so we
    surface plain ``dict`` / ``list`` shapes on the wire. Bytes pass through
    — Pydantic itself handles bytes-to-base64 / bytes-to-string at JSON time.
    """
    if isinstance(value, MappingProxyType):
        return {k: thaw_extras_value(v) for k, v in value.items()}
    if isinstance(value, dict):
        return {k: thaw_extras_value(v) for k, v in value.items()}
    if isinstance(value, tuple):
        return [thaw_extras_value(v) for v in value]
    return value


__all__ = [
    "check_str_keys",
    "freeze_extras_value",
    "thaw_extras_value",
]
