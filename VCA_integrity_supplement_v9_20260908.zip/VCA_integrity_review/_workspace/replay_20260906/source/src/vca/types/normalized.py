"""Normalized, chain-agnostic domain types (P1-001).

This module is the single source of truth for the immutable DTOs that flow
through the entire VCA pipeline: ChainAdapter → BridgeDecoder → FlowTracer
→ Labeler → Reporter. Every model is frozen (Pydantic v2 ``frozen=True``)
and forbids extra fields so accidental schema drift surfaces immediately.

Design notes
------------
* Monetary values use ``int`` minor units + ``int`` decimals — never
  ``float`` or ``Decimal`` arithmetic. ``decimal.Decimal`` is used only as
  a parsing helper inside :meth:`Amount.from_human` / :meth:`Amount.to_human`.
* Datetimes are always tz-aware UTC. Naive inputs raise ``ValidationError``;
  non-UTC aware inputs are normalised to UTC.
* Address normalisation: EVM addresses use EIP-55 (via ``eth_utils``); BTC
  addresses use the in-house :mod:`vca.types._bech32` helper.

See ``_workspace/P1-001_architect_wbs.md`` for the full WBS.
"""

from __future__ import annotations

import json
import re
import uuid
from collections.abc import Mapping
from datetime import UTC, datetime
from decimal import Decimal
from enum import StrEnum
from typing import Annotated, Any, Final, NewType, Self, overload

from eth_utils import is_hex_address, to_checksum_address  # type: ignore[attr-defined]
from pydantic import (
    BaseModel,
    BeforeValidator,
    ConfigDict,
    Field,
    StrictInt,
    field_serializer,
    field_validator,
    model_validator,
)

from vca.types._bech32 import normalize_btc_address
from vca.types._extras_freeze import check_str_keys as _check_str_keys_shared
from vca.types._extras_freeze import freeze_extras_value as _freeze_extras_value_shared
from vca.types._extras_freeze import thaw_extras_value as _thaw_extras_value_shared

# ---------------------------------------------------------------------------
# Shared model config
# ---------------------------------------------------------------------------

# ``strict=True`` matches the architect's WBS §4 requirement and was
# erroneously dropped in round 1 to ease JSON deserialisation. Round 6
# restores strict mode and routes the legitimate JSON convenience paths
# (string → :class:`ChainId`, list → ``tuple``) through
# :class:`pydantic.BeforeValidator` aliases below — strict mode now blocks
# silent corruption (bool→int, str→int) while keeping the public API
# unchanged.
_FROZEN_CONFIG: Final[ConfigDict] = ConfigDict(frozen=True, strict=True, extra="forbid")


def _reject_bool(v: Any, *, field: str) -> Any:
    """Reject ``bool`` values for fields typed as :class:`pydantic.StrictInt`.

    ``bool`` is a subclass of ``int`` in Python (``isinstance(True, int) is
    True``), so ``StrictInt`` alone happily accepts ``True``/``False`` and
    silently stores them as ``1``/``0``. Any field where booleans are
    semantically nonsense (decimals, monetary minor units, etc.) must route
    through this helper as a ``mode="before"`` validator. Sharing one
    module-level helper across :class:`Amount` and :class:`Asset` keeps the
    rejection message format (and rationale) in one place — the round-4 fix
    inlined this inside ``Amount`` only; round 5 lifted it out so ``Asset``
    can reuse the same gate without copy-paste.
    """
    if isinstance(v, bool):
        raise ValueError(  # noqa: TRY004 - pydantic value-domain validator
            f"{field} must be int, not bool"
        )
    return v


def _validate_status_zero_or_one(v: Any) -> Any:
    """Strict 0/1/None gate for :attr:`NormalizedTransaction.status`.

    Round 7 used ``Literal[0, 1] | None`` directly, but Pydantic v2 matches
    ``Literal`` members by **equality before strictness applies**, so
    ``True``/``False`` (subclass of int) and ``1.0``/``0.0`` (``__eq__`` to
    ``1``/``0``) coerce silently into ``status=1``/``status=0``. Round-8
    P2-23 routes the field through this ``mode="before"`` validator that
    delegates to the module-level :func:`_reject_bool` helper and then
    requires a true ``int`` (not ``float``) whose value is exactly ``0`` or
    ``1``. ``None`` short-circuits so the field stays optional.
    """
    if v is None:
        return None
    _reject_bool(v, field="status")
    # ``not isinstance(v, int)`` rejects ``float`` (1.0 / 0.0); ``bool`` was
    # already rejected above so the surviving ``int`` check is precise.
    if not isinstance(v, int) or v not in (0, 1):
        raise ValueError(f"status must be 0 or 1 (or None), got {v!r}")
    return v


_HEX_ADDRESS_RE: Final[re.Pattern[str]] = re.compile(r"0x[0-9a-fA-F]{40}")
# P1-012 R-INPUT-FIELD: ``NormalizedTransaction.input`` may be empty
# (``""`` / ``"0x"``) or any even-length hex string after the ``0x`` prefix.
# The regex anchors via :func:`re.fullmatch`; allowed total length is 2
# (just ``0x``) or any 2+2k hex form (selector + arg-words).
_HEX_CALLDATA_RE: Final[re.Pattern[str]] = re.compile(r"0x([0-9a-fA-F]{2})*")
# Tx-hash regexes drop the explicit ``^...$`` anchors because the validator
# uses :func:`re.fullmatch` (round-6 P2-20). ``re.match(r"^...$", value)``
# accepts trailing ``\n`` because ``$`` matches the end of the line, not the
# end of the string by default — :func:`re.fullmatch` rejects any non-matching
# tail character including ``\n``.
_EVM_TX_HASH_RE: Final[re.Pattern[str]] = re.compile(r"0x[0-9a-fA-F]{64}")
_BTC_TX_HASH_RE: Final[re.Pattern[str]] = re.compile(r"[0-9a-fA-F]{64}")


# ---------------------------------------------------------------------------
# 1) ChainId + hex NewType identifiers
# ---------------------------------------------------------------------------


class ChainId(StrEnum):
    """Supported chains for VCA Phase 0/1.

    ``UNICHAIN`` was added in P1-009 so LayerZero V2 EID 30320 maps to a
    real enum member rather than a sentinel. Unichain is an OP-Stack EVM
    rollup (gas paid in ETH, 18 decimals) and the KelpDAO exploit's
    cross-chain hop originates there (source §2.다.3 line 43). Phase 1
    treats Unichain as ``src_chain``-only — we have no Unichain adapter
    yet, so the labeler and tracer recognise it solely via this enum.
    """

    ETHEREUM = "eth"
    ARBITRUM = "arb"
    BITCOIN = "btc"
    UNICHAIN = "unichain"

    @classmethod
    def from_str(cls, raw: str) -> ChainId:
        """Parse a chain identifier; accept canonical or human-friendly forms."""
        if not isinstance(raw, str):
            raise TypeError(f"ChainId expects str, got {type(raw).__name__}")
        token = raw.strip().lower()
        aliases = {
            "eth": cls.ETHEREUM,
            "ethereum": cls.ETHEREUM,
            "arb": cls.ARBITRUM,
            "arbitrum": cls.ARBITRUM,
            "btc": cls.BITCOIN,
            "bitcoin": cls.BITCOIN,
            "unichain": cls.UNICHAIN,
        }
        try:
            return aliases[token]
        except KeyError as exc:
            raise ValueError(f"unknown chain id: {raw!r}") from exc

    @property
    def is_evm(self) -> bool:
        return self in (ChainId.ETHEREUM, ChainId.ARBITRUM, ChainId.UNICHAIN)

    @property
    def native_symbol(self) -> str:
        return "BTC" if self is ChainId.BITCOIN else "ETH"

    @property
    def native_decimals(self) -> int:
        return 8 if self is ChainId.BITCOIN else 18


def _coerce_chain_id(value: Any) -> Any:
    """Strict-mode pre-coercion for :class:`ChainId` fields.

    Strict Pydantic rejects ``str → StrEnum`` coercion outright; without this
    pre-validator, every ``model_validate_json`` call (where ``chain`` lands
    as a plain ``"eth"`` string) would raise. We accept already-typed
    :class:`ChainId` instances unchanged and route every other ``str`` through
    :meth:`ChainId.from_str` so the alias-table (``"ethereum"``, ``"ETH"``,
    etc.) keeps working uniformly between Python and JSON callers.
    """
    if isinstance(value, ChainId):
        return value
    if isinstance(value, str):
        return ChainId.from_str(value)
    return value


# Annotated aliases so chain-bearing fields can stay annotated as ``ChainId``
# / ``ChainId | None`` while still admitting the legitimate JSON-string input.
ChainIdField = Annotated[ChainId, BeforeValidator(_coerce_chain_id)]
OptionalChainIdField = Annotated[ChainId | None, BeforeValidator(_coerce_chain_id)]


def _validate_optional_calldata(value: Any) -> Any:
    """Pre-validate :attr:`NormalizedTransaction.input` (P1-012 R-INPUT-FIELD).

    Accepts:
    * ``None`` — explicit "no calldata" (BTC, contract-creation).
    * ``""`` or ``"0x"`` — EVM "no calldata" sentinel.
    * ``"0x" + <even-length hex>`` — full calldata; lowercase-normalised.

    Rejects everything else with :class:`ValueError`. ``BeforeValidator``
    runs *before* the strict ``str | None`` annotation check, so non-string
    inputs (e.g. ``int``) propagate to Pydantic as a strict-type error
    rather than landing in the regex branch.
    """
    if value is None:
        return None
    if not isinstance(value, str):
        # Defer to Pydantic's strict-type message for the type-mismatch case.
        return value
    if value == "":
        return ""
    if not value.startswith("0x"):
        raise ValueError(f"input must start with 0x or be empty, got: {value!r}")
    # ``0x`` alone is the explicit "no calldata" form.
    if value == "0x":
        return "0x"
    # The remaining suffix must be non-empty even-length hex.
    suffix = value[2:]
    if len(suffix) % 2 != 0:
        raise ValueError(
            f"input must have an even number of hex digits after 0x prefix, "
            f"got {len(suffix)}: {value!r}"
        )
    if not _HEX_CALLDATA_RE.fullmatch(value):
        raise ValueError(f"input must match 0x[0-9a-fA-F]* hex form, got: {value!r}")
    return value.lower()


def _coerce_to_tuple(value: Any) -> Any:
    """Pre-coerce ``list`` → ``tuple`` for tuple-typed collection fields.

    ``model_dump_json`` emits a JSON array for any tuple field; the inverse
    ``model_validate_json`` parse therefore yields a Python ``list``. Strict
    mode refuses the implicit ``list → tuple`` conversion, so every tuple
    field that may originate from JSON wraps this validator. Other input
    shapes are returned unchanged so Pydantic can surface the natural type
    mismatch error.
    """
    if isinstance(value, list):
        return tuple(value)
    return value


# Hex identifiers are typed as NewType for readability; runtime validation
# lives on the model classes that wrap them (Address, NormalizedTransaction).
TxHash = NewType("TxHash", str)
ContractAddr = NewType("ContractAddr", str)


# ---------------------------------------------------------------------------
# 2) Address
# ---------------------------------------------------------------------------


def _normalize_evm_address(raw: str) -> str:
    """Return EIP-55 checksummed form. Raises ValueError for malformed input."""
    if not isinstance(raw, str) or not _HEX_ADDRESS_RE.fullmatch(raw):
        raise ValueError(f"invalid EVM hex address: {raw!r}")
    if not is_hex_address(raw):
        raise ValueError(f"invalid EVM address: {raw!r}")
    return to_checksum_address(raw)


def _normalize_address_value(raw: str, chain: ChainId) -> str:
    if chain.is_evm:
        return _normalize_evm_address(raw)
    return normalize_btc_address(raw)


class Address(BaseModel):
    """Chain-scoped address. EIP-55 (EVM) / bech32 + base58check (BTC)."""

    model_config = _FROZEN_CONFIG

    chain: ChainIdField
    value: str = Field(..., description="canonical address string")

    @model_validator(mode="before")
    @classmethod
    def _normalize_value(cls, data: Any) -> Any:
        """Run the same normalization pipeline as ``from_str`` for nested validation.

        Without this, lower-case EVM hex (or any case-insensitive bech32) survives
        ``model_validate`` / ``model_validate_json`` unchanged, which breaks
        equality and hashing across construction paths. We normalise *before*
        field validation so the stored ``value`` is always canonical.
        """
        if not isinstance(data, dict):
            return data
        chain_in = data.get("chain")
        value_in = data.get("value")
        if chain_in is None or value_in is None:
            return data
        # Coerce chain (StrEnum value or str alias) to ChainId.
        chain = chain_in if isinstance(chain_in, ChainId) else ChainId.from_str(str(chain_in))
        if not isinstance(value_in, str):
            # Pydantic translates ValueError → ValidationError; TypeError would
            # surface differently in non-validator callers. Stay consistent
            # with the rest of this module's input-coercion idiom.
            raise ValueError(  # noqa: TRY004 - value-domain validator path
                f"Address.value must be str, got {type(value_in).__name__}"
            )
        normalized = _normalize_address_value(value_in, chain)
        return {**data, "chain": chain, "value": normalized}

    @classmethod
    def from_str(cls, raw: str, chain: ChainId) -> Self:
        return cls(chain=chain, value=_normalize_address_value(raw, chain))

    def short(self, head: int = 6, tail: int = 4) -> str:
        if head + tail >= len(self.value):
            return self.value
        return f"{self.value[:head]}...{self.value[-tail:]}"

    def __str__(self) -> str:
        return f"{self.chain.value}:{self.value}"

    def __hash__(self) -> int:
        return hash((self.chain.value, self.value))


# ---------------------------------------------------------------------------
# 3) Asset / Amount
# ---------------------------------------------------------------------------


class Asset(BaseModel):
    """Chain-scoped asset definition (native coin or ERC-20-style token).

    ``decimals`` is :class:`pydantic.StrictInt` for the same reason
    :class:`Amount` is — lax-mode coercion of ``"18"``/``18.0`` corrupts the
    downstream ``to_human``/``from_human`` math. ``bool`` is rejected by the
    module-level :func:`_reject_bool` pre-validator (shared with
    :class:`Amount`) because ``True`` is officially ``isinstance(True, int)``
    and would slip through ``StrictInt`` otherwise.
    """

    model_config = _FROZEN_CONFIG

    chain: ChainIdField
    symbol: str
    decimals: StrictInt = Field(ge=0, le=36)
    contract: Address | None = None

    @field_validator("decimals", mode="before")
    @classmethod
    def _reject_bool_decimals(cls, v: Any) -> Any:
        """Reject ``bool`` decimals — shares the module-level helper with Amount."""
        return _reject_bool(v, field="Asset.decimals")

    @model_validator(mode="after")
    def _validate_contract_chain(self) -> Self:
        """Reject Asset whose contract address is on a non-EVM or wrong chain.

        Two invariants enforced here:

        1. ``contract.chain == self.chain`` — otherwise downstream callers
           attribute an EVM token to a BTC asset (or vice versa) and the
           decimals/decoders pipeline silently produces nonsense.
        2. ``contract.chain.is_evm`` — token contracts are an EVM-only
           concept. The round-2 (1) check alone would let
           ``Asset.erc20(contract=<BTC addr>, chain=BITCOIN, ...)`` slip
           through (both chains equal BTC), but BTC has no token contracts
           so the field semantics are EVM-only.

        Native assets keep ``contract is None`` and bypass both checks — they
        remain legal on any chain (including BTC).
        """
        if self.contract is None:
            return self
        if self.contract.chain is not self.chain:
            raise ValueError(
                f"Asset.contract.chain mismatch for symbol={self.symbol!r}: "
                f"asset.chain={self.chain.value}, "
                f"contract.chain={self.contract.chain.value}"
            )
        if not self.contract.chain.is_evm:
            raise ValueError(
                f"Asset.contract must be on an EVM chain (non-EVM contract "
                f"rejected) for symbol={self.symbol!r}, got: "
                f"{self.contract.chain.value}"
            )
        return self

    @classmethod
    def native(cls, chain: ChainId) -> Self:
        return cls(
            chain=chain,
            symbol=chain.native_symbol,
            decimals=chain.native_decimals,
            contract=None,
        )

    @classmethod
    def erc20(cls, contract: Address, symbol: str, decimals: int) -> Self:
        return cls(chain=contract.chain, symbol=symbol, decimals=decimals, contract=contract)

    @property
    def is_native(self) -> bool:
        return self.contract is None


def _decimal_from_human(raw: str, decimals: int) -> int:
    """Parse a human decimal string into ``raw * 10**decimals`` (int).

    Rejects fractional digits beyond ``decimals`` and any non-numeric token.
    """
    if not isinstance(raw, str):
        raise TypeError(f"Amount.from_human expects str, got {type(raw).__name__}")
    token = raw.strip()
    if not token:
        raise ValueError("Amount.from_human empty input")
    if token.startswith("-"):
        raise ValueError("Amount.from_human does not accept negatives")
    try:
        # Decimal handles arbitrary precision; we never use it for arithmetic.
        d = Decimal(token)
    except Exception as exc:
        raise ValueError(f"invalid decimal: {raw!r}") from exc
    sign, digits, exponent = d.as_tuple()
    if sign:
        raise ValueError("Amount.from_human does not accept negatives")
    if not isinstance(exponent, int):
        # Non-finite Decimal (NaN/Infinity) — exponent is a special string
        # ("n", "N", "F"). The user's *input* was a valid str so this is a
        # value-domain failure, not a type error → ValueError, not TypeError.
        raise ValueError(  # noqa: TRY004 - value-domain check, not isinstance
            f"non-finite decimal not allowed: {raw!r}"
        )
    fractional_digits = -exponent if exponent < 0 else 0
    if fractional_digits > decimals:
        raise ValueError(
            f"value {raw!r} has {fractional_digits} fractional digits but "
            f"asset only supports {decimals}"
        )
    # Compose the integer mantissa and shift to minor units.
    mantissa = 0
    for digit in digits:
        mantissa = mantissa * 10 + int(digit)
    if exponent >= 0:
        return int(mantissa * (10 ** (exponent + decimals)))
    return int(mantissa * (10 ** (decimals + exponent)))


class Amount(BaseModel):
    """Integer minor unit (wei / satoshi / token-minor) + decimals.

    ``raw`` and ``decimals`` are typed as :class:`pydantic.StrictInt` so that
    Pydantic's lax coercion (str → int, float → int) cannot silently corrupt
    minor-unit money. ``StrictInt`` accepts any ``int`` instance, **including
    ``bool``** (because ``True`` is officially ``isinstance(True, int)``) — so
    the explicit pre-validator below rejects ``bool`` before the strict-int
    check runs. Without it, ``Amount(raw=True, decimals=18)`` would store
    ``raw=1`` and corrupt downstream accounting.
    """

    model_config = _FROZEN_CONFIG

    raw: StrictInt = Field(ge=0)
    decimals: StrictInt = Field(ge=0, le=36)

    @field_validator("raw", "decimals", mode="before")
    @classmethod
    def _reject_bool(cls, v: Any) -> Any:
        """Delegate to the module-level :func:`_reject_bool` helper.

        Round 5 lifted the rejection logic to module scope so :class:`Asset`
        can share the same gate without duplication.
        """
        return _reject_bool(v, field="Amount field")

    @classmethod
    def from_human(cls, value: str, decimals: int) -> Self:
        return cls(raw=_decimal_from_human(value, decimals), decimals=decimals)

    @classmethod
    def from_raw(cls, raw: int, decimals: int) -> Self:
        return cls(raw=raw, decimals=decimals)

    def to_human(self, *, trim_zeros: bool = True) -> str:
        if self.decimals == 0:
            return str(self.raw)
        scale = 10**self.decimals
        whole, frac = divmod(self.raw, scale)
        frac_str = f"{frac:0{self.decimals}d}"
        if trim_zeros:
            frac_str = frac_str.rstrip("0")
        if not frac_str:
            return str(whole)
        return f"{whole}.{frac_str}"

    def to_minor_str(self) -> str:
        return str(self.raw)

    def _require_same_decimals(self, other: Amount) -> None:
        if self.decimals != other.decimals:
            raise ValueError(f"Amount decimals mismatch: {self.decimals} vs {other.decimals}")

    def __add__(self, other: Amount) -> Amount:
        self._require_same_decimals(other)
        return Amount(raw=self.raw + other.raw, decimals=self.decimals)

    def __sub__(self, other: Amount) -> Amount:
        self._require_same_decimals(other)
        return Amount(raw=self.raw - other.raw, decimals=self.decimals)

    def __lt__(self, other: Amount) -> bool:
        self._require_same_decimals(other)
        return self.raw < other.raw


# ---------------------------------------------------------------------------
# 4) BlockRef
# ---------------------------------------------------------------------------


def _ensure_utc(value: datetime) -> datetime:
    if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
        raise ValueError("datetime must be timezone-aware (UTC)")
    return value.astimezone(UTC)


@overload
def _assume_utc(value: datetime) -> datetime: ...


@overload
def _assume_utc(value: None) -> None: ...


@overload
def _assume_utc(value: datetime | None) -> datetime | None: ...


def _assume_utc(value: datetime | None) -> datetime | None:
    """Tolerate SQLite's naive-datetime fallback for ``DateTime(timezone=True)``.

    SQLAlchemy + aiosqlite returns naive ``datetime`` objects for columns
    declared with ``timezone=True``; the underlying SQLite engine drops tz
    info on persistence. The DB-side value is always written from a tz-aware
    UTC datetime, so re-tagging a naive read with UTC restores the canonical
    form. This relaxation lives at the ``from_orm`` boundary only — direct
    DTO construction continues to use the strict :func:`_ensure_utc`
    validator. (Boundary rule: trust the DB, validate user input.)
    """
    if value is None:
        return None
    if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


class BlockRef(BaseModel):
    """Block identifier: EVM number / BTC height + tz-aware UTC timestamp."""

    model_config = _FROZEN_CONFIG

    chain: ChainIdField
    # ``StrictInt`` so strict mode rejects ``True``/``"1"`` etc. The round-1
    # decision to drop strict mode let those values silently coerce — codex
    # round 6 surfaced ``BlockRef(number=True)`` as a regression case.
    number: StrictInt = Field(ge=0)
    hash: str | None = None
    timestamp: datetime

    @field_validator("timestamp", mode="before")
    @classmethod
    def _coerce_timestamp(cls, v: Any) -> datetime:
        if isinstance(v, datetime):
            return _ensure_utc(v)
        if isinstance(v, str):
            # Pydantic will parse the string for us, but we need to enforce
            # tz-awareness too — defer to fromisoformat which keeps tz info.
            parsed = datetime.fromisoformat(v.replace("Z", "+00:00"))
            return _ensure_utc(parsed)
        raise ValueError(f"unsupported timestamp type: {type(v).__name__}")


# ---------------------------------------------------------------------------
# 5) NormalizedTransfer / NormalizedTransaction
# ---------------------------------------------------------------------------


class NormalizedTransfer(BaseModel):
    """Single value movement (EVM ERC-20 log or BTC vin/vout pair)."""

    model_config = _FROZEN_CONFIG

    log_index: StrictInt | None
    asset: Asset
    from_addr: Address | None
    to_addr: Address | None
    amount: Amount

    @model_validator(mode="after")
    def _amount_decimals_match_asset(self) -> Self:
        """Asset and Amount must agree on decimals; otherwise ``to_human`` lies."""
        if self.amount.decimals != self.asset.decimals:
            raise ValueError(
                f"NormalizedTransfer decimals mismatch for asset "
                f"{self.asset.symbol!r}: asset.decimals={self.asset.decimals}, "
                f"amount.decimals={self.amount.decimals}"
            )
        return self

    @model_validator(mode="after")
    def _endpoint_chains_match_asset(self) -> Self:
        """Non-null transfer endpoints must live on the same chain as the asset.

        Mint/burn (null endpoints) stay legal. Cross-chain movement is
        modelled by :class:`CrossChainHop`, never by a single transfer.
        """
        if self.from_addr is not None and self.from_addr.chain is not self.asset.chain:
            raise ValueError(
                f"NormalizedTransfer.from_addr.chain mismatch: "
                f"asset.chain={self.asset.chain.value}, "
                f"from_addr.chain={self.from_addr.chain.value}"
            )
        if self.to_addr is not None and self.to_addr.chain is not self.asset.chain:
            raise ValueError(
                f"NormalizedTransfer.to_addr.chain mismatch: "
                f"asset.chain={self.asset.chain.value}, "
                f"to_addr.chain={self.to_addr.chain.value}"
            )
        return self


def _validate_chain_tx_hash(chain: ChainId, value: str, *, field: str = "tx_hash") -> str:
    """Validate a chain-aware tx hash and return its canonical lowercase form.

    EVM (Ethereum/Arbitrum): ``0x`` + 64 lowercase hex.
    BTC: 64 lowercase hex (no ``0x`` prefix per Bitcoin convention).

    This helper is the single source of truth for tx-hash format checks —
    used by both :class:`NormalizedTransaction.tx_hash` and
    :class:`CrossChainHop.src_tx` so the rule never drifts between the two.
    The ``field`` argument lets the error message identify which field the
    bad value came from without a separate try/except in each call site.
    """
    if not isinstance(value, str):
        raise ValueError(  # noqa: TRY004 - value-domain validator path
            f"{field} must be str, got {type(value).__name__}"
        )
    if chain.is_evm:
        # ``re.fullmatch`` (not ``re.match`` with anchors) so trailing ``\n``
        # is rejected — codex round-6 P2-20.
        if not _EVM_TX_HASH_RE.fullmatch(value):
            raise ValueError(
                f"{field} must be 0x + 64 lowercase hex for chain={chain.value}, got: {value}"
            )
        return value.lower()
    # BTC
    if not _BTC_TX_HASH_RE.fullmatch(value):
        raise ValueError(
            f"{field} must be 0x + 64 lowercase hex (BTC: 64 hex, no 0x) "
            f"for chain={chain.value}, got: {value}"
        )
    return value.lower()


class NormalizedTransaction(BaseModel):
    """Chain-agnostic transaction (EVM or UTXO)."""

    model_config = _FROZEN_CONFIG

    chain: ChainIdField
    tx_hash: str
    block: BlockRef
    from_addr: Address | None
    to_addr: Address | None
    value_native: Amount
    gas_used: StrictInt | None = None
    # ``BeforeValidator`` runs ``_validate_status_zero_or_one`` so ``bool``
    # (round-8 P2-23) and ``float`` (1.0 / 0.0) inputs are rejected before the
    # ``StrictInt`` type check; the validator also pins the value domain to
    # ``{0, 1, None}`` per architect WBS line 219.
    status: Annotated[StrictInt | None, BeforeValidator(_validate_status_zero_or_one)] = None
    transfers: Annotated[tuple[NormalizedTransfer, ...], BeforeValidator(_coerce_to_tuple)] = ()
    raw_uri: str | None = None
    # P1-012 R-INPUT-FIELD: optional EVM calldata. ``None`` for BTC and any
    # tx that the upstream adapter did not populate; ``""`` / ``"0x"`` for
    # EVM transactions with no data; ``"0x..."`` for contract calls.
    # The pre-validator lowercase-normalises and rejects malformed hex.
    input: Annotated[str | None, BeforeValidator(_validate_optional_calldata)] = None

    @model_validator(mode="after")
    def _validate_tx_hash(self) -> Self:
        """Chain-aware tx_hash validation. Stores the lowercase normalised form."""
        normalised = _validate_chain_tx_hash(self.chain, self.tx_hash, field="tx_hash")
        if normalised != self.tx_hash:
            # Bypass FrozenInstanceError-equivalent: __dict__ is the only way to
            # rewrite a field on a frozen Pydantic v2 model after validation.
            object.__setattr__(self, "tx_hash", normalised)
        return self

    @model_validator(mode="after")
    def _validate_nested_chain_coherence(self) -> Self:
        """Every nested chain-bearing field must agree with ``self.chain``.

        Without this check, a tx claiming ``chain=ETHEREUM`` could carry a
        ``BlockRef(chain=BITCOIN)`` or BTC-encoded endpoints — the tracer
        would happily walk those edges and emit nonsense routes. Each branch
        emits a field-named error for fast triage.
        """
        if self.block.chain is not self.chain:
            raise ValueError(
                f"block.chain mismatch: tx chain={self.chain.value}, "
                f"block.chain={self.block.chain.value}"
            )
        if self.from_addr is not None and self.from_addr.chain is not self.chain:
            raise ValueError(
                f"from_addr.chain mismatch: tx chain={self.chain.value}, "
                f"from_addr.chain={self.from_addr.chain.value}"
            )
        if self.to_addr is not None and self.to_addr.chain is not self.chain:
            raise ValueError(
                f"to_addr.chain mismatch: tx chain={self.chain.value}, "
                f"to_addr.chain={self.to_addr.chain.value}"
            )
        for idx, transfer in enumerate(self.transfers):
            if transfer.asset.chain is not self.chain:
                raise ValueError(
                    f"transfers[{idx}].asset.chain mismatch: "
                    f"tx chain={self.chain.value}, "
                    f"transfer.asset.chain={transfer.asset.chain.value}"
                )
        return self

    @model_validator(mode="after")
    def _validate_value_native_decimals(self) -> Self:
        """``value_native.decimals`` must equal ``chain.native_decimals``.

        ORM persistence stores only the raw integer (Numeric(40,0)) and
        reconstructs decimals from the chain on read. A mismatched-decimals
        ``value_native`` therefore round-trips into a different value, which
        is silent data corruption rather than a parser bug.
        """
        expected = self.chain.native_decimals
        if self.value_native.decimals != expected:
            raise ValueError(
                f"value_native.decimals mismatch: tx chain={self.chain.value} "
                f"expects native_decimals={expected}, got "
                f"value_native.decimals={self.value_native.decimals}"
            )
        return self

    @property
    def tx_id(self) -> str:
        return f"{self.chain.value}:{self.tx_hash}"

    @classmethod
    def from_orm(cls, row: Any, transfers: tuple[NormalizedTransfer, ...] = ()) -> Self:
        chain = ChainId.from_str(row.chain_id)
        from_addr = Address.from_str(row.from_addr, chain) if row.from_addr else None
        to_addr = Address.from_str(row.to_addr, chain) if row.to_addr else None
        block = BlockRef(
            chain=chain,
            number=int(row.block_number),
            hash=None,
            timestamp=_assume_utc(row.block_time),
        )
        raw_value = row.value_native if row.value_native is not None else 0
        value_native = Amount.from_raw(int(raw_value), chain.native_decimals)
        # P1-012 R2 P2-2: read the persisted ``input`` column when present.
        # ``getattr`` keeps the helper backwards-compatible with stub rows
        # used by the unit suite that omit the column entirely.
        calldata = getattr(row, "input", None)
        return cls(
            chain=chain,
            tx_hash=row.hash,
            block=block,
            from_addr=from_addr,
            to_addr=to_addr,
            value_native=value_native,
            gas_used=row.gas_used,
            status=row.status,
            transfers=transfers,
            raw_uri=row.raw_json_uri,
            input=calldata,
        )

    def to_orm_kwargs(self) -> dict[str, Any]:
        return {
            "tx_id": self.tx_id,
            "chain_id": self.chain.value,
            "hash": self.tx_hash,
            "block_number": self.block.number,
            "block_time": self.block.timestamp,
            "from_addr": self.from_addr.value if self.from_addr else None,
            "to_addr": self.to_addr.value if self.to_addr else None,
            "value_native": self.value_native.raw,
            "gas_used": self.gas_used,
            "status": self.status,
            "raw_json_uri": self.raw_uri,
            # P1-012 R2 P2-2: persist the EVM calldata so the abi_fallback
            # resolver can read stored transactions back. ``None`` for BTC
            # and contract-creation rows.
            "input": self.input,
        }


# ---------------------------------------------------------------------------
# 6) NormalizedAddress
# ---------------------------------------------------------------------------


class NormalizedAddress(BaseModel):
    """Address metadata snapshot produced by the labeler/clusterer."""

    model_config = _FROZEN_CONFIG

    address: Address
    first_seen_block: StrictInt | None = None
    first_seen_at: datetime | None = None
    label_primary: str | None = None
    cluster_id: str | None = None
    risk_score: float | None = Field(default=None, ge=0.0, le=1.0)

    @field_validator("first_seen_at", mode="before")
    @classmethod
    def _coerce_first_seen_at(cls, v: Any) -> Any:
        if v is None:
            return None
        if isinstance(v, datetime):
            return _ensure_utc(v)
        if isinstance(v, str):
            parsed = datetime.fromisoformat(v.replace("Z", "+00:00"))
            return _ensure_utc(parsed)
        raise ValueError(f"unsupported first_seen_at type: {type(v).__name__}")

    @field_validator("cluster_id")
    @classmethod
    def _validate_cluster_id(cls, v: str | None) -> str | None:
        """Enforce a real UUIDv4 (canonical lowercase) — codex round-6 P2-21.

        The original ``_UUID_RE`` regex accepted any UUID-shaped hex string
        including v1/v3 (version digit at position 14 is unconstrained) and a
        trailing ``\\n`` (``re.match`` only anchors the start). Routing
        through :class:`uuid.UUID` rejects newlines and non-hex chars, and
        ``parsed.version`` lets us require v4 specifically. ``str(parsed)``
        returns the canonical lowercase hyphenated form.
        """
        if v is None:
            return None
        try:
            parsed = uuid.UUID(v)
        except (ValueError, AttributeError, TypeError) as exc:
            raise ValueError(f"cluster_id must be UUID4 string, got {v!r}") from exc
        if parsed.version != 4:
            raise ValueError(
                f"cluster_id must be UUID4 (version=4), got version={parsed.version} for {v!r}"
            )
        return str(parsed)

    @classmethod
    def from_orm(cls, row: Any) -> Self:
        chain = ChainId.from_str(row.chain_id)
        return cls(
            address=Address.from_str(row.address, chain),
            first_seen_block=row.first_seen_block,
            first_seen_at=_assume_utc(row.first_seen_at),
            label_primary=row.label_primary,
            cluster_id=row.cluster_id,
            risk_score=row.risk_score,
        )

    def to_orm_kwargs(self) -> dict[str, Any]:
        return {
            "address_id": str(self.address),
            "chain_id": self.address.chain.value,
            "address": self.address.value,
            "first_seen_block": self.first_seen_block,
            "first_seen_at": self.first_seen_at,
            "label_primary": self.label_primary,
            "cluster_id": self.cluster_id,
            "risk_score": self.risk_score,
        }


# ---------------------------------------------------------------------------
# 7) DecodedCall / ExtractedTarget / CrossChainHop
# ---------------------------------------------------------------------------


class ExtractedTarget(BaseModel):
    """A single decoded extraction target (e.g. THORChain memo BTC address)."""

    model_config = _FROZEN_CONFIG

    kind: str
    chain: OptionalChainIdField
    value: str


# Recursive-freeze pipeline for :class:`DecodedCall.params` lives in
# :mod:`vca.types._extras_freeze` (lifted in P1-012 R-FREEZE-LIFT). The
# thin wrappers below preserve the historical "DecodedCall.params"-prefixed
# error messages while delegating the actual walking logic to the shared
# helpers — no behaviour change for P1-001 callers.
_DECODED_CALL_PARAMS_LABEL: Final[str] = "DecodedCall.params"


def _check_str_keys(mapping: Mapping[Any, Any]) -> None:
    """Enforce ``str`` keys on every dict in a recursively-frozen params tree."""
    _check_str_keys_shared(mapping, label=_DECODED_CALL_PARAMS_LABEL)


def _freeze_params_value(value: Any) -> Any:
    """Recursively convert ``value`` into a deeply-immutable JSON-friendly form."""
    return _freeze_extras_value_shared(value, label=_DECODED_CALL_PARAMS_LABEL)


def _thaw_params_value(value: Any) -> Any:
    """Inverse of :func:`_freeze_params_value` for serialisation paths."""
    return _thaw_extras_value_shared(value)


class DecodedCall(BaseModel):
    """BridgeDecoder output: decoded function/memo + extraction targets.

    ``params`` is exposed as a read-only :class:`~collections.abc.Mapping`
    (backed by :class:`types.MappingProxyType`) and is **deeply** immutable:
    nested ``dict`` becomes :class:`types.MappingProxyType`, nested ``list``/
    ``tuple`` becomes ``tuple``. ``frozen=True`` therefore extends transitively
    through every level. The wire format remains plain JSON — the field
    serializer thaws the proxy/tuple back to ``dict``/``list``.
    """

    model_config = _FROZEN_CONFIG

    decoder: str
    function_name: str
    params: Mapping[str, Any] = Field(default_factory=dict)
    extracted_targets: Annotated[
        tuple[ExtractedTarget, ...], BeforeValidator(_coerce_to_tuple)
    ] = ()

    @model_validator(mode="after")
    def _freeze_params(self) -> Self:
        """Recursively freeze ``params`` and reject non-JSON-friendly values.

        Pydantic v2 coerces ``Mapping`` annotations back to ``dict`` during
        validation, so we wrap *after* validation completes and bypass
        ``frozen=True`` via :func:`object.__setattr__` (the same hatch we use
        for ``tx_hash`` lower-case normalisation).
        """
        frozen = _freeze_params_value(dict(self.params))
        object.__setattr__(self, "params", frozen)
        return self

    @field_serializer("params")
    def _serialize_params(self, value: Mapping[str, Any]) -> dict[str, Any]:
        """Surface ``params`` as plain ``dict``/``list`` on the wire.

        ``MappingProxyType`` and nested ``tuple`` are not the wire shape we
        want; downstream consumers (and ``stable_dump_json``) expect regular
        JSON objects/arrays.
        """
        thawed = _thaw_params_value(value)
        # The field's declared type is Mapping[str, Any]; the top-level result
        # is always a dict because params itself is a dict at validation time.
        if not isinstance(thawed, dict):  # pragma: no cover - structural guarantee
            raise TypeError("params must serialise to a dict at the top level")
        return thawed


class CrossChainHop(BaseModel):
    """Cross-chain edge: src tx → dst address on another chain."""

    model_config = _FROZEN_CONFIG

    src_chain: ChainIdField
    dst_chain: ChainIdField
    src_tx: str
    dst_address: Address
    via: str
    memo: str | None = None
    asset_in: Asset
    asset_out: Asset
    amount_in: Amount
    amount_out: Amount | None = None

    @model_validator(mode="after")
    def _validate_src_tx(self) -> Self:
        """Enforce chain-aware tx-hash format on ``src_tx``.

        Tracer/reporter joins hops back to NormalizedTransactions through
        this field; an unvalidated string silently breaks those joins. We
        share the format helper with :class:`NormalizedTransaction` so the
        rule never drifts. Lowercase rewrite uses the same frozen-model
        bypass idiom as the tx_hash validator.
        """
        normalised = _validate_chain_tx_hash(self.src_chain, self.src_tx, field="src_tx")
        if normalised != self.src_tx:
            object.__setattr__(self, "src_tx", normalised)
        return self

    @model_validator(mode="after")
    def _validate_chain_and_unit_coherence(self) -> Self:
        """Pin each chain-bearing field to its claimed src/dst chain.

        Without these checks an analyst could construct a "ETH→BTC" hop whose
        ``dst_address`` is actually an ETH address — the visualiser would
        render the wrong cluster. Each branch emits a field-named error.

        The same-chain guard runs **first** so an ETH→ETH hop (definitionally
        not a cross-chain hop) surfaces with a clear top-level message rather
        than a confusing nested ``asset_out.chain mismatch`` error from the
        chain-coherence checks below.
        """
        if self.src_chain is self.dst_chain:
            raise ValueError(
                f"CrossChainHop requires src_chain != dst_chain, got "
                f"src_chain={self.src_chain.value}, dst_chain={self.dst_chain.value}"
            )
        if self.dst_address.chain is not self.dst_chain:
            raise ValueError(
                f"dst_address.chain mismatch: hop dst_chain={self.dst_chain.value}, "
                f"dst_address.chain={self.dst_address.chain.value}"
            )
        if self.asset_in.chain is not self.src_chain:
            raise ValueError(
                f"asset_in.chain mismatch: hop src_chain={self.src_chain.value}, "
                f"asset_in.chain={self.asset_in.chain.value}"
            )
        if self.asset_out.chain is not self.dst_chain:
            raise ValueError(
                f"asset_out.chain mismatch: hop dst_chain={self.dst_chain.value}, "
                f"asset_out.chain={self.asset_out.chain.value}"
            )
        if self.amount_in.decimals != self.asset_in.decimals:
            raise ValueError(
                f"amount_in.decimals mismatch: asset_in.decimals="
                f"{self.asset_in.decimals}, amount_in.decimals={self.amount_in.decimals}"
            )
        if self.amount_out is not None and self.amount_out.decimals != self.asset_out.decimals:
            raise ValueError(
                f"amount_out.decimals mismatch: asset_out.decimals="
                f"{self.asset_out.decimals}, amount_out.decimals={self.amount_out.decimals}"
            )
        return self


# ---------------------------------------------------------------------------
# Deterministic JSON serialisation helper
# ---------------------------------------------------------------------------


def stable_dump_json(model: BaseModel) -> str:
    """Deterministic JSON dump: sorted keys, compact separators, UTF-8."""
    payload = model.model_dump(mode="json", by_alias=False)
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


__all__ = [
    "Address",
    "Amount",
    "Asset",
    "BlockRef",
    "ChainId",
    "ContractAddr",
    "CrossChainHop",
    "DecodedCall",
    "ExtractedTarget",
    "NormalizedAddress",
    "NormalizedTransaction",
    "NormalizedTransfer",
    "TxHash",
    "stable_dump_json",
]
