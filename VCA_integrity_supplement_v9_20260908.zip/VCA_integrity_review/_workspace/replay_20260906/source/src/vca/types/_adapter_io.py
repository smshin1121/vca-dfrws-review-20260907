"""Adapter I/O helper types (P1-002).

Pulled into a private submodule so :mod:`vca.types.normalized` stays under the
800-line file cap (R-SPLIT). The public surface is unchanged — every symbol
defined here is re-exported through :mod:`vca.types`.

Design notes
------------
* ``Cursor`` — stateless pagination resume token. Structural rather than
  opaque-string so process restarts can rebuild the same query without
  consulting the upstream provider.
* ``Page[T]`` — pydantic v2 generic page envelope. ``items`` is a tuple
  (immutability), ``next_cursor is None`` ↔ ``has_more is False``.
* ``Balance`` — point-in-time balance snapshot used by labelers/heuristics.
  Cross-field validators enforce chain coherence and decimals match between
  ``amount`` and ``asset``.
* ``NormalizedLog`` — generic EVM event log. Distinct from ``NormalizedTransfer``
  (which is value-movement-specific) so decoders (P1-008+) can consume raw
  topics/data when an event has no value semantics.
"""

from __future__ import annotations

import re
from typing import Annotated, Final, Self

from pydantic import BaseModel, BeforeValidator, Field, StrictInt, model_validator

from vca.types.normalized import (
    _FROZEN_CONFIG,
    Address,
    Amount,
    Asset,
    BlockRef,
    ChainIdField,
    _coerce_to_tuple,
    _validate_chain_tx_hash,
)

# ---------------------------------------------------------------------------
# Hex-payload helpers (codex round-1 P2-1)
# ---------------------------------------------------------------------------
#
# EVM event topics are always 32-byte hashes (``0x`` + 64 hex chars). EVM
# event ``data`` is an arbitrary even-length byte payload (``0x`` + 0-or-more
# hex pairs). Decoders downstream of the adapter rely on this — surfacing
# a malformed payload as a :class:`pydantic.ValidationError` at construction
# time is much more useful than ``ValueError`` deep inside an ABI decoder.

_TOPIC_HEX_RE: Final[re.Pattern[str]] = re.compile(r"0x[0-9a-f]{64}")
_DATA_HEX_RE: Final[re.Pattern[str]] = re.compile(r"0x([0-9a-f]{2})*")


def _validate_hex_lowercase(
    value: str,
    *,
    field: str,
    length: int | None = None,
) -> str:
    """Validate ``value`` is ``0x`` + (optionally length-pinned) lowercase hex.

    Returns the canonical lowercase form so uppercase EVM hex is normalised
    on the way in (mirrors :func:`vca.types.normalized._validate_chain_tx_hash`'s
    P1-001 round-6 P2 treatment of tx-hash case-folding).

    Args:
        value: candidate hex string (must be ``0x``-prefixed).
        field: human-readable field name for the error message — full
            dotted path so callers can pinpoint the failing slot
            (e.g. ``"NormalizedLog.topics[0]"``).
        length: when set, the **total** expected length including the
            ``0x`` prefix. ``66`` for a 32-byte topic, ``None`` for the
            variable-length ``data`` field.

    Raises:
        ValueError: ``value`` does not satisfy the format.
    """
    if not isinstance(value, str):
        raise ValueError(  # noqa: TRY004 - value-domain validator path
            f"{field} must be str, got {type(value).__name__}"
        )
    candidate = value.lower()
    if length is not None:
        if not _TOPIC_HEX_RE.fullmatch(candidate) or len(candidate) != length:
            raise ValueError(f"{field} must be 0x + {length - 2} lowercase hex chars, got: {value}")
    elif not _DATA_HEX_RE.fullmatch(candidate):
        raise ValueError(f"{field} must be 0x-prefixed lowercase hex (even length), got: {value}")
    return candidate


# ---------------------------------------------------------------------------
# 8) Cursor — stateless pagination resume token
# ---------------------------------------------------------------------------


class Cursor(BaseModel):
    """Stateless pagination resume token.

    Stores the union of (page_token, start_block, end_block) so that any
    chain adapter — Etherscan v2's ``page+offset``, mempool.space's
    ``last_seen_txid``, or a block-range scan — can encode its resumption
    state in the same shape. JSON-round-trip equivalence is required so a
    crashed worker can pick up exactly where it left off.
    """

    model_config = _FROZEN_CONFIG

    page_token: str | None = None
    start_block: StrictInt | None = Field(default=None, ge=0)
    end_block: StrictInt | None = Field(default=None, ge=0)

    @model_validator(mode="after")
    def _validate_block_range(self) -> Self:
        if (
            self.start_block is not None
            and self.end_block is not None
            and self.start_block > self.end_block
        ):
            raise ValueError(
                f"Cursor start_block must be <= end_block, got "
                f"start_block={self.start_block}, end_block={self.end_block}"
            )
        return self


# ---------------------------------------------------------------------------
# 9) Page[T] — generic page envelope
# ---------------------------------------------------------------------------


class Page[T](BaseModel):
    """Pagination response envelope.

    ``items`` is an immutable tuple — JSON ``list`` input is coerced via
    :func:`vca.types.normalized._coerce_to_tuple`. ``has_more`` and
    ``next_cursor`` are linked by an after-validator so callers cannot
    construct a logically inconsistent page (cursor present but ``has_more``
    false, or vice versa).
    """

    model_config = _FROZEN_CONFIG

    items: Annotated[tuple[T, ...], BeforeValidator(_coerce_to_tuple)]
    next_cursor: Cursor | None = None
    has_more: bool = False

    @model_validator(mode="after")
    def _has_more_consistency(self) -> Self:
        if self.next_cursor is None and self.has_more:
            raise ValueError(
                "Page has_more=True requires a non-null next_cursor "
                "(no cursor means no further pages)"
            )
        if self.next_cursor is not None and not self.has_more:
            raise ValueError(
                "Page next_cursor is present but has_more=False "
                "(unreachable: a cursor implies more pages exist)"
            )
        return self


# ---------------------------------------------------------------------------
# 10) Balance — point-in-time balance snapshot
# ---------------------------------------------------------------------------


class Balance(BaseModel):
    """Point-in-time balance snapshot.

    Used by labelers (e.g. "balance is 0 immediately after withdrawal")
    and by reporters that surface address state alongside flow edges.
    Cross-field validators enforce that ``chain``, ``address.chain``,
    ``asset.chain`` and (when set) ``at_block.chain`` all agree, plus the
    same decimals invariant as :class:`NormalizedTransfer`.
    """

    model_config = _FROZEN_CONFIG

    chain: ChainIdField
    address: Address
    at_block: BlockRef | None = None
    amount: Amount
    asset: Asset

    @model_validator(mode="after")
    def _validate_chain_coherence(self) -> Self:
        if self.address.chain is not self.chain:
            raise ValueError(
                f"Balance.address.chain mismatch: balance.chain={self.chain.value}, "
                f"address.chain={self.address.chain.value}"
            )
        if self.asset.chain is not self.chain:
            raise ValueError(
                f"Balance.asset.chain mismatch: balance.chain={self.chain.value}, "
                f"asset.chain={self.asset.chain.value}"
            )
        if self.at_block is not None and self.at_block.chain is not self.chain:
            raise ValueError(
                f"Balance.at_block.chain mismatch: balance.chain={self.chain.value}, "
                f"at_block.chain={self.at_block.chain.value}"
            )
        return self

    @model_validator(mode="after")
    def _decimals_match(self) -> Self:
        if self.amount.decimals != self.asset.decimals:
            raise ValueError(
                f"Balance decimals mismatch for asset {self.asset.symbol!r}: "
                f"asset.decimals={self.asset.decimals}, "
                f"amount.decimals={self.amount.decimals}"
            )
        return self


# ---------------------------------------------------------------------------
# 11) NormalizedLog — generic EVM event log
# ---------------------------------------------------------------------------


class NormalizedLog(BaseModel):
    """EVM event log. Generic over any event signature.

    :class:`NormalizedTransfer` is the value-movement specialisation
    (``Transfer(address,address,uint256)`` and BTC vin/vout pairs), this
    class is the raw form that decoders (LayerZero ``OFTReceived``, Aave
    ``Supply``, etc.) consume to extract their domain shape. The two are
    deliberately distinct types — alias would silently lose semantics.

    For BTC adapters, ``get_logs`` returns ``()``: BTC has no event log
    surface. The validator nevertheless allows ``chain=BITCOIN`` so that
    diagnostic tooling can construct an empty-tuple BTC NormalizedLog list
    without a per-call branch — but the adapter must never emit non-empty
    BTC log tuples, and the EVM-only field semantics (``topics``, ``data``
    hex) make BTC instances functionally degenerate.
    """

    model_config = _FROZEN_CONFIG

    chain: ChainIdField
    block: BlockRef
    tx_hash: str
    log_index: StrictInt = Field(ge=0)
    address: Address
    topics: Annotated[tuple[str, ...], BeforeValidator(_coerce_to_tuple)]
    data: str
    removed: bool = False

    @model_validator(mode="after")
    def _validate_chain_coherence(self) -> Self:
        if self.block.chain is not self.chain:
            raise ValueError(
                f"NormalizedLog.block.chain mismatch: log.chain={self.chain.value}, "
                f"block.chain={self.block.chain.value}"
            )
        if self.address.chain is not self.chain:
            raise ValueError(
                f"NormalizedLog.address.chain mismatch: log.chain={self.chain.value}, "
                f"address.chain={self.address.chain.value}"
            )
        return self

    @model_validator(mode="after")
    def _validate_tx_hash(self) -> Self:
        normalised = _validate_chain_tx_hash(self.chain, self.tx_hash, field="tx_hash")
        if normalised != self.tx_hash:
            object.__setattr__(self, "tx_hash", normalised)
        return self

    @model_validator(mode="after")
    def _validate_topics_hex(self) -> Self:
        """Each topic must be ``0x`` + 64 lowercase hex (32-byte hash).

        Empty ``topics`` is allowed (anonymous events). Uppercase input is
        canonicalised — pydantic ``frozen=True`` blocks normal assignment, so
        any change is applied via ``object.__setattr__`` (the same escape
        hatch used by ``_validate_tx_hash``).
        """
        normalised = tuple(
            _validate_hex_lowercase(t, field=f"NormalizedLog.topics[{i}]", length=66)
            for i, t in enumerate(self.topics)
        )
        if normalised != self.topics:
            object.__setattr__(self, "topics", normalised)
        return self

    @model_validator(mode="after")
    def _validate_data_hex(self) -> Self:
        """``data`` must be ``0x`` + even-length lowercase hex (zero bytes ok)."""
        normalised = _validate_hex_lowercase(self.data, field="NormalizedLog.data")
        if normalised != self.data:
            object.__setattr__(self, "data", normalised)
        return self


__all__ = [
    "Balance",
    "Cursor",
    "NormalizedLog",
    "Page",
]
