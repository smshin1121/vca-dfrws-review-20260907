"""Stage classifier (P1-015) — pure synchronous label assignment.

Maps every :class:`vca.tracer.FlowEdge` in a frozen :class:`CaseGraph` to
one of 13 closed :class:`StageLabel` members per
``docs/source/03_KelpDAO_rsETH_Exploit_분석.md`` lines 77-89.

Package layout (WBS §10 — split per R-FILE-CAP):

* :mod:`._vocab` — closed :class:`StageLabel` enum + module regex constants.
* :mod:`._policy` — frozen :class:`StagePolicy` DTO.
* :mod:`._assignment` — frozen :class:`StageAssignment` DTO.
* :mod:`._priority` — :class:`ClassifierContext` + edge-id helpers + smurf
  bucket math (built once per classify call).
* :mod:`._heuristics` — 8 paired predicate ↔ asserter pairs + outcome
  producers (R-SSOT-PREDICATE).
* :mod:`._fallback` — DoD-10 fallback table catching unclaimed edges.

R-rules:
* R-NO-FREEZE-CHANGE — never adds vocabulary to ``EdgeKind`` /
  ``TerminationReason``.
* R-PURE — no side effects, no logging, no I/O.
* R-SSOT-PREDICATE — every heuristic exposes a paired predicate ↔ asserter
  delegating to a single private finder.
* R-PRIORITY — rationale string starts with the winning heuristic name.
* R-DETERMINISTIC — every iteration ``sorted()`` by edge canonical key.
* R-FILE-CAP — package files each ≤ 250 LoC.
"""

from __future__ import annotations

from collections.abc import Callable

from vca.tracer.graph import CaseGraph, EdgeKind, FlowEdge, canonical_address_key
from vca.tracer.stage_classifier._assignment import StageAssignment
from vca.tracer.stage_classifier._fallback import fallback_outcome
from vca.tracer.stage_classifier._heuristics import (
    address_label_anchor_outcome,
    assert_is_address_label_anchor,
    assert_is_btc_layered,
    assert_is_cross_chain_hop,
    assert_is_defi_collateral,
    assert_is_fan_in,
    assert_is_fan_out,
    assert_is_kind_override,
    assert_is_out_of_scope_boundary,
    assert_is_seed_anchor,
    assert_is_smurfing,
    assert_is_trace_terminated,
    btc_layered_outcome,
    cross_chain_outcome,
    defi_outcome,
    fan_in_outcome,
    fan_out_outcome,
    is_address_label_anchor,
    is_btc_layered,
    is_cross_chain_hop,
    is_defi_collateral,
    is_fan_in,
    is_fan_out,
    is_kind_override,
    is_out_of_scope_boundary,
    is_seed_anchor,
    is_smurfing,
    is_trace_terminated,
    kind_override_outcome,
    out_of_scope_boundary_outcome,
    seed_anchor_outcome,
    smurfing_outcome,
    trace_terminated_outcome,
)
from vca.tracer.stage_classifier._policy import StagePolicy
from vca.tracer.stage_classifier._priority import (
    ClassifierContext,
    derive_edge_id_by_index,
    edge_contract_key,
    edge_id,
    edge_sort_key,
)
from vca.tracer.stage_classifier._vocab import StageLabel

# Internal alias preserved for the test suite (R-SSOT-PREDICATE pairs).
_ClassifierContext = ClassifierContext


# Priority-ordered (predicate, outcome) tuples — see WBS §5.
#
# Rank pipeline (P2-005.3 inserted rank 5 ``is_address_label_anchor``
# between rank 4 ``is_kind_override`` and rank 5-old
# ``is_out_of_scope_boundary``, shifting ranks 5-10 down to 6-11):
#
#   1. ``is_seed_anchor``              — seed-anchor edge → STAGE_1
#   2. ``is_cross_chain_hop``          — known cross-chain decoder → policy map
#   3. ``is_defi_collateral``          — whitelisted DEFI decoder → defi_outcome
#   4. ``is_kind_override``            — DefiAction.extras["kind_override"]
#                                          consumption (swap → 3-A/3-B,
#                                          bridge_send → 3-B; defers
#                                          boundary to rank 6)  [P2-002.3]
#   5. ``is_address_label_anchor``     — AddressLabel.extras["attribution_role"]
#                                          consumption (5 roles):
#                                          smurfing_residual_sweep → STAGE_6,
#                                          eth_btc_ratio_attribution → STAGE_7,
#                                          btc_peeling_chain_origin /
#                                          btc_coinjoin_pool_entry /
#                                          btc_vault_address → STAGE_8_BTC_L1.
#                                          Source endpoint > target endpoint
#                                          per R-ATTRIBUTION-ROLE-SOURCE-OVER-
#                                          TARGET.  [P2-005.3 / P2-006.3 /
#                                          P2-007.3]
#   6. ``is_out_of_scope_boundary``    — DefiAction.extras boundary marker
#                                          (POLYGON / SOLANA_MAYAN) →
#                                          STAGE_TRACE_TERMINATED with
#                                          ``out_of_scope_boundary:<label>``
#                                          rationale  [P2-008.3]
#   7. ``is_smurfing``                 — equal-value TRANSFER cluster → STAGE_6
#   8. ``is_fan_in``                   — N→1 dense window → STAGE_4
#   9. ``is_fan_out``                  — 1→N dense window → STAGE_2/STAGE_5
#  10. ``is_btc_layered``              — BTC endpoint → Stage 8 / BTC L*
#  11. ``is_trace_terminated``         — target in terminal_reasons → TRACE_TERMINATED
#   F. fallback_outcome                — F1..F8 catch-all
_PIPELINE: tuple[
    tuple[
        Callable[[CaseGraph, FlowEdge, ClassifierContext], bool],
        Callable[[CaseGraph, FlowEdge, ClassifierContext], tuple[StageLabel, str]],
    ],
    ...,
] = (
    (is_seed_anchor, seed_anchor_outcome),
    (is_cross_chain_hop, cross_chain_outcome),
    (is_defi_collateral, defi_outcome),
    (is_kind_override, kind_override_outcome),
    (is_address_label_anchor, address_label_anchor_outcome),
    (is_out_of_scope_boundary, out_of_scope_boundary_outcome),
    (is_smurfing, smurfing_outcome),
    (is_fan_in, fan_in_outcome),
    (is_fan_out, fan_out_outcome),
    (is_btc_layered, btc_layered_outcome),
    (is_trace_terminated, trace_terminated_outcome),
)


def classify_stages(
    graph: CaseGraph,
    *,
    policy: StagePolicy | None = None,
) -> StageAssignment:
    """Pure synchronous Stage classifier — see DoD-7.

    Two-pass: pass 1 resolves every non-ABRIDGED edge through the rank
    pipeline + fallback; pass 2 resolves ABRIDGED edges so that F1 (source
    inheritance) sees the now-complete cache regardless of edge sort order
    (codex P1-015 R1 finding #5).

    Codex P1-015 R2 finding #1 — assignment dict keys derive from
    ``ctx.edge_id_by_index``, so two edges identical in every visible
    field but at distinct positions in ``graph.edges`` no longer collide.

    Codex P1-015 R6 finding #1 — the per-input-index map now uses
    sort-stable per-base-id occurrence counters (computed in
    :meth:`ClassifierContext.build`), so permuting ``graph.edges`` on
    input no longer changes the assignment ids. ``model_dump_json()``
    is byte-equal across permutations of morally-identical graphs.

    Codex P1-015 R9 finding #1 — pass 1 populates two separate caches
    (``outgoing_label_cache``, ``incoming_label_cache``) for F1
    inheritance with strict precedence (outgoing > incoming). Prevents
    incoming labels from polluting an ABRIDGED edge's inherited stage
    when the source has its own outgoing classification.
    """
    effective_policy = policy or StagePolicy()
    ctx = ClassifierContext.build(graph, effective_policy)

    edge_labels: dict[str, StageLabel] = {}
    rationale: dict[str, str] = {}
    # Codex P1-015 R9 finding #1 — F1 ABRIDGED inheritance is split into
    # two per-node caches with explicit semantic precedence:
    #
    # * ``outgoing_label_cache[src_key]`` — first-by-sort label of a
    #   non-ABRIDGED edge whose SOURCE has canonical key ``src_key``.
    #   Models "what stage was this node acting in as a sender?" — the
    #   right signal for an ABRIDGED breadcrumb branching off the same
    #   source.
    # * ``incoming_label_cache[tgt_key]`` — first-by-sort label of a
    #   non-ABRIDGED edge whose TARGET has canonical key ``tgt_key``.
    #   Models "what stage reached this node?" — only consulted by F1
    #   when a node has no outgoing label (the R4 finding #2 fallback,
    #   so an ABRIDGED off a node that was only ever a target still
    #   inherits via F1 instead of slipping to F2/F7/F8).
    #
    # Pre-R9 a single ``node_label_cache`` recorded BOTH endpoints, so an
    # incoming STAGE_1 (e.g. seed-anchor reaching B) shadowed B's later
    # outgoing STAGE_3_A label and an ABRIDGED off B inherited the wrong
    # stage. ``setdefault`` keeps first-by-sort semantics in BOTH caches;
    # the (edge_sort_key, edge_id) ordering is content-derived so the
    # split is fully deterministic.
    outgoing_label_cache: dict[str, StageLabel] = {}
    incoming_label_cache: dict[str, StageLabel] = {}

    # Tag each edge with its INPUT position (frozen tuple ordering — part
    # of the CaseGraph contract). Sort the (idx, edge) pairs by the
    # deterministic edge sort key with the FULL ``edge_id`` (post-R7,
    # which includes decoder/asset/decimals) as the tiebreaker — codex
    # P1-015 R8 finding #1. Using the input index here would make
    # ``node_label_cache`` first-by-sort entries depend on raw tuple
    # order: two non-ABRIDGED edges sharing a ``(source, target,
    # tx_hash, kind)`` ``edge_sort_key`` but with different labels would
    # cache different labels under the shared source/target node key
    # depending on input order, and downstream ABRIDGED edges inheriting
    # via F1 would then see different labels across permutations,
    # breaking R-DETERMINISTIC for ``model_dump_json()``.
    indexed_edges: list[tuple[int, FlowEdge]] = list(enumerate(graph.edges))
    indexed_edges.sort(
        key=lambda pair: (edge_sort_key(pair[1]), edge_id(pair[1]), edge_contract_key(pair[1]))
    )

    def _resolve(edge: FlowEdge) -> tuple[StageLabel, str]:
        for predicate, outcome in _PIPELINE:
            if predicate(graph, edge, ctx):
                return outcome(graph, edge, ctx)
        return fallback_outcome(
            graph,
            edge,
            ctx,
            edge_labels,
            outgoing_label_cache,
            incoming_label_cache,
        )

    # Pass 1 — every non-ABRIDGED edge.
    for idx, edge in indexed_edges:
        if edge.kind == EdgeKind.ABRIDGED:
            continue
        eid = ctx.edge_id_by_index[idx]
        label, rat = _resolve(edge)
        edge_labels[eid] = label
        rationale[eid] = rat
        # Codex P1-015 R9 finding #1 — record source under outgoing,
        # target under incoming. Each cache uses ``setdefault`` so the
        # first-by-sort label wins; F1 prefers outgoing over incoming.
        src_key = canonical_address_key(edge.source)
        tgt_key = canonical_address_key(edge.target)
        outgoing_label_cache.setdefault(src_key, label)
        incoming_label_cache.setdefault(tgt_key, label)

    # Pass 2 — ABRIDGED edges now see the full pass-1 cache.
    for idx, edge in indexed_edges:
        if edge.kind != EdgeKind.ABRIDGED:
            continue
        eid = ctx.edge_id_by_index[idx]
        label, rat = _resolve(edge)
        edge_labels[eid] = label
        rationale[eid] = rat

    return StageAssignment(
        case_id=graph.case_id,
        edge_labels=edge_labels,
        rationale=rationale,
    )


__all__ = [
    "StageAssignment",
    "StageLabel",
    "StagePolicy",
    "_ClassifierContext",
    "address_label_anchor_outcome",
    "assert_is_address_label_anchor",
    "assert_is_btc_layered",
    "assert_is_cross_chain_hop",
    "assert_is_defi_collateral",
    "assert_is_fan_in",
    "assert_is_fan_out",
    "assert_is_kind_override",
    "assert_is_out_of_scope_boundary",
    "assert_is_seed_anchor",
    "assert_is_smurfing",
    "assert_is_trace_terminated",
    "classify_stages",
    "derive_edge_id_by_index",
    "is_address_label_anchor",
    "is_btc_layered",
    "is_cross_chain_hop",
    "is_defi_collateral",
    "is_fan_in",
    "is_fan_out",
    "is_kind_override",
    "is_out_of_scope_boundary",
    "is_seed_anchor",
    "is_smurfing",
    "is_trace_terminated",
]
