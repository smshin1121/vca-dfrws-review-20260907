"""Predicate finders + asserters + outcome producers (P1-015 DoD-8).

Each heuristic family is a paired predicate ↔ asserter delegating to the
SAME private ``_X_problem(...) -> str | None`` finder per R-SSOT-PREDICATE.
The outcome producers turn a winning predicate into a (StageLabel,
rationale) pair.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Final

from vca.tracer.graph import (
    CaseGraph,
    EdgeKind,
    FlowEdge,
    TerminationReason,
    canonical_address_key,
)
from vca.tracer.stage_classifier._priority import ClassifierContext, _is_seed_anchor_edge
from vca.tracer.stage_classifier._vocab import (
    _ATTRIBUTION_ROLE_TO_STAGE,
    _BRIDGE_OUT_BOUNDARY,
    _KNOWN_ATTRIBUTION_ROLES,
    _KNOWN_KIND_OVERRIDES,
    _KNOWN_OUT_OF_SCOPE_STAGE_LABELS,
    StageLabel,
)
from vca.types import ChainId

# ---------------------------------------------------------------------------
# Module constants
# ---------------------------------------------------------------------------

# P2-CLASSIFIER-AUDIT.1 — single-source-of-truth defer string for
# ABRIDGED edges. Every problem-finder that explicitly short-circuits
# ``edge.kind == EdgeKind.ABRIDGED`` MUST return this exact literal so
# the 8 sibling ranks remain byte-equal and the
# :func:`assert_is_<name>` asserters emit a uniform diagnostic
# (``ValueError(f"{name}: {problem}")`` at
# :func:`_make_predicate`). Drift is forbidden — pinned by
# ``tests/unit/tracer/test_abridged_defer_consistency.py``::
# ``TestSourceFileGrepInvariantNoLowercaseAbridgedDefer`` (AST-scan
# negative invariant) AND ``TestAbridgedDeferStringCanonicalAcrossAllRanks``
# (per-rank literal pin).
_ABRIDGED_DEFER_F1_INHERITANCE: Final[str] = "ABRIDGED edges defer to F1 inheritance"


# ---------------------------------------------------------------------------
# Predicate finders (R-SSOT-PREDICATE)
# ---------------------------------------------------------------------------


def _seed_anchor_problem(graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext) -> str | None:
    del ctx
    # ABRIDGED markers carry ``tx_hash=None`` so the next check already
    # rejects them, but make the short-circuit explicit so future
    # refactors of the tx_hash check cannot accidentally let an
    # ABRIDGED edge pass — codex P1-015 R2 finding #3.
    if edge.kind == EdgeKind.ABRIDGED:
        return _ABRIDGED_DEFER_F1_INHERITANCE
    # R-SSOT-PREDICATE — delegate to ``_is_seed_anchor_edge`` (codex P1-015
    # R5 finding #2) so the build-time fan cluster filter and the rank-1
    # heuristic agree on what counts as a seed-anchor edge. Reasons are
    # produced here so the asserter still emits a precise diagnostic.
    if _is_seed_anchor_edge(graph, edge):
        return None
    if edge.tx_hash != graph.seed_tx.tx_hash:
        return f"edge.tx_hash {edge.tx_hash!r} != graph.seed_tx {graph.seed_tx.tx_hash!r}"
    # WBS §4 rank 1 requires BOTH tx_hash AND chain match. While the
    # chain-aware tx_hash regex makes the EVM-vs-BTC collision unreachable,
    # ETH and Arbitrum both use the ``0x[64-hex]`` shape so an ARB edge can
    # collide with an ETH seed hash — codex P1-015 R1 finding #2.
    return (
        f"edge.source.chain {edge.source.chain.value} != "
        f"graph.seed_tx.chain {graph.seed_tx.chain.value}"
    )


def _cross_chain_hop_problem(
    graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext
) -> str | None:
    del graph
    if edge.kind != EdgeKind.CROSS_CHAIN:
        return f"edge.kind {edge.kind.value} != cross_chain"
    if edge.decoder is None or edge.decoder not in ctx.policy.cross_chain_decoder_stage_map:
        return f"decoder {edge.decoder!r} not in policy cross_chain map"
    return None


def _defi_collateral_problem(
    graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext
) -> str | None:
    del graph
    if edge.kind != EdgeKind.DEFI:
        return f"edge.kind {edge.kind.value} != defi"
    if edge.decoder is None or edge.decoder not in ctx.policy.defi_decoder_names:
        return f"decoder {edge.decoder!r} not in policy defi_decoder_names"
    return None


def _kind_override_problem(graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext) -> str | None:
    """Rank 4 — consume ``edge.extras["kind_override"]`` (P2-002.3).

    Closes the P2-002.0 R-7 deferred codex finding. The P2-001 / P2-002 /
    P2-008 decoder fleet emits a ``kind_override`` tag in ``DefiAction.extras``;
    P2-002.2 propagated it onto ``FlowEdge.extras``; this rule turns the tag
    into a stage label without expanding the closed Phase-1 enum.

    Mapping:
        * ``"swap"`` + ETH source → STAGE_3_A (rank-3 catch in
          ``defi_outcome`` falls back to F6/F8 for unknown decoders;
          rank-4 here lifts swap-decoded edges back to Stage 3-A even
          when the decoder is outside ``policy.defi_decoder_names``).
        * ``"swap"`` + ARB source → STAGE_3_B (defensive — no Phase 2
          emitter routes through ARB swap today, but the mapping is
          consistent with fallback F6 ``defi_arb``).
        * ``"swap"`` + other source chains → defer (BTC swap has no
          Phase 2 emitter; fall through to btc_layered / fallback).
        * ``"bridge_send"`` (any source chain) → STAGE_3_B
          (chain-agnostic LayerZero v2 bridge SEND mapping).
        * ``"bridge_out_boundary"`` → defer to P2-008.3 (Stage 8 BFS
          termination + ``OUT_OF_SCOPE_*`` stage label disambiguation
          live in the boundary-recognizer vertical, NOT here).
        * Unknown values → defer (forward-compatibility; new
          ``kind_override`` strings introduced by a future decoder MUST
          be added to ``_KNOWN_KIND_OVERRIDES`` before they can land
          here, otherwise they flow to fallback F6/F7/F8).
        * ABRIDGED edges → defer to F1 inheritance (mirrors the
          fan_in / fan_out / btc_layered / trace_terminated defer
          pattern; ABRIDGED markers carry no per-edge data and inherit
          their source's acting stage via the outgoing-label cache).
        * Non-DEFI EdgeKinds (TRANSFER / INTERNAL / BRIDGE /
          CROSS_CHAIN) → defer regardless of extras content
          (R-KIND-OVERRIDE-DEFI-ONLY — codex P2-002.3 finding F-C).

    R-KIND-OVERRIDE-DEFI-ONLY (codex P2-002.3 finding F-C). The
    propagation contract per ``project_p2_dot0_close_patterns.md`` and
    the P2-002.2 propagation site is that ``kind_override`` originates
    in ``DefiAction.extras`` and is forwarded onto ``FlowEdge.extras``
    by ``_make_defi_edge`` only. A public ``CaseGraph`` may still
    contain a non-ABRIDGED ``TRANSFER`` or unknown-decoder
    ``CROSS_CHAIN`` edge carrying a ``kind_override`` key — that is
    out-of-contract noise (forged manually, replayed from a stale
    snapshot, etc.) and rank 4 MUST defer it to the lower ranks that
    legitimately claim those EdgeKinds (rank 2 ``cross_chain_hop`` for
    known-decoder cross-chain, fallback F5-CROSSCHAIN for unknown
    cross-chain, ranks 5..7 + F4/F8 for TRANSFER). The ABRIDGED
    short-circuit just above this guard handles ABRIDGED separately
    because ABRIDGED is a meta-kind (F1 inheritance); this guard is
    the substantive predicate.

    R-EXTRAS-AS-CLASSIFICATION-INPUT: extras informs classification and
    IS part of ``edge_id`` (codex P2-002.3 finding F-A — once extras
    started driving label selection, R-EDGE-ID-LABEL-AFFECTING-FIELDS
    forced its inclusion). Two edges identical except for extras have
    DIFFERENT ``edge_id`` so the post-sort occurrence counter never
    needs input order to discriminate them — permutation invariance
    preserved. **Supersedes the P2-002.2 contract** (which excluded
    extras at a time when extras was propagation-only).
    """
    del graph, ctx
    if edge.kind == EdgeKind.ABRIDGED:
        return _ABRIDGED_DEFER_F1_INHERITANCE
    if edge.kind != EdgeKind.DEFI:
        # R-KIND-OVERRIDE-DEFI-ONLY (codex P2-002.3 finding F-C). Only
        # ``_make_defi_edge`` is documented as a ``kind_override``
        # propagation site; a non-DEFI edge carrying the key in
        # ``extras`` is out-of-contract noise. Defer BEFORE reading
        # ``extras["kind_override"]`` so the rank-4 predicate never
        # steals the classification from the rank/fallback that
        # legitimately handles this EdgeKind.
        return f"kind_override applies to DEFI edges only (got {edge.kind.name})"
    override = edge.extras.get("kind_override")
    if override is None:
        return "no kind_override in extras"
    if not isinstance(override, str):
        # Codex P2-002.3 finding F-B — defensive guard. ``FlowEdge.extras``
        # admits nested mappings (the recursive freeze pipeline accepts
        # dict/list-of-scalars and stores nested ``dict`` as
        # ``MappingProxyType``); a hashable-but-non-string ``kind_override``
        # would otherwise raise ``TypeError`` from the
        # ``override not in _KNOWN_KIND_OVERRIDES`` check below (the
        # frozenset's ``__contains__`` hashes its argument, and hashing a
        # ``MappingProxyType`` raises). Defer to fallback like any other
        # unknown override per R-KIND-OVERRIDE-DEFER-UNKNOWN.
        return f"kind_override is not a string (type={type(override).__name__})"
    if override == _BRIDGE_OUT_BOUNDARY:
        # R-KIND-OVERRIDE-DEFER-BOUNDARY — Stage 8 boundary recognizer
        # consumption lives in rank 6 ``is_out_of_scope_boundary``
        # (P2-008.3 — shifted from rank 5 to rank 6 by P2-005.3's
        # rank-5 ``is_address_label_anchor`` insertion). Returning a
        # defer reason here keeps the rank-4 predicate False so the
        # edge falls through (past rank 5 attribution-anchor for which
        # it doesn't qualify either) to rank 6 which consumes the
        # ``stage_label`` to disambiguate POLYGON vs SOLANA_MAYAN and
        # emits ``TRACE_TERMINATED`` with a boundary-specific rationale.
        return "bridge_out_boundary handled at rank 6"
    if override not in _KNOWN_KIND_OVERRIDES:
        # R-KIND-OVERRIDE-DEFER-UNKNOWN — forward-compatibility. A new
        # decoder may emit a new ``kind_override`` value before the
        # classifier knows what to do with it; deferring keeps the
        # downstream fallback table intact.
        return f"kind_override {override!r} not in known set"
    if override == "swap" and edge.source.chain not in (ChainId.ETHEREUM, ChainId.ARBITRUM):
        # R-KIND-OVERRIDE-CHAIN-AWARE-SWAP — swap branches on source
        # chain. ETH → Stage 3-A (direct sell), ARB → Stage 3-B
        # (defensive). Other chains (BTC) have no Phase 2 swap emitter
        # so defer to btc_layered / fallback.
        return (
            f"swap kind_override: source chain {edge.source.chain!r} not in {{ETHEREUM, ARBITRUM}}"
        )
    return None


def _address_label_anchor_match(edge: FlowEdge, ctx: ClassifierContext) -> tuple[str, str] | None:
    """Return ``(attribution_role, endpoint)`` if either endpoint matches.

    Resolves the source-vs-target precedence rule for rank 5
    ``is_address_label_anchor`` (P2-005.3). Source wins per
    R-ATTRIBUTION-ROLE-SOURCE-OVER-TARGET: an :class:`AddressLabel`
    describes "this wallet is X", and when the wallet is the SOURCE of
    the edge, the edge represents that wallet ACTING. Target-side
    attribution is consulted only when no source label carries a known
    role.

    Defensive guard against forged ``AddressLabel.extras["attribution_role"]``
    values that aren't strings (``MappingProxyType`` / ``int`` / ``None``):
    ``isinstance(role, str)`` runs BEFORE the frozenset ``in`` check,
    mirroring F-B parity in :func:`_kind_override_problem` line 157.

    Returns ``None`` when no label on either endpoint carries a role
    inside :data:`_KNOWN_ATTRIBUTION_ROLES`.
    """
    src_key = canonical_address_key(edge.source)
    tgt_key = canonical_address_key(edge.target)
    source_labels = ctx.address_labels_by_key.get(src_key, ())
    for label in source_labels:
        role = label.extras.get("attribution_role")
        if isinstance(role, str) and role in _KNOWN_ATTRIBUTION_ROLES:
            return role, "source"
    target_labels = ctx.address_labels_by_key.get(tgt_key, ())
    for label in target_labels:
        role = label.extras.get("attribution_role")
        if isinstance(role, str) and role in _KNOWN_ATTRIBUTION_ROLES:
            return role, "target"
    return None


def _address_label_anchor_problem(
    graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext
) -> str | None:
    """Rank 5 — promote :class:`AddressLabel.extras["attribution_role"]`
    into a Stage label (P2-005.3 / P2-006.3 / P2-007.3 / P3-XVAL3).

    Consumes the 6 attribution-role markers stamped by the P2-005.0 /
    P2-006.0 / P2-007.0 / P3-XVAL3 labelers onto :class:`GraphNode.label`
    (the SSOT — see ``graph.py:189``). Mapping per
    :data:`_ATTRIBUTION_ROLE_TO_STAGE`:

        * ``smurfing_residual_sweep``   → ``STAGE_6``
          (Sky LitePSM ≥0.999 residual sweep — P2-005.0).
        * ``eth_btc_ratio_attribution`` → ``STAGE_7``
          (THORChain ETH→BTC swap cluster, ~33.3x ratio — P2-006.0).
        * ``btc_peeling_chain_origin``  → ``STAGE_8_BTC_L1``
          (BTC peel-chain N-hop UNKNOWN origin — P2-007.0).
        * ``btc_coinjoin_pool_entry``   → ``STAGE_8_BTC_L1``
          (Wasabi/JoinMarket ≥7 inputs ≥800 outputs — P2-007.0).
        * ``btc_vault_address``         → ``STAGE_8_BTC_L1``
          (≥10 BTC inflow + ≥10 24h splits — P2-007.0).
        * ``btc_address_reuse_attribution`` → ``STAGE_8_BTC_L1``
          (BTC recipient address reused across ≥2 THORChain deposits —
          a BTC-chain re-consolidation address, NOT the cross-chain
          ``STAGE_7`` of its EVM-anchored ``eth_btc_ratio`` twin —
          P3-XVAL3).

    Source-vs-target precedence (R-ATTRIBUTION-ROLE-SOURCE-OVER-TARGET):
    when the SOURCE endpoint of the edge carries a label with a known
    attribution role, the edge represents that wallet ACTING under
    that role. Source wins outright; target-side attribution is the
    fallback signal (e.g. ``btc_coinjoin_pool_entry`` typically rides
    on edges going INTO the coordinator-inferred pool entry — the
    target — so the target-side branch is the dominant carrier).

    Defer cases (predicate False; falls through to rank 6..11 / fallback):

        * ``edge.kind == EdgeKind.ABRIDGED`` → defer to F1 inheritance
          (ABRIDGED markers carry no per-edge data and inherit their
          source's acting stage via the outgoing-label cache).
        * No label on either endpoint → defer (forward-compat with the
          NullLabelerService default → empty
          ``ctx.address_labels_by_key`` → every edge defers).
        * Labels present but no recognised attribution role → defer
          (R-ATTRIBUTION-ROLE-WHITELIST-CLASSIFIER —
          forward-compatibility for future labelers).
        * Non-string ``attribution_role`` (``MappingProxyType`` /
          ``int`` / ``None``) → defer defensively
          (R-NON-STRING-ATTRIBUTION-ROLE-DEFERS).

    R-ADDRESS-LABEL-NODE-LEVEL-NOT-EDGE-EXTRAS — reads
    ``ctx.address_labels_by_key`` (derived from ``GraphNode.label``),
    NEVER ``edge.extras``. Two edges identical in every edge-visible
    field share the same node-label lookup so ``edge_id`` does NOT need
    extending (R-NO-EDGE-ID-CHANGE-FROM-NODE-LABELS — R-EDGE-ID-LABEL-
    AFFECTING-FIELDS held negatively).

    Rank-5 deliberately sits between rank-4 ``is_kind_override`` and
    rank-6 ``is_out_of_scope_boundary``: F-alpha pre-block —
    ``kind_override`` is stronger explicit semantics emitted by the
    decoder vertical; an ``attribution_role`` is post-hoc pattern
    recognition. When both fire on the same edge, kind_override wins
    (pinned by ``TestKindOverrideStillWinsOverAddressLabelAnchor``).
    Rank-5 BEFORE boundary: boundary is a terminus marker; if both
    fire on the same edge, attribution stage wins (the boundary
    outcome would later strip the attribution evidence).
    """
    del graph
    if edge.kind == EdgeKind.ABRIDGED:
        return _ABRIDGED_DEFER_F1_INHERITANCE
    match = _address_label_anchor_match(edge, ctx)
    if match is None:
        return "no AddressLabel with known attribution_role on source or target"
    return None


def _out_of_scope_boundary_problem(
    graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext
) -> str | None:
    """Rank 6 — Stage 8 boundary recognizer wiring (P2-008.3).

    Consumes ``edge.extras["kind_override"]=="bridge_out_boundary"`` plus
    ``edge.extras["stage_label"] in _KNOWN_OUT_OF_SCOPE_STAGE_LABELS`` to
    drive the :class:`StageLabel.TRACE_TERMINATED` rationale-string
    disambiguation. Mapping:

        * ``stage_label="OUT_OF_SCOPE_POLYGON"`` →
          rationale ``"out_of_scope_boundary:OUT_OF_SCOPE_POLYGON"``
          (Polygon PoS Bridge ``depositFor`` per P2-008.0d).
        * ``stage_label="OUT_OF_SCOPE_SOLANA_MAYAN"`` →
          rationale ``"out_of_scope_boundary:OUT_OF_SCOPE_SOLANA_MAYAN"``
          (Mayan Forwarder ``forwardERC20`` per P2-008.0e).

    Defer cases (predicate False; falls through to rank 7..11 / fallback):

        * ABRIDGED edges → defer to F1 inheritance.
        * Non-DEFI EdgeKinds → defer (R-KIND-OVERRIDE-DEFI-ONLY — same
          guard as rank 4; the boundary marker originates in
          ``DefiAction.extras`` and is propagated by
          ``_make_defi_edge`` only; non-DEFI carriers are
          out-of-contract noise).
        * Missing / non-string ``kind_override`` → defer.
        * ``kind_override != "bridge_out_boundary"`` → defer
          (rank 4 ``is_kind_override`` claims the swap / bridge_send
          cases; this predicate is the boundary-only complement).
        * Missing / non-string ``stage_label`` → defer (R-1 codex F-B
          parity — defensive against frozen-mapping leaf values).
        * ``stage_label`` outside ``_KNOWN_OUT_OF_SCOPE_STAGE_LABELS`` →
          defer (R-OUT-OF-SCOPE-BOUNDARY-FROZENSET; forward-compat for
          future boundary chains).

    Pairs with the tracer-side BFS termination hook in
    :meth:`vca.tracer._run._TraceRun._expand_tx` — the hook upserts the
    boundary target + marks it ``TerminationReason.TERMINAL_LABEL`` so
    the BFS frontier never expands it. This classifier rule provides the
    rationale string that distinguishes a true boundary terminus from a
    generic terminal-label node (rank-11 ``trace_terminated`` emits
    ``trace_terminated:reason=...``; rank-6 emits the boundary-aware
    ``out_of_scope_boundary:<stage_label>`` instead).

    R-OUT-OF-SCOPE-BOUNDARY-FROZENSET: only the 2 enumerated values
    trigger termination; new chains require an explicit frozenset entry.
    Codex pre-emption F-B: non-string ``stage_label`` defers (defensive
    against ``MappingProxyType`` leaf values that fail ``hash()``).
    Codex pre-emption F-C: ``edge.kind == EdgeKind.DEFI`` gate FIRST.
    """
    del graph, ctx
    if edge.kind == EdgeKind.ABRIDGED:
        return _ABRIDGED_DEFER_F1_INHERITANCE
    if edge.kind != EdgeKind.DEFI:
        # R-KIND-OVERRIDE-DEFI-ONLY — same DEFI-only gate as rank 4
        # (codex P2-002.3 finding F-C). Non-DEFI carriers of the
        # boundary marker are out-of-contract noise; defer BEFORE reading
        # ``extras["kind_override"]`` so the rank-6 predicate never
        # steals a TRANSFER / CROSS_CHAIN classification.
        return f"out_of_scope_boundary applies to DEFI edges only (got {edge.kind.name})"
    override = edge.extras.get("kind_override")
    if not isinstance(override, str):
        # Missing key (None) or non-string (e.g. MappingProxyType leaf
        # from a forged extras shape) — defer. Codex F-B parity.
        return "kind_override missing or not a string"
    if override != _BRIDGE_OUT_BOUNDARY:
        # Rank 4 already claimed swap / bridge_send; only the boundary
        # marker reaches rank 6.
        return f"kind_override {override!r} is not {_BRIDGE_OUT_BOUNDARY!r}"
    stage_label_value = edge.extras.get("stage_label")
    if not isinstance(stage_label_value, str):
        # Defensive — boundary recognizers always emit a string stage
        # label, but if a forged / unfrozen extras shape carries
        # something else, defer rather than raise from the frozenset
        # ``in`` check (codex F-B parity).
        return f"stage_label missing or not a string (type={type(stage_label_value).__name__})"
    if stage_label_value not in _KNOWN_OUT_OF_SCOPE_STAGE_LABELS:
        # R-OUT-OF-SCOPE-BOUNDARY-FROZENSET — forward-compatibility.
        # New boundary chains are added by appending to
        # ``_KNOWN_OUT_OF_SCOPE_STAGE_LABELS`` in lockstep with a new
        # decoder ship; until then the edge falls through to fallback.
        return f"stage_label {stage_label_value!r} not in known out-of-scope set"
    return None


def _smurfing_problem(graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext) -> str | None:
    del graph
    if edge.kind != EdgeKind.TRANSFER or edge.value_minor is None:
        return f"edge.kind {edge.kind.value} or value_minor missing"
    if edge.source.chain == ChainId.BITCOIN:
        # P2-005.3 rank shift: rank 9 → rank 10 for btc_layered.
        return "BTC source defers to btc_layered (rank 10)"
    anchor = ctx.smurf_anchor_for_edge(edge)
    if anchor is None:
        return "edge has no precomputed smurf anchor"
    cluster_key = (
        canonical_address_key(edge.source),
        edge.asset_symbol,
        edge.decimals,
        anchor,
    )
    cluster = ctx.smurf_clusters.get(cluster_key, ())
    if len(cluster) < ctx.policy.smurf_threshold:
        return f"cluster size {len(cluster)} < threshold {ctx.policy.smurf_threshold}"
    # scan #13 AGG-2: smurfing (structuring) is distribution across MANY
    # recipient wallets — repeated near-equal deposits to a SINGLE wallet are
    # ordinary consolidation / instalment payment, not a laundering fan-out.
    # Counting cluster EDGES (above) over-fires: a source paying ONE wallet in
    # N near-equal instalments would clear the threshold. Mirror the fan-in
    # predicate (``_fan_in_problem`` counts distinct SOURCES) by requiring the
    # cluster to reach ``smurf_threshold`` DISTINCT recipients. Reverses the
    # deliberate P3.2-007.1 edge-count boundary (golden re-blessed: KelpDAO
    # Stage 6 163 → 105).
    distinct_targets = {canonical_address_key(e.target) for e in cluster}
    if len(distinct_targets) < ctx.policy.smurf_threshold:
        return (
            f"distinct recipients {len(distinct_targets)} < threshold {ctx.policy.smurf_threshold}"
        )
    return None


def _fan_in_problem(graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext) -> str | None:
    # ABRIDGED markers MUST NOT be claimed by fan_in (codex P1-015 R2
    # finding #3): they are synthetic branching breadcrumbs and must
    # flow to F1 inheritance instead.
    if edge.kind == EdgeKind.ABRIDGED:
        return _ABRIDGED_DEFER_F1_INHERITANCE
    # Codex P1-015 R10 finding #1 — CROSS_CHAIN edges with unknown
    # decoders must reach fallback F5 (target-chain mapping: BTC →
    # ``STAGE_7``, ARB → ``STAGE_3_B``, else → ``STAGE_5``). Without this
    # defer, an unknown-decoder CROSS_CHAIN edge that happens to land in
    # a fan-in burst is mis-labelled by ``fan_in_outcome`` as ``STAGE_4``,
    # losing the F5 specialised handling. Rank 2 (``cross_chain_hop``)
    # still wins for KNOWN decoders because precedence places it ahead
    # of rank 6 (P2-002.3 rank shift: was rank 5 pre-P2-002.3). Symmetric
    # to the R3 finding #1 / R4 finding #3 / R9 finding #2 defer pattern:
    # ranks with catch-all triggers must explicitly defer kinds that
    # have specialised fallback handling.
    if edge.kind == EdgeKind.CROSS_CHAIN:
        return "cross-chain edge defers to fallback F5"
    # Codex P1-015 R4 finding #1 — seed-anchor exclusion must be
    # chain-aware. ``_seed_anchor_problem`` is the SSOT (R-SSOT-PREDICATE);
    # delegate so a tx_hash collision on a different chain (ARB edge sharing
    # the ETH seed hash) does NOT exclude the edge from fan_in.
    if _seed_anchor_problem(graph, edge, ctx) is None:
        return "seed-anchor edge excluded from fan_in"
    if edge.target.chain == ChainId.BITCOIN:
        # P2-005.3 rank shift: rank 9 → rank 10 for btc_layered.
        return "BTC target defers to btc_layered (rank 10)"
    tgt_key = canonical_address_key(edge.target)
    # Codex P1-015 R2 finding #2 — the predicate must require this edge
    # to be IN the densest window before counting cluster sources, so
    # outliers outside the burst do not inherit a fan label from an
    # unrelated cluster on the same target.
    if not ctx.fan_in_includes(tgt_key, edge):
        return f"edge outside fan_in window for target {tgt_key}"
    cluster = ctx.fan_in_clusters.get(tgt_key, ())
    distinct_sources = {canonical_address_key(e.source) for e in cluster}
    if len(distinct_sources) < ctx.policy.fan_threshold:
        return f"distinct sources {len(distinct_sources)} < threshold {ctx.policy.fan_threshold}"
    return None


def _fan_out_problem(graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext) -> str | None:
    del graph
    # ABRIDGED markers MUST NOT be claimed by fan_out — codex P1-015 R2
    # finding #3.
    if edge.kind == EdgeKind.ABRIDGED:
        return _ABRIDGED_DEFER_F1_INHERITANCE
    # Codex P1-015 R10 finding #1 — CROSS_CHAIN edges with unknown
    # decoders must reach fallback F5 (target-chain mapping: BTC →
    # ``STAGE_7``, ARB → ``STAGE_3_B``, else → ``STAGE_5``). Without this
    # defer, an unknown-decoder CROSS_CHAIN edge that happens to land in
    # a fan-out burst is mis-labelled by ``fan_out_outcome`` as
    # ``STAGE_2`` (source depth 0) or ``STAGE_5`` (source depth >= 1),
    # losing the F5 specialised handling. Rank 2 (``cross_chain_hop``)
    # still wins for KNOWN decoders because precedence places it ahead
    # of rank 7 (P2-002.3 rank shift: was rank 6 pre-P2-002.3). Symmetric
    # to the R3 finding #1 / R4 finding #3 / R9 finding #2 defer pattern:
    # ranks with catch-all triggers must explicitly defer kinds that
    # have specialised fallback handling.
    if edge.kind == EdgeKind.CROSS_CHAIN:
        return "cross-chain edge defers to fallback F5"
    if edge.source.chain == ChainId.BITCOIN:
        # P2-005.3 rank shift: rank 9 → rank 10 for btc_layered.
        return "BTC source defers to btc_layered (rank 10)"
    src_key = canonical_address_key(edge.source)
    # Codex P1-015 R2 finding #2 — require edge membership in the
    # chosen burst window, not just the source's cluster size.
    if not ctx.fan_out_includes(src_key, edge):
        return f"edge outside fan_out window for source {src_key}"
    cluster = ctx.fan_out_clusters.get(src_key, ())
    distinct_targets = {canonical_address_key(e.target) for e in cluster}
    if len(distinct_targets) < ctx.policy.fan_threshold:
        return f"distinct targets {len(distinct_targets)} < threshold {ctx.policy.fan_threshold}"
    return None


def _btc_layered_problem(graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext) -> str | None:
    del graph, ctx
    if edge.source.chain != ChainId.BITCOIN and edge.target.chain != ChainId.BITCOIN:
        return "edge does not touch BTC chain"
    # Codex P1-015 R9 finding #2 — ABRIDGED edges on BTC nodes MUST
    # defer to F1 inheritance instead of being claimed by rank 8
    # (P2-002.3 rank shift: was rank 7 pre-P2-002.3). The rank-8
    # BTC-touching predicate would otherwise label an ABRIDGED
    # self-loop on a BTC node as ``Stage 8 / BTC L<depth>`` from the
    # generic depth-based formula (``btc_layered_outcome``), losing the
    # source node's previously-assigned BTC layer. Symmetric to the R3
    # finding #1 CROSS_CHAIN defer below.
    if edge.kind == EdgeKind.ABRIDGED:
        return _ABRIDGED_DEFER_F1_INHERITANCE
    # Codex P1-015 R3 finding #1 — a CROSS_CHAIN edge whose decoder is
    # absent from ``policy.cross_chain_decoder_stage_map`` must reach
    # fallback F5 (which assigns ``STAGE_7`` for BTC targets) instead of
    # being claimed by rank 8 ``btc_layered`` (P2-002.3 rank shift: was
    # rank 7 pre-P2-002.3) and mis-labelled as ``Stage 8 / BTC L*``.
    # Rank 2 (``cross_chain_hop``) still wins for known decoders because
    # precedence places it ahead of rank 8.
    if edge.kind == EdgeKind.CROSS_CHAIN:
        return "cross-chain edge defers to fallback F5"
    return None


def _trace_terminated_problem(
    graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext
) -> str | None:
    del ctx
    # Codex P1-015 R11 finding #2 — ABRIDGED edges MUST defer to F1
    # inheritance instead of being claimed by rank 9 (P2-002.3 rank
    # shift: was rank 8 pre-P2-002.3) even when their target is in
    # ``graph.terminal_reasons``. Symmetric to the rank 8 (R9 finding #2,
    # was rank 7 pre-P2-002.3), rank 7/6 (R10 finding #1, was rank 6/5
    # pre-P2-002.3) defer pattern: ranks with catch-all triggers must
    # explicitly defer kinds with specialised fallback handling.
    # Without this, an ABRIDGED edge whose target is a
    # TERMINAL_LABEL/MAX_DEPTH node gets ``STAGE_TRACE_TERMINATED``
    # instead of inheriting the source's acting-stage via F1.
    if edge.kind == EdgeKind.ABRIDGED:
        return _ABRIDGED_DEFER_F1_INHERITANCE
    # Codex P1-015 R12 finding — CROSS_CHAIN edges with unknown decoders
    # whose target lands on a terminal (``TERMINAL_LABEL`` /
    # ``MAX_DEPTH``) node MUST defer to fallback F5's target-chain
    # mapping (BTC → ``STAGE_7``, ARB → ``STAGE_3_B``, else → ``STAGE_5``)
    # instead of being relabelled ``STAGE_TRACE_TERMINATED`` by rank 9
    # (P2-002.3 rank shift: was rank 8 pre-P2-002.3).
    # Concrete pre-fix failure: an unknown-decoder bridge ETH → ARB CEX
    # address (target in ``terminal_reasons``) was caught here and lost
    # the F5 ARB carve-out → rank 9 produced ``TRACE_TERMINATED`` rather
    # than ``STAGE_3_B``. Symmetric to:
    #   * R3 finding #1 — rank 8 (was 7) defers CROSS_CHAIN to F5 BTC mapping.
    #   * R4 finding #3 — F5 reordered before F2 so unknown CROSS_CHAIN
    #     never falls into the BTC catch-all.
    #   * R10 finding #1 — ranks 6/7 (was 5/6) defer CROSS_CHAIN to F5.
    #   * R11 finding #2 — rank 9 (was 8) defers ABRIDGED to F1 (above).
    # Rank 2 (``cross_chain_hop``) still wins for KNOWN decoders because
    # precedence places it ahead of rank 9.
    if edge.kind == EdgeKind.CROSS_CHAIN:
        return "cross-chain edge defers to fallback F5"
    target_key = canonical_address_key(edge.target)
    reason = graph.terminal_reasons.get(target_key)
    if reason is None:
        return "edge target not in terminal_reasons"
    if reason not in (TerminationReason.TERMINAL_LABEL, TerminationReason.MAX_DEPTH):
        return f"reason {reason.value} not in {{terminal_label, max_depth}}"
    # Any BTC-touching edge defers to rank 8 ``btc_layered`` (P2-002.3
    # rank shift: was rank 7 pre-P2-002.3) or, for the
    # CROSS_CHAIN-to-BTC carve-out (codex P1-015 R3 finding #1), to
    # fallback F5. We keep the original BTC chain check inlined here so
    # the change to ``_btc_layered_problem`` does not accidentally let
    # CROSS_CHAIN-to-BTC edges leak into ``TRACE_TERMINATED``.
    if edge.source.chain == ChainId.BITCOIN or edge.target.chain == ChainId.BITCOIN:
        return "BTC-touching edge excluded from trace_terminated"
    return None


# ---------------------------------------------------------------------------
# Predicate ↔ asserter pairing helper
# ---------------------------------------------------------------------------


def _make_predicate(
    name: str,
    finder: Callable[[CaseGraph, FlowEdge, ClassifierContext], str | None],
) -> tuple[
    Callable[[CaseGraph, FlowEdge, ClassifierContext], bool],
    Callable[[CaseGraph, FlowEdge, ClassifierContext], None],
]:
    def predicate(graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext) -> bool:
        return finder(graph, edge, ctx) is None

    def asserter(graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext) -> None:
        problem = finder(graph, edge, ctx)
        if problem is not None:
            raise ValueError(f"{name}: {problem}")

    predicate.__name__ = f"is_{name}"
    asserter.__name__ = f"assert_is_{name}"
    return predicate, asserter


is_seed_anchor, assert_is_seed_anchor = _make_predicate("seed_anchor", _seed_anchor_problem)
is_cross_chain_hop, assert_is_cross_chain_hop = _make_predicate(
    "cross_chain_hop", _cross_chain_hop_problem
)
is_defi_collateral, assert_is_defi_collateral = _make_predicate(
    "defi_collateral", _defi_collateral_problem
)
is_kind_override, assert_is_kind_override = _make_predicate("kind_override", _kind_override_problem)
is_address_label_anchor, assert_is_address_label_anchor = _make_predicate(
    "address_label_anchor", _address_label_anchor_problem
)
is_out_of_scope_boundary, assert_is_out_of_scope_boundary = _make_predicate(
    "out_of_scope_boundary", _out_of_scope_boundary_problem
)
is_smurfing, assert_is_smurfing = _make_predicate("smurfing", _smurfing_problem)
is_fan_in, assert_is_fan_in = _make_predicate("fan_in", _fan_in_problem)
is_fan_out, assert_is_fan_out = _make_predicate("fan_out", _fan_out_problem)
is_btc_layered, assert_is_btc_layered = _make_predicate("btc_layered", _btc_layered_problem)
is_trace_terminated, assert_is_trace_terminated = _make_predicate(
    "trace_terminated", _trace_terminated_problem
)


# ---------------------------------------------------------------------------
# Outcome producers — turn a winning predicate into (StageLabel, rationale).
# ---------------------------------------------------------------------------


def seed_anchor_outcome(
    graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext
) -> tuple[StageLabel, str]:
    del graph, ctx
    return StageLabel.STAGE_1, f"seed_anchor:tx={(edge.tx_hash or '')[:18]}"


def cross_chain_outcome(
    graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext
) -> tuple[StageLabel, str]:
    del graph
    decoder = edge.decoder or ""
    label = ctx.policy.cross_chain_decoder_stage_map[decoder]
    return label, f"cross_chain_hop:decoder={decoder}"


def defi_outcome(
    graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext
) -> tuple[StageLabel, str]:
    del graph, ctx
    src_chain = edge.source.chain
    if src_chain == ChainId.ETHEREUM:
        label = StageLabel.STAGE_3_A
    elif src_chain == ChainId.ARBITRUM:
        label = StageLabel.STAGE_3_B
    else:
        label = StageLabel.STAGE_5
    return label, f"defi_collateral:decoder={edge.decoder or ''}"


def kind_override_outcome(
    graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext
) -> tuple[StageLabel, str]:
    """Rank-4 outcome producer — turn ``edge.extras["kind_override"]``
    into a (StageLabel, rationale) pair.

    Pre-condition: ``_kind_override_problem(graph, edge, ctx) is None``,
    which means ``edge.extras["kind_override"]`` is in
    ``_KNOWN_KIND_OVERRIDES`` AND (when ``"swap"``) the source chain is
    ETH or ARB. The defer cases (ABRIDGED, missing extras, unknown
    value, ``bridge_out_boundary``, BTC swap) are filtered upstream.

    Mapping summary (matches the ``_kind_override_problem`` docstring):

      * ``"swap"`` + ETH source → ``STAGE_3_A``
        (supplement PDF §3.가.3 "직접 매도")
      * ``"swap"`` + ARB source → ``STAGE_3_B`` (defensive — consistent
        with fallback F6 ``defi_arb``; no Phase 2 emitter routes ARB
        swap today)
      * ``"bridge_send"`` (any source chain) → ``STAGE_3_B`` (LayerZero
        v2 OFT bridge SEND, chain-agnostic mapping)

    R-KIND-OVERRIDE-CHAIN-AWARE-SWAP / R-KIND-OVERRIDE-CHAIN-AGNOSTIC-BRIDGE.

    Extras ARE in ``edge_id`` (codex P2-002.3 finding F-A —
    supersedes the P2-002.2 propagation-only contract). Two DEFI edges
    differing only in ``extras`` produce DIFFERENT ``edge_id`` so the
    post-sort occurrence counter never falls back to input position to
    discriminate them, preserving permutation invariance (pinned by
    ``tests/unit/tracer/test_extras_propagation.py``::
    ``test_edge_id_includes_extras_signature``).

    TODO(P2-008): ``STAGE_8_ROUTE_B`` disambiguation requires
    depth/wallet-identity context (no enum exists today; closed Phase 1
    vocab). CoW Protocol DAI→USDT and Sky LitePSM DAI→USDC at the
    consolidation wallet ``0x0A6272bE`` classify as ``STAGE_3_A`` here;
    the reporter / P2-008 vertical can re-label using cluster context.
    """
    del graph, ctx
    override = str(edge.extras["kind_override"])
    rationale = f"kind_override:value={override}"
    if override == "bridge_send":
        # R-KIND-OVERRIDE-CHAIN-AGNOSTIC-BRIDGE — LayerZero v2 OFT
        # SEND is always Stage 3-B regardless of source chain (today
        # only ETH→ARB is emitted, but the wire format is
        # chain-agnostic).
        return StageLabel.STAGE_3_B, rationale
    # override == "swap" — _kind_override_problem already filtered out
    # non-{ETHEREUM, ARBITRUM} source chains.
    if edge.source.chain == ChainId.ARBITRUM:
        return StageLabel.STAGE_3_B, rationale
    # ChainId.ETHEREUM (the only remaining choice after the swap chain
    # filter in ``_kind_override_problem``).
    return StageLabel.STAGE_3_A, rationale


def address_label_anchor_outcome(
    graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext
) -> tuple[StageLabel, str]:
    """Rank-5 outcome producer — turn a winning :class:`AddressLabel`
    attribution role into a (StageLabel, rationale) pair (P2-005.3).

    Pre-condition: ``_address_label_anchor_problem(graph, edge, ctx) is
    None`` — i.e. ``edge.kind != EdgeKind.ABRIDGED`` AND
    :func:`_address_label_anchor_match` returned a non-None
    ``(role, endpoint)`` tuple. Source endpoint wins over target per
    R-ATTRIBUTION-ROLE-SOURCE-OVER-TARGET — the helper resolves the
    precedence; the outcome producer simply re-derives the match and
    emits the stage / rationale.

    Mapping per :data:`_ATTRIBUTION_ROLE_TO_STAGE`:

      * ``smurfing_residual_sweep``       → ``STAGE_6``
      * ``eth_btc_ratio_attribution``     → ``STAGE_7``
      * ``btc_peeling_chain_origin``      → ``STAGE_8_BTC_L1``
      * ``btc_coinjoin_pool_entry``       → ``STAGE_8_BTC_L1``
      * ``btc_vault_address``             → ``STAGE_8_BTC_L1``
      * ``btc_address_reuse_attribution`` → ``STAGE_8_BTC_L1``

    Rationale format:
    ``"address_label_anchor:role=<role>:endpoint=<source|target>"`` —
    complies with :data:`vca.tracer.stage_classifier._vocab.RATIONALE_RE`
    (lowercase identifier + ``:`` + ASCII payload). The ``endpoint``
    suffix is the precedence breadcrumb (always ``source`` or
    ``target``); analysts can grep the rationale to find which side of
    the edge carried the marker.

    R-NO-EDGE-ID-CHANGE-FROM-NODE-LABELS — extras digest in
    ``edge_id`` is unaffected because this rule reads NODE-level not
    EDGE-level fields. Two edges with identical
    ``(source, target, tx_hash, kind, value_minor, asset, decimals,
    decoder, block, extras)`` still receive the SAME ``edge_id`` and
    are discriminated by the post-sort ``|#N`` occurrence counter
    regardless of attribution-role state on their endpoint nodes
    (pinned by ``TestPermutationInvarianceWithAttributionRoles``).
    """
    del graph
    match = _address_label_anchor_match(edge, ctx)
    # Pre-condition: the predicate only fires when match is not None.
    # The defensive ``assert`` documents the contract; a missing match
    # at outcome time would be a Phase-2 invariant violation (predicate
    # ↔ outcome SSOT broken).
    assert match is not None, (
        "address_label_anchor_outcome called without a winning AddressLabel match"
    )
    role, endpoint = match
    stage = _ATTRIBUTION_ROLE_TO_STAGE[role]
    rationale = f"address_label_anchor:role={role}:endpoint={endpoint}"
    return stage, rationale


def out_of_scope_boundary_outcome(
    graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext
) -> tuple[StageLabel, str]:
    """Rank-6 outcome producer — emit
    :class:`StageLabel.TRACE_TERMINATED` with a rationale string keyed
    on ``edge.extras["stage_label"]``.

    Pre-condition: ``_out_of_scope_boundary_problem(graph, edge, ctx) is
    None`` — i.e. ``edge.kind == EdgeKind.DEFI``, ``kind_override ==
    "bridge_out_boundary"`` and ``stage_label`` is in
    :data:`_KNOWN_OUT_OF_SCOPE_STAGE_LABELS`. All defer cases
    (non-DEFI, missing/wrong override, unknown stage label) are filtered
    upstream by the predicate.

    Rationale format: ``"out_of_scope_boundary:<stage_label>"`` — the
    stage label is the exact verbatim value from extras (already
    validated as a string + in the frozenset). Compatible with the
    classifier ``RATIONALE_RE`` charset (lowercase identifier + ``:`` +
    ASCII payload).
    """
    del graph, ctx
    stage_label_value = str(edge.extras["stage_label"])
    rationale = f"out_of_scope_boundary:{stage_label_value}"
    return StageLabel.TRACE_TERMINATED, rationale


def smurfing_outcome(
    graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext
) -> tuple[StageLabel, str]:
    del graph
    anchor = ctx.smurf_anchor_for_edge(edge)
    cluster: tuple[FlowEdge, ...] = ()
    if anchor is not None:
        cluster = ctx.smurf_clusters.get(
            (canonical_address_key(edge.source), edge.asset_symbol, edge.decimals, anchor),
            (),
        )
    return StageLabel.STAGE_6, f"smurfing:cluster_size={len(cluster)}"


def fan_in_outcome(
    graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext
) -> tuple[StageLabel, str]:
    del graph
    cluster = ctx.fan_in_clusters.get(canonical_address_key(edge.target), ())
    distinct = len({canonical_address_key(e.source) for e in cluster})
    return StageLabel.STAGE_4, f"fan_in:sources={distinct}"


def fan_out_outcome(
    graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext
) -> tuple[StageLabel, str]:
    src_key = canonical_address_key(edge.source)
    src_node = ctx.nodes_by_key.get(src_key)
    src_depth = 0 if src_node is None else src_node.depth
    cluster = ctx.fan_out_clusters.get(src_key, ())
    distinct = len({canonical_address_key(e.target) for e in cluster})
    if src_depth == 0 and edge.tx_hash == graph.seed_tx.tx_hash:
        # Seed anchor wins via rank 1 — defensive STAGE_2 for depth-0 fallback.
        label = StageLabel.STAGE_2
    elif src_depth == 0:
        label = StageLabel.STAGE_2
    elif src_key in ctx.primary_receiver_keys:
        # P1-024 / FINDING-A — the Primary Receiver is the target of the
        # seed-anchor edge (depth 1) and its fan-out is documented Stage 2
        # ("초기 분산 — Primary Receiver → 7개 분산 지갑") per
        # ``docs/source/03_KelpDAO_rsETH_Exploit_분석.md`` §3.가.3 (3).
        # Without this branch the pre-P1-024 ``src_depth >= 1 → STAGE_5``
        # default mis-labelled the documented Stage 2 dispersal as
        # Stage 5 re-distribution. Membership in
        # ``ctx.primary_receiver_keys`` is restricted to seed-anchor
        # targets (R-alpha-3 guard), so depth-1 dispersal wallets that
        # themselves emit a fan-out (a real "secondary" re-distribution)
        # still fall through to STAGE_5 below.
        label = StageLabel.STAGE_2
    else:
        label = StageLabel.STAGE_5
    return label, f"fan_out:depth={src_depth},targets={distinct}"


def btc_layered_outcome(
    graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext
) -> tuple[StageLabel, str]:
    del graph
    # P3.2-008 — layer is keyed on the edge's SOURCE depth, not its target.
    # A BTC laundering layer is defined by where the funds depart FROM: the
    # entry one-time receiver (depth == btc_entry_depth) redistributing its
    # balance is the L1 ("BTC 수신 (일회성 주소) → 즉시 L2 재이동") activity;
    # the next hop departing one level deeper is L2, etc. Keying on the
    # target depth was off-by-one — the first BTC->BTC hop targets depth
    # entry+1 so L1 (relative 0) was structurally unreachable (the entry is
    # only ever reached by a CROSS_CHAIN edge = Stage 7). Mirror site:
    # ``_fallback.py`` F2 (kept in lockstep).
    source_node = ctx.nodes_by_key.get(canonical_address_key(edge.source))
    source_depth = 0 if source_node is None else source_node.depth
    base = 0 if ctx.btc_entry_depth is None else ctx.btc_entry_depth
    relative = source_depth - base
    layer = max(0, min(3, relative))
    label = ctx.policy.btc_layer_depths.get(layer, StageLabel.STAGE_8_BTC_L1)
    return label, f"btc_layered:layer={layer},depth={source_depth}"


def trace_terminated_outcome(
    graph: CaseGraph, edge: FlowEdge, ctx: ClassifierContext
) -> tuple[StageLabel, str]:
    del ctx
    reason = graph.terminal_reasons.get(canonical_address_key(edge.target))
    reason_value = reason.value if reason is not None else "unknown"
    return StageLabel.TRACE_TERMINATED, f"trace_terminated:reason={reason_value}"


__all__ = [
    "address_label_anchor_outcome",
    "assert_is_address_label_anchor",
    "assert_is_btc_layered",
    "assert_is_cross_chain_hop",
    "assert_is_defi_collateral",
    "assert_is_fan_in",
    "assert_is_fan_out",
    "assert_is_kind_override",
    "assert_is_out_of_scope_boundary",
    "assert_is_seed_anchor",
    "assert_is_smurfing",
    "assert_is_trace_terminated",
    "btc_layered_outcome",
    "cross_chain_outcome",
    "defi_outcome",
    "fan_in_outcome",
    "fan_out_outcome",
    "is_address_label_anchor",
    "is_btc_layered",
    "is_cross_chain_hop",
    "is_defi_collateral",
    "is_fan_in",
    "is_fan_out",
    "is_kind_override",
    "is_out_of_scope_boundary",
    "is_seed_anchor",
    "is_smurfing",
    "is_trace_terminated",
    "kind_override_outcome",
    "out_of_scope_boundary_outcome",
    "seed_anchor_outcome",
    "smurfing_outcome",
    "trace_terminated_outcome",
]
