"""ClassifierContext + edge-id helpers + smurf bucket math (P1-015)."""

from __future__ import annotations

import json
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from datetime import timedelta
from types import MappingProxyType
from typing import Any

from vca.labeler._types import AddressLabel
from vca.tracer.graph import (
    CaseGraph,
    EdgeKind,
    FlowEdge,
    GraphNode,
    canonical_address_key,
)
from vca.tracer.stage_classifier._policy import StagePolicy
from vca.types import ChainId
from vca.types._extras_freeze import thaw_extras_value


def _extras_digest(extras: Mapping[str, Any]) -> str:
    """Deterministic JSON digest of ``FlowEdge.extras`` for ``edge_id``.

    Codex P2-002.3 finding F-A — once :func:`_kind_override_problem`
    started reading ``edge.extras["kind_override"]`` to choose the rank-4
    stage label, ``extras`` joined the label-affecting set per the P1-015
    invariant **R-EDGE-ID-LABEL-AFFECTING-FIELDS** ("edge_id MUST include
    all label-affecting fields"). Two otherwise-identical DEFI edges
    where only one carries ``extras={"kind_override": "swap"}`` then
    earn DIFFERENT rationale/labels; if they share an ``edge_id`` the
    post-sort occurrence counter falls back to input position and
    reversing ``graph.edges`` swaps which edge wins the swap label —
    breaking R-DETERMINISTIC permutation invariance.

    This supersedes the P2-002.2 documentation contract
    (``test_edge_id_includes_extras_signature_or_does_not``) — that
    contract was correct only while extras was propagation-only.

    Stability rules:

    * Always thaw (:func:`vca.types._extras_freeze.thaw_extras_value`)
      first so ``MappingProxyType`` and inner frozen tuples collapse to
      plain dict/list. JSON encoders reject ``MappingProxyType``.
    * Use ``json.dumps(..., sort_keys=True, separators=(",", ":"),
      default=str)`` for compact, key-stable, ASCII-safe output. The
      freeze pipeline already restricts leaf scalars to ``str | bool |
      int | finite float | None``, so ``default=str`` is a defensive
      no-op (covers a hypothetical future leaf that ``json`` cannot
      render natively without raising).
    * Empty extras → ``"{}"`` (NOT ``""``) so the segment is always
      present and unambiguous when post-fixed onto ``edge_id``. This
      keeps the rendered shape uniform and avoids ambiguity at the
      ``|`` join boundary.
    """
    thawed = thaw_extras_value(extras)
    if not isinstance(thawed, dict):  # pragma: no cover - structural guarantee
        # ``FlowEdge.extras`` is always a Mapping; the recursive freeze in
        # :meth:`FlowEdge._freeze_extras` thaws back to ``dict``. Guard
        # defensively in case a future caller hands us a tuple/list.
        thawed = {"_extras": thawed}
    return json.dumps(thawed, sort_keys=True, separators=(",", ":"), default=str)


def _is_seed_anchor_edge(graph: CaseGraph, edge: FlowEdge) -> bool:
    """Free-function seed-anchor check — codex P1-015 R5 finding #2.

    Mirrors :func:`vca.tracer.stage_classifier._heuristics._seed_anchor_problem`
    (R-SSOT-PREDICATE) but available at ``ClassifierContext.build`` time
    where no ``ClassifierContext`` exists yet. ABRIDGED markers carry
    ``tx_hash=None`` and never satisfy the equality, so the explicit
    short-circuit at the top of :func:`_seed_anchor_problem` is implicit
    here. Chain-aware (R1 finding #2): EVM and ARB share the
    ``0x[64-hex]`` ``tx_hash`` shape so a tx_hash-only check would
    wrongly flag an ARB edge sharing the ETH seed hash.
    """
    if edge.tx_hash != graph.seed_tx.tx_hash:
        return False
    return edge.source.chain == graph.seed_tx.chain


def edge_id(edge: FlowEdge) -> str:
    """Stable per-edge identifier — see WBS §3.4.

    The id is the ``|``-joined concatenation of every ``FlowEdge`` field
    that distinguishes one logical edge from another. Each field listed
    below is INCLUDED in the id; any other field on ``FlowEdge`` is NOT
    part of the identity contract:

    * ``canonical_address_key(source)`` — chain-prefixed source address
    * ``canonical_address_key(target)`` — chain-prefixed target address
    * ``tx_hash`` (empty string when ``None``)
    * ``kind.value`` — ``EdgeKind`` discriminator
    * ``value_minor`` (empty string when ``None``)
    * ``asset_symbol`` — codex P1-015 R1 finding #1 (asset-only siblings)
    * ``decimals`` — codex P1-015 R1 finding #1 (decimal-unit siblings)
    * ``decoder`` (empty string when ``None``) — codex P1-015 R7 finding
      #1: two edges that share every other visible field but differ only
      in their decoder are LOGICALLY distinct (e.g. an ``aave_v3``
      classified edge vs an unknown bridge edge whose ``EdgeKind`` is
      still ``DEFI``). Without ``decoder`` in the id, the post-sort
      occurrence counter assigns ``|#0`` / ``|#1`` based on input
      position — and reversing ``graph.edges`` swaps which edge gets
      which rationale, breaking R-DETERMINISTIC.
    * ``block.number`` (empty string when ``edge.block is None``) —
      codex P1-015 R11 finding #1: two edges sharing every other visible
      field but emitted in DIFFERENT blocks are LOGICALLY distinct.
      Without ``block.number`` in the id, the post-sort occurrence
      counter assigns ``|#0`` / ``|#1`` based on input position; if the
      two edges fall on opposite sides of a fan-window boundary (one in
      the densest cluster, the other outside) reversing ``graph.edges``
      swaps which edge gets the fan label vs the fallback, breaking
      ``model_dump_json()`` byte-equality. ``block.number`` is the
      canonical sort key in EVM/BTC and stable as a small integer.
    * ``block.timestamp.isoformat()`` (joined to ``block.number`` with
      ``@``; empty when ``edge.block is None``) — codex P1-015 R13
      finding #1: ``BlockRef`` does NOT enforce uniqueness on
      ``(chain, number, timestamp)``, so two edges may share the same
      ``block.number`` yet carry DIFFERENT ``block.timestamp`` values
      (reorg simulations, fixture-built test cases, multi-chain graphs
      whose chains coincidentally minted matching numbers). The fan
      window in :func:`filter_window` keys on ``timestamp``, not
      ``number``, so two such edges can fall on opposite sides of the
      densest cluster and earn DIFFERENT classifications. With only
      ``block.number`` in the id the post-sort occurrence counter
      assigns ``|#0`` / ``|#1`` based on input position again — a
      regression of R11. Including the ISO 8601 timestamp closes the
      loop: ``_ensure_utc`` already normalises every ``BlockRef`` to
      UTC at validation time so the formatting is canonical and ASCII
      safe (``edge_id`` is a derived key, not a rationale value, and
      isn't bound by the rationale charset). Human-debuggable too:
      dumping ``edge_id`` shows the timestamp in readable form.
    * ``extras`` digest (compact JSON, sort_keys, ``"{}"`` when empty)
      — codex P2-002.3 finding F-A. Once :func:`_kind_override_problem`
      reads ``edge.extras["kind_override"]`` to assign a rank-4 stage
      label, ``extras`` joined the label-affecting set per the P1-015
      invariant **R-EDGE-ID-LABEL-AFFECTING-FIELDS**. Two DEFI edges
      that differ ONLY in ``extras`` then earn DIFFERENT rationale; if
      they shared an ``edge_id`` the post-sort occurrence counter would
      fall back to input position so reversing ``graph.edges`` would
      swap which edge gets the swap label — breaking permutation
      invariance. The digest is built via :func:`_extras_digest`
      (thaw → ``json.dumps`` with sorted keys + compact separators).
      Supersedes the P2-002.2 contract that extras was excluded.

    NOTE: This shape DOES NOT distinguish two edges that are identical in
    every visible field listed above (e.g. ``graph.edges = (e, e)`` or
    two ERC-20 ``Transfer`` log_index siblings emitted by the same TX
    with the same ``(from, to, value, asset, decoder, block, extras)``).
    Truly-identical edges receive a permutation-stable ``|#N`` suffix at
    :meth:`ClassifierContext.build` time — see ``edge_id_by_index`` and
    codex P1-015 R2 finding #1 / R6 finding #1.
    """
    src = canonical_address_key(edge.source)
    tgt = canonical_address_key(edge.target)
    value = "" if edge.value_minor is None else str(edge.value_minor)
    if edge.block is None:
        block_part = ""
    else:
        # Include timestamp alongside number — codex P1-015 R13 finding
        # #1. ``BlockRef`` allows same-number-different-timestamp pairs
        # (no chain-level uniqueness invariant — see
        # ``vca.types.normalized.BlockRef``), so timestamp must
        # participate in the id whenever ``edge.block`` is present.
        block_part = f"{edge.block.number}@{edge.block.timestamp.isoformat()}"
    extras_part = _extras_digest(edge.extras)
    return (
        f"{src}->{tgt}|{edge.tx_hash or ''}|{edge.kind.value}|{value}"
        f"|{edge.asset_symbol}|{edge.decimals}|{edge.decoder or ''}"
        f"|{block_part}|{extras_part}"
    )


def edge_id_with_index(edge: FlowEdge, index: int) -> str:
    """Stable per-occurrence id including position in ``graph.edges``.

    NOTE — codex P1-015 R6 finding #1: this helper concatenates the raw
    input position from ``graph.edges`` and is RETAINED only for legacy
    consumers and tests. The classifier itself no longer uses it directly;
    :meth:`ClassifierContext.build` now computes per-base-edge-id
    occurrence counters AFTER sorting (see ``edge_id_by_index`` in
    :meth:`ClassifierContext.build`) so the resulting suffix ``|#N`` is
    stable across input tuple permutations of the same edges. Callers that
    need a position-aware id for an isolated edge should still derive it
    from the post-sort ``edge_id_by_index`` map on a built context.
    """
    return f"{edge_id(edge)}|#{index}"


def edge_sort_key(edge: FlowEdge) -> tuple[str, str, str, str, str]:
    """Deterministic edge sort key — mirrors P1-014 traversal order.

    Codex P2-002.3 finding F-A — append the ``extras`` digest as a 5th
    tiebreaker so two edges sharing ``(source, target, tx_hash, kind)``
    but differing only in ``extras`` (and therefore claiming DIFFERENT
    rank-4 labels) sort deterministically across input permutations.
    Without the extras tiebreaker the post-sort occurrence counter in
    :meth:`ClassifierContext.build` would assign ``|#0`` / ``|#1`` via
    CPython's stable sort (input order), so reversing ``graph.edges``
    would swap which sort position the swap-tagged edge holds — the
    same permutation-invariance failure that motivated R-EDGE-ID
    extras inclusion. The digest is bytewise-stable
    (:func:`_extras_digest`) and ASCII-safe.
    """
    return (
        canonical_address_key(edge.source),
        canonical_address_key(edge.target),
        edge.tx_hash or "",
        edge.kind.value,
        _extras_digest(edge.extras),
    )


def derive_edge_id_by_index(edges: Sequence[FlowEdge]) -> Mapping[int, str]:
    """Permutation-stable per-occurrence edge ids, keyed by original index.

    This IS the ``edge_id_by_index`` map :meth:`ClassifierContext.build`
    computes — the post-sort per-base-id occurrence counter with ``|#N``
    suffixes (codex P1-015 R6/R8: sort by ``(edge_sort_key, edge_id,
    edge_contract_key)`` then count occurrences per ``edge_id`` base, so the
    same set of edges in any tuple permutation yields the same suffixed ids).

    Factored out so a caller that needs ONLY the id map — e.g. the read-only
    web detail builders joining PERSISTED stage labels + edge_pks — can skip
    the policy-dependent fan-cluster / smurf-cluster / btc-depth precompute the
    full :meth:`ClassifierContext.build` performs. Building the whole context to
    read one field is O(whole-graph) per call (repeated ``json.dumps`` over
    every edge across multiple passes); this is O(E log E) with no clustering.
    """
    indexed = list(enumerate(edges))
    indexed.sort(
        key=lambda pair: (
            edge_sort_key(pair[1]),
            edge_id(pair[1]),
            edge_contract_key(pair[1]),
        )
    )
    occurrence: dict[str, int] = {}
    result: dict[int, str] = {}
    for orig_idx, edge in indexed:
        base = edge_id(edge)
        suffix = occurrence.get(base, 0)
        occurrence[base] = suffix + 1
        result[orig_idx] = f"{base}|#{suffix}"
    return MappingProxyType(result)


def edge_contract_key(edge: FlowEdge) -> str:
    """Canonical ``(chain, contract)`` token key, or ``""`` for a native coin.

    The FINAL total-order tiebreaker for the scan #16 contract-identity refactor.
    ``FlowEdge.asset_contract`` is deliberately NOT part of ``edge_id`` (it is not
    label-affecting — the classifier keys on ``asset_symbol``, so R-EDGE-ID keeps it
    out), so two edges identical except their TOKEN CONTRACT share an ``edge_id`` and
    tie on ``(edge_sort_key, edge_id)``. Appending this key AFTER ``edge_id`` at every
    canonical-order site (graph.edges snapshot, the occurrence counter, the label-cache
    sort, the Mermaid order) restores a TOTAL order — so ``|#N`` suffixes / ``edge_pk``
    / serialized edge order stay permutation-invariant when two DISTINCT tokens move
    between the same endpoints in one tx. It changes nothing for edges that already
    differ on ``edge_sort_key`` or ``edge_id`` (byte-neutral for the goldens: no golden
    edge pair ties that far).

    Cross-chain hop fallback (codex P2-C): a pre-0007 / legacy CROSS_CHAIN TOKEN edge
    can carry ``asset_contract=None`` while ``hop.asset_in.contract`` still names its
    identity, so two such hops for DIFFERENT tokens would both key to ``""`` and stay
    tied. When ``asset_contract`` is None on a CROSS_CHAIN edge with a hop we fall back
    to ``hop.asset_in.contract``. Byte-neutral: fresh native cross-chain edges have both
    None (→ ``""``); fresh token cross-chain edges have ``asset_contract ==
    hop.asset_in.contract`` (same key either way).
    """
    contract = edge.asset_contract
    if contract is None and edge.kind == EdgeKind.CROSS_CHAIN and edge.hop is not None:
        contract = edge.hop.asset_in.contract
    return canonical_address_key(contract) if contract is not None else ""


def filter_window(
    edges: list[FlowEdge],
    window: timedelta,
    endpoint_key: Callable[[FlowEdge], str] | None = None,
) -> list[FlowEdge]:
    """Return edges inside the densest rolling ``window`` by block time.

    Codex P1-015 R5 finding #3 — densest is measured by **distinct endpoint
    count** when ``endpoint_key`` is provided (fan_in/fan_out require
    ``distinct_sources``/``distinct_targets`` to clear the threshold; raw
    edge count over-counts duplicate endpoints). Tiebreak: more edges in
    the window, then earliest start (deterministic — R-DETERMINISTIC).
    When ``endpoint_key`` is ``None`` (legacy callers and the smurf
    pipeline) the densest is measured by raw edge count, preserving the
    R1 sliding-window scan.

    Anchoring on the first timed edge misses late bursts (e.g. ``[t=0,
    3600, 3610, 3620]`` with a 600 s window — codex P1-015 R1 finding #3).
    We instead two-pointer-scan for each candidate anchor ``i`` the
    largest ``j`` with ``timed[j].ts - timed[i].ts <= window`` and keep
    the densest such cluster.

    Edges with no block timestamp piggy-back on the cluster — they cannot
    be windowed, so we always include them so they remain available to
    downstream predicates that ignore time.
    """
    timed = [(e.block.timestamp, e) for e in edges if e.block is not None]
    untimed = [e for e in edges if e.block is None]
    if len(timed) < 2:
        return list(edges)
    timed.sort(key=lambda kv: kv[0])
    best_start = 0
    best_end = 0  # inclusive index of the densest cluster's last edge
    best_distinct = 1 if endpoint_key is not None else 0
    j = 0
    for i in range(len(timed)):
        if j < i:
            j = i
        while j + 1 < len(timed) and (timed[j + 1][0] - timed[i][0]) <= window:
            j += 1
        if endpoint_key is None:
            if (j - i) > (best_end - best_start):
                best_start, best_end = i, j
            continue
        # Distinct-endpoint scoring (R5 finding #3): primary key is the
        # number of distinct endpoint canonical keys in ``timed[i..j]``;
        # tiebreak prefers larger raw edge count, then earliest start
        # (already guaranteed by left-to-right iteration over sorted
        # timestamps). Build the distinct set lazily — fan windows are
        # bounded by the per-endpoint group size so this stays O(N).
        distinct = len({endpoint_key(e) for _, e in timed[i : j + 1]})
        if distinct > best_distinct or (
            distinct == best_distinct and (j - i) > (best_end - best_start)
        ):
            best_distinct = distinct
            best_start, best_end = i, j
    selected = [e for _, e in timed[best_start : best_end + 1]]
    return selected + untimed


def _greedy_smurf_clusters(
    values_sorted: list[int], tolerance_bps: int
) -> list[tuple[int, list[int]]]:
    """Greedy-cluster ascending ``values_sorted`` within ``tolerance_bps``.

    Two values land in the same cluster iff the larger does not exceed
    ``smaller * (1 + tolerance_bps / 10000)``. Returns a list of
    ``(anchor, members)`` pairs where ``anchor`` is the cluster's smallest
    value and ``members`` is every value in that cluster, in input order.
    Avoids the bit-length-boundary split that the previous logarithmic
    bucketing produced for e.g. ``1023 vs 1024`` (codex P1-015 R1
    finding #4).
    """
    if not values_sorted:
        return []
    threshold = 10000
    step_num = threshold + tolerance_bps
    clusters: list[tuple[int, list[int]]] = []
    anchor = values_sorted[0]
    members: list[int] = [anchor]
    for value in values_sorted[1:]:
        if value * threshold <= anchor * step_num:
            members.append(value)
        else:
            clusters.append((anchor, members))
            anchor = value
            members = [anchor]
    clusters.append((anchor, members))
    return clusters


@dataclass(frozen=True)
class ClassifierContext:
    """Pre-computed indexes amortising O(N²) work across predicates.

    ``fan_out_clusters`` / ``fan_in_clusters`` map an endpoint canonical
    key to ``(window_edges, member_ids)`` where ``member_ids`` is a
    ``frozenset`` of ``id(edge)`` values for the edges in the densest
    rolling window. Predicates check edge-level membership in
    ``member_ids`` BEFORE counting distinct sources/targets — codex
    P1-015 R2 finding #2 (outliers outside the chosen window must NOT
    inherit a fan label from an unrelated burst).

    ``ABRIDGED`` edges are excluded from fan clustering at build time —
    codex P1-015 R2 finding #3 (synthetic branching markers must not
    inflate ``distinct_targets`` / ``distinct_sources`` and must flow to
    the F1 fallback).

    Seed-anchor edges are excluded from BOTH fan clusters (codex P1-015
    R5 finding #2) AND smurf clusters (codex P1-015 R14 finding #1):
    the rank-1 ``is_seed_anchor`` heuristic always wins for the seed
    edge, so its inclusion only inflates fan ``distinct_*`` /
    smurf ``cluster_size`` counts toward the threshold for OTHER edges
    sharing the endpoint or ``(source, asset, decimals, value_minor)``.
    Both filters are applied via the free-function ``_is_seed_anchor_edge``
    and behave identically (chain-aware, ABRIDGED-safe).
    """

    policy: StagePolicy
    fan_out_clusters: Mapping[str, tuple[FlowEdge, ...]]
    fan_out_member_ids: Mapping[str, frozenset[int]]
    fan_in_clusters: Mapping[str, tuple[FlowEdge, ...]]
    fan_in_member_ids: Mapping[str, frozenset[int]]
    smurf_clusters: Mapping[tuple[str, str, int, int], tuple[FlowEdge, ...]]
    smurf_anchor_by_edge: Mapping[str, int]
    btc_entry_depth: int | None
    nodes_by_key: Mapping[str, GraphNode]
    edge_id_by_index: Mapping[int, str]
    # P1-024 / FINDING-A — canonical-key set of seed-anchor edge TARGETS.
    # A "Primary Receiver" per ``docs/source/03_KelpDAO_rsETH_Exploit_분석.md``
    # §3.가.3 (3) Stage 2 is the depth-1 node that received the seed
    # transfer; its subsequent fan-out is documented as the Stage 2
    # initial dispersal. ``fan_out_outcome`` consults this set to lift
    # those edges from STAGE_5 (generic depth>=1 fan_out) into STAGE_2.
    # Membership derives from :func:`_is_seed_anchor_edge` so the build-
    # time set, the rank-1 heuristic, the fan/smurf cluster filters, and
    # the STAGE_2 promotion all share a single predicate (R-SSOT-PREDICATE).
    primary_receiver_keys: frozenset[str]
    # P2-005.3 — per-address-key index of :class:`AddressLabel` snapshots
    # carried by :class:`GraphNode.label`. Keyed by
    # :func:`canonical_address_key` (chain-aware lowercase EVM /
    # case-preserved BTC) so the rank-5 ``is_address_label_anchor``
    # heuristic can look up the SOURCE / TARGET endpoint of an edge in
    # O(1). Nodes without an ``AddressLabel`` produce no entry; lookup
    # defaults to ``()``. R-PURE / R-PURE-READ — built from
    # ``graph.nodes`` only, no I/O.
    #
    # R-ADDRESS-LABEL-NODE-LEVEL-NOT-EDGE-EXTRAS — the predicate reads
    # this index, NEVER ``edge.extras``. Two edges identical in every
    # edge-visible field AND sharing endpoints share the same node-label
    # lookup, so they remain truly-identical and the post-sort occurrence
    # counter ``|#0`` / ``|#1`` discriminates correctly. ``edge_id``
    # therefore does NOT need to grow an attribution-role digest (the
    # P1-024 / P2-002.3 / P2-008.3 R-EDGE-ID-LABEL-AFFECTING-FIELDS
    # invariant is held negatively here).
    address_labels_by_key: Mapping[str, tuple[AddressLabel, ...]]

    def smurf_anchor_for_edge(self, edge: FlowEdge) -> int | None:
        """Return the precomputed cluster anchor for ``edge`` (None if absent)."""
        return self.smurf_anchor_by_edge.get(edge_id(edge))

    def fan_out_includes(self, source_key: str, edge: FlowEdge) -> bool:
        """``True`` iff ``edge`` is in the densest fan-out cluster of ``source_key``."""
        return id(edge) in self.fan_out_member_ids.get(source_key, frozenset())

    def fan_in_includes(self, target_key: str, edge: FlowEdge) -> bool:
        """``True`` iff ``edge`` is in the densest fan-in cluster of ``target_key``."""
        return id(edge) in self.fan_in_member_ids.get(target_key, frozenset())

    @classmethod
    def build(cls, graph: CaseGraph, policy: StagePolicy) -> ClassifierContext:
        nodes_by_key: dict[str, GraphNode] = {n.canonical_key: n for n in graph.nodes}
        sorted_edges = sorted(graph.edges, key=edge_sort_key)

        # P2-005.3 — per-key snapshot of every :class:`AddressLabel`
        # carried by a node. ``GraphNode.label`` at ``graph.py:189`` is
        # the SSOT for "this wallet is X"; rank 5
        # ``is_address_label_anchor`` reads this map to promote the 5
        # attribution roles (``smurfing_residual_sweep`` /
        # ``eth_btc_ratio_attribution`` / ``btc_peeling_chain_origin``
        # / ``btc_coinjoin_pool_entry`` / ``btc_vault_address``) into
        # stage labels. Nodes without a label produce no entry. The
        # value is a ``tuple[AddressLabel, ...]`` to allow future
        # multi-label nodes (frozen-tuple shape leaves room for the
        # P2-009.x label-resolver to evolve without breaking the index
        # contract). Today every node has at most one label, so each
        # tuple has length 1.
        address_labels_by_key: dict[str, tuple[AddressLabel, ...]] = {}
        for labelled_node in graph.nodes:
            if labelled_node.label is None:
                continue
            address_labels_by_key[labelled_node.canonical_key] = (labelled_node.label,)

        # P1-024 / FINDING-A — derive Primary Receiver canonical keys from
        # the target endpoints of seed-anchor edges. Uses the SSOT
        # ``_is_seed_anchor_edge`` predicate (R-SSOT-PREDICATE) so a
        # tx_hash collision on a different chain (e.g. ARB edge sharing
        # the ETH seed hash — R1 finding #2) cannot wrongly promote an
        # unrelated downstream node into the Primary Receiver set.
        # KelpDAO's single-seed contract makes this a one-element set in
        # practice; the frozenset shape leaves room for future
        # multi-seed cases without changing the consumer signature.
        primary_receiver_keys = frozenset(
            canonical_address_key(edge.target)
            for edge in graph.edges
            if _is_seed_anchor_edge(graph, edge)
        )

        # Per-base-id occurrence counter computed AFTER sorting (codex
        # P1-015 R6/R8) — factored into the module-level
        # ``derive_edge_id_by_index`` so the read-only web detail builders can
        # reuse it WITHOUT this whole policy-dependent context build. See that
        # function's docstring for the permutation-invariance rationale.
        edge_id_by_index = derive_edge_id_by_index(graph.edges)

        # ABRIDGED edges are synthetic branching markers — exclude them from
        # fan clustering (codex P1-015 R2 finding #3) so a self-loop ABRIDGED
        # cannot inflate ``distinct_targets``/``distinct_sources``, and they
        # flow to F1 inheritance.
        #
        # Seed-anchor edges are also excluded (codex P1-015 R5 finding #2):
        # the rank-1 ``is_seed_anchor`` heuristic always wins for the seed
        # edge, so its inclusion in the cluster only inflates fan counts
        # for OTHER edges sharing the endpoint. The filter is symmetric
        # (fan_in AND fan_out) for consistency — fan_out on a seed TX is
        # already STAGE_1 via rank 1, so this is a no-op for fan_out
        # today, but locks the invariant against future regressions.
        fan_out_raw: dict[str, list[FlowEdge]] = {}
        fan_in_raw: dict[str, list[FlowEdge]] = {}
        for edge in sorted_edges:
            if edge.kind == EdgeKind.ABRIDGED:
                continue
            if _is_seed_anchor_edge(graph, edge):
                continue
            src_key = canonical_address_key(edge.source)
            tgt_key = canonical_address_key(edge.target)
            # Self-loop edges (source == target — e.g. a consolidation/change
            # self-send) return value to the same address and add no distinct
            # dispersal target or collection source. Excluding them keeps
            # ``distinct_targets``/``distinct_sources`` honest so a self-send
            # cannot inflate a source/target past ``fan_threshold`` (scan #13
            # TOP-1). Mirrors the ABRIDGED/seed-anchor skips above.
            if src_key == tgt_key:
                continue
            fan_out_raw.setdefault(src_key, []).append(edge)
            fan_in_raw.setdefault(tgt_key, []).append(edge)

        fan_out_clusters: dict[str, tuple[FlowEdge, ...]] = {}
        fan_out_member_ids: dict[str, frozenset[int]] = {}
        for src_key, group in sorted(fan_out_raw.items()):
            window_set = filter_window(
                group,
                policy.fan_window,
                endpoint_key=lambda e: canonical_address_key(e.target),
            )
            fan_out_clusters[src_key] = tuple(window_set)
            fan_out_member_ids[src_key] = frozenset(id(e) for e in window_set)
        fan_in_clusters: dict[str, tuple[FlowEdge, ...]] = {}
        fan_in_member_ids: dict[str, frozenset[int]] = {}
        for tgt_key, group in sorted(fan_in_raw.items()):
            window_set = filter_window(
                group,
                policy.fan_window,
                endpoint_key=lambda e: canonical_address_key(e.source),
            )
            fan_in_clusters[tgt_key] = tuple(window_set)
            fan_in_member_ids[tgt_key] = frozenset(id(e) for e in window_set)

        # Smurf clustering — greedy sort+cluster per (src, asset, decimals)
        # group so values within tolerance always collapse, regardless of
        # bit-length boundaries (codex P1-015 R1 finding #4). The
        # ``decimals`` axis is part of the group key (codex P1-015 R3
        # finding #2) so two edges that share an ``asset_symbol`` but use
        # incompatible decimal units (e.g. 6-decimal vs. 18-decimal
        # printings of the same symbol) cannot smurf together — their
        # raw ``value_minor`` integers are not comparable across units.
        #
        # Seed-anchor edges are also excluded from the smurf precompute
        # (codex P1-015 R14 finding #1): the rank-1 ``is_seed_anchor``
        # heuristic always wins for the seed edge, so its inclusion in a
        # smurf cluster only inflates ``cluster_size`` for OTHER edges
        # sharing ``(source, asset, decimals, value_minor)``. Concrete
        # failure (R14 reproduction): seed TX is a TRANSFER S→T1 with
        # ``value_minor=v``; source ``S`` later emits 2 more identical
        # TRANSFERs to T2/T3. With ``smurf_threshold=3`` the unfiltered
        # cluster sees ``[seed, e2, e3]`` → size 3 → e2/e3 mis-labelled
        # ``STAGE_6``. With the seed filter the cluster is ``[e2, e3]``
        # → size 2 → smurfing fails → e2/e3 fall through to fan_out
        # (depth-0 source) or fallback. The filter mirrors the R5 fan
        # cluster filter — same predicate (``_is_seed_anchor_edge``),
        # same call site (build-time), same rationale (rank-1 ownership).
        smurf_groups: dict[tuple[str, str, int], list[FlowEdge]] = {}
        for edge in sorted_edges:
            if edge.kind != EdgeKind.TRANSFER or edge.value_minor is None:
                continue
            if _is_seed_anchor_edge(graph, edge):
                continue
            # Self-loop transfers (source == target) are not a smurf dispersal
            # — they add no distinct recipient — so excluding them keeps a
            # self-send from inflating ``cluster_size`` past ``smurf_threshold``
            # (scan #13 TOP-1). Mirrors the seed-anchor skip above.
            if canonical_address_key(edge.source) == canonical_address_key(edge.target):
                continue
            group_key = (
                canonical_address_key(edge.source),
                edge.asset_symbol,
                edge.decimals,
            )
            smurf_groups.setdefault(group_key, []).append(edge)

        smurf_clusters_raw: dict[tuple[str, str, int, int], list[FlowEdge]] = {}
        smurf_anchor_by_edge: dict[str, int] = {}
        for group_key, group_edges in sorted(smurf_groups.items()):
            sorted_group = sorted(
                group_edges,
                key=lambda e: (e.value_minor or 0, edge_sort_key(e), edge_contract_key(e)),
            )
            sorted_values = [e.value_minor or 0 for e in sorted_group]
            cursor = 0
            for anchor, members in _greedy_smurf_clusters(
                sorted_values, policy.smurf_value_tolerance_bps
            ):
                cluster_key = (group_key[0], group_key[1], group_key[2], anchor)
                bucket_edges: list[FlowEdge] = []
                for _ in members:
                    edge_obj = sorted_group[cursor]
                    cursor += 1
                    bucket_edges.append(edge_obj)
                    smurf_anchor_by_edge[edge_id(edge_obj)] = anchor
                smurf_clusters_raw[cluster_key] = bucket_edges
        smurf_clusters: dict[tuple[str, str, int, int], tuple[FlowEdge, ...]] = {
            k: tuple(v) for k, v in sorted(smurf_clusters_raw.items())
        }

        btc_entry_depth: int | None = None
        for edge in sorted_edges:
            for endpoint in (edge.source, edge.target):
                if endpoint.chain == ChainId.BITCOIN:
                    node = nodes_by_key.get(canonical_address_key(endpoint))
                    if node is None:
                        continue
                    if btc_entry_depth is None or node.depth < btc_entry_depth:
                        btc_entry_depth = node.depth

        return cls(
            policy=policy,
            fan_out_clusters=MappingProxyType(fan_out_clusters),
            fan_out_member_ids=MappingProxyType(fan_out_member_ids),
            fan_in_clusters=MappingProxyType(fan_in_clusters),
            fan_in_member_ids=MappingProxyType(fan_in_member_ids),
            smurf_clusters=MappingProxyType(smurf_clusters),
            smurf_anchor_by_edge=MappingProxyType(smurf_anchor_by_edge),
            btc_entry_depth=btc_entry_depth,
            nodes_by_key=MappingProxyType(nodes_by_key),
            edge_id_by_index=edge_id_by_index,
            primary_receiver_keys=primary_receiver_keys,
            address_labels_by_key=MappingProxyType(address_labels_by_key),
        )


__all__ = [
    "ClassifierContext",
    "derive_edge_id_by_index",
    "edge_contract_key",
    "edge_id",
    "edge_id_with_index",
    "edge_sort_key",
    "filter_window",
]
