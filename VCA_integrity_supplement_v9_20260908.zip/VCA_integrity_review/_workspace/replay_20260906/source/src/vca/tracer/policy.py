"""TracePolicy — frozen BFS policy DTO (P1-014).

Phase 1 uses **per-chain native-unit thresholds** (R-PRICING) rather than
a USD-based ``min_value_usd``. USD pricing requires a price feed (CoinGecko
/ Pyth / Chainlink) which is not plumbed in Phase 1; the architecture's
``min_value_usd`` field is deferred to Phase 2.

The policy is frozen at construction; ``min_value_native`` is wrapped in
:class:`types.MappingProxyType` so callers cannot mutate it after building
a tracer.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import timedelta
from types import MappingProxyType
from typing import Final, Self

from pydantic import BaseModel, ConfigDict, Field, field_serializer, model_validator

from vca.labeler import LabelKind
from vca.types import ChainId

# ---------------------------------------------------------------------------
# Default factories — module-level constants so test fixtures can compare
# defaults by reference (parity with HeuristicConfig defaults).
# ---------------------------------------------------------------------------

# Per-chain wei/sat thresholds. 0.01 ETH (10**16 wei), 0.01 BTC (10**6 sat).
_DEFAULT_VALUE_THRESHOLDS: Final[Mapping[ChainId, int]] = MappingProxyType(
    {
        ChainId.ETHEREUM: 10**16,
        ChainId.ARBITRUM: 10**16,
        ChainId.BITCOIN: 10**6,
    }
)

# Per-chain "significant" native-value floor for the per-address cap
# (P3.2-007.1). When a chain carries a floor, ``max_address_txs_per_address``
# no longer silently drops that chain's high-value TAIL (e.g. E7's
# 585/570/552/462 ETH consolidation sends + the late-clustering E25/E31 legs):
# any in-window row whose ``value_native.raw >= cap_significance_native[chain]``
# is FORCE-ADMITTED on top of the first-N ascending admission, so the admitted
# set stays a strict SUPERSET (zero removals) and risk-1 stages stay byte-stable.
#
# The GLOBAL default is EMPTY (codex R2 P2): a bare ``TracePolicy()`` opts OUT
# of force-admission and keeps the exact pre-007.1 cap. The KelpDAO floor
# (100 ETH / 100 ARB-ETH / 10 BTC -- well above any value participating in
# Stage 1/2/3-A/3-B) is supplied EXPLICITLY by ``_build_kelpdao_trace_policy``
# + the decoder-wiring tests, never inherited globally. Kept as a named
# ``Final`` constant (consumed by ``_default_cap_significance``) to mirror
# ``_DEFAULT_VALUE_THRESHOLDS``.
_DEFAULT_CAP_SIGNIFICANCE: Final[Mapping[ChainId, int]] = MappingProxyType({})

# PB-003.1: per-chain native floor applied ONLY to the curated
# ``deep_expand_addresses`` set (the Bybit layer-2 sinks). SOURCE-gated in
# ``_run.py`` (keys on the EXPANDING address = edge source), so only those
# addresses' ONWARD legs see the lower floor; the global ``min_value_native``
# and ``cap_significance_native`` floors are untouched (the 43 already-expanded
# nodes never see it → KelpDAO byte-identical, INV-2). The GLOBAL default is
# EMPTY (a bare ``TracePolicy()`` opts out entirely — same pattern as
# ``_DEFAULT_CAP_SIGNIFICANCE``); the Bybit floor (10 ETH) is supplied
# EXPLICITLY by the case policy builder. Named ``Final`` constant consumed by
# ``_default_deep_expand_floor`` (mirrors ``_DEFAULT_CAP_SIGNIFICANCE``).
_DEFAULT_DEEP_EXPAND_FLOOR: Final[Mapping[ChainId, int]] = MappingProxyType({})

# Architecture §3.3 line 137 + P1-013's HOT/COLD split.
_DEFAULT_TERMINAL_LABELS: Final[frozenset[LabelKind]] = frozenset(
    {
        LabelKind.EXCHANGE_HOT,
        LabelKind.EXCHANGE_COLD,
        LabelKind.MIXER,
        LabelKind.COINJOIN,
        LabelKind.GOV_FROZEN,
    }
)

_FROZEN_CONFIG: Final[ConfigDict] = ConfigDict(frozen=True, strict=True, extra="forbid")


def _default_value_thresholds() -> Mapping[ChainId, int]:
    """Pydantic ``default_factory`` returning the per-chain default mapping.

    Returning a fresh ``MappingProxyType`` over a fresh ``dict`` avoids the
    "same instance shared across all TracePolicy instances" gotcha that
    bites mutable defaults.
    """
    return MappingProxyType(dict(_DEFAULT_VALUE_THRESHOLDS))


def _default_cap_significance() -> Mapping[ChainId, int]:
    """Pydantic ``default_factory`` returning the EMPTY global cap-significance floor.

    P3.2-007.1 (codex R2 P2): the global default OPTS OUT of force-admission,
    so a bare ``TracePolicy()`` keeps the exact pre-007.1 per-address cap (with
    an empty floor no row is ever "significant" and the tracer's floor-inactive
    path restores the original pagination bound). The KelpDAO floor is supplied
    EXPLICITLY by ``_build_kelpdao_trace_policy`` + the wiring tests.

    Returns a fresh ``MappingProxyType`` over a copy of
    ``_DEFAULT_CAP_SIGNIFICANCE`` (mirrors :func:`_default_value_thresholds`) to
    avoid the shared-instance mutable-default gotcha.
    """
    return MappingProxyType(dict(_DEFAULT_CAP_SIGNIFICANCE))


def _default_deep_expand_floor() -> Mapping[ChainId, int]:
    """Pydantic ``default_factory`` returning the EMPTY deep-expand floor.

    PB-003.1: mirrors :func:`_default_cap_significance`. The global default
    OPTS OUT of the deep-expand override, so a bare ``TracePolicy()`` never
    lowers any address's floor and the whole trace is byte-identical to the
    pre-PB-003.1 behaviour. Returns a fresh ``MappingProxyType`` over a copy of
    ``_DEFAULT_DEEP_EXPAND_FLOOR`` (mirrors :func:`_default_value_thresholds`)
    to avoid the shared-instance mutable-default gotcha.
    """
    return MappingProxyType(dict(_DEFAULT_DEEP_EXPAND_FLOOR))


def _default_terminal_labels() -> frozenset[LabelKind]:
    """Pydantic ``default_factory`` returning the default terminal label set."""
    return frozenset(_DEFAULT_TERMINAL_LABELS)


class TracePolicy(BaseModel):
    """Frozen BFS policy DTO. :class:`Tracer` takes one instance.

    Cross-field rule: every key in ``min_value_native`` must be a
    :class:`vca.types.ChainId` member; every value must be ``>= 0``.
    Lazy chain-coverage check (R-PRICING / behaviour 109) runs at
    traversal time when the tracer encounters an unregistered chain.
    """

    model_config = _FROZEN_CONFIG

    max_depth: int = Field(default=8, ge=0, le=32)
    min_value_native: Mapping[ChainId, int] = Field(default_factory=_default_value_thresholds)
    terminal_labels: frozenset[LabelKind] = Field(default_factory=_default_terminal_labels)
    time_window: timedelta = Field(default=timedelta(days=14))
    max_branching: int = Field(default=50, ge=1, le=10000)
    max_address_txs_per_address: int = Field(default=200, ge=1, le=100000)
    cap_significance_native: Mapping[ChainId, int] = Field(
        default_factory=_default_cap_significance
    )
    max_total_addresses: int = Field(default=5000, ge=1, le=100000)
    # P3.2-008 (OPTION A): BTC CoinJoin/batch-mixing fanout bound. When a
    # single BITCOIN tx fans out to >= ``btc_fanout_terminal`` non-self-loop
    # child pairs, the expanding actor node is treated as TERMINAL
    # (BRANCHING_LIMIT) and NONE of that tx's children are enqueued — the
    # inbound edges are still recorded so the depth-based BTC layers
    # (L1-L4) survive, but the BFS does not wander into the mixed
    # post-CoinJoin funds (the PDF model stops at CoinJoin entry —
    # "추적 종료"). The GLOBAL default is ``None`` (DISABLED) so a bare
    # ``TracePolicy()`` keeps EVM/non-KelpDAO behaviour byte-identical;
    # the KelpDAO floor (12) is supplied EXPLICITLY by
    # ``_build_kelpdao_trace_policy``. Gated on ``ChainId.BITCOIN`` so
    # Stage 1-7 (EVM) are unaffected.
    btc_fanout_terminal: int | None = Field(default=None, ge=1)
    # PB-003.1: layer-2 deep-expansion floor override.
    # ``deep_expand_addresses`` holds canonical address keys (EVM = lowercased
    # hex, per ``vca.tracer.graph.canonical_address_key``);
    # ``deep_expand_floor_native`` is the per-chain native floor those addresses
    # get on BOTH the per-address cap-admission gate AND the edge-admission gate
    # (SOURCE-gated on the expanding address, so only their ONWARD legs are
    # affected). Both default EMPTY so a bare ``TracePolicy()`` is byte-identical
    # to pre-PB-003.1; the Bybit sinks + 10-ETH floor are supplied EXPLICITLY by
    # the case policy builder.
    deep_expand_addresses: frozenset[str] = Field(default_factory=frozenset)
    deep_expand_floor_native: Mapping[ChainId, int] = Field(
        default_factory=_default_deep_expand_floor
    )
    # BTC-SPINE BTC-1 (Mechanism 1): per-address CAP-COUNT override for the
    # curated BTC L2 payouts. ``deep_expand_cap_addresses`` holds canonical
    # address keys (BTC Base58/bech32 case preserved verbatim, per
    # ``vca.tracer.graph.canonical_address_key``). A listed EXPANDING address
    # gets ``deep_expand_cap`` in place of ``max_address_txs_per_address`` at
    # every per-address cap gate (SOURCE-gated in ``_run.py`` on the expanding
    # node), so all of its in-window sweeps survive the global cap of 5. This
    # is a COUNT knob only — it moves NO floor, so the edge floor, the
    # ``_btc_tx_fanout`` counter, and the per-vout dust filter stay
    # byte-identical. Both default empty/None so a bare ``TracePolicy()`` opts
    # out entirely (byte-identical to pre-BTC-SPINE); the Bybit payouts + cap
    # 100 are supplied EXPLICITLY by the case policy builder.
    deep_expand_cap_addresses: frozenset[str] = Field(default_factory=frozenset)
    deep_expand_cap: int | None = Field(default=None, ge=1, le=100000)
    # BTC-SPINE BTC-1 (Mechanism 2): per-address TIME-WINDOW override for the
    # BTC L3 reuse hub only. A listed EXPANDING address gets
    # ``deep_expand_window`` in place of ``time_window`` at the BFS window gates
    # (SOURCE-gated on the expanding node), so its post-14-day spends (the doc's
    # L3 집결 + L4 mixer-entry frontier) are admitted instead of dropped as
    # TIME_WINDOW. Both default empty/None so a bare ``TracePolicy()`` is
    # byte-identical; the hub key + timedelta(days=140) are supplied EXPLICITLY
    # by the case policy builder.
    deep_expand_window_addresses: frozenset[str] = Field(default_factory=frozenset)
    deep_expand_window: timedelta | None = Field(default=None)

    @model_validator(mode="after")
    def _validate_min_value_native_keys(self) -> Self:
        for chain, threshold in self.min_value_native.items():
            if not isinstance(chain, ChainId):
                raise ValueError(  # noqa: TRY004 - pydantic value-domain validator
                    f"TracePolicy.min_value_native key must be ChainId, got {type(chain).__name__}"
                )
            if not isinstance(threshold, int) or isinstance(threshold, bool):
                raise ValueError(  # noqa: TRY004 - pydantic value-domain validator
                    f"TracePolicy.min_value_native[{chain.value}] must be int, "
                    f"got {type(threshold).__name__}"
                )
            if threshold < 0:
                raise ValueError(
                    f"TracePolicy.min_value_native[{chain.value}] must be >= 0, got {threshold}"
                )
        # Same ChainId-key / non-bool-int / >= 0 rules for the per-address
        # cap-significance floor (P3.2-007.1). Mirrors the min_value_native
        # contract exactly so callers cannot smuggle a string key, a bool
        # floor, or a negative floor past the frozen DTO.
        for chain, floor in self.cap_significance_native.items():
            if not isinstance(chain, ChainId):
                raise ValueError(  # noqa: TRY004 - pydantic value-domain validator
                    f"TracePolicy.cap_significance_native key must be ChainId, "
                    f"got {type(chain).__name__}"
                )
            if not isinstance(floor, int) or isinstance(floor, bool):
                raise ValueError(  # noqa: TRY004 - pydantic value-domain validator
                    f"TracePolicy.cap_significance_native[{chain.value}] must be int, "
                    f"got {type(floor).__name__}"
                )
            if floor < 0:
                raise ValueError(
                    f"TracePolicy.cap_significance_native[{chain.value}] must be >= 0, got {floor}"
                )
        object.__setattr__(self, "min_value_native", MappingProxyType(dict(self.min_value_native)))
        object.__setattr__(
            self, "cap_significance_native", MappingProxyType(dict(self.cap_significance_native))
        )
        return self

    @model_validator(mode="after")
    def _validate_deep_expand_keys(self) -> Self:
        # PB-003.1: byte-copy the cap_significance_native value-domain rules for
        # the per-chain deep-expand floor (ChainId key / non-bool int / >= 0),
        # plus a lowercase-canonical rule on the address set so callers cannot
        # smuggle an EIP-55 checksummed key that would never match the
        # ``canonical_address_key`` lookup in the tracer's ``_deep_floor``.
        for chain, floor in self.deep_expand_floor_native.items():
            if not isinstance(chain, ChainId):
                raise ValueError(  # noqa: TRY004 - pydantic value-domain validator
                    f"TracePolicy.deep_expand_floor_native key must be ChainId, "
                    f"got {type(chain).__name__}"
                )
            if not isinstance(floor, int) or isinstance(floor, bool):
                raise ValueError(  # noqa: TRY004 - pydantic value-domain validator
                    f"TracePolicy.deep_expand_floor_native[{chain.value}] must be int, "
                    f"got {type(floor).__name__}"
                )
            if floor < 0:
                raise ValueError(
                    f"TracePolicy.deep_expand_floor_native[{chain.value}] must be >= 0, got {floor}"
                )
            # The deep floor is EVM-only by design. A lowered BTC floor would
            # diverge from the BTC CoinJoin/batch-mixing fanout counter
            # (``_btc_tx_fanout`` filters vouts with the GLOBAL
            # ``min_value_native``), so a mixer could emit + enqueue children yet
            # fail the terminal check. Reject ``ChainId.BITCOIN`` so the BTC
            # gates (fanout + ``_carries_qualifying_btc_output``) stay a proven
            # no-op — the whole PB-003 mechanism is native-EVM only.
            if chain is ChainId.BITCOIN:
                raise ValueError(
                    "TracePolicy.deep_expand_floor_native does not support "
                    "ChainId.BITCOIN: the deep floor is EVM-only (the BTC fanout "
                    "counter uses the global min_value_native)"
                )
            # LOWER-ONLY contract: every tracer call site REPLACES the applicable
            # global floor with the deep floor. A deep floor ABOVE the global
            # edge floor (``min_value_native``) or cap floor
            # (``cap_significance_native``) would make a curated sink MORE
            # restrictive than the rest of the graph — dropping onward legs that
            # pass globally — contradicting the lower-only override. Require a
            # global edge floor to lower and reject any deep floor that raises it.
            global_edge_floor = self.min_value_native.get(chain)
            if global_edge_floor is None:
                raise ValueError(
                    f"TracePolicy.deep_expand_floor_native[{chain.value}] requires a "
                    f"min_value_native entry for {chain.value} to lower"
                )
            if floor > global_edge_floor:
                raise ValueError(
                    f"TracePolicy.deep_expand_floor_native[{chain.value}] ({floor}) must "
                    f"not exceed min_value_native[{chain.value}] ({global_edge_floor}): the "
                    f"deep floor LOWERS the floor for curated sinks, it never raises it"
                )
            global_cap_floor = self.cap_significance_native.get(chain)
            if global_cap_floor is not None and floor > global_cap_floor:
                raise ValueError(
                    f"TracePolicy.deep_expand_floor_native[{chain.value}] ({floor}) must "
                    f"not exceed cap_significance_native[{chain.value}] ({global_cap_floor})"
                )
        for address in self.deep_expand_addresses:
            if not address:
                raise ValueError(
                    f"TracePolicy.deep_expand_addresses entries must be non-empty "
                    f"canonical address keys, got {address!r}"
                )
            chain_prefix, sep, rest = address.partition(":")
            if not sep or not rest:
                raise ValueError(
                    f"TracePolicy.deep_expand_addresses entries must be canonical keys "
                    f"of the form '<chain>:<address>' (per canonical_address_key), "
                    f"got {address!r}"
                )
            try:
                key_chain = ChainId(chain_prefix)
            except ValueError as exc:
                raise ValueError(
                    f"TracePolicy.deep_expand_addresses entry has unknown chain prefix "
                    f"{chain_prefix!r}, got {address!r}"
                ) from exc
            # Full canonical round-trip: the payload MUST reconstruct a valid
            # Address whose ``canonical_address_key`` equals the input. This
            # rejects a malformed payload (e.g. "eth:not-an-address" / a short
            # hex), a non-normalized EVM key (EIP-55 checksummed → canonical
            # lowercases → mismatch), and preserves case-sensitive BTC Base58
            # verbatim — so a config typo fails fast at construction instead of
            # silently never matching ``_deep_floor``. Imported function-locally
            # so this frozen DTO keeps no module-level dependency on the tracer
            # graph (the ``_deep_floor`` SSOT the key must round-trip through).
            from vca.tracer.graph import canonical_address_key
            from vca.types import Address

            try:
                reconstructed = canonical_address_key(Address.from_str(rest, key_chain))
            except ValueError as exc:
                raise ValueError(
                    f"TracePolicy.deep_expand_addresses entry {address!r} is not a valid "
                    f"canonical address key ({rest!r} is not a valid {key_chain.value} address)"
                ) from exc
            if reconstructed != address:
                raise ValueError(
                    f"TracePolicy.deep_expand_addresses entry {address!r} is not canonical: "
                    f"expected {reconstructed!r} from canonical_address_key (reject EIP-55 "
                    f"smuggling / non-normalized keys)"
                )
        object.__setattr__(
            self, "deep_expand_floor_native", MappingProxyType(dict(self.deep_expand_floor_native))
        )
        return self

    @model_validator(mode="after")
    def _validate_deep_expand_cap_window(self) -> Self:
        # BTC-SPINE BTC-1: sibling of the PB-003.1 deep-expand pair for the two
        # BTC override scalars. The cap is RAISE-ONLY and the window is
        # EXTEND-ONLY (INVERTED from the LOWER-ONLY floor above): a cap BELOW
        # the global would truncate MORE and a window SHORTER than the global
        # would drop in-window rows — both contradict the raise/extend intent.
        # Each curated key must round-trip through ``canonical_address_key``
        # exactly like ``deep_expand_addresses`` (rejects EIP-55 smuggling /
        # malformed keys; preserves BTC case). A non-empty set requires its
        # scalar; all four fields default empty/None so a bare ``TracePolicy()``
        # skips every branch → byte-identical to pre-BTC-SPINE.
        for field_name, addresses in (
            ("deep_expand_cap_addresses", self.deep_expand_cap_addresses),
            ("deep_expand_window_addresses", self.deep_expand_window_addresses),
        ):
            for address in addresses:
                if not address:
                    raise ValueError(
                        f"TracePolicy.{field_name} entries must be non-empty "
                        f"canonical address keys, got {address!r}"
                    )
                chain_prefix, sep, rest = address.partition(":")
                if not sep or not rest:
                    raise ValueError(
                        f"TracePolicy.{field_name} entries must be canonical keys of the "
                        f"form '<chain>:<address>' (per canonical_address_key), got {address!r}"
                    )
                try:
                    key_chain = ChainId(chain_prefix)
                except ValueError as exc:
                    raise ValueError(
                        f"TracePolicy.{field_name} entry has unknown chain prefix "
                        f"{chain_prefix!r}, got {address!r}"
                    ) from exc
                # Function-local imports (mirror ``_validate_deep_expand_keys``)
                # so this frozen DTO keeps no module-level dependency on the
                # tracer graph — the ``canonical_address_key`` SSOT the key must
                # round-trip through.
                from vca.tracer.graph import canonical_address_key
                from vca.types import Address

                try:
                    reconstructed = canonical_address_key(Address.from_str(rest, key_chain))
                except ValueError as exc:
                    raise ValueError(
                        f"TracePolicy.{field_name} entry {address!r} is not a valid canonical "
                        f"address key ({rest!r} is not a valid {key_chain.value} address)"
                    ) from exc
                if reconstructed != address:
                    raise ValueError(
                        f"TracePolicy.{field_name} entry {address!r} is not canonical: expected "
                        f"{reconstructed!r} from canonical_address_key (reject EIP-55 smuggling / "
                        f"non-normalized keys)"
                    )
        if self.deep_expand_cap_addresses:
            if self.deep_expand_cap is None:
                raise ValueError(
                    "TracePolicy.deep_expand_cap_addresses is non-empty but deep_expand_cap "
                    "is None: a cap override requires its count"
                )
            if self.deep_expand_cap < self.max_address_txs_per_address:
                raise ValueError(
                    f"TracePolicy.deep_expand_cap ({self.deep_expand_cap}) must be >= "
                    f"max_address_txs_per_address ({self.max_address_txs_per_address}): the cap "
                    f"override RAISES the per-address cap for curated sinks, it never lowers it"
                )
        if self.deep_expand_window_addresses:
            if self.deep_expand_window is None:
                raise ValueError(
                    "TracePolicy.deep_expand_window_addresses is non-empty but "
                    "deep_expand_window is None: a window override requires its timedelta"
                )
            if self.deep_expand_window < self.time_window:
                raise ValueError(
                    f"TracePolicy.deep_expand_window ({self.deep_expand_window}) must be >= "
                    f"time_window ({self.time_window}): the window override EXTENDS the BFS time "
                    f"window for curated hubs, it never shortens it"
                )
        return self

    @model_validator(mode="after")
    def _validate_time_window(self) -> Self:
        if self.time_window <= timedelta(0):
            raise ValueError(f"TracePolicy.time_window must be positive, got {self.time_window}")
        return self

    @field_serializer("min_value_native")
    def _serialize_min_value_native(self, value: Mapping[ChainId, int]) -> dict[str, int]:
        """Serialise the chain→threshold mapping with string keys.

        Pydantic's JSON encoder cannot handle :class:`types.MappingProxyType`
        (it raises ``PydanticSerializationError: Unable to serialize unknown
        type: mappingproxy``). The validator wraps ``min_value_native`` in
        a MappingProxy after construction; this serializer mirrors the
        unwrap pattern used by ``DefiAction.extras`` /
        ``TraceMetrics.adapter_calls`` and converts ``ChainId`` enum keys
        to their canonical string form so the dump round-trips through
        ``model_validate_json``.
        """
        return {chain.value: threshold for chain, threshold in value.items()}

    @field_serializer("cap_significance_native")
    def _serialize_cap_significance_native(self, value: Mapping[ChainId, int]) -> dict[str, int]:
        """Serialise the chain→floor mapping with string keys.

        Mirrors :meth:`_serialize_min_value_native`: the validator wraps
        ``cap_significance_native`` in a :class:`types.MappingProxyType`
        which Pydantic's JSON encoder cannot serialise, so this unwraps to
        a plain ``dict`` with canonical ``ChainId`` string keys that
        round-trips through ``model_validate_json``.
        """
        return {chain.value: floor for chain, floor in value.items()}

    @field_serializer("deep_expand_floor_native")
    def _serialize_deep_expand_floor_native(self, value: Mapping[ChainId, int]) -> dict[str, int]:
        """Serialise the chain→deep-floor mapping with string keys.

        PB-003.1: mirrors :meth:`_serialize_cap_significance_native`. The
        validator wraps ``deep_expand_floor_native`` in a
        :class:`types.MappingProxyType` which Pydantic's JSON encoder cannot
        serialise, so this unwraps to a plain ``dict`` with canonical
        ``ChainId`` string keys that round-trips through ``model_validate_json``.
        """
        return {chain.value: floor for chain, floor in value.items()}

    @field_serializer("deep_expand_addresses")
    def _serialize_deep_expand_addresses(self, value: frozenset[str]) -> list[str]:
        """Serialise the canonical-key set as a SORTED list (determinism).

        PB-003.1: ``frozenset`` iteration order is non-deterministic, so an
        unsorted dump would perturb byte-stable artifacts. Sorting yields a
        canonical order independent of insertion order.
        """
        return sorted(value)

    @field_serializer("deep_expand_cap_addresses")
    def _serialize_deep_expand_cap_addresses(self, value: frozenset[str]) -> list[str]:
        """Serialise the BTC-1 cap-override key set as a SORTED list.

        Mirrors :meth:`_serialize_deep_expand_addresses`: ``frozenset``
        iteration order is non-deterministic, so sorting keeps byte-stable
        artifacts independent of insertion order.
        """
        return sorted(value)

    @field_serializer("deep_expand_window_addresses")
    def _serialize_deep_expand_window_addresses(self, value: frozenset[str]) -> list[str]:
        """Serialise the BTC-1 window-override key set as a SORTED list
        (mirror :meth:`_serialize_deep_expand_cap_addresses`)."""
        return sorted(value)


__all__ = ["TracePolicy"]
