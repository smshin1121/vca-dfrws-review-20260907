"""Flow Tracer package (P1-014).

In-memory BFS orchestrator over the transaction graph. Consumes
:class:`vca.adapters.AdapterRegistry`, :class:`vca.decoders.DecoderRegistry`,
and an optional :class:`vca.decoders.abi_fallback.AbiFallbackResolver`;
emits a frozen :class:`CaseGraph` with nodes + edges + per-address
termination reasons.

Public surface — exactly the 13 symbols listed in WBS DoD-2:
"""

from vca.tracer._errors import TracerError, TracerExpansionError, TracerPolicyError
from vca.tracer.graph import (
    CaseGraph,
    EdgeKind,
    FlowEdge,
    GraphNode,
    TerminationReason,
    TraceMetrics,
    TxRef,
)
from vca.tracer.labeler_service import LabelerService
from vca.tracer.policy import TracePolicy
from vca.tracer.stage_classifier import (
    StageAssignment,
    StageLabel,
    StagePolicy,
    classify_stages,
)
from vca.tracer.tracer import Tracer

__all__ = [
    "CaseGraph",
    "EdgeKind",
    "FlowEdge",
    "GraphNode",
    "LabelerService",
    "StageAssignment",
    "StageLabel",
    "StagePolicy",
    "TerminationReason",
    "TraceMetrics",
    "TracePolicy",
    "Tracer",
    "TracerError",
    "TracerExpansionError",
    "TracerPolicyError",
    "TxRef",
    "classify_stages",
]
