"""Typed ``TracerError`` hierarchy (P1-014).

Mirrors :mod:`vca.labeler._errors` shape — every instance carries enough
operator-replay context (``case_id``, ``address``, ``tx``) for an
investigator to re-run the offending step against the same cassette set.
The base class is the only catch-all consumer code should rely on;
concrete subclasses identify the failure mode so log filters can target
a single class without sniffing strings.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from vca.tracer.graph import TxRef
    from vca.types import Address


class TracerError(Exception):
    """Base class for all P1-014 tracer failures.

    Constructed positionally (``message``) plus keyword-only context. The
    tracer NEVER raises this on routine "no outgoing" / "value below
    threshold" cases — those go to :class:`TerminationReason`. Subclasses
    are reserved for genuine bug-detection rails (e.g. an unregistered
    seed-chain adapter or an internally inconsistent
    :class:`TracePolicy`).
    """

    def __init__(
        self,
        message: str,
        *,
        case_id: str | None = None,
        address: Address | None = None,
        tx: TxRef | None = None,
    ) -> None:
        super().__init__(message)
        self.case_id = case_id
        self.address = address
        self.tx = tx


class TracerPolicyError(TracerError):
    """Raised when a :class:`TracePolicy` is internally inconsistent.

    Lazily raised (per WBS R-PRICING / behaviour 109) when the tracer
    encounters a chain reachable from the seed that lacks a
    ``min_value_native`` threshold entry.
    """


class TracerExpansionError(TracerError):
    """Raised on unrecoverable expansion failures.

    Examples:
        * Seed-chain adapter not registered (DoD-15 / behaviour 54).
        * Seed-TX fetch failure — the seed cannot fail-soft (behaviour 55).

    Per-address adapter exceptions (HTTP, validation, single-TX errors)
    do NOT raise this — they go to ``CaseGraph.metadata["expansion_errors"]``
    per DoD-15 instead.
    """


__all__ = [
    "TracerError",
    "TracerExpansionError",
    "TracerPolicyError",
]
