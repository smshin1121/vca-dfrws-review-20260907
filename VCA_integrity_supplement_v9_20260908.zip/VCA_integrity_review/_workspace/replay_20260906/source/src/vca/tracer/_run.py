"""Per-call BFS execution context (_TraceRun).

Externalising the mutable trace state into a separate class keeps
:class:`vca.tracer.Tracer` re-entrant — a single Tracer can run multiple
concurrent ``trace()`` calls without sharing intermediate caches.

This module is private (underscore-prefixed) and not part of the public
``vca.tracer`` surface (DoD-2 lists exactly 13 symbols; ``_TraceRun`` is
not one of them).
"""

from __future__ import annotations

import logging
import re
import time
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from types import MappingProxyType
from typing import TYPE_CHECKING, Any

from pydantic import ValidationError

from vca.adapters import AdapterRegistry
from vca.decoders import BridgeDecoder, DecoderRegistry, DefiAction, DefiActionKind
from vca.tracer._errors import TracerExpansionError, TracerPolicyError
from vca.tracer._known_tokens import ERC20_PLACEHOLDER_SYMBOL, resolve_known_token_decimals

if TYPE_CHECKING:  # pragma: no cover - import-time only, kept off the runtime path
    # ``vca.decoders.abi_fallback`` transitively imports ``httpx`` (via the
    # 4byte / Sourcify / Etherscan resolver tiers), which violates the tracer's
    # documented no-I/O import boundary (DoD-23). The concrete class is only
    # referenced as a parameter type hint, so guarding the import under
    # ``TYPE_CHECKING`` keeps mypy happy while keeping the HTTP stack out of
    # ``sys.modules`` when callers omit ``abi_fallback=...``.
    from vca.decoders.abi_fallback import AbiFallbackResolver
from vca.tracer.frontier import Frontier
from vca.tracer.graph import (
    CaseGraph,
    EdgeKind,
    FlowEdge,
    GraphNode,
    TerminationReason,
    TraceMetrics,
    TxRef,
    canonical_address_key,
)
from vca.tracer.labeler_service import LabelerService
from vca.tracer.policy import TracePolicy
from vca.tracer.stage_classifier._priority import edge_contract_key, edge_id, edge_sort_key
from vca.types import (
    Address,
    Amount,
    Asset,
    ChainId,
    CrossChainHop,
    Cursor,
    NormalizedLog,
    NormalizedTransaction,
    NormalizedTransfer,
)

logger = logging.getLogger(__name__)

_EXPANSION_ERRORS_CAP = 100

# ITER-72: re-declared module-private (NOT imported) byte-identical to the
# ``CaseGraph`` charset validator ``vca.tracer.graph._CASE_ID_RE`` (R-NO-PRIVATE-
# IMPORT — the tracer re-declares the validators it mirrors). ``execute()`` uses
# it to fail-fast on a malformed ``case_id`` BEFORE any adapter round-trip,
# instead of running the entire BFS and then leaking a raw ``pydantic.ValidationError``
# from the final ``CaseGraph(case_id=...)`` construction past the typed
# ``TracerExpansionError`` contract (``case_id`` is the last unguarded sibling of
# the ITER-32/53 clock guards in this exact ``execute()`` construction path).
_CASE_ID_RE = re.compile(r"[a-zA-Z0-9_-]+")

# Round 30 codex P1 fix: adapter errors raised by httpx
# (``HTTPStatusError``, ``ConnectError`` with cause) frequently embed
# the request URL into ``str(exc)``. EVM adapter URLs carry the
# Etherscan/Arbiscan API key as the ``apikey`` query parameter and
# generic bearer tokens may surface in ``Authorization`` strings.
# Persisting the raw error into ``CaseGraph.metadata['expansion_errors']``
# would leak credentials into any exported trace artifact (JSON dump,
# Mermaid timeline, etc.). Redact known secret-bearing patterns BEFORE
# the error reaches the metadata sink.
_SECRET_QUERY_RE = re.compile(
    r"(?P<param>(?:apikey|api_key|api-key|access[_-]?token)=)[^&\s'\"<>]+",
    re.IGNORECASE,
)
_BEARER_RE = re.compile(r"(?P<scheme>Bearer\s+)[^\s'\"<>]+", re.IGNORECASE)


def _redact_secrets(message: str) -> str:
    """Replace API keys / bearer tokens in error strings with ``***``.

    Round 30 codex P1: applied at the metadata sink boundary
    (:meth:`_TraceRun._record_expansion_error`) so every exception text
    that flows into ``CaseGraph.metadata['expansion_errors']`` is
    sanitized regardless of where it originated. Non-string inputs
    (defensive against future callers passing exceptions directly) are
    coerced through :func:`str` before regex substitution.
    """
    redacted = _SECRET_QUERY_RE.sub(r"\g<param>***", message)
    return _BEARER_RE.sub(r"\g<scheme>***", redacted)


# Round 28 codex P1 fix: keccak256("Transfer(address,address,uint256)").
# The canonical ERC-20 / ERC-721 Transfer event topic. Used by
# :func:`_synthesize_erc20_transfers_from_logs` to recover token movement
# from receipt logs when the producer-side adapter (P1-002 EtherscanAdapter,
# P1-003 ArbitrumAdapter) returns ``transfers=()`` because
# ``eth_getTransactionByHash`` and the Etherscan ``txlist`` account API
# do not surface token movements.
_ERC20_TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
# Round 29 codex P2 fix: the ERC-20 zero address (0x0000…0000) marks
# the mint endpoint (when it appears as ``from``) or the burn endpoint
# (when it appears as ``to``). The existing transfer-derivation pipeline
# in :meth:`_TraceRun._derive_transfer_edge_pairs` already handles the
# mint/burn semantics — but only when ``transfer.from_addr`` /
# ``transfer.to_addr`` is ``None``. Convert the zero topic to ``None``
# at synthesis time so synthesized mint/burn events flow through the
# same code path as producer-supplied mint/burn transfers.
_ERC20_ZERO_ADDRESS = "0x0000000000000000000000000000000000000000"
# Placeholder ERC-20 asset metadata: 18 decimals matches the most common
# token convention (DAI / WETH / many bridge tokens). scan #15 true-decimals:
# a curated static table (:mod:`vca.tracer._known_tokens`) now resolves the REAL
# decimals of well-known LOW-decimal tokens (USDC/USDT=6, WBTC=8) so they no
# longer surface understated; the placeholder remains the fallback for tokens
# outside that table. DECIMALS-ONLY -- the placeholder SYMBOL is preserved (only
# the value-critical decimals is corrected), keeping the 18-decimal golden
# fixtures byte-identical (no INV-2 re-bless; see the module docstring).
# The placeholder SYMBOL is the shared SSOT ``ERC20_PLACEHOLDER_SYMBOL`` imported
# from :mod:`vca.tracer._known_tokens` (the web builders reference the same
# constant to recognise unresolved legacy token rows).
_ERC20_PLACEHOLDER_DECIMALS = 18

# P2-008.3 — Stage 8 boundary recognizer wiring constants. The
# ``DefiAction.extras["kind_override"]=="bridge_out_boundary"`` marker
# combined with one of these ``stage_label`` values triggers BFS
# termination via :meth:`_TraceRun._record_boundary_exit` — the boundary
# target is upserted into the graph and marked
# ``TerminationReason.TERMINAL_LABEL`` (semantic: an off-chain
# account behaves like a CEX / MIXER terminal). Unknown stage labels
# fall through (R-OUT-OF-SCOPE-BOUNDARY-FROZENSET; forward-compat).
#
# This SSOT is duplicated by
# :data:`vca.tracer.stage_classifier._vocab._KNOWN_OUT_OF_SCOPE_STAGE_LABELS`
# — keep the two in sync when adding boundary chains. The tracer-side
# copy lives here (not imported) because :mod:`vca.tracer._run` MUST
# NOT import the stage classifier (R-PURE classifier; the classifier
# imports the tracer's :class:`CaseGraph`, not the other way round).
_BRIDGE_OUT_BOUNDARY_KIND_OVERRIDE = "bridge_out_boundary"
_KNOWN_OUT_OF_SCOPE_STAGE_LABELS_TRACER: frozenset[str] = frozenset(
    {
        "OUT_OF_SCOPE_POLYGON",
        "OUT_OF_SCOPE_SOLANA_MAYAN",
    }
)


def _synthesize_erc20_transfers_from_logs(
    tx: NormalizedTransaction,
    logs: tuple[NormalizedLog, ...],
) -> tuple[NormalizedTransfer, ...]:
    """Best-effort: parse standard ERC-20 ``Transfer`` events into transfers.

    Round 28 codex P1: producers (P1-002 EVM adapters) currently leave
    :attr:`NormalizedTransaction.transfers` empty because
    ``eth_getTransactionByHash`` and the Etherscan ``txlist`` account
    API do not surface token movements. The Flow Tracer otherwise
    fetches receipt logs only when a registered :class:`BridgeDecoder`
    matches, so ordinary ERC-20-only flows would be invisible (no
    decoder → no log fetch → empty transfers → ``NO_OUTGOING``).

    This synthesis is BEST-EFFORT: it parses the canonical
    ``Transfer(address indexed from, address indexed to, uint256 value)``
    event without an extra API roundtrip per token contract. The SYMBOL is
    always the placeholder (``"ERC20"``). The ``decimals`` are resolved from
    the static :mod:`vca.tracer._known_tokens` table for well-known tokens
    (USDC/USDT=6, WBTC=8, WETH/DAI=18, ...) so low-decimal amounts are not
    understated (scan #15 true-decimals); tokens outside that table keep the
    ``18`` placeholder. Symbol resolution remains deferred.

    Skips:
    * Non-EVM logs (BTC has no log surface).
    * ``log.removed`` (chain reorg).
    * ERC-721 ``Transfer(from, to, tokenId)`` (3 indexed topics, no data).
    * Zero-amount events (no value moved).
    * Malformed topics / data (parse-error → drop, not raise).
    """
    if not logs or not tx.chain.is_evm:
        return ()
    transfers: list[NormalizedTransfer] = []
    for log in logs:
        if log.removed:
            continue
        topics = log.topics
        # ERC-20 Transfer has exactly 3 topics (event sig + indexed from + indexed to)
        # and the value lives in ``data``. ERC-721 Transfer has 4 topics
        # (event sig + from + to + tokenId) — skip those (different semantic).
        if len(topics) != 3:
            continue
        if topics[0] != _ERC20_TRANSFER_TOPIC:
            continue
        try:
            from_addr_hex = "0x" + topics[1][-40:]
            to_addr_hex = "0x" + topics[2][-40:]
            data_hex = log.data
            # The ERC-20 value is the FIRST 32-byte word of ``data``; read
            # exactly that word (parity with every decoder's
            # ``_read_uint256_word(data, 0)``). Parsing the whole blob would
            # concatenate trailing words from a non-standard / topic-collision
            # log into a phantom-inflated amount. ``data`` too short to supply
            # one full word is malformed → drop (this function's
            # "malformed → drop" contract; ``data="0x"`` / empty included).
            if len(data_hex) < 2 + 64:
                continue
            amount_raw = int(data_hex[2 : 2 + 64], 16)
        except (ValueError, IndexError):
            continue
        if amount_raw <= 0:
            continue
        # Round 29 codex P2 fix: zero address denotes mint (from=0x0) or
        # burn (to=0x0) — converting the topic into a real Address would
        # produce phantom edges/nodes for the canonical ``0x0…0`` slot,
        # contaminating the graph with non-flow events. Map it to the
        # ``None`` sentinel so the existing mint/burn handling in
        # :meth:`_TraceRun._derive_transfer_edge_pairs` (which keys on
        # ``from_addr is None`` / ``to_addr is None``) fires uniformly.
        from_addr: Address | None = None
        to_addr: Address | None = None
        try:
            if from_addr_hex.lower() != _ERC20_ZERO_ADDRESS:
                from_addr = Address.from_str(from_addr_hex, tx.chain)
            if to_addr_hex.lower() != _ERC20_ZERO_ADDRESS:
                to_addr = Address.from_str(to_addr_hex, tx.chain)
            # scan #15 true-decimals: resolve the REAL decimals for well-known
            # tokens (USDC/USDT=6, WBTC=8, ...) so low-decimal amounts are not
            # understated; unknown tokens keep the 18 placeholder. DECIMALS-ONLY
            # -- the SYMBOL stays the placeholder so 18-decimal tokens are
            # byte-identical in the golden fixtures. The Asset and Amount MUST
            # share the same decimals (validated downstream).
            resolved_decimals = resolve_known_token_decimals(log.address)
            token_decimals = (
                resolved_decimals if resolved_decimals is not None else _ERC20_PLACEHOLDER_DECIMALS
            )
            asset = Asset.erc20(
                contract=log.address,
                symbol=ERC20_PLACEHOLDER_SYMBOL,
                decimals=token_decimals,
            )
            transfer = NormalizedTransfer(
                log_index=log.log_index,
                asset=asset,
                from_addr=from_addr,
                to_addr=to_addr,
                amount=Amount(raw=amount_raw, decimals=token_decimals),
            )
        except (ValueError, ValidationError):
            # Address / Asset / Amount validators rejected the parse —
            # drop the malformed log instead of aborting the trace.
            continue
        transfers.append(transfer)
    return tuple(transfers)


def _addr_key(address: Address) -> str:
    """Canonical key for visited / direction comparisons.

    Single source of truth lives in :func:`vca.tracer.graph.canonical_address_key`
    so EVM (case-insensitive hex) and BTC (case-sensitive Base58Check)
    semantics stay in sync between this module's direction filter and
    :class:`GraphNode.canonical_key` / :class:`CaseGraph` referential
    integrity (round 11 codex P2 fix).
    """
    return canonical_address_key(address)


def _carries_hidden_value(tx: NormalizedTransaction) -> bool:
    """True when a tx carries NO top-level native value but DOES carry contract
    calldata — the shape of an outgoing ERC-20 transfer or a contract-withdraw /
    unwrap whose economic value surfaces only later, per admitted tx, via
    ``_synthesize_erc20_transfers_from_logs`` (receipt logs) or
    ``get_internal_txs`` (scan #13 TRM-1).

    Gating on ``value_native.raw == 0`` (NOT merely below-floor) keeps the
    cap-significance policy honest: a below-floor NON-zero native contract call
    is ordinary tail and stays dropped exactly like a plain send, so
    force-admitting a hidden-value candidate can never leak a below-floor native
    edge into the graph (its ``value_native`` is 0, below ``min_value_native`` →
    no native edge is derived) — only its token / internal legs are recovered.
    ``input`` is ``None`` for BTC / unpopulated rows and ``""`` / ``"0x"`` for
    EVM no-data sends; only a ``"0x<selector>…"`` contract call qualifies.
    A REVERTED tx (``status == 0``) is excluded — it moved no value at any
    layer (``_process_tx`` rejects it before fetching logs / internals), so
    admitting it would only burn the bounded probe budget without ever
    recovering a hidden leg, starving a later successful transfer (codex TRM-1
    R3 P2). Shared SSOT for the cap-significance admission predicate AND its
    defensive-trim mirror so the two can never drift (a candidate force-admitted
    by the loop must also survive the trim, else it is silently evicted).
    """
    return tx.value_native.raw == 0 and tx.input not in (None, "", "0x") and tx.status != 0


def _carries_qualifying_btc_output(
    tx: NormalizedTransaction, native_floor: int, expanding_address: Address
) -> bool:
    """True when a non-EVM (BTC) tx has at least one per-vout output to a
    DISTINCT recipient that would derive a BFS-EXPANDING edge at/above the
    chain's ``min_value_native`` edge floor — the shape of an edge-worthy peel
    leg the SUM-based ``cap_significance_native`` floor misses (scan #15 Lens A).

    BTC ``value_native`` is the SUM of every vout while edge/fanout derivation
    is PER-VOUT (:meth:`Tracer._derive_transfer_edge_pairs`), so a peel leg that
    carries a ``[floor, cap_significance)`` BTC output (edge-worthy, but below
    the sum floor) is silently truncated past the per-address cap. This
    predicate lets the admission arm force-admit such a tx on a BOUNDED probe
    budget — the low per-vout floor would otherwise let a busy peel address
    escape the cap entirely. A dust-aggregate tx (sum >= floor but NO single
    output >= floor) has NO qualifying output and stays dropped, closing the
    gap WITHOUT the unsound sum-based lowering of ``cap_significance_native``
    that codex-5.6-sol rejected (it would force-admit dust aggregates
    UNBOUNDED).

    A change/self output (``to_addr`` == the expanding address) does NOT count:
    it derives a self-loop edge that opens NO new frontier (``child`` is None in
    ``_derive_transfer_edge_pairs``), so admitting a tx solely for its change
    output would spend the bounded probe budget without recovering a peel leg —
    starving a later genuine peel to a NEW address (codex-5.6-sol R1 P2). Only a
    DISTINCT-recipient output at/above the floor qualifies, matching the
    child-selection and ``_btc_tx_fanout`` semantics.

    EVM is excluded: its recoverable value rides in calldata, handled by
    :func:`_carries_hidden_value`. The per-vout test mirrors the edge
    derivation's native-floor gate exactly — a token output
    (``asset.contract`` set) bypasses the native floor just as an edge would be
    derived for it — so the admission predicate and the edge it protects can
    never drift. Shared SSOT for the admission arm AND its defensive-trim
    mirror.
    """
    if tx.chain.is_evm:
        return False
    actor_key = _addr_key(expanding_address)
    for transfer in tx.transfers:
        if transfer.to_addr is None:
            continue
        if _addr_key(transfer.to_addr) == actor_key:
            continue  # change/self output — opens no new frontier, skip
        if transfer.asset.contract is not None or transfer.amount.raw >= native_floor:
            return True
    return False


def _rejected(reason: str, *, had_expansion_error: bool = False) -> dict[str, Any]:
    """Helper that builds the per-TX rejection dict (DoD-17 filter chain).

    Round 8 codex P2-1 fix: ``had_expansion_error`` flags rejections that
    were forced by a recorded expansion error (decoder ``decode()`` raised,
    ``get_logs`` raised, ``get_internal_txs`` raised). The address-level
    termination logic in :meth:`_TraceRun._expand_address` checks this flag
    so the parent's terminal reason reflects the real failure
    (``EXPANSION_ERROR``) instead of the cosmetic "no edges produced"
    classification (``VALUE_SUB_THRESHOLD``).
    """
    return {
        "accepted": False,
        "reason": reason,
        "edges_emitted": 0,
        "branching_hit": False,
        "expandable_children": 0,
        "had_expansion_error": had_expansion_error,
    }


class _TraceRun:
    """One-shot BFS execution context. Mutable internal state only."""

    __slots__ = (
        "_abi_fallback",
        "_abi_fallback_resolutions",
        "_abridged_emissions",
        "_adapter_calls",
        "_adapters",
        "_case_id",
        "_clock",
        "_decoder_matches",
        "_decoders",
        "_edges",
        "_expansion_errors",
        "_expansion_errors_overflow",
        "_frontier",
        "_label_cache",
        "_labeler",
        "_nodes",
        # P2-008.3 — boundary exit metadata accumulator. Each entry is
        # a 5-key dict captured by ``_record_boundary_exit`` when the
        # ``_expand_tx`` BFS hook detects a DEFI ``FlowEdge`` whose
        # ``extras["kind_override"]=="bridge_out_boundary"`` and whose
        # ``extras["stage_label"]`` is in
        # ``_KNOWN_OUT_OF_SCOPE_STAGE_LABELS_TRACER``. Merged into
        # ``CaseGraph.metadata["boundary_exits"]`` (frozen tuple) by
        # :meth:`execute`.
        "_pending_boundary_exits",
        "_policy",
        "_seed_block_number",
        "_seed_block_timestamp",
        "_seed_tx",
        "_started_monotonic",
        "_sub_threshold_drops",
        "_terminal_reasons",
    )

    def __init__(
        self,
        *,
        case_id: str,
        seed_tx: TxRef,
        adapters: AdapterRegistry,
        decoders: DecoderRegistry,
        labeler: LabelerService,
        policy: TracePolicy,
        abi_fallback: AbiFallbackResolver | None,
        clock: Callable[[], datetime],
    ) -> None:
        self._case_id = case_id
        self._seed_tx = seed_tx
        self._adapters = adapters
        self._decoders = decoders
        self._labeler = labeler
        self._policy = policy
        self._abi_fallback = abi_fallback
        self._clock = clock
        self._frontier = Frontier(policy=policy)
        self._nodes: dict[str, GraphNode] = {}
        self._edges: list[FlowEdge] = []
        self._terminal_reasons: dict[str, TerminationReason] = {}
        self._adapter_calls: dict[ChainId, int] = {}
        self._decoder_matches: int = 0
        self._abi_fallback_resolutions: int = 0
        self._abridged_emissions: int = 0
        self._expansion_errors: list[dict[str, Any]] = []
        self._expansion_errors_overflow: int = 0
        # Round 27 codex P2 fix: count sub-threshold extraction drops so the
        # seed-expansion path can distinguish NO_OUTGOING (no value movement
        # at all) from VALUE_SUB_THRESHOLD (movement existed but was pruned
        # by ``min_value_native``). The per-address path already emits this
        # distinction via the precedence ladder in ``_expand_address``;
        # without this counter, the round-26 P1 fix would homogenise both
        # cases into NO_OUTGOING for seeds.
        self._sub_threshold_drops: int = 0
        self._label_cache: dict[str, Any] = {}
        self._seed_block_number: int = 0
        self._seed_block_timestamp: datetime = datetime.now(UTC)
        self._started_monotonic: float = 0.0
        # P2-008.3 — boundary exits accumulated by ``_record_boundary_exit``
        # and merged into ``CaseGraph.metadata["boundary_exits"]`` in
        # :meth:`execute` as a frozen tuple of ``MappingProxyType``.
        self._pending_boundary_exits: list[dict[str, str]] = []

    # ------------------------------------------------------------------
    # Public execution
    # ------------------------------------------------------------------

    async def execute(self) -> CaseGraph:
        started_at = self._clock()
        if started_at.tzinfo is None or started_at.tzinfo.utcoffset(started_at) is None:
            raise TracerPolicyError(
                "Tracer.clock() must return a tz-aware UTC datetime",
                case_id=self._case_id,
                tx=self._seed_tx,
            )
        # ITER-72: fail-fast on a malformed ``case_id`` BEFORE any adapter call.
        # ``case_id`` is stored raw in ``__init__`` and was otherwise validated
        # only at the LAST statement of ``execute()`` (``CaseGraph(case_id=...)``),
        # whose ``_validate_case_id`` raises a bare ``ValueError`` pydantic wraps as
        # a raw ``ValidationError`` — escaping the documented ``TracerExpansionError``
        # contract after the ENTIRE BFS already ran. Mirror the consumer charset
        # check here (the remaining unguarded sibling of the ITER-32/53 clock
        # guards). Production callers (CLI/API) pre-validate ``case_id`` so this is
        # a no-op on the golden path (``"kelpdao"`` matches).
        if not _CASE_ID_RE.fullmatch(self._case_id):
            raise TracerExpansionError(
                f"case_id must match [a-zA-Z0-9_-]+, got: {self._case_id!r}",
                case_id=self._case_id,
                tx=self._seed_tx,
            )
        self._started_monotonic = time.monotonic()

        await self._expand_seed()
        await self._expand_frontier()

        finished_at = self._clock()
        # ITER-32: mirror the started_at guard above (sibling parity). A clock
        # that is tz-aware on read #1 but naive on read #2 would otherwise leak
        # a raw pydantic.ValidationError from TraceMetrics construction below
        # instead of the typed TracerError the trace contract documents.
        if finished_at.tzinfo is None or finished_at.tzinfo.utcoffset(finished_at) is None:
            raise TracerPolicyError(
                "Tracer.clock() must return a tz-aware UTC datetime",
                case_id=self._case_id,
                tx=self._seed_tx,
            )
        # ITER-53: the sibling CROSS-FIELD invariant ITER-32's comment flagged but
        # left unguarded. ``TraceMetrics``' ``@model_validator`` (graph.py) raises a
        # bare ValueError when ``started_at > finished_at`` → pydantic wraps it as a
        # raw ValidationError that escapes the typed TracerError contract. The
        # default ``_default_clock`` is ``datetime.now(UTC)`` (explicitly
        # non-monotonic wall-clock — the reason ``duration_seconds`` uses
        # ``time.monotonic()``), so a backward NTP step / manual adjustment / DST or
        # leap handling between the two reads makes ``finished_at < started_at`` and
        # fires the leak. Guard here, mirroring the consumer. codex P3: compare
        # ABSOLUTE UTC instants (``.astimezone(UTC)``, exactly what the consumer's
        # ``_ensure_utc`` applies) — same-``tzinfo`` aware datetimes otherwise
        # compare by WALL clock, so a non-UTC DST-observing clock could falsely
        # trip across a fall-back fold (a later absolute instant with an earlier
        # wall time). The default UTC clock is unaffected either way.
        if started_at.astimezone(UTC) > finished_at.astimezone(UTC):
            raise TracerPolicyError(
                "Tracer.clock() must be monotonic non-decreasing across reads",
                case_id=self._case_id,
                tx=self._seed_tx,
            )
        duration_seconds = max(0.0, time.monotonic() - self._started_monotonic)

        sorted_nodes = tuple(sorted(self._nodes.values(), key=lambda n: (n.depth, n.canonical_key)))
        flagged_nodes = tuple(
            (
                n.model_copy(update={"terminal": True})
                if n.canonical_key in self._terminal_reasons and not n.terminal
                else n
            )
            for n in sorted_nodes
        )
        sorted_edges = tuple(
            sorted(
                self._edges,
                # Round 11 codex P2 fix: ``edge_sort_key`` routes through the
                # chain-aware canonical key (preserves BTC Base58Check case,
                # lowercases EVM hex). Scan #7 VCA-ORDER-001: the legacy
                # 4-key sort left four-key-tied edges (same source/target/
                # tx_hash/kind, differing asset/value/extras) in adapter
                # DISCOVERY order — a permutation hazard for graph.json and
                # the report Mermaid body, both of which consume
                # ``graph.edges`` raw. ``(edge_sort_key, edge_id)`` is the
                # classifier's proven total order over distinct edges.
                key=lambda e: (edge_sort_key(e), edge_id(e), edge_contract_key(e)),
            )
        )

        metrics = TraceMetrics(
            started_at=started_at,
            finished_at=finished_at,
            duration_seconds=duration_seconds,
            nodes_count=len(flagged_nodes),
            edges_count=len(sorted_edges),
            frontier_max_size=self._frontier.peek_max_size(),
            adapter_calls=dict(self._adapter_calls),
            decoder_matches=self._decoder_matches,
            abi_fallback_resolutions=self._abi_fallback_resolutions,
            abridged_emissions=self._abridged_emissions,
        )

        metadata: dict[str, Any] = {}
        if self._expansion_errors:
            metadata["expansion_errors"] = tuple(self._expansion_errors)
        if self._expansion_errors_overflow:
            metadata["expansion_errors_overflow"] = self._expansion_errors_overflow
        # P2-008.3 — boundary exits side-channel. Freeze each accumulated
        # dict into a :class:`types.MappingProxyType` and emit as a
        # frozen tuple so downstream consumers (P2-008.4 reporter)
        # cannot mutate the records. Sorted by ``edge_id`` so the
        # ordering is content-deterministic across runs
        # (R-DETERMINISTIC).
        if self._pending_boundary_exits:
            sorted_exits = sorted(self._pending_boundary_exits, key=lambda d: d["edge_id"])
            metadata["boundary_exits"] = tuple(
                MappingProxyType(dict(entry)) for entry in sorted_exits
            )

        sorted_terminal_reasons = dict(sorted(self._terminal_reasons.items()))

        return CaseGraph(
            case_id=self._case_id,
            seed_tx=self._seed_tx,
            nodes=flagged_nodes,
            edges=sorted_edges,
            terminal_reasons=sorted_terminal_reasons,
            metrics=metrics,
            metadata=metadata,
        )

    # ------------------------------------------------------------------
    # Seed expansion (depth 0 -> depth 1)
    # ------------------------------------------------------------------

    async def _expand_seed(self) -> None:
        """Fetch the seed TX and emit depth=0/1 nodes + edges (DoD-16).

        The seed TX itself may be a bridge / DeFi interaction whose semantic
        children come from a registered :class:`BridgeDecoder` or the
        :class:`AbiFallbackResolver` rather than ``tx.transfers``. Round 2
        codex P1 fix: route the seed through the same decoder + abi-fallback
        + transfer-derivation pipeline that ``_process_tx`` uses, instead of
        only deriving transfer edges.
        """
        try:
            adapter = self._adapters.get(self._seed_tx.chain)
        except KeyError as exc:
            raise TracerExpansionError(
                f"seed-chain adapter not registered: {self._seed_tx.chain.value}",
                case_id=self._case_id,
                address=None,
                tx=self._seed_tx,
            ) from exc

        if self._seed_tx.chain not in self._policy.min_value_native:
            raise TracerPolicyError(
                f"TracePolicy.min_value_native missing entry for seed chain "
                f"{self._seed_tx.chain.value}; configured chains: "
                f"{[c.value for c in self._policy.min_value_native]}",
                case_id=self._case_id,
                tx=self._seed_tx,
            )

        # Round 31 / 33 / 35 codex P1 fixes: seed-TX fetch failures must
        # not leak Etherscan/Arbiscan credentials through ANY exception
        # surface. Round 31 added ``_redact_secrets`` to the message;
        # round 33 added ``from None`` to suppress ``__cause__``; round
        # 35 surfaced that re-raising INSIDE the ``except`` block still
        # attaches the raw exception as ``__context__`` because an
        # active exception is always recorded as implicit context.
        # Audit hooks / structured error reporters (Sentry, custom
        # exception inspectors) walk both ``__cause__`` and
        # ``__context__``, so a leak through context is just as
        # damaging as a leak through cause. Save the redacted message
        # inside the ``except`` and raise OUTSIDE it — when the raise
        # runs, no exception is active, so ``__context__`` stays None.
        seed_fetch_redacted: str | None = None
        try:
            self._adapter_calls[self._seed_tx.chain] = (
                self._adapter_calls.get(self._seed_tx.chain, 0) + 1
            )
            tx = await adapter.get_tx(self._seed_tx.tx_hash)
        except Exception as exc:
            seed_fetch_redacted = _redact_secrets(str(exc))

        if seed_fetch_redacted is not None:
            raise TracerExpansionError(
                f"seed-TX fetch failed: {seed_fetch_redacted}",
                case_id=self._case_id,
                address=None,
                tx=self._seed_tx,
            ) from None

        # Round 28 codex P2 fix: real EVM ``get_tx`` is built from
        # ``eth_getTransactionByHash`` whose response has no ``status`` field,
        # so ``tx.status`` for a freshly-fetched EVM seed is always ``None``.
        # The reverted-seed guard (``if tx.status == 0`` below) would
        # otherwise silently fall through. Resolve the status via the
        # dedicated Protocol surface (P1-002 ``ChainAdapter.get_tx_status``)
        # whose EVM implementation consults the cached receipt endpoint.
        # Failures are downgraded to a metadata expansion-error record so a
        # transient receipt fetch failure cannot abort the whole trace; the
        # status stays unresolved (treated as "unknown / proceed as success"
        # to match pre-fix behaviour for non-EVM seeds whose status field
        # is always absent).
        if tx.chain.is_evm and tx.status is None:
            try:
                self._adapter_calls[tx.chain] = self._adapter_calls.get(tx.chain, 0) + 1
                resolved_status = await adapter.get_tx_status(tx.tx_hash)
            except Exception as exc:
                anchor_for_error = tx.from_addr if tx.from_addr is not None else tx.to_addr
                if anchor_for_error is not None:
                    self._record_expansion_error(
                        anchor_for_error,
                        self._seed_tx.tx_hash,
                        f"seed_status_fetch_error: {exc}",
                    )
            else:
                if resolved_status is not None:
                    tx = tx.model_copy(update={"status": resolved_status})

        self._seed_block_number = tx.block.number
        self._seed_block_timestamp = tx.block.timestamp

        # Seed parties (depth 0). Both endpoints must exist before any edge
        # references them so the CaseGraph referential-integrity validator
        # is satisfied even when the seed itself emits no children.
        #
        # Round 8 codex P3 fix: ``max_total_addresses`` MUST be enforced
        # before the second seed anchor is inserted. Pre-fix, a policy with
        # ``max_total_addresses=1`` allowed both ``from_addr`` and
        # ``to_addr`` in unconditionally because the cap projection only
        # ran inside ``_expand_tx`` for child pairs. Honouring the cap at
        # seed-anchor time keeps the invariant ``len(self._nodes) <=
        # policy.max_total_addresses`` for every step of expansion.
        # Pydantic already rejects ``max_total_addresses < 1`` (Field ge=1
        # in policy.py), so the cap is at minimum 1 and the seed
        # ``from_addr`` (when present) always fits.
        seed_anchors: list[Address] = []
        if tx.from_addr is not None:
            seed_anchors.append(tx.from_addr)
        if tx.to_addr is not None and (
            tx.from_addr is None or _addr_key(tx.to_addr) != _addr_key(tx.from_addr)
        ):
            seed_anchors.append(tx.to_addr)

        seed_from_node: GraphNode | None = None
        seed_cap_reached = False
        for anchor_addr in seed_anchors:
            if len(self._nodes) >= self._policy.max_total_addresses:
                # Record one diagnostic entry per cap-rejected anchor so
                # the metadata trail mirrors the per-TX cap diagnostic
                # already emitted by ``_expand_tx``.
                self._record_expansion_error(
                    anchor_addr,
                    self._seed_tx.tx_hash,
                    f"seed_address_cap_reached: max_total_addresses="
                    f"{self._policy.max_total_addresses}",
                )
                seed_cap_reached = True
                continue
            node, _ = self._upsert_node(
                address=anchor_addr,
                depth=0,
                first_seen_tx=self._seed_tx,
                first_seen_at=tx.block.timestamp,
            )
            # Track the ``from_addr`` node — it is the "expanding" party
            # used as the cap-termination target inside ``_expand_tx``.
            if tx.from_addr is not None and _addr_key(anchor_addr) == _addr_key(tx.from_addr):
                seed_from_node = node

        if seed_cap_reached and seed_from_node is not None:
            # Mark the seed sender terminal with EXPANSION_ERROR — the
            # downstream expansion cannot legally insert any more nodes,
            # so the BFS has nothing more to do for this seed. This
            # mirrors the cap-termination behaviour ``_expand_tx`` already
            # applies for downstream TXs.
            self._mark_terminal(seed_from_node, TerminationReason.EXPANSION_ERROR)
            return

        # The "expanding address" for seed-derived transfer edges is the
        # outgoing party of the seed TX. Native-value transfers and BTC
        # vouts (``transfer.from_addr=None``) require an explicit fallback
        # to ``tx.from_addr``.
        expanding = tx.from_addr if tx.from_addr is not None else tx.to_addr
        if expanding is None:
            return

        # Round 6 codex P2-1 fix: a reverted seed TX moved no value on-chain,
        # so any edges derived from it (native value transfer, ERC-20
        # ``Transfer`` logs that may have been emitted before the revert
        # rolled the receipt back, or internal sub-frames) are phantom. The
        # downstream ``_process_tx`` path applies the same filter for history
        # TXs (round 5 P2-1); applying it to the seed keeps the two paths
        # consistent. Seed parties (``from_addr`` / ``to_addr``) remain
        # upserted at depth 0 — the addresses still exist as participants in
        # the (failed) attempt — but no edges are derived. Strict ``== 0``
        # check leaves BTC behaviour untouched (BTC ``status is None``).
        #
        # Round 9 codex P2 fix: round 6 only skipped EDGE derivation for the
        # reverted seed, but the seed anchor nodes were still pushed into
        # the frontier above. Without an explicit terminal mark, the
        # frontier loop would happily expand them and emit downstream
        # edges from the seed sender's POST-seed history — so a reverted
        # seed could still produce a multi-hop graph. Mark every seed
        # anchor terminal so ``_expand_frontier``'s terminal-skip guard
        # pops them off without further work.
        #
        # Round 16 codex P2-4 fix: collapse the bespoke ``SEED_REVERTED``
        # terminal reason into the existing ``EXPANSION_ERROR`` member of
        # the closed termination-reason vocabulary (see
        # :class:`TerminationReason` docstring). The semantics already
        # match — "BFS aborted because the proximate cause was a
        # decoder/adapter failure" — and reverted seeds emit a per-anchor
        # expansion-error record whose ``error`` field carries the
        # ``"seed_reverted"`` marker. Downstream consumers can still
        # distinguish the case via ``CaseGraph.metadata['expansion_errors']``
        # without relying on a non-public enum value.
        if tx.status == 0:
            for anchor_addr in seed_anchors:
                anchor_key = _addr_key(anchor_addr)
                anchor_node = self._nodes.get(anchor_key)
                if anchor_node is not None:
                    self._record_expansion_error(
                        anchor_addr, self._seed_tx.tx_hash, "seed_reverted"
                    )
                    self._mark_terminal(anchor_node, TerminationReason.EXPANSION_ERROR)
            return

        # Round 4 codex P2-1 fix: when ``max_depth=0`` the seed node is the
        # only legal node and no child edges should be emitted. Without
        # this gate ``_expand_tx`` would still enqueue depth-1 children
        # (and the frontier loop's ``depth >= max_depth`` check fires AFTER
        # the children have already been upserted, so the graph contains
        # nodes / edges it shouldn't). The same predicate covers
        # ``max_depth >= 1`` (the inverse of the early return).
        if self._policy.max_depth < 1:
            return

        # Run the full edge-emission pipeline (decoders + abi_fallback +
        # transfer derivation). ``_expand_tx`` returns ready-to-emit pairs
        # WITHOUT side effects on the visited set, the edge list, or the
        # frontier; the caller is responsible for upserting / appending.
        #
        # Round 10 codex P2-1 fix: the seed expansion path mirrors the
        # ``_process_tx`` ``had_expansion_error`` precedence introduced in
        # round 8. Snapshot the expansion-error counter before ``_expand_tx``
        # so a decoder ``decode()`` raise / ``get_logs`` failure /
        # ``get_internal_txs`` failure that yields an empty pair list
        # promotes the seed anchors to ``EXPANSION_ERROR`` instead of
        # silently leaving them in the frontier (which would walk the seed
        # sender's POST-seed history as if the seed itself succeeded).
        # Pre-fix: ``_expand_seed`` returned with an empty pair list and the
        # seed anchors stayed enqueued; ``_expand_address`` then expanded
        # them and emitted phantom downstream edges, exactly the
        # round-9 ``SEED_REVERTED`` failure mode but for failure causes that
        # are NOT receipt-status reverts. The legitimate "decoder produced
        # 0 edges" case (no expansion error recorded) keeps the existing
        # behaviour — anchors stay in the frontier and may expand via
        # address history.
        errors_before_seed = len(self._expansion_errors)
        errors_overflow_before_seed = self._expansion_errors_overflow
        sub_threshold_drops_before_seed = self._sub_threshold_drops
        # Round 16 codex P2-1 fix: mirror the per-TX ``ValidationError``
        # guard at the seed level. A decoder/transfer that violates a
        # ``FlowEdge`` model invariant during seed expansion would
        # otherwise propagate out of ``_expand_seed`` → ``Tracer.trace``
        # and abort the BFS before the frontier loop even runs.
        # Consistent with the round-10 P2-1 handling for "seed produced
        # no edges due to expansion error", record the validation error
        # and mark every seed anchor terminal with ``EXPANSION_ERROR``.
        # That keeps the closed termination-reason vocabulary intact
        # (round 16 P2-4) and preserves the documented invariant that
        # downstream consumers see a complete ``CaseGraph`` even when the
        # seed itself fails to produce edges.
        try:
            edge_child_pairs = await self._expand_tx(
                tx=tx,
                actor_address=expanding,
                child_depth=1,
                seed_node_for_cap_termination=seed_from_node,
            )
        except ValidationError as exc:
            self._record_expansion_error(
                expanding, self._seed_tx.tx_hash, f"seed_validation_error: {exc}"
            )
            for anchor_addr in seed_anchors:
                anchor_key = _addr_key(anchor_addr)
                anchor_node = self._nodes.get(anchor_key)
                if anchor_node is not None:
                    self._mark_terminal(anchor_node, TerminationReason.EXPANSION_ERROR)
            return
        seed_had_expansion_error = (
            len(self._expansion_errors) > errors_before_seed
            or self._expansion_errors_overflow > errors_overflow_before_seed
        )

        if not edge_child_pairs and seed_had_expansion_error:
            # Round 10 codex P2-1: seed expansion produced no edges DUE TO an
            # expansion error. Mark every seed anchor terminal with
            # ``EXPANSION_ERROR`` so the frontier loop's terminal-skip guard
            # pops them off without further work. Reuse the existing
            # ``EXPANSION_ERROR`` reason rather than introducing a new
            # ``SEED_EXPANSION_ERROR`` — the closed vocabulary already covers
            # the semantics ("BFS aborted because the proximate cause was a
            # decoder/adapter failure"), and the recorded
            # ``metadata['expansion_errors']`` entry preserves the seed
            # context (tx_hash + actor_address) for forensic analysis.
            for anchor_addr in seed_anchors:
                anchor_key = _addr_key(anchor_addr)
                anchor_node = self._nodes.get(anchor_key)
                if anchor_node is not None:
                    self._mark_terminal(anchor_node, TerminationReason.EXPANSION_ERROR)
            return

        if not edge_child_pairs:
            # Round 26 codex P1 fix: seed expansion produced 0 edges with NO
            # recorded expansion error (e.g. successful zero-value approval,
            # decoder match returning empty extractions, native value 0 with
            # no transfer logs and no internal sub-frames). Round 10's
            # sanity-guard left these anchors in the frontier so
            # ``_expand_address`` could walk the seed sender's POST-seed
            # outgoing history. Codex round 26 re-classified that behaviour
            # as a false-positive vector: those follow-on transfers have NO
            # causal link to the seed TX, so attributing them to the
            # investigation contaminates the graph.
            #
            # Round 27 codex P2 fix: distinguish "no movement at all" from
            # "movement intentionally pruned by ``min_value_native``" so
            # the seed precedence ladder mirrors the per-address path in
            # ``_expand_address`` (lines 884-907). When ``_expand_tx``
            # observed at least one positive value flow that fell below
            # the configured threshold, mark the anchors
            # ``VALUE_SUB_THRESHOLD``. Otherwise, mark them
            # ``NO_OUTGOING`` (the genuine empty case). Both reasons are
            # already members of the closed termination-reason vocabulary,
            # so no new enum value is introduced (round 16 P2-4).
            seed_had_sub_threshold_drop = (
                self._sub_threshold_drops > sub_threshold_drops_before_seed
            )
            empty_reason = (
                TerminationReason.VALUE_SUB_THRESHOLD
                if seed_had_sub_threshold_drop
                else TerminationReason.NO_OUTGOING
            )
            for anchor_addr in seed_anchors:
                anchor_key = _addr_key(anchor_addr)
                anchor_node = self._nodes.get(anchor_key)
                if anchor_node is not None:
                    self._mark_terminal(anchor_node, empty_reason)
            return

        for edge, child_addr in edge_child_pairs:
            # Source of the edge may differ from ``expanding`` (e.g. an
            # ERC-20 transfer log carries its own from_addr). Upsert at
            # depth 0 because it's a party to the seed TX itself.
            self._upsert_node(
                address=edge.source,
                depth=0,
                first_seen_tx=self._seed_tx,
                first_seen_at=tx.block.timestamp,
            )
            self._edges.append(edge)
            # P2-008.3 codex F-D fix (R-BOUNDARY-POST-ADMISSION): the
            # boundary side effects (upsert target + mark terminal +
            # append metadata) MUST run only after the pair survived
            # ``_expand_tx``'s ``max_branching`` trimming and
            # ``max_total_addresses`` cap projection. The detection is
            # pure (reads ``edge.kind`` + ``edge.extras`` only), so
            # routing it here keeps the boundary target counted by the
            # cap projection (``child_addr`` carries the boundary
            # target) while ensuring no ghost metadata for pairs that
            # the admission pipeline dropped. The boundary target is
            # NOT enqueued for BFS expansion because
            # :meth:`_record_boundary_exit` marks it terminal in the
            # same call as the upsert — the frontier-loop terminal-skip
            # guard at line 796 short-circuits the pop.
            boundary_stage_label = self._is_boundary_edge(edge)
            if boundary_stage_label is not None:
                self._record_boundary_exit(
                    edge=edge,
                    tx=tx,
                    stage_label_value=boundary_stage_label,
                    depth=1,
                )
                continue
            if child_addr is None:
                continue
            if child_addr.chain != tx.chain and not self._adapters.has(child_addr.chain):
                self._handle_unregistered_dst_chain(child_addr, tx, source_addr=expanding, depth=1)
                continue
            self._upsert_node(
                address=child_addr,
                depth=1,
                first_seen_tx=self._seed_tx,
                first_seen_at=tx.block.timestamp,
            )

    # ------------------------------------------------------------------
    # Per-address expansion (depth N -> depth N+1)
    # ------------------------------------------------------------------

    async def _expand_frontier(self) -> None:
        while True:
            node = self._frontier.pop()
            if node is None:
                return

            # Round 3 codex P3 fix: skip nodes whose terminal reason was
            # already recorded by a prior path (e.g. a soft-failed unregistered
            # cross-chain destination upserted then immediately marked terminal
            # by ``_handle_unregistered_dst_chain``). Without this guard the
            # frontier expands the address again, issues another adapter call,
            # and records a duplicate ``chain not registered`` expansion error.
            if node.canonical_key in self._terminal_reasons:
                continue

            if node.depth >= self._policy.max_depth:
                self._mark_terminal(node, TerminationReason.MAX_DEPTH)
                continue

            label = await self._fetch_label_cached(node)
            if label is not None and label.kind in self._policy.terminal_labels:
                node = node.model_copy(update={"label": label})
                self._nodes[node.canonical_key] = node
                self._mark_terminal(node, TerminationReason.TERMINAL_LABEL)
                continue
            if label is not None and node.label is None:
                node = node.model_copy(update={"label": label})
                self._nodes[node.canonical_key] = node

            await self._expand_address(node)

    async def _expand_address(self, node: GraphNode) -> None:
        chain = node.address.chain
        try:
            adapter = self._adapters.get(chain)
        except KeyError as exc:
            self._record_expansion_error(node.address, None, str(exc))
            self._mark_terminal(node, TerminationReason.EXPANSION_ERROR)
            return

        if chain not in self._policy.min_value_native:
            raise TracerPolicyError(
                f"TracePolicy.min_value_native missing entry for chain {chain.value} "
                f"reached during expansion of {node.address.value!r}",
                case_id=self._case_id,
                address=node.address,
                tx=self._seed_tx,
            )

        items: list[NormalizedTransaction] = []
        # Round 3 codex P1-1 fix: start the address-history scan AT the seed
        # block instead of from genesis. Long-lived addresses with more
        # transactions BEFORE the seed than ``max_address_txs_per_address``
        # would otherwise fill ``items`` with pre-seed history and hit the
        # cap, dropping all post-seed activity. ``Cursor.start_block`` is
        # the structural slot the EVM adapter (P1-002 / P1-003) honours via
        # Etherscan ``startblock``; the ``forward_walk`` defensive guard in
        # ``_process_tx`` remains as a safety check for adapters that
        # ignore the hint.
        #
        # Round 9 codex P1 fix: ``_seed_block_number`` is a SOURCE-CHAIN
        # height. Block heights are chain-local, so passing it as the
        # ``startblock`` hint to a destination chain's adapter (after a
        # cross-chain hop) is meaningless: the destination chain may have
        # advanced far past the source-chain height (filtering out years of
        # legitimate post-arrival history) or be far behind it (filtering
        # out everything). Only pass the block hint when this address lives
        # on the seed chain. For non-seed chains, omit ``start_block`` and
        # rely on the timestamp filter at ``_process_tx`` (``time_window``
        # and ``forward_walk``) to prune pre-arrival history. Performance
        # note: real Etherscan/Arbiscan calls without ``startblock`` scan
        # from genesis, but the trace is bounded by
        # ``max_address_txs_per_address`` (default 200) and the time window;
        # Phase 2 should derive the destination block at the cross-chain
        # arrival timestamp for a tighter lower bound.
        cursor: Cursor | None
        if chain == self._seed_tx.chain:
            cursor = Cursor(start_block=self._seed_block_number)
        else:
            cursor = None
        # Round 12 codex P2-1 fix: filter the seed TX hash BEFORE applying the
        # per-address cap. ``adapter.get_address_txs`` returns the seed itself
        # when the expanding address is also the seed sender (Etherscan
        # ``txlist`` does not exclude it); ``_expand_seed`` has already
        # processed it, so re-counting it toward
        # ``max_address_txs_per_address`` consumes a slot that should have
        # gone to a real post-seed TX. Pre-fix sequence with cap=1: page 1
        # returned ``[seed, post_seed_tx_a]``, ``items`` reached length 2 →
        # cap-break before fetching page 2, then the seed-hash filter ran
        # AFTER and dropped the seed → ``items=[post_seed_tx_a]`` (one TX
        # admitted, but the post-seed TX from page 2 was never fetched). With
        # higher caps the bug only surfaces when the seed sits within the
        # first N fetched rows; a low cap makes the regression deterministic.
        #
        # Round 13 codex P1 fix: also pre-filter PRE-ARRIVAL history before
        # counting toward the cap. The same cap-consumption argument applies
        # to TXs that ``_process_tx`` would later reject as ``forward_walk``
        # (seed-chain: ``tx.block.number < self._seed_block_number``;
        # cross-chain: ``tx.block.timestamp < node.first_seen_at``). For a
        # cross-chain destination expanded with ``cursor=None``, the EVM
        # adapter walks from block 0 in ascending order — if the destination
        # has more than ``max_address_txs_per_address`` worth of pre-arrival
        # rows, the loop breaks before any post-arrival TX is fetched, and
        # the address terminates as ``NO_OUTGOING`` even though legitimate
        # post-arrival activity exists. Apply the same time / block lower
        # bound that ``_process_tx``'s ``forward_walk`` branch enforces, so
        # the cap reflects only the relevant time range.
        seed_hash = self._seed_tx.tx_hash
        # Round 14 codex P1 fix: align the cap-pre-filter with the per-TX
        # ``forward_walk`` check above. Same-chain non-seed nodes (depth >= 1)
        # need the timestamp lower bound IN ADDITION to the block-number
        # bound so that pre-arrival yet post-seed history (TXs in
        # ``[seed_block, first_seen_at)``) does not consume cap slots
        # before the per-TX filter has a chance to drop them. Seed parties
        # (depth 0) keep ``lower_bound_timestamp = None`` so they can
        # legitimately re-spend from the seed timestamp onwards.
        if chain == self._seed_tx.chain:
            lower_bound_block: int | None = self._seed_block_number
            if node.depth >= 1:
                lower_bound_timestamp: datetime | None = node.first_seen_at
            else:
                lower_bound_timestamp = None
        else:
            lower_bound_block = None
            lower_bound_timestamp = node.first_seen_at
        # Round 15 codex P1-2 fix: also pre-filter POST-window TXs before
        # counting toward the cap. ``_process_tx`` rejects any TX whose
        # ``block.timestamp > seed_cutoff`` as ``time_window``; for adapters
        # that return address history newest-first (notably the Bitcoin
        # ``mempool.space`` live-head pages) those out-of-window rows
        # otherwise consume cap slots BEFORE older in-window TXs are even
        # fetched. Mirroring the per-TX upper bound here keeps the cap
        # reserved for in-window history regardless of adapter ordering.
        #
        # We must preserve the round-8 terminal-reason invariant that an
        # address whose post-cutoff history is entirely INCOMING (e.g.
        # late deposits to the receiver) terminates as ``NO_OUTGOING``,
        # not ``TIME_WINDOW`` — the per-TX path uses the direction filter
        # FIRST so incoming-late TXs never bump the time_window counter.
        # Replicate the cheap direction signal here so the cap pre-filter
        # does not over-promote to ``TIME_WINDOW``. We only use signals
        # that don't require an adapter call:
        #   * EVM: ``tx.from_addr == node.address`` → clearly outgoing.
        #     ``from_addr != node.address`` may still be a contract-call
        #     payout pattern (round 12 internal-only branch); leave those
        #     ambiguous TXs in ``items`` so the per-TX path can decide
        #     after fetching internal txs.
        #   * BTC: ``vin[0] == node.address`` OR no transfer.to_addr equals
        #     ``node.address`` (i.e., not exclusively a vout) — mirrors the
        #     round-11 BTC heuristic in ``_process_tx`` without the
        #     niche change-to-self false-reject (the
        #     ``_clearly_outgoing_no_io`` flag is conservative on BTC: when
        #     ambiguous, treat as outgoing for TIME_WINDOW counting which
        #     matches the per-TX behaviour).
        # BTC-SPINE BTC-1 Edit W1: the cap pre-filter's post-window upper bound
        # uses the per-address EFFECTIVE window (extended for the curated hub,
        # else the global window). Empty window-set → global window → identical.
        upper_bound_timestamp = self._seed_block_timestamp + self._effective_time_window(
            node.address
        )
        pre_filtered_post_window_outgoing = 0
        # P3.2-007.1 value-floor cap fix: the first ``max_address_txs_per_address``
        # in-window rows by block form the bounded prefix -- each consumes a slot
        # (significant or not), mirroring the pre-fix ascending cap. Rows that
        # clear the per-chain ``cap_significance_native`` floor AND fall PAST that
        # prefix are additionally force-admitted on top, so the admitted set is a
        # strict SUPERSET of the pre-fix first-N head and the high-value tail past
        # the cap is never silently truncated. Tracked across pages.
        non_significant_admitted = 0
        # scan #13 TRM-1 (codex R2 P2): a running count of ZERO-native calldata
        # rows force-admitted PAST the cap via the hidden-value arm. Bounded by
        # ``max_address_txs_per_address`` (see the admission block below) so a
        # busy address flooded with zero-native contract calls cannot escape the
        # per-address cap — the native-floor arm stays unbounded (self-limiting).
        hidden_value_admitted = 0
        # scan #15 Lens A: a running count of BTC rows force-admitted PAST the
        # cap via the per-vout qualifying-output arm (``_carries_qualifying_btc_
        # output``). Bounded by ``max_address_txs_per_address`` (see the
        # admission block below) — the per-vout edge floor (0.01 BTC) is LOW, so
        # an unbounded arm would let a busy peel address escape the cap. Mutually
        # exclusive with ``hidden_value_admitted`` (EVM-only), so at most one of
        # the two increments per expansion (an address expansion is single-chain).
        btc_qualifying_admitted = 0
        # The floor for THIS expansion's chain (fixed per address). When the
        # floor is absent for the chain (empty mapping / chain omitted), NO
        # row can ever be significant, so the cap reverts to the EXACT pre-fix
        # pagination bound (codex P3.2-007.1 R3 P2 — an explicit opt-out must
        # keep pre-fix cap behaviour, and a later-page adapter error must not
        # discard the already-capped rows). When the floor IS active the walk
        # scans the whole in-window region so EVERY above-floor row is
        # force-admitted regardless of page size (codex R2 P2).
        # PB-003.1: a curated deep-expand sink gets a lower native floor on the
        # cap force-admit gate so its 10-100 ETH onward rows survive the cap of
        # 5 via the unbounded native-floor arm. Falls back to the global floor
        # for every non-deep address (empty set → byte-identical).
        #
        # This gate is ADDRESS-level (keyed on ``node.address``) per the frozen
        # WBS Edit A, so the lower floor also admits the sink's INBOUND ≥floor
        # rows. Those rows are direction-rejected in ``_process_tx`` (no edge),
        # and the PB-003 capture is any-direction (WBS §2.2 admits value ≥ floor
        # in EITHER direction, with internals) so the re-trace never MISSes →
        # no spurious expansion error and the graph is unchanged. The net effect
        # is redundant processing of a few inbound rows, an EFFICIENCY concern
        # only; row-level cap source-gating (outbound-only) is a possible
        # PB-003.4 optimization, not a correctness fix (deferred to the architect
        # since it changes the WBS-specified address-level admission semantics).
        _deep = self._deep_floor(chain, node.address)
        chain_significance_floor = (
            _deep if _deep is not None else self._policy.cap_significance_native.get(chain)
        )
        floor_active = chain_significance_floor is not None
        # BTC-SPINE BTC-1 Edit C1: the per-address max-tx cap for THIS expansion
        # (raised for a curated BTC L2 payout, else the global cap). Computed
        # once here — keyed on the single expanding ``node.address`` — and used
        # at every cap gate below. Empty cap-set → global cap → byte-identical.
        effective_cap = self._effective_cap(node.address)
        # Round 37 codex P2-2 fix: bound pagination on ascending-order
        # adapters once we've passed ``upper_bound_timestamp``. The
        # round-19 P1 fix removed the round-16 first-page early-exit
        # because mempool.space (BTC) returns DESCENDING pages and a
        # first-page-all-post-window heuristic cut off legitimate older
        # in-window TXs on subsequent pages. The smarter signal here:
        # AFTER we've accepted (or even encountered) any in-window TX,
        # a page that is ENTIRELY post-window means the adapter is
        # ascending (post-window items come after in-window) and every
        # subsequent page will also be post-window. Continuing burns
        # rate-limit calls. For DESCENDING adapters this branch never
        # fires because once in-window items are seen, post-window
        # items (which are NEWER than in-window) cannot appear again
        # on any later page. Tracked as an outer-scope flag so per-page
        # bookkeeping can update it after the inner item loop.
        has_seen_in_window = False
        # P3.2-008 (codex re-review) — distinguishes a FIRST-page fetch failure
        # (the address history was never captured / reachable — a genuine
        # EXPANSION_ERROR, the BTC scope-guard frontier) from a LATER-page MISS
        # (the expected ``max_pages=1`` capture boundary for an address whose
        # page 1 WAS fetched). Only the latter preserves the page-1 ``items``.
        at_least_one_page_fetched = False
        try:
            while True:
                self._adapter_calls[chain] = self._adapter_calls.get(chain, 0) + 1
                # P3.2-007.1 (codex R5 P2): once the budget is full, any
                # FURTHER page fetch exists ONLY to collect significant
                # overflow rows (floor-active scan). A failure there (rate
                # limit / cassette miss) MUST NOT discard the already-capped
                # prefix by escalating to EXPANSION_ERROR — pre-fix the cap
                # break stopped before those pages and emitted the prefix.
                # So in the overflow-scan phase, treat a fetch error as a
                # clean stop (keep ``items``); the FIRST-page fetch (budget
                # not yet full) still propagates to the outer handler, exactly
                # like pre-fix.
                if floor_active and non_significant_admitted >= effective_cap:
                    try:
                        page = await adapter.get_address_txs(node.address, cursor)
                    except Exception as exc:
                        # Overflow-scan best-effort: keep the capped prefix
                        # (codex R5 P2 — do NOT escalate to EXPANSION_ERROR /
                        # discard the prefix). Scan #8 EXC-2: but do NOT stay
                        # SILENT either — the outer handler records every
                        # OTHER pagination failure, so a rate-limit hit here
                        # would otherwise truncate exactly the high-value
                        # overflow scan the floor feature exists for with no
                        # operator signal. A WARNING closes that half without
                        # touching graph.json bytes (the record-into-metadata
                        # variant would risk a golden re-bless). ``str(exc)``
                        # is redacted (an adapter error can embed the
                        # Etherscan ``apikey`` — parity with the round-34
                        # abi_fallback log redaction).
                        logger.warning(
                            "overflow_scan.page_error addr=%s: %s",
                            node.address.value,
                            _redact_secrets(str(exc)),
                        )
                        break
                else:
                    page = await adapter.get_address_txs(node.address, cursor)
                # A page was fetched successfully — a later-page MISS is now a
                # capture boundary, not a first-fetch failure (codex re-review).
                at_least_one_page_fetched = True
                # Round 19 codex P1: removed the round-16 ASCENDING-only
                # early-exit heuristic. The original "if a page crossed
                # ``upper_bound_timestamp`` and admitted zero in-window
                # rows, break" rule was direction-naive: for newest-
                # first adapters (notably mempool.space, which documents
                # descending ordering) the FIRST page may contain only
                # post-window TXs while older in-window TXs follow on
                # subsequent pages. The heuristic stopped the scan
                # after the first page and silently dropped those valid
                # in-window rows. The pagination loop now relies solely
                # on ``has_more`` / ``next_cursor`` (adapter contract)
                # and ``max_address_txs_per_address`` (policy cap) to
                # bound the walk. Ascending adapters with long
                # post-window tails pay a small adapter-call cost for
                # correctness — acceptable because the cap and the
                # adapter's own pagination terminator already keep the
                # walk bounded. See ``Round 19 codex P1`` in
                # ``_workspace/P1-014_builder_notes.md``.
                #
                # Filter the seed AND pre-arrival rows BEFORE counting toward
                # the cap so they do not consume slots.
                # Round 37 codex P2-2 ascending-detection counters: track
                # how many TXs in this page were in-window vs post-window
                # (excluding seed/pre-arrival rows that the adapter is
                # also expected to return). After the loop, if we've
                # ever seen an in-window TX (``has_seen_in_window``) AND
                # this page contributed ZERO in-window items AND at
                # least one post-window item, the adapter is ascending
                # and every later page will also be post-window.
                page_in_window_count = 0
                page_post_window_count = 0
                # P3.2-007.1 (codex R4 P2): count pre-arrival rows so the
                # active-floor scan can early-exit on a descending adapter
                # once it has moved entirely below the lower bound (every
                # such row is pre-arrival/filtered and can never be a
                # significant in-window row — see the lower-bound exit below).
                page_pre_arrival_count = 0
                for tx in page.items:
                    if tx.tx_hash == seed_hash:
                        continue
                    if lower_bound_block is not None and tx.block.number < lower_bound_block:
                        page_pre_arrival_count += 1
                        continue
                    if (
                        lower_bound_timestamp is not None
                        and tx.block.timestamp < lower_bound_timestamp
                    ):
                        page_pre_arrival_count += 1
                        continue
                    if tx.block.timestamp > upper_bound_timestamp:
                        page_post_window_count += 1
                        # Round 15 P1-2: post-window TXs are rejected
                        # per-TX at ``_process_tx`` (``time_window``);
                        # skipping them here too prevents newest-first
                        # adapters from filling the cap with rows that
                        # would later be rejected, which would starve
                        # the in-window history of cap slots. Track
                        # whether the post-window TX would have been
                        # outgoing (i.e. would have bumped the per-TX
                        # ``time_window_violations`` counter) so the
                        # terminal-reason precedence below can promote
                        # the address to ``TIME_WINDOW`` only when at
                        # least one would-be-outgoing post-window TX was
                        # seen — incoming-late TXs continue to land on
                        # ``NO_OUTGOING`` exactly like the per-TX path.
                        #
                        # Round 22 codex P2-1 fix: mirror the round-5/6
                        # reverted-EVM-tx filter in ``_process_tx``. A
                        # reverted EVM TX (``status == 0``) moves no
                        # value at any layer — it is rejected as
                        # ``reverted`` (NOT ``time_window``) by the
                        # per-TX path before the time-window check
                        # runs, so the cap pre-filter must NOT promote
                        # post-window reverted TXs to TIME_WINDOW
                        # either. Without this guard, an address whose
                        # only post-window history is failed
                        # (reverted) outgoing attempts is wrongly
                        # promoted from NO_OUTGOING to TIME_WINDOW. BTC
                        # has ``status is None`` so the EVM-only
                        # ``status == 0`` check is a no-op there; the
                        # ``tx.chain.is_evm`` gate is defence-in-depth.
                        #
                        # Round 24 codex P2-1 fix: when the cheap
                        # direction probe ``_is_clearly_outgoing_no_io``
                        # returns ``False`` for an EVM TX, the TX is
                        # ambiguous — top-level incoming
                        # (``tx.from_addr != node.address``) on EVM may
                        # still carry a contract-as-sender internal
                        # payout that the per-TX path would surface via
                        # ``get_internal_txs`` (the round-12 P2-3
                        # ``TestEvmIncomingCallWithOutgoingInternalTx``
                        # behaviour). Pre-fix the ambiguous post-window
                        # branch unconditionally ``continue``d, so the
                        # TX never reached ``_process_tx`` AND never
                        # bumped ``pre_filtered_post_window_outgoing``
                        # — an EVM contract node whose only post-window
                        # history is a contract-payout pattern would be
                        # mis-classified as ``NO_OUTGOING`` instead of
                        # ``TIME_WINDOW``. We pay no extra adapter call
                        # at the pre-filter (the cap-pre-filter MUST
                        # stay IO-free) and instead conservatively
                        # treat ambiguous post-window EVM TXs as
                        # outgoing for the counter — Option B in the
                        # round-24 review notes. The reverted-tx guard
                        # still wins (a reverted TX moves no value at
                        # any layer, so it is excluded regardless of
                        # the direction probe). BTC remains unaffected:
                        # BTC has no ``txlistinternal`` analogue, so
                        # the cheap probe IS the full direction filter
                        # there — ambiguous BTC post-window TXs stay
                        # incoming-late, exactly like the round-15
                        # ``test_only_incoming_post_window_still_terminates_as_no_outgoing``
                        # behaviour.
                        is_reverted_evm = tx.chain.is_evm and tx.status == 0
                        # P3.2-007.1 (codex R3b P2): once the per-address budget
                        # is full the walk is in the floor-active OVERFLOW SCAN,
                        # whose ONLY purpose is to collect significant overflow
                        # rows. A non-admitted post-window row fetched there MUST
                        # NOT bump the terminal-reason counter — otherwise
                        # enabling ``cap_significance_native`` would flip a node's
                        # terminal reason (e.g. VALUE_SUB_THRESHOLD -> TIME_WINDOW)
                        # versus the floor-inactive walk, which stops at the cap
                        # and never sees this row. ``page_post_window_count`` (the
                        # ascending-adapter early-exit signal) is still
                        # incremented above so the scan still terminates.
                        budget_full = non_significant_admitted >= effective_cap
                        if not is_reverted_evm and not budget_full:
                            if self._is_clearly_outgoing_no_io(tx, node.address):
                                pre_filtered_post_window_outgoing += 1
                            elif tx.chain.is_evm:
                                # Ambiguous post-window EVM TX: top-level
                                # incoming may hide a contract-as-sender
                                # internal payout. Without the adapter
                                # call we cannot tell, so count it as
                                # outgoing for time-window classification.
                                pre_filtered_post_window_outgoing += 1
                        continue
                    page_in_window_count += 1
                    # Round 38 codex P2 fix: skip CLEARLY-INCOMING TXs at
                    # the cap pre-filter. Pre-fix: incoming-only rows
                    # (e.g. an exchange-deposit address receiving 200
                    # incoming transfers before any outgoing TX) filled
                    # the per-address cap, ``_process_tx`` rejected them
                    # all as ``direction``, and any later outgoing TX
                    # was never fetched — the node was falsely terminal
                    # as ``NO_OUTGOING`` despite real outgoing flow on
                    # subsequent pages. Skipping clearly-incoming rows
                    # keeps the cap available for outgoing / ambiguous
                    # TXs (the round-12 P2-3 contract-as-sender pattern
                    # is preserved because ambiguous EVM TXs return
                    # ``False`` from this helper). The skipped rows
                    # are still legitimately incoming history — they
                    # just don't drive the BFS expansion this address.
                    if self._is_clearly_incoming_no_io(tx, node.address):
                        continue
                    # P3.2-007.1 value-floor cap fix: the per-address cap
                    # truncates a node's in-window history ASCENDING by
                    # block, which silently drops the high-value TAIL
                    # (E7's 585/570/552/462 ETH consolidation sends + the
                    # E25/E31 legs cluster late in the window). The first-N
                    # rows by block form the bounded prefix (every row counts
                    # toward the cap); any in-window row that clears the
                    # per-chain ``cap_significance_native`` floor AND falls PAST
                    # that prefix is additionally FORCE-ADMITTED on top. The
                    # admitted set stays a strict SUPERSET (zero removals) of the
                    # pre-fix first-N head, so risk-1 stages remain byte-stable
                    # while the largest movements past the cap are never lost.
                    # The floor
                    # is high (100 ETH / 10 BTC) so the cap still bounds
                    # the common-case fan-out. Significant rows are scanned
                    # to the end of every page (no mid-page break) so a big
                    # send past the cap is never missed.
                    # scan #13 TRM-1: the native-value floor only sees the
                    # top-level ``value_native``. An ERC-20 laundering leg
                    # (USDT/USDC/DAI transfer — the dominant DPRK vehicle) or a
                    # contract-withdraw / WETH-unwrap payout rides in a tx whose
                    # ``value_native.raw == 0``; its economic value surfaces
                    # LATER, per admitted tx, via ``_synthesize_erc20_transfers``
                    # (receipt logs) or ``get_internal_txs``. A high-value
                    # token/internal leg clustering past the cap would therefore
                    # be dropped BEFORE its logs are ever fetched. Force-admit a
                    # ZERO-native row that carries contract calldata (the hidden-
                    # value candidate) so the true value determination is deferred
                    # to ``_process_tx``. Gating on ``value_native.raw == 0`` (not
                    # merely below-floor) means a below-floor NON-zero native
                    # contract call stays dropped like a plain send — the widened
                    # admission can never leak a below-floor native edge into the
                    # graph (codex TRM-1 R1 P2). Clearly-incoming no-IO rows were
                    # already skipped above, so this only widens outgoing /
                    # ambiguous admission — golden-safe (the frozen goldens have
                    # zero such rows past the cap).
                    over_native_floor = (
                        chain_significance_floor is not None
                        and tx.value_native.raw >= chain_significance_floor
                    )
                    # scan #13 TRM-1 (codex R2 P2): the hidden-value arm force-
                    # admits a zero-native calldata candidate past the cap ONLY
                    # while a BOUNDED probe budget remains. Zero-native contract
                    # calls (approvals, no-op calls, swaps with no relevant logs)
                    # are ubiquitous on EVM, so an unbounded hidden-value arm would
                    # let a busy address escape the per-address cap entirely (one
                    # receipt/internal fetch per admitted row). Capping the probes
                    # at ``max_address_txs_per_address`` keeps the admitted set at
                    # most 2x the configured cap while still recovering the
                    # earliest (ascending-by-block) hidden-value legs. The
                    # native-floor arm stays UNBOUNDED — the high floor
                    # (100 ETH / 10 BTC) is self-limiting.
                    hidden_value_candidate = (
                        chain_significance_floor is not None
                        and not over_native_floor
                        and _carries_hidden_value(tx)
                        and hidden_value_admitted < effective_cap
                    )
                    # scan #15 Lens A: BTC per-vout qualifying-output arm. The
                    # ``over_native_floor`` check above compares the SUM of a BTC
                    # tx's vouts to the (high) 10-BTC floor, so an edge-worthy
                    # [0.01, 10) BTC peel leg — whose SUM is below the floor but
                    # whose single output clears the per-vout edge floor — is
                    # missed and truncated past the cap. Force-admit it on a
                    # BOUNDED probe budget (the per-vout floor is LOW, so an
                    # unbounded arm would let a busy peel address escape the
                    # cap). EVM returns False from the predicate (its recoverable
                    # value is calldata, handled by the hidden-value arm above),
                    # so ``hidden_value_candidate`` and ``btc_qualifying_candidate``
                    # are mutually exclusive — at most one increments below.
                    btc_qualifying_candidate = (
                        chain_significance_floor is not None
                        and not over_native_floor
                        and _carries_qualifying_btc_output(
                            tx, self._policy.min_value_native.get(tx.chain, 0), node.address
                        )
                        and btc_qualifying_admitted < effective_cap
                    )
                    if non_significant_admitted >= effective_cap:
                        # Budget full: ONLY significant overflow is admitted.
                        # When the floor is active the walk continues so that
                        # every in-window row above the floor is force-admitted
                        # regardless of page size or where it clusters (codex
                        # P3.2-007.1 R2 P2 — "ANY in-window significant row",
                        # not a page-size-dependent prefix). The scan stays
                        # BOUNDED by the time-window terminators below (the
                        # post-window upper-bound skip + the ascending-adapter
                        # early-exit). When the floor is INACTIVE the inner
                        # break below stops the walk identically to pre-fix.
                        if (
                            not over_native_floor
                            and not hidden_value_candidate
                            and not btc_qualifying_candidate
                        ):
                            continue
                        if hidden_value_candidate:
                            hidden_value_admitted += 1
                        if btc_qualifying_candidate:
                            btc_qualifying_admitted += 1
                    else:
                        non_significant_admitted += 1
                    items.append(tx)
                    # Pre-fix bound restored for the floor-inactive case (codex
                    # R3 P2): when no row on this chain can be significant,
                    # break the inner item loop as soon as the cap is full so
                    # the outer page walk also stops — identical to the
                    # original ``max_address_txs_per_address`` semantics.
                    if not floor_active and non_significant_admitted >= effective_cap:
                        break
                if page_in_window_count > 0:
                    has_seen_in_window = True
                # Floor INACTIVE → restore the exact pre-fix walk terminator:
                # stop paginating once the budget is full (no row past it can
                # ever be admitted). Floor ACTIVE → keep scanning the window
                # for significant overflow (bounded by the window terminators).
                if not floor_active and non_significant_admitted >= effective_cap:
                    break
                if not page.has_more or page.next_cursor is None:
                    break
                # P3.2-008 (codex r6) — once a CoinJoin / batch-mixing tx has
                # been admitted, this BITCOIN address is a TERMINUS (the
                # post-loop ``_btc_tx_fanout`` pre-scan will mark it
                # BRANCHING_LIMIT and drop its children). STOP paginating NOW so
                # a FULL first page (``has_more=True``) does not request an
                # older page whose MISS would set ``EXPANSION_ERROR`` first and
                # PREEMPT the BRANCHING_LIMIT mark (``_mark_terminal`` is
                # setdefault — first-wins). This is NOT the removed first-page
                # heuristic: it fires ONLY when a genuine CoinJoin fanout
                # signature (>= unique-dest threshold) is already present, so a
                # normal address still paginates fully. Mirrors the pre-scan's
                # ``_btc_tx_fanout`` over the items admitted so far.
                btc_fanout_n = self._policy.btc_fanout_terminal
                if (
                    node.address.chain == ChainId.BITCOIN
                    and btc_fanout_n is not None
                    and any(self._btc_tx_fanout(tx, node.address) >= btc_fanout_n for tx in items)
                ):
                    break
                # P3.2-008 (codex re-review) — BTC paginates FULLY like EVM.
                # An earlier first-page-only break (in any gated form) silently
                # truncated valid older outgoing history in live/default traces
                # (post-window, incoming-only, and multi-page-outgoing first
                # pages all leaked). The cassette's ``max_pages=1`` boundary is
                # handled where it belongs — the ``except`` above preserves the
                # collected page-1 ``items`` on a BTC pagination MISS instead of
                # discarding them — so the cassette trace is byte-identical
                # while a live trace walks every in-window page. The window
                # early-exits below still bound the BTC walk by arrival /
                # post-window terminators.
                # Round 37 codex P2-2: ascending-adapter early-exit. See
                # the ``has_seen_in_window`` declaration above for the
                # full rationale. The check fires AFTER the cap and
                # adapter-pagination terminators so the existing
                # bounded-walk semantics are unchanged for the cases
                # they cover.
                if has_seen_in_window and page_in_window_count == 0 and page_post_window_count > 0:
                    break
                # P3.2-007.1 (codex R4 P2): descending-adapter LOWER-bound
                # early-exit, symmetric to the post-window exit above. When
                # the floor is ACTIVE the per-row cap break no longer bounds
                # the walk; on a newest-first (descending) adapter the scan
                # eventually moves entirely below the arrival lower bound,
                # where every row is pre-arrival (filtered) and can NEVER be
                # a significant in-window row. Once we have seen in-window
                # history and a page is ALL pre-arrival (zero in-window AND
                # zero post-window), every older page is also pre-arrival, so
                # stop — restoring a bounded walk without dropping any
                # in-window significant row. (Floor-inactive already stopped
                # at the cap break above; ascending adapters hit the
                # post-window exit; this covers the descending active-floor
                # tail codex R4 flagged.)
                if (
                    floor_active
                    and has_seen_in_window
                    and page_in_window_count == 0
                    and page_post_window_count == 0
                    and page_pre_arrival_count > 0
                ):
                    break
                cursor = page.next_cursor
        except Exception as exc:
            # A pagination failure in the ADMISSION phase (budget not yet
            # full) is recorded + flagged EXPANSION_ERROR so an incomplete
            # walk (cassette ``max_pages=1`` boundary OR a live 429 / 5xx /
            # validation error) is never silently swallowed (codex re-review).
            # The ONLY difference for BTC is whether the already-collected
            # page-1 ``items`` are preserved. (The floor-active OVERFLOW-scan
            # arm above deliberately keeps its capped prefix instead of
            # flagging EXPANSION_ERROR — codex R5 P2 — but still emits a
            # WARNING so the failure is not silent: scan #8 EXC-2.)
            self._record_expansion_error(node.address, None, str(exc))
            self._mark_terminal(node, TerminationReason.EXPANSION_ERROR)
            if node.address.chain.is_evm or not at_least_one_page_fetched:
                # EVM (block-range, fully captured) and BTC FIRST-page failures
                # (the history was never fetched / reachable — the scope-guard
                # frontier) have no page-1 work to keep: discard and terminate,
                # exactly as before.
                return
            # BTC, page 1 ALREADY fetched: an OLDER-page failure leaves the
            # node flagged EXPANSION_ERROR (codex r5 — a live error is surfaced,
            # not hidden) but PRESERVES the real page-1 outgoing history by
            # falling through to process the collected ``items`` instead of
            # discarding them (codex r2/r4 — the old EVM-style discard truncated
            # valid BTC traces). A live BTC trace that succeeds on every page
            # never reaches here and paginates fully like EVM.

        # Defensive trim — the loop already enforces the cap, but a future
        # adapter that returns more items than ``page_size`` declares would
        # otherwise leak past the policy bound.
        #
        # P3.2-007.1 value-floor cap fix: the trim MUST never evict a
        # significant row (one that cleared the per-chain
        # ``cap_significance_native`` floor). Split ``items`` into the head
        # (first ``cap`` rows, mirroring the bounded admission) plus the
        # significant rows that fell past it, and concatenate — the result
        # is a strict superset of the pre-fix first-``cap`` head, so the
        # high-value tail survives the defensive bound.
        # BTC-SPINE BTC-1 Edit C1: the defensive trim mirrors the admission cap,
        # so it uses the same per-address ``effective_cap`` (raised for a curated
        # payout) — otherwise it would silently evict onward rows the raised cap
        # just admitted. Empty cap-set → global cap → byte-identical.
        cap = effective_cap
        head = items[:cap]
        head_ids = {id(t) for t in head}
        # scan #13 TRM-1: mirror the admission predicate's hidden-value arm so
        # the trim never evicts a zero-native calldata overflow row the loop just
        # force-admitted (a native-only predicate here would silently undo the
        # widened admission for any hidden token/internal leg past the cap).
        # scan #15 Lens A: likewise mirror the BTC per-vout qualifying-output arm
        # so a force-admitted [0.01, 10) BTC peel leg (SUM below the floor)
        # survives the trim instead of being silently evicted. The loop already
        # bounded how many such rows entered ``items``, so keeping every match
        # here cannot exceed the probe budget.
        # PB-003.1: the defensive trim mirrors the admission predicate, so it
        # MUST honour the deep-expand floor for a curated sink — otherwise it
        # would silently EVICT the onward rows Edit A just force-admitted. Keyed
        # on the EXPANDING address (single-chain per expansion, ``t.chain ==
        # chain``), exactly like the cap gate above. Empty set → falls back to
        # the global ``cap_significance_native`` floor → byte-identical.
        _deep_cap = self._deep_floor(chain, node.address)
        cap_floor = (
            _deep_cap if _deep_cap is not None else self._policy.cap_significance_native.get(chain)
        )
        overflow_significant = [
            t
            for t in items[cap:]
            if cap_floor is not None
            and (
                t.value_native.raw >= cap_floor
                or _carries_hidden_value(t)
                or _carries_qualifying_btc_output(
                    t, self._policy.min_value_native.get(t.chain, 0), node.address
                )
            )
            and id(t) not in head_ids
        ]
        items = head + overflow_significant

        if not items:
            # Round 15 codex P1-2 fix: if at least one would-be-outgoing
            # row was pre-filtered as post-window, the address still HAD
            # outgoing history — it is just outside the trace's time
            # horizon. The pre-fix per-TX path counted those as
            # ``time_window_violations`` and promoted the address to
            # ``TIME_WINDOW``; keep that semantics alive even though the
            # TXs never reach ``_process_tx``. Incoming-late TXs (which
            # the per-TX direction filter rejects as ``direction``, not
            # ``time_window``) deliberately do NOT contribute to this
            # counter — the address falls through to the ``NO_OUTGOING``
            # branch exactly like the round-8 P2-2 behaviour.
            if pre_filtered_post_window_outgoing > 0:
                self._mark_terminal(node, TerminationReason.TIME_WINDOW)
                return
            self._mark_terminal(node, TerminationReason.NO_OUTGOING)
            return

        # P3.2-008 (OPTION A, codex re-review) — BTC high-fanout CoinJoin
        # terminal bound, applied ADDRESS-LEVEL and ORDER-INDEPENDENTLY. A
        # BITCOIN address that authored ANY tx fanning out to >=
        # ``btc_fanout_terminal`` distinct above-threshold vout recipients is a
        # CoinJoin / batch-mixing terminus (the PDF model stops here — "추적
        # 종료"). mempool.space returns history NEWEST-FIRST, so a per-tx bound
        # would let a tx newer than the CoinJoin row enqueue its children
        # before the bound fired. Pre-scanning the whole (already window-/cap-
        # filtered) ``items`` BEFORE emitting any edge makes the mixing address
        # terminal regardless of tx order, dropping the entire post-CoinJoin
        # spray instead of wandering into the mixed funds. ``_btc_tx_fanout``
        # mirrors ``_derive_transfer_edge_pairs``'s BTC vout filtering so the
        # signature agrees with the edge derivation. Gated strictly on
        # ChainId.BITCOIN (Stage 1-7 EVM byte-stable); disabled when
        # ``btc_fanout_terminal is None`` (the global default).
        btc_fanout_terminal = self._policy.btc_fanout_terminal
        if (
            node.address.chain == ChainId.BITCOIN
            and btc_fanout_terminal is not None
            and any(self._btc_tx_fanout(tx, node.address) >= btc_fanout_terminal for tx in items)
        ):
            self._mark_terminal(node, TerminationReason.BRANCHING_LIMIT)
            return

        edges_emitted_for_node = 0
        time_window_violations = 0
        sub_threshold_violations = 0
        branching_hit = False
        accepted_txs = 0
        expandable_children_for_node = 0
        # Round 8 codex P2-1 fix: track whether ANY TX recorded an expansion
        # error (decoder ``decode()`` raised, ``get_logs`` failed,
        # ``get_internal_txs`` failed) during this address's expansion. If
        # the address ends up with zero accepted TXs AND zero expandable
        # children, the EXPANSION_ERROR terminal reason takes precedence
        # over VALUE_SUB_THRESHOLD / TIME_WINDOW because the "no edges"
        # outcome was caused by an adapter/decoder failure rather than a
        # legitimate filter rejection.
        had_any_expansion_error = False

        for tx in items:
            outcome = await self._process_tx(node, tx)
            if outcome.get("had_expansion_error", False):
                had_any_expansion_error = True
            if outcome["accepted"]:
                accepted_txs += 1
                edges_emitted_for_node += outcome["edges_emitted"]
                expandable_children_for_node += outcome["expandable_children"]
                if outcome["branching_hit"]:
                    branching_hit = True
            else:
                if outcome["reason"] == "time_window":
                    time_window_violations += 1
                elif outcome["reason"] == "value":
                    sub_threshold_violations += 1

        # Round 8 codex P2-1 fix: terminal-reason precedence order
        # (highest priority first):
        #   1. BRANCHING_LIMIT — branching guard fired AND no expandable
        #      children were enqueued (handled below, after the zero-accepted
        #      branch).
        #   2. EXPANSION_ERROR — adapter/decoder failure recorded during
        #      this address's expansion AND no expandable children were
        #      enqueued (so the parent legitimately has nothing more to
        #      walk and the failure is the proximate cause).
        #   3. TIME_WINDOW — only sub-window TXs found.
        #   4. VALUE_SUB_THRESHOLD — only sub-threshold TXs found.
        #   5. NO_OUTGOING — empty page.
        #
        # Pre-fix: a zero-value bridge/DeFi TX whose decoder raised emitted
        # zero edges, was rejected as ``reason="value"``, and the address
        # was mis-classified as VALUE_SUB_THRESHOLD even though the real
        # cause was an EXPANSION_ERROR already recorded against the TX.
        #
        # Round 16 codex P2-2 fix: ``pre_filtered_post_window_outgoing``
        # tracks would-be-outgoing TXs the cap pre-filter dropped because
        # they were beyond ``upper_bound_timestamp``. Sum it with the
        # per-TX ``time_window_violations`` counter so that an address
        # whose only post-window outgoing TXs were pre-filtered (and whose
        # remaining in-window TXs were rejected for unrelated reasons —
        # e.g. reverted, sub-threshold) still terminates as
        # ``TIME_WINDOW`` rather than the misleading ``NO_OUTGOING``.
        # Pre-fix: the round-15 counter was only consulted when ``items``
        # was empty; a single in-window rejection was enough to skip that
        # branch and lose the ``TIME_WINDOW`` signal.
        total_time_window_violations = time_window_violations + pre_filtered_post_window_outgoing
        if accepted_txs == 0 and expandable_children_for_node == 0 and had_any_expansion_error:
            self._mark_terminal(node, TerminationReason.EXPANSION_ERROR)
            return
        # Round 19 codex P2 fix: ``TIME_WINDOW`` MUST win over
        # ``VALUE_SUB_THRESHOLD`` when both signals are non-zero. The
        # pre-fix predicate added ``and sub_threshold_violations == 0``,
        # which caused the TIME_WINDOW branch to be skipped whenever an
        # in-window sub-threshold TX coexisted with any post-window
        # outgoing TX (per-TX ``time_window_violations`` or pre-filtered
        # ``pre_filtered_post_window_outgoing``). The next branch then
        # mis-classified the address as ``VALUE_SUB_THRESHOLD``,
        # contradicting the precedence ladder documented in the round-8
        # comment above (TIME_WINDOW priority 3, VALUE_SUB_THRESHOLD
        # priority 4). Drop the spurious clause so the natural ordering
        # of these two ``if`` blocks expresses the precedence directly.
        if accepted_txs == 0 and total_time_window_violations > 0:
            self._mark_terminal(node, TerminationReason.TIME_WINDOW)
            return
        if accepted_txs == 0 and sub_threshold_violations > 0:
            self._mark_terminal(node, TerminationReason.VALUE_SUB_THRESHOLD)
            return
        if accepted_txs == 0:
            self._mark_terminal(node, TerminationReason.NO_OUTGOING)
            return
        # Round 6 codex P2-2 fix: per WBS behaviour 75 / DoD-18 step 4 —
        # ``BRANCHING_LIMIT`` fires when the branching guard tripped on at
        # least one TX AND no expandable transfers remained after pruning.
        # The pre-fix predicate counted ``edges_emitted_for_node``, which
        # included self-loop edges (DeFi self-loops, ABRIDGED markers) that
        # do NOT enqueue any new node. As a result, a TX whose only kept
        # pairs were self-loops left the parent non-terminal even though no
        # frontier work was generated. Counting ``expandable_children``
        # (pairs whose child_addr was non-null AND whose chain was reachable
        # — i.e., the ones that actually upserted a new graph node) makes
        # the predicate match the "no expandable transfers remained" wording
        # in the WBS exactly.
        if branching_hit and expandable_children_for_node == 0:
            self._mark_terminal(node, TerminationReason.BRANCHING_LIMIT)
            return

    async def _process_tx(
        self,
        node: GraphNode,
        tx: NormalizedTransaction,
    ) -> dict[str, Any]:
        chain = node.address.chain

        # Round 8 codex P2-2 fix: apply the direction filter BEFORE the
        # time-window filter. ``adapter.get_address_txs`` (Etherscan
        # ``txlist``) returns BOTH incoming and outgoing TXs touching the
        # address; only outgoing TXs (``from_addr == node.address``) are
        # relevant for forward-walk expansion. Pre-fix: an address whose
        # only history was incoming TXs after the seed cutoff hit the
        # time-window branch first, mis-classifying the parent as
        # ``TIME_WINDOW`` even though there were no outgoing TXs at all
        # (the correct terminal reason is ``NO_OUTGOING``). The semantic
        # ordering — "is this even a TX I should expand?" must precede
        # "is this TX inside my time window?" — keeps the per-rejection
        # counters honest.
        #
        # Round 11 codex P1 fix: BTC's UTXO model means a TX has multiple
        # inputs but :class:`NormalizedTransaction.from_addr` only carries
        # ``vin[0]`` (per :func:`vca.adapters.btc._mempool._vin_from_addr`'s
        # R-UTXO-COLLAPSE rule — multi-input ``from_addr`` is intentionally
        # lossy). A valid multi-input spend where the expanding address is
        # ``vin[1+]`` would be rejected as ``direction`` even though it's
        # outgoing. ``mempool.space``'s ``/address/{addr}/txs`` endpoint
        # returns every TX where the address appears as ANY vin OR ANY vout
        # — so for BTC the heuristic is: accept unless the address is
        # exclusively a vout (in which case the TX is incoming).
        #
        # Detection: the BTC adapter exposes every vout in ``tx.transfers``
        # (and ``tx.to_addr`` is just ``transfers[0].to_addr`` — see
        # :func:`vca.adapters.btc._mempool._vout_to_addr`). If the expanding
        # address is ``tx.from_addr`` (vin[0] match), it's outgoing —
        # accept. Otherwise, if the address appears as ``to_addr`` of any
        # transfer, treat the TX as incoming and reject. Otherwise the
        # address must be a hidden ``vin[1+]`` (the only remaining way for
        # ``get_address_txs`` to have surfaced it), so accept.
        #
        # Trade-off: a multi-input BTC spend that ALSO has the expanding
        # address as a change-output vout collapses both signals (vin[1+]
        # AND vout) — under this rule we'd reject as ``direction``. That's
        # an accepted false-negative; the alternative (always-accept) would
        # invent fake outgoing edges from purely-incoming TXs because
        # :meth:`_derive_transfer_edge_pairs` uses ``expanding_address`` as
        # the implicit source for any vout whose ``transfer.from_addr is
        # None``. False-rejecting a niche change-to-self pattern is
        # strictly safer than fabricating flow.
        if chain == ChainId.BITCOIN:
            node_key = _addr_key(node.address)
            if tx.from_addr is not None and _addr_key(tx.from_addr) == node_key:
                # Vin[0] match — clearly outgoing.
                pass
            elif any(
                t.to_addr is not None and _addr_key(t.to_addr) == node_key for t in tx.transfers
            ):
                # Address appears as a vout (recipient) and is not vin[0].
                # Treat as incoming — see trade-off comment above.
                return _rejected("direction")
            # else: vin[1+] in a multi-input spend — accept and let
            # ``_derive_transfer_edge_pairs`` use ``expanding_address`` as
            # the implicit source.
        # Round 21 codex P2 fix: reject reverted EVM TXs BEFORE the round-12
        # internal-tx probe. A reverted EVM TX (``tx.status == 0``) moves no
        # value at any layer — top-level OR internal (the entire call frame
        # unwinds). Probing ``get_internal_txs`` for such a TX is wasted work
        # at best, and actively harmful when the optional internal-trace
        # endpoint fails: ``_fetch_internal_txs_for_tx`` records an expansion
        # error and the caller's ``had_expansion_error=True`` flag bubbles
        # the address up to ``EXPANSION_ERROR`` instead of the correct
        # ``NO_OUTGOING`` (when no other accepted edges exist). Pre-fix order:
        # (1) round-12 internal probe → (2) round-5/6 reverted-tx filter, so
        # an incoming reverted TX with a flaky ``txlistinternal`` endpoint
        # mis-classified the contract as ``EXPANSION_ERROR``. Post-fix: the
        # status check fires first for EVM, so reverted TXs are skipped
        # without ever consulting internals — direction-independent. The
        # later (round-5) ``status == 0`` guard at line ~1012 still handles
        # the outgoing-direction path (where the round-12 probe is skipped
        # anyway) and BTC is unaffected (``status is None`` for BTC).
        if tx.chain.is_evm and tx.status == 0:
            return _rejected("reverted")

        # Round 12 codex P2-3 fix: track whether this EVM TX qualifies for
        # "internal-only" emission. When ``tx.from_addr != node.address`` the
        # call is incoming at the top level — but if the contract (the
        # current node) appears as the ``from_addr`` of any successful
        # internal tx with ``value_native > 0``, the TX is actually a
        # contract-withdrawal / payout pattern (e.g. user → contract.claim()
        # → contract → user). Pre-fix: the direction check rejected such
        # TXs outright, dropping the outgoing internal value movement that
        # ``get_internal_txs`` would have surfaced. We accept the TX but
        # take a restricted code path that emits ONLY internal-tx edges —
        # decoders + top-level transfer derivation would otherwise fabricate
        # phantom incoming-direction flow.
        internal_only_for_evm = False
        prefetched_internal_txs: tuple[NormalizedTransaction, ...] | None = None
        if chain != ChainId.BITCOIN and (
            tx.from_addr is None or _addr_key(tx.from_addr) != _addr_key(node.address)
        ):
            # Direct outbound check failed — peek at internal txs for
            # contract-as-sender activity before rejecting.
            if not tx.chain.is_evm:
                return _rejected("direction")
            prefetched_internal_txs = await self._fetch_internal_txs_for_tx(
                tx=tx,
                expanding_address=node.address,
            )
            # Round 13 codex P2 fix: distinguish "adapter raised" (None) from
            # "adapter returned no actor-as-sender internals" (tuple but no
            # match). ``_fetch_internal_txs_for_tx`` returns ``None`` when
            # the chain isn't EVM, the adapter is missing, or the
            # ``get_internal_txs`` call raised — and in the failure cases
            # the helper has already recorded an expansion error. The chain
            # is guarded above (``if not tx.chain.is_evm``) so a ``None``
            # here is always an adapter / fetch failure. Propagate
            # ``had_expansion_error=True`` so the address-level terminal
            # precedence (round 8 fix) prefers ``EXPANSION_ERROR`` over
            # ``NO_OUTGOING`` when the contract had no other accepted edges.
            # Pre-fix: a contract reached only via inbound calls whose
            # ``get_internal_txs`` failed was marked ``NO_OUTGOING`` even
            # though the tracer never saw the payout surface.
            if prefetched_internal_txs is None:
                return _rejected("direction", had_expansion_error=True)
            if not self._internal_has_actor_as_sender(prefetched_internal_txs, node.address):
                return _rejected("direction")
            internal_only_for_evm = True

        # BTC-SPINE BTC-1 Edit W2: the per-tx window gate uses the same
        # per-address EFFECTIVE window as the W1 pre-filter, keyed on the
        # expanding ``node.address`` (the hub gets its extended window here too,
        # so its post-window spends are not re-rejected). Empty window-set →
        # global window → byte-identical.
        seed_cutoff = self._seed_block_timestamp + self._effective_time_window(node.address)
        if tx.block.timestamp > seed_cutoff:
            return _rejected("time_window")

        # Round 9 codex P1 fix: forward-walk lower bound is chain-local.
        # ``self._seed_block_number`` is meaningful only for TXs on the seed
        # chain. For nodes reached via a cross-chain hop the destination
        # chain has its own block height that bears no relation to the
        # source chain's; comparing them mixes domains. Use the per-chain
        # rule:
        #   * Seed chain: keep the existing block-number guard (preserves
        #     the same-chain regression already covered by
        #     :class:`TestSeedBlockAddressScan` and the ``forward_walk``
        #     defensive check from round 3).
        #   * Cross-chain: enforce ``tx.block.timestamp >= node.first_seen_at``
        #     instead. ``first_seen_at`` was set when the node was
        #     enqueued — for cross-chain destinations that's the source-chain
        #     hop timestamp, i.e. when the value first ARRIVED on the
        #     destination chain. Pre-arrival history on the destination is
        #     filtered out as ``forward_walk`` exactly like the seed-chain
        #     case.
        #
        # Round 14 codex P1 fix: same-chain non-seed nodes ALSO need
        # ``first_seen_at`` filtering. The seed-block-number bound only
        # rejects TXs strictly older than the seed block, but a non-seed
        # node may have unrelated outgoing TXs that occurred AFTER the seed
        # but BEFORE the value arrived at this node (i.e. post-seed yet
        # pre-arrival). Those are not part of the trace — they are spends
        # of unrelated funds the node already held. Pre-fix: an address X
        # that received traced funds at block N+10 but spent unrelated
        # funds at block N+5 would emit a spurious downstream edge from
        # the N+5 TX. Apply the timestamp filter to BOTH chains for non-
        # seed nodes (depth >= 1). Seed parties are at depth 0 and have
        # ``first_seen_at == seed timestamp``, so applying the filter is a
        # natural no-op for them, but the explicit ``depth >= 1`` guard
        # makes the intent unambiguous and preserves the existing
        # ``TestSeedBlockAddressScan`` behaviour where the seed sender
        # legitimately re-spends from the seed timestamp onwards.
        if tx.chain == self._seed_tx.chain:
            if tx.block.number < self._seed_block_number:
                return _rejected("forward_walk")
            if node.depth >= 1 and tx.block.timestamp < node.first_seen_at:
                return _rejected("forward_walk")
        else:
            if tx.block.timestamp < node.first_seen_at:
                return _rejected("forward_walk")

        # Round 5 codex P2-1 fix: skip reverted EVM transactions before they
        # reach the decoder/transfer pipeline. ``normalize_account_tx``
        # encodes Etherscan ``txreceipt_status="0"`` / ``isError=1`` as
        # ``status == 0`` — a failed TX moves no value on-chain, but the
        # downstream pipeline would still emit a phantom TRANSFER edge from
        # ``tx.value_native`` (or any ERC-20 logs that happen to be present
        # on the failed-tx receipt). BTC carries ``status is None`` (UTXO
        # has no failure mode at the TX level — invalid TXs aren't included
        # in blocks), so the strict ``== 0`` check leaves BTC behaviour
        # untouched. ``status == 1`` (success) and ``status is None`` (BTC
        # / unset) both pass through.
        if tx.status == 0:
            return _rejected("reverted")

        # Round 3 codex P1-2 fix: removed the redundant TX-level value gate
        # that ran BEFORE decoders. Bridge / DeFi calls with ``value_native=0``
        # and no pre-populated ``tx.transfers`` carry their semantic flow in
        # decoder output (CrossChainHop / DefiAction); rejecting them here
        # silently dropped those edges and mis-classified the parent as
        # VALUE_SUB_THRESHOLD. The per-transfer threshold check inside
        # ``_derive_transfer_edge_pairs`` still drops below-threshold transfer
        # edges, so plain sub-threshold sends still produce no edges. We
        # detect "no edges produced at all" AFTER ``_expand_tx`` runs and
        # treat that as the value-rejected case to preserve the old
        # ``VALUE_SUB_THRESHOLD`` termination reason.
        #
        # Round 8 codex P2-1 fix: snapshot the expansion-error counter before
        # calling ``_expand_tx`` so the caller can detect whether a decoder
        # ``decode()`` / ``get_logs`` / ``get_internal_txs`` failure
        # contributed to the empty result. Without this, a TX whose only
        # decoder raised would silently appear as ``VALUE_SUB_THRESHOLD``
        # at the parent, hiding the real failure mode.
        errors_before = len(self._expansion_errors)
        errors_overflow_before = self._expansion_errors_overflow
        # Round 16 codex P2-1 fix: catch :class:`pydantic.ValidationError`
        # raised when ``_expand_tx`` constructs a :class:`FlowEdge` from
        # decoded/transfer data that violates a model invariant (e.g. a
        # decoder emits a :class:`CrossChainHop` whose ``dst_address``
        # disagrees with the cross-chain consistency pin, or an adapter
        # returns a transfer whose ``Asset.symbol`` falls outside the
        # FlowEdge regex). Pre-fix: a single per-TX validation failure
        # propagated out of ``_expand_address`` → ``Tracer.trace`` and
        # aborted the whole BFS, contradicting the documented tracer
        # error contract that single-TX/per-address validation failures
        # are recorded as ``EXPANSION_ERROR`` metadata instead. Recording
        # the failure as a per-TX expansion error and treating the TX as
        # a rejection with ``had_expansion_error=True`` preserves the
        # round-8 P2-1 terminal-reason precedence (the parent prefers
        # ``EXPANSION_ERROR`` over ``VALUE_SUB_THRESHOLD`` when no real
        # edge survived) while keeping the BFS alive for the rest of the
        # address's history.
        try:
            edge_child_pairs = await self._expand_tx(
                tx=tx,
                actor_address=node.address,
                child_depth=node.depth + 1,
                seed_node_for_cap_termination=node,
                internal_only=internal_only_for_evm,
                prefetched_internal_txs=prefetched_internal_txs,
            )
        except ValidationError as exc:
            self._record_expansion_error(node.address, tx.tx_hash, f"validation_error: {exc}")
            return _rejected("validation_error", had_expansion_error=True)
        had_expansion_error = (
            len(self._expansion_errors) > errors_before
            or self._expansion_errors_overflow > errors_overflow_before
        )

        # Zero pairs → no decoder match AND no transfer met threshold →
        # treat as value-rejected (preserves the VALUE_SUB_THRESHOLD
        # termination path the old TX-level gate relied on). Round 8 P2-1:
        # propagate ``had_expansion_error`` so the address-level termination
        # logic can prefer EXPANSION_ERROR over VALUE_SUB_THRESHOLD when a
        # decoder/log/internal failure is the real cause of zero pairs.
        if not edge_child_pairs:
            return _rejected("value", had_expansion_error=had_expansion_error)

        # ``_expand_tx`` returns the trimmed/cap-projected pair list but
        # leaves emission to the caller. ``branching_hit`` is reported via
        # the abridged marker — detect it from the ABRIDGED edge presence.
        branching_hit = any(edge.kind is EdgeKind.ABRIDGED for edge, _ in edge_child_pairs)

        # Round 6 codex P2-2 fix: track the count of expandable children
        # (pairs whose ``child_addr is not None``) so the address-level
        # branching-termination check at ``_expand_address`` can distinguish
        # "we kept only self-loops" from "we enqueued a real downstream
        # node". A self-loop edge (e.g., a DeFi action whose pool is the
        # actor, or an ABRIDGED summary marker) does NOT progress the BFS.
        # Per WBS DoD-18 / behaviour 75: BRANCHING_LIMIT applies when the
        # branching guard fired AND no expandable transfers remained.
        #
        # Round 20 codex P2 fix: expandable-children accounting must include
        # NEW non-actor source upserts too. When branch trimming keeps a
        # non-actor edge whose target is the current node (e.g. a swap log
        # ``pool -> actor``) and drops the actor's outgoing child edge, the
        # source-upsert loop below enqueues the pool at ``node.depth + 1``
        # — that IS frontier work for the actor's continuation. Pre-fix:
        # the source-upsert loop discarded ``was_new`` and ``expandable_children``
        # only counted target-side upserts, so BRANCHING_LIMIT mis-fired on
        # the actor even though a new source node had just been enqueued.
        expandable_children = 0

        for edge, _child in edge_child_pairs:
            self._edges.append(edge)
            # Round 15 codex P1-1 fix: upsert the edge SOURCE at the right
            # depth. The actor (``node.address``) is already in the graph at
            # ``node.depth`` from the prior pop, so re-upserting it is a
            # no-op. A non-actor source means this transfer was emitted by
            # a counterparty within the actor's TX (e.g. swap pattern where
            # the TX has ``actor -> pool`` AND ``pool -> actor`` transfer
            # logs). That counterparty is one hop away from the actor in
            # the flow graph, so it belongs at ``node.depth + 1`` — NOT at
            # ``node.depth``. Pre-fix the round-10 ``shallower-depth-wins``
            # rule pinned such a counterparty at the actor's depth and the
            # subsequent ``node.depth + 1`` upsert in the children loop
            # below was a no-op, so the pool ended up reported one hop
            # shallower than its true BFS depth.
            if _addr_key(edge.source) == _addr_key(node.address):
                continue
            _source_node, source_was_new = self._upsert_node(
                address=edge.source,
                depth=node.depth + 1,
                first_seen_tx=TxRef(chain=tx.chain, tx_hash=tx.tx_hash),
                first_seen_at=tx.block.timestamp,
            )
            # Round 20 codex P2 fix: a freshly-enqueued non-actor source IS
            # new BFS frontier work for the actor (the next pop will expand
            # this counterparty). Count it toward ``expandable_children`` so
            # ``BRANCHING_LIMIT`` does not mis-fire when branch trimming
            # kept only the inbound edge from a new counterparty.
            if source_was_new:
                expandable_children += 1

        for _edge, child_addr in edge_child_pairs:
            # P2-008.3 codex F-D fix (R-BOUNDARY-POST-ADMISSION): route
            # boundary pairs through :meth:`_record_boundary_exit` only
            # after admission. ``_expand_tx`` no longer pre-applies the
            # side effects, so any boundary pair trimmed by
            # ``max_branching`` or rejected by ``max_total_addresses``
            # never reaches here — ghost metadata cannot land in
            # ``self._pending_boundary_exits`` and the cap projection
            # counts the boundary target like any normal child (the
            # decoder loop now keeps ``child=edge.target``). Boundary
            # targets do NOT count toward ``expandable_children``
            # because no further frontier expansion happens for them
            # (twin pattern: the unregistered-dst-chain branch below).
            boundary_stage_label = self._is_boundary_edge(_edge)
            if boundary_stage_label is not None:
                self._record_boundary_exit(
                    edge=_edge,
                    tx=tx,
                    stage_label_value=boundary_stage_label,
                    depth=node.depth + 1,
                )
                continue
            if child_addr is None:
                continue
            if child_addr.chain != chain and not self._adapters.has(child_addr.chain):
                self._handle_unregistered_dst_chain(
                    child_addr, tx, source_addr=node.address, depth=node.depth + 1
                )
                # The unregistered dst-chain node is created and immediately
                # marked terminal — it does NOT count as an expandable child
                # because no further frontier expansion will happen for it.
                continue
            # Round 7 codex P2 fix: count only newly enqueued children. If
            # ``child_addr`` is already in ``self._nodes`` (cycle / duplicate
            # destination), ``_upsert_node`` is a no-op and produces no new
            # frontier work — so it must NOT count toward ``expandable_children``,
            # otherwise the BRANCHING_LIMIT terminal reason at ``_expand_address``
            # is masked when pruning kept only such no-op upserts.
            _child_node, was_new = self._upsert_node(
                address=child_addr,
                depth=node.depth + 1,
                first_seen_tx=TxRef(chain=tx.chain, tx_hash=tx.tx_hash),
                first_seen_at=tx.block.timestamp,
            )
            if was_new:
                expandable_children += 1

        return {
            "accepted": True,
            "reason": "ok",
            "edges_emitted": len(edge_child_pairs),
            "branching_hit": branching_hit,
            "expandable_children": expandable_children,
            "had_expansion_error": had_expansion_error,
        }

    # ------------------------------------------------------------------
    # Shared TX expansion pipeline (P1-014 codex round 2 P1)
    # ------------------------------------------------------------------

    async def _expand_tx(
        self,
        *,
        tx: NormalizedTransaction,
        actor_address: Address,
        child_depth: int,
        seed_node_for_cap_termination: GraphNode | None,
        internal_only: bool = False,
        prefetched_internal_txs: tuple[NormalizedTransaction, ...] | None = None,
    ) -> list[tuple[FlowEdge, Address | None]]:
        """Run decoders + abi_fallback + transfer derivation on a single TX.

        ``internal_only=True`` (round 12 codex P2-3) restricts emission to
        internal-tx edges. Used when ``_process_tx`` accepts an EVM TX whose
        top-level direction is incoming (``tx.from_addr != actor_address``)
        because a successful internal tx surfaces the actor as a value
        sender. Decoders + ``_derive_transfer_edge_pairs`` would otherwise
        fabricate edges from an inbound call (top-level value flows TO the
        actor, plus any ERC-20 logs that happen to be emitted on the call).
        Address-cap projection still runs on the internal-tx edges.

        The output is a list of ``(FlowEdge, child_address)`` pairs, already
        branching-trimmed and address-cap-projected, ready for the caller to
        append to the edge list / enqueue children. ``child_address`` is
        ``None`` for self-loop edges (e.g. DeFi actions whose pool is the
        actor, ABRIDGED markers, address-cap-rejected children).

        Round 2 codex P1 fix: extract the decoder + abi-fallback + transfer
        pipeline so both ``_expand_seed`` and ``_process_tx`` exercise the
        same path. Round 2 P2-2 fix: the address-cap projection inside this
        helper now applies during seed expansion as well.

        ``actor_address`` is the address whose outgoing TXs are being
        walked; for the seed it is ``tx.from_addr`` (or ``tx.to_addr`` as
        fallback). ``seed_node_for_cap_termination`` is the parent graph
        node that should be marked terminal if the address cap fires; pass
        ``None`` to skip the terminal marking (rare — only when no parent
        node exists yet).
        """
        edge_child_pairs: list[tuple[FlowEdge, Address | None]] = []
        # Round 12 codex P2-3 fix: ``internal_only=True`` skips the decoder,
        # ABI-fallback, and top-level transfer pipelines. Only internal-tx
        # emission survives — see the contract-withdrawal scenario in
        # ``_process_tx`` for why.
        #
        # Round 26 codex P2 fix (refined in round 32 P2-1): a misbehaving
        # decoder's ``matches()`` predicate must be quarantined so it
        # cannot block legitimate sibling decoders.
        # ``DecoderRegistry.find_matching`` is documented to propagate
        # ``matches()`` exceptions as-is (DoD-13). The round-26 fix
        # wrapped that call in try/except and dropped ALL decoders on
        # any predicate failure, which let a single broken low/high-
        # priority plugin silently disable every other registered
        # bridge/DeFi decoder. Round 32 P2-1 fix: bypass
        # ``find_matching`` here and iterate the registered decoders
        # directly with PER-DECODER try/except, so only the faulty
        # plugin is quarantined; the surviving decoders keep matching.
        # Each ``matches()`` failure is still demoted to a per-TX
        # expansion-error record (parity with the ``decode()`` failure
        # handler below).
        if internal_only:
            decoders: tuple[BridgeDecoder, ...] = ()
        else:
            matched: list[BridgeDecoder] = []
            for candidate in self._decoders.decoders():
                try:
                    if candidate.matches(tx):
                        matched.append(candidate)
                except Exception as exc:
                    self._record_expansion_error(
                        actor_address,
                        tx.tx_hash,
                        f"decoder_matches_error: {candidate.name}: {exc}",
                    )
            decoders = tuple(matched)
        # Round 38 codex P3 fix: ``_fetch_logs_safe`` returns ``None`` on
        # failure (and also when no fetch was attempted yet). The
        # synthesizer branch below cannot distinguish those two states
        # using ``logs_fetched is None`` alone — a failed-and-recorded
        # fetch would be retried by the synthesis path, double-counting
        # the same failing receipt endpoint in
        # ``metadata['expansion_errors']`` and burning a second
        # adapter call. Track the fetch attempt with an explicit
        # boolean so the synthesis path can short-circuit when a prior
        # fetch already failed for this TX.
        logs_fetched: tuple[NormalizedLog, ...] | None = None
        logs_fetch_attempted = False

        if decoders:
            logs_fetched = await self._fetch_logs_safe(actor_address, tx)
            logs_fetch_attempted = True
            for decoder in decoders:
                try:
                    extractions = decoder.decode(tx, logs_fetched or ())
                except Exception as exc:
                    self._record_expansion_error(actor_address, tx.tx_hash, str(exc))
                    continue
                self._decoder_matches += 1
                for extraction in extractions:
                    # Round 12 codex P2-2 fix: apply the chain's
                    # ``min_value_native`` threshold to decoder-emitted flows
                    # the same way native / ERC-20 / internal-tx pipelines do.
                    # Pre-fix: a misbehaving decoder that yielded a 1-wei
                    # CrossChainHop / DefiAction from a zero-value call still
                    # produced a FlowEdge despite the 0.01 ETH default
                    # threshold, contaminating the trace with sub-dust hops.
                    # The threshold is denominated in the source-chain native
                    # unit (CrossChainHop.src_chain / DefiAction.chain), which
                    # matches how _derive_transfer_edge_pairs and
                    # _derive_internal_tx_edge_pairs key into the policy.
                    if isinstance(extraction, CrossChainHop):
                        # Round 36 codex P1 fix: ``min_value_native`` is
                        # denominated in the chain's native unit (wei /
                        # sat). Comparing it to a TOKEN ``amount_in``
                        # (e.g. USDC has 6 decimals) prunes any sane
                        # bridge transfer because token raw units are
                        # orders of magnitude smaller than native wei.
                        # A 100k USDC bridge hop has ``raw=10**11``,
                        # below the default ``10**16`` ETH threshold —
                        # the tracer would silently drop large
                        # stablecoin flows as ``VALUE_SUB_THRESHOLD``.
                        # Apply the native threshold ONLY when the hop
                        # transports the source chain's native asset
                        # (``asset_in.contract is None``); token-
                        # denominated hops are emitted unconditionally
                        # because USD pricing / per-token thresholds
                        # are deferred to Phase 2.
                        # PB-003.1: a curated deep sink's ONWARD native cross-
                        # chain hop clears the lower deep floor (the edge source
                        # is ``actor_address``). Empty set → global fallback.
                        _deep_hop = self._deep_floor(extraction.src_chain, actor_address)
                        hop_threshold = (
                            _deep_hop
                            if _deep_hop is not None
                            else self._policy.min_value_native.get(extraction.src_chain, 0)
                        )
                        if (
                            extraction.asset_in.contract is None
                            and extraction.amount_in.raw < hop_threshold
                        ):
                            self._sub_threshold_drops += 1
                            continue
                        edge = self._make_cross_chain_edge(
                            actor=actor_address,
                            tx=tx,
                            hop=extraction,
                            decoder_name=decoder.name,
                        )
                        edge_child_pairs.append((edge, extraction.dst_address))
                    elif isinstance(extraction, DefiAction):
                        # Round 36 codex P1 fix (parity with the
                        # CrossChainHop branch above): native-only
                        # threshold; token-denominated DeFi actions
                        # bypass.
                        # PB-003.1: source-gate the deep floor on the
                        # DIRECTION-AWARE edge source, computed WITHOUT building
                        # the FlowEdge so the threshold check stays BEFORE edge
                        # validation (a sub-threshold action is dropped, never
                        # constructed). ``_defi_edge_endpoints`` emits ``pool →
                        # actor`` for BORROW / COLLATERAL_WITHDRAW, so a
                        # pool-sourced disbursement INTO a deep sink (inbound)
                        # keeps the global floor; only actor-sourced actions
                        # (SUPPLY / REPAY = onward) clear the deep floor. Empty
                        # set → global fallback.
                        defi_source, _defi_target = self._defi_edge_endpoints(
                            extraction, actor_address
                        )
                        _deep_action = self._deep_floor(extraction.chain, defi_source)
                        action_threshold = (
                            _deep_action
                            if _deep_action is not None
                            else self._policy.min_value_native.get(extraction.chain, 0)
                        )
                        if (
                            extraction.asset.contract is None
                            and extraction.amount.raw < action_threshold
                        ):
                            self._sub_threshold_drops += 1
                            continue
                        edge = self._make_defi_edge(
                            actor=actor_address,
                            tx=tx,
                            action=extraction,
                            decoder_name=decoder.name,
                        )
                        # Round 22 codex P2-2 fix: the BFS continuation
                        # child must follow value-flow direction, not
                        # always be the pool. For BORROW /
                        # COLLATERAL_WITHDRAW the value moves
                        # pool → actor, so the next BFS hop walks the
                        # actor (the recipient of the disbursement /
                        # withdrawal); for COLLATERAL_SUPPLY / REPAY
                        # the value moves actor → pool, so the BFS
                        # continues at the pool exactly as before. Use
                        # ``edge.target`` (already direction-aware via
                        # ``_make_defi_edge`` after the round-22 fix
                        # below) as the canonical continuation child —
                        # this keeps the BFS continuation in lockstep
                        # with the FlowEdge direction without
                        # re-deriving the kind→direction mapping in
                        # two places.
                        child = (
                            edge.target
                            if _addr_key(edge.target) != _addr_key(actor_address)
                            else None
                        )
                        # P2-008.3 — Stage 8 boundary recognizer wiring.
                        # Codex F-D (post-P2-008.3) fix: side effects
                        # (target upsert + terminal-mark + metadata
                        # record) are DEFERRED to the post-admission
                        # caller loops in ``_expand_seed`` and
                        # ``_expand_address``. Pre-fix they fired here
                        # (before ``max_branching`` trimming and
                        # ``max_total_addresses`` cap projection),
                        # producing two correctness failures:
                        #   1. Ghost metadata — boundary recorded for
                        #      pairs later dropped by trim/cap or
                        #      abandoned after a sibling ValidationError.
                        #   2. Cap bypass — pre-upserting the target
                        #      let it slip into ``provisional_known``
                        #      and bypass ``max_total_addresses``.
                        # The detection itself stays pure here so the
                        # cap projection (lines below) counts the
                        # boundary's ``edge.target`` exactly like any
                        # normal child: keep ``child=edge.target`` (not
                        # coerced to ``None``) when the edge is a
                        # boundary so it consumes a slot. The post-
                        # admission caller then routes those surviving
                        # boundary pairs through
                        # :meth:`_record_boundary_exit` instead of the
                        # normal child-upsert path. R-BOUNDARY-CHILD-
                        # COERCION (the BFS-never-enqueues semantic) is
                        # preserved at the caller — boundary pairs are
                        # intercepted before the normal frontier upsert
                        # and routed to ``_record_boundary_exit`` which
                        # upserts + marks terminal in one step so the
                        # frontier-loop terminal-skip guard at line 796
                        # never expands the boundary target.
                        edge_child_pairs.append((edge, child))

        decoder_label_for_transfers: str | None = None
        if not internal_only and not decoders and self._abi_fallback is not None:
            try:
                resolved = await self._abi_fallback.resolve(tx)
            except Exception as exc:
                # Round 34 codex P1 fix: abi_fallback resolvers
                # (4byte / Sourcify / Etherscan) raise httpx exceptions
                # whose text embeds the full request URL — including the
                # Etherscan ``apikey`` query parameter. Logging the raw
                # exception via ``%s`` formatting would leak credentials
                # into application logs (parity with the round-30 metadata
                # sink redaction and round-31 hard-error redaction).
                # Apply :func:`_redact_secrets` to the exception text
                # before it reaches the logging surface.
                logger.warning(
                    "abi_fallback.resolve raised on tx=%s: %s",
                    tx.tx_hash,
                    _redact_secrets(str(exc)),
                )
                resolved = None
            if resolved is not None:
                self._abi_fallback_resolutions += 1
                # Round 3 codex P2-1: ``DecodedCall.decoder`` from
                # :class:`AbiFallbackResolver` is already prefixed
                # (``abi_fallback.4byte`` / ``abi_fallback.sourcify`` /
                # ``abi_fallback.etherscan``) — see
                # ``vca.decoders.abi_fallback.decode.recover_abi_for_tx``
                # which sets ``decoder=f"abi_fallback.{source.value}"``.
                # The previous implementation re-prefixed it, producing
                # ``abi_fallback.abi_fallback.4byte``. Use the resolver's
                # value directly.
                decoder_label_for_transfers = resolved.decoder

        # Round 28 codex P1 fix: when the producer-side adapter (P1-002
        # EtherscanAdapter, P1-003 ArbitrumAdapter) returned an EVM TX
        # with ``transfers=()`` AND no decoder matched (so no logs were
        # fetched yet) AND we're not in internal-only mode, fetch logs
        # and synthesize ERC-20 ``Transfer`` events into the transfer
        # list. Pre-fix: ordinary ERC-20-only flows were invisible to the
        # tracer because ``get_tx`` / ``get_address_txs`` only encode
        # ``eth_getTransactionByHash`` / ``txlist`` data, neither of
        # which surfaces token movements. The synthesized transfers feed
        # the existing :meth:`_derive_transfer_edge_pairs` pipeline so
        # downstream threshold / direction filters apply uniformly.
        #
        # Round 31 codex P2 fix (refined in round 32 P2-2 and round 37
        # P2-1): synthesis is the fallback path only — gate tightly so
        # we don't double-emit alongside semantic decoder edges, but
        # WIDE enough to catch every TX whose ERC-20 ``Transfer`` logs
        # would otherwise be invisible.
        # 1. ``not edge_child_pairs`` — neither decoders nor abi_fallback
        #    produced any edge yet. Round 31 used ``not decoders``,
        #    which incorrectly suppressed synthesis when a decoder
        #    merely *matched* (the BridgeDecoder Protocol allows
        #    ``decode()`` to return ``()`` legitimately — e.g. a broad
        #    matcher that found no extractions). Round 32 P2-2 fix:
        #    branch on whether anything was actually emitted.
        # 2. (Round 31 P2 also added ``tx.value_native.raw == 0`` to
        #    avoid wasted log fetches for native-only sends. Round 37
        #    P2-1 surfaced the regression: a TX that BOTH sends native
        #    value AND emits ERC-20 ``Transfer`` logs would skip
        #    synthesis under that gate, so the token edges silently
        #    disappeared from the graph for mixed native+token
        #    transactions. The native-only optimisation was the wrong
        #    trade-off for forensic accuracy — codex round 37 makes
        #    correctness the priority. Removing the value_native gate
        #    re-introduces an extra receipt request for true
        #    native-only sends (no decoder match, value>0, no logs),
        #    bounded by ``max_address_txs_per_address`` (default 200).
        #    The same logs are reused if a decoder already fetched
        #    them, so the cost only accrues for the genuinely-empty
        #    decoder-miss case.
        if not internal_only and not tx.transfers and tx.chain.is_evm and not edge_child_pairs:
            # Round 38 codex P3 fix: only fetch when no prior attempt
            # was made. ``logs_fetched is None`` ALONE could mean either
            # "not fetched yet" or "fetch failed and recorded an
            # expansion-error" — the latter must not be retried, both
            # to spare an adapter round-trip and to avoid duplicating
            # the failure record. Re-using the already-recorded result
            # means a None outcome here yields an empty synthesis (no
            # logs to parse), which is the desired behaviour.
            if not logs_fetch_attempted:
                logs_fetched = await self._fetch_logs_safe(actor_address, tx)
                logs_fetch_attempted = True
            synthesized = _synthesize_erc20_transfers_from_logs(tx, logs_fetched or ())
            if synthesized:
                tx = tx.model_copy(update={"transfers": synthesized})

        # Native EVM value transfers, ERC-20 transfers, and BTC vouts.
        # Round 12 codex P2-3: skip top-level transfer derivation when the
        # caller has explicitly accepted an inbound EVM call only because of
        # contract-as-sender internal txs. The top-level transfers belong to
        # the inbound direction (or to ERC-20 logs whose ``from`` is not the
        # actor) and would create phantom edges.
        if not internal_only:
            edge_child_pairs.extend(
                self._derive_transfer_edge_pairs(
                    tx,
                    expanding_address=actor_address,
                    child_depth=child_depth,
                    decoder_label=decoder_label_for_transfers,
                )
            )

        # Round 4 codex P2-2 fix: surface EVM internal transfers as
        # ``EdgeKind.INTERNAL`` edges. Contract withdrawals / receive()
        # callbacks frequently move value through ``CALL`` / ``CREATE``
        # sub-frames that leave ``tx.value_native=0`` and emit no ERC-20
        # ``Transfer`` log; without this fetch those flows produce zero
        # edges and the trace silently drops the transit. BTC has no
        # internal-tx surface (no message-call sub-frames), so the call
        # is gated on ``chain.is_evm`` to avoid burning an adapter call
        # against the BTC adapter's hard-coded empty stub.
        if tx.chain.is_evm:
            internal_pairs = await self._derive_internal_tx_edge_pairs(
                tx,
                expanding_address=actor_address,
                prefetched_internal_txs=prefetched_internal_txs,
            )
            if internal_only:
                # Round 12 codex P2-3: in internal-only mode, restrict to
                # internal-tx edges where the actor is the sender. Other
                # internal txs (e.g., external_caller → contract → other)
                # would survive the direction check on their own merits but
                # belong to a different actor's expansion frontier.
                actor_key = _addr_key(actor_address)
                internal_pairs = [
                    pair for pair in internal_pairs if _addr_key(pair[0].source) == actor_key
                ]
            edge_child_pairs.extend(internal_pairs)

        # P3.2-008 (OPTION A) — the BTC high-fanout CoinJoin terminal bound is
        # applied ADDRESS-LEVEL in ``_expand_address`` (``_btc_tx_fanout``
        # pre-scan), NOT per-tx here. mempool.space returns newest-first, so a
        # tx newer than the CoinJoin row is processed first; a per-tx bound
        # would let those newer children leak before it fired (codex
        # re-review finding). The pre-scan marks the whole mixing address
        # terminal before any of its history is emitted.

        # Branching trim — keep top-N by absolute value, append an ABRIDGED
        # self-loop summarising the dropped pairs.
        #
        # Rank by human-unit magnitude, not raw ``value_minor`` (scan #13
        # DEC-1). ``edge_child_pairs`` mixes assets of different decimals in
        # a single tx (native 18/8-dec wei/sat, ERC-20 token 6-dec,
        # decoder-emitted hops), so a raw-minor comparison conflates decimal
        # scale with economic magnitude — a 1-ETH edge (raw 1e18) would
        # outrank a 500k-USDC edge (raw 5e11) and the larger flow would be
        # dropped into a count-only ABRIDGED marker. Scale every value to a
        # common decimal basis (the MAX decimals in this trim set) with EXACT
        # integer arithmetic: since ``ref_dec >= edge.decimals`` the exponent
        # is >= 0, so ``value_minor * 10 ** (ref_dec - decimals)`` is an exact
        # integer proportional to the human value — no float bridge and no
        # context-rounded ``Decimal`` divide (codex DEC-1 R1 P2: a rounded
        # divide could tie two distinct uint256-scale amounts and abridge the
        # larger). Mirrors the round-36 threshold-prune fix and
        # ``web/builders/_sankey.py`` reference-decimals normalization. (USD
        # pricing is out of scope — Phase 2.)
        max_branching = self._policy.max_branching
        if len(edge_child_pairs) > max_branching:
            ref_dec = max(edge.decimals for edge, _child in edge_child_pairs)
            ordered = sorted(
                enumerate(edge_child_pairs),
                key=lambda pair: (
                    -((pair[1][0].value_minor or 0) * 10 ** (ref_dec - pair[1][0].decimals)),
                    pair[1][0].tx_hash or "",
                    pair[0],
                ),
            )
            kept_indices = {idx for idx, _pair in ordered[:max_branching]}
            dropped = len(edge_child_pairs) - len(kept_indices)
            edge_child_pairs = [
                pair for idx, pair in enumerate(edge_child_pairs) if idx in kept_indices
            ]
            edge_child_pairs.append(
                (
                    FlowEdge(
                        source=actor_address,
                        target=actor_address,
                        kind=EdgeKind.ABRIDGED,
                        value_minor=None,
                        asset_symbol=actor_address.chain.native_symbol,
                        decimals=actor_address.chain.native_decimals,
                        tx_hash=None,
                        extras={
                            "dropped": dropped,
                            "tx_hash": tx.tx_hash,
                            "kind": "branching",
                        },
                    ),
                    None,
                )
            )
            self._abridged_emissions += 1

        # Address-cap projection — drop pairs whose child would push the
        # visited set past ``max_total_addresses``. Round 2 P2-2 fix: this
        # projection now runs for the seed expansion path too, because
        # ``_expand_seed`` delegates here.
        cap = self._policy.max_total_addresses
        admitted_pairs: list[tuple[FlowEdge, Address | None]] = []
        cap_hit = False
        provisional_known = set(self._nodes.keys())
        for edge, child_addr in edge_child_pairs:
            # Round 17 codex P2: deduplicate ``new_keys`` before counting.
            # Pre-fix: when ``edge.source == child_addr`` (e.g. a
            # ``DefiAction`` self-loop on a non-actor pool, or a
            # ``CrossChainHop`` whose source and target coincide), the
            # source and child contributed two entries for the SAME
            # canonical key, so a one-slot-remaining cap would falsely
            # reject the edge with ``address_cap_reached`` even though
            # only one new distinct address would be admitted.
            new_keys: set[str] = set()
            src_key = self._node_key(edge.source)
            if src_key not in provisional_known:
                new_keys.add(src_key)
            if child_addr is not None:
                child_key = self._node_key(child_addr)
                if child_key not in provisional_known:
                    new_keys.add(child_key)
            if len(provisional_known) + len(new_keys) > cap:
                cap_hit = True
                continue
            provisional_known |= new_keys
            admitted_pairs.append((edge, child_addr))

        if cap_hit:
            self._record_expansion_error(
                actor_address,
                tx.tx_hash,
                f"address_cap_reached: max_total_addresses={cap}",
            )
            if seed_node_for_cap_termination is not None:
                self._mark_terminal(
                    seed_node_for_cap_termination, TerminationReason.EXPANSION_ERROR
                )

        return admitted_pairs

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _node_key(address: Address) -> str:
        # Round 11 codex P2 fix: route through ``canonical_address_key``
        # so BTC Base58Check case-sensitivity is preserved across the
        # ``self._nodes`` dict keys (matched against ``GraphNode.canonical_key``).
        return canonical_address_key(address)

    def _deep_floor(self, chain: ChainId, address: Address) -> int | None:
        """PB-003.1 deep-expand native floor for ``address`` on ``chain``.

        Returns the per-chain deep floor when ``address`` is one of the curated
        ``deep_expand_addresses`` sinks (keyed on its canonical key), else
        ``None`` so the caller falls back to the exact global lookup. The floor
        map is ETH-only, so a deep sink on a chain absent from
        ``deep_expand_floor_native`` also gets ``None`` (global floor). The
        empty default set means this always returns ``None`` for a bare policy →
        every call site is byte-identical to pre-PB-003.1.
        """
        if canonical_address_key(address) in self._policy.deep_expand_addresses:
            return self._policy.deep_expand_floor_native.get(chain)
        return None

    def _effective_cap(self, address: Address) -> int:
        """BTC-SPINE BTC-1: per-address max-tx cap for ``address``.

        Returns the raised ``deep_expand_cap`` when ``address`` is one of the
        curated BTC L2 payouts (keyed on its canonical key), else the global
        ``max_address_txs_per_address``. The empty default set (bare policy)
        always returns the global cap → every cap gate byte-identical to
        pre-BTC-SPINE. SOURCE-gated on the expanding node, so only a curated
        payout's own admission is affected (no bleed).
        """
        if (
            self._policy.deep_expand_cap is not None
            and canonical_address_key(address) in self._policy.deep_expand_cap_addresses
        ):
            return self._policy.deep_expand_cap
        return self._policy.max_address_txs_per_address

    def _effective_time_window(self, address: Address) -> timedelta:
        """BTC-SPINE BTC-1: per-address BFS time window for ``address``.

        Returns the extended ``deep_expand_window`` when ``address`` is the
        curated hub (keyed on its canonical key), else the global
        ``time_window``. The empty default set always returns the global window
        → both BFS window gates byte-identical to pre-BTC-SPINE. SOURCE-gated on
        the expanding node, so only the hub sees the extended window.
        """
        if (
            self._policy.deep_expand_window is not None
            and canonical_address_key(address) in self._policy.deep_expand_window_addresses
        ):
            return self._policy.deep_expand_window
        return self._policy.time_window

    def _onward_deep_floor(
        self, chain: ChainId, expanding_address: Address, target: Address
    ) -> int | None:
        """Deep floor for an ONWARD native sub-frame edge, or None → global floor.

        PB-003.1: the deep floor lowers only a curated sink's ONWARD legs — value
        moving to a NEW recipient. A native sub-frame (internal tx / per-transfer)
        whose RECIPIENT is the expanding sink itself (a borrow / withdrawal /
        refund INFLOW, e.g. ``pool → sink``) is NOT an onward leg and keeps the
        global floor, even though the sink causally initiated the tx — this
        mirrors the direction-aware DeFi gate that keeps BORROW-style inflows at
        the global floor. Returns None for an inbound-to-sink target OR a
        non-curated sink, so the caller falls back to the global floor in both.
        """
        if _addr_key(target) == _addr_key(expanding_address):
            return None
        return self._deep_floor(chain, expanding_address)

    def _btc_tx_fanout(self, tx: NormalizedTransaction, actor: Address) -> int:
        """Count a BTC tx's outgoing fanout the SAME way
        :meth:`_derive_transfer_edge_pairs` counts BTC vout child pairs.

        BTC vouts carry ``from_addr=None`` (UTXO collapse), so the expanding
        ``actor`` is the implicit source and every vout whose ``to_addr`` is a
        DISTINCT-from-actor recipient at or above ``min_value_native`` becomes
        an outgoing child edge. Mirroring the derivation's filtering (skip
        burns, skip EVM mints, drop native sub-threshold vouts, treat
        self/change vouts as non-children) keeps the address-level CoinJoin
        pre-scan in :meth:`_expand_address` consistent with the edges the
        per-tx loop would actually emit. BTC has no decoder / internal-tx
        edges, so transfer vouts are the only child source for a BITCOIN tx.

        Counts UNIQUE non-self destination keys, NOT raw vouts (codex
        re-review): the CoinJoin / batch-mixing signature is "fans out to many
        DISTINCT addresses", which is exactly the number of downstream children
        the BFS would enqueue. A one-recipient tx split into N outputs to the
        SAME address is a single child and must NOT trip the bound.
        """
        actor_key = _addr_key(actor)
        destinations: set[str] = set()
        for transfer in tx.transfers:
            if transfer.to_addr is None:
                continue  # burn — no destination
            if transfer.from_addr is not None:
                continue  # real on-chain sender — not a UTXO vout
            if transfer.asset.chain.is_evm:
                continue  # EVM ERC-20 mint (from_addr=None), not a BTC vout
            threshold = self._policy.min_value_native.get(transfer.asset.chain, 0)
            if transfer.asset.contract is None and transfer.amount.raw < threshold:
                continue  # native sub-threshold vout — no child edge
            dest_key = _addr_key(transfer.to_addr)
            if dest_key == actor_key:
                continue  # self / change vout — child would be None
            destinations.add(dest_key)
        return len(destinations)

    def _derive_transfer_edge_pairs(
        self,
        tx: NormalizedTransaction,
        *,
        expanding_address: Address,
        child_depth: int,
        decoder_label: str | None = None,
    ) -> list[tuple[FlowEdge, Address | None]]:
        """Derive ``(FlowEdge, child_address)`` pairs for a transaction.

        Handles three cases identified in P1-014 codex round 1:

        1. **Native EVM value transfer** — ``tx.transfers`` is empty AND
           ``tx.value_native > 0`` AND both ``tx.from_addr`` / ``tx.to_addr``
           are set. Emits one TRANSFER edge using the chain's native symbol.
           Without this, ordinary ETH/ARB payments produced by the real
           adapters (which leave ``transfers=()`` for native sends) yield
           no edge — the tracer would lose the main flow.

        2. **ERC-20 token transfer** — the existing case. ``transfer.from_addr``
           and ``transfer.to_addr`` are both set on EVM, so the edge endpoints
           come straight from the transfer.

        3. **BTC vout** — UTXO TXs put ``transfer.from_addr=None`` because
           multiple inputs may share authorship. The expanding address (the
           one whose outgoing TXs we're walking) is the implicit source.

        A TX with both ``value_native > 0`` and ERC-20 transfers (e.g.,
        a swap call where ETH is sent in addition to a token movement)
        produces edges for both — we do not dedupe, both are real flows.

        Each entry is a 2-tuple. ``child_address`` is ``None`` for self-loops
        (e.g., when the transfer's ``to_addr`` resolves to the expanding
        address itself). The branching trim filter consumes the pairs as a
        unit so edge↔child correspondence is preserved.
        """
        del child_depth  # caller decides where to enqueue the child; this helper
        # only carries the child *address* — depth is derived in _process_tx /
        # _expand_seed at the call site.

        results: list[tuple[FlowEdge, Address | None]] = []
        chain = tx.chain
        # PB-003.1: a deep-expand sink's ONWARD native value edge (Case 1 / 1b,
        # target = ``tx.to_addr``) clears the lower deep floor instead of the
        # global ``min_value_native``. A self-send (``tx.to_addr == expanding
        # sink``) is not an onward leg and keeps the global floor via
        # ``_onward_deep_floor`` (consistent with the internal / per-transfer
        # branches). Empty set → global fallback.
        _deep = (
            self._onward_deep_floor(chain, expanding_address, tx.to_addr)
            if tx.to_addr is not None
            else None
        )
        chain_threshold = (
            _deep if _deep is not None else self._policy.min_value_native.get(chain, 0)
        )

        if not tx.transfers:
            # Case 1: native EVM value transfer with no token logs.
            if tx.value_native.raw > 0 and tx.from_addr is not None and tx.to_addr is not None:
                if tx.value_native.raw < chain_threshold:
                    # Round 27 codex P2 fix: count the drop so the seed
                    # path can promote NO_OUTGOING -> VALUE_SUB_THRESHOLD.
                    self._sub_threshold_drops += 1
                else:
                    edge = FlowEdge(
                        source=tx.from_addr,
                        target=tx.to_addr,
                        kind=EdgeKind.TRANSFER,
                        value_minor=tx.value_native.raw,
                        asset_symbol=chain.native_symbol,
                        decimals=chain.native_decimals,
                        tx_hash=tx.tx_hash,
                        block=tx.block,
                        decoder=decoder_label,
                    )
                    child = (
                        tx.to_addr
                        if _addr_key(tx.to_addr) != _addr_key(expanding_address)
                        else None
                    )
                    results.append((edge, child))
        else:
            # Case 1b: native value AND token transfers in the same TX.
            # Both flows are real; emit edges for each. Round 4 codex P1
            # fix: gate on ``chain.is_evm`` because BTC's ``transfers`` is
            # an exhaustive per-vout representation and ``value_native``
            # is the SUM of those vouts — emitting an aggregate edge here
            # would double-count BTC value (the seed vout would receive
            # both the per-vout transfer edge AND a redundant aggregate
            # edge for the entire tx amount). EVM TXs can legitimately
            # carry both a native value transfer AND ERC-20 token
            # movements in the same tx, so the EVM path is preserved.
            if (
                chain.is_evm
                and tx.value_native.raw > 0
                and tx.from_addr is not None
                and tx.to_addr is not None
            ):
                if tx.value_native.raw < chain_threshold:
                    # Round 27 codex P2 fix: same as Case 1 — count the
                    # native-value drop for the seed precedence ladder.
                    self._sub_threshold_drops += 1
                else:
                    edge = FlowEdge(
                        source=tx.from_addr,
                        target=tx.to_addr,
                        kind=EdgeKind.TRANSFER,
                        value_minor=tx.value_native.raw,
                        asset_symbol=chain.native_symbol,
                        decimals=chain.native_decimals,
                        tx_hash=tx.tx_hash,
                        block=tx.block,
                        decoder=decoder_label,
                    )
                    child = (
                        tx.to_addr
                        if _addr_key(tx.to_addr) != _addr_key(expanding_address)
                        else None
                    )
                    results.append((edge, child))

            # Case 2 / 3: ERC-20 token transfers and BTC vouts.
            for transfer in tx.transfers:
                if transfer.to_addr is None:
                    # Burn — no destination, skip.
                    continue
                if transfer.from_addr is None:
                    # BTC vout: UTXO TXs leave from_addr=None because multiple
                    # inputs can share authorship — use the expanding address
                    # as the implicit source.
                    # EVM ERC-20 mints (from_addr=None) are real semantic
                    # mints (no on-chain sender) so the existing behaviour of
                    # skipping them stays correct on EVM chains.
                    if not transfer.asset.chain.is_evm:
                        source = expanding_address
                    else:
                        continue
                else:
                    source = transfer.from_addr
                # Round 36 codex P1 fix: ``min_value_native`` is in
                # native chain units (wei / sat). For TOKEN transfers
                # (``asset.contract is not None``) the raw amount is in
                # token base units, which are orders of magnitude
                # smaller than native wei — comparing them directly
                # prunes large stablecoin movements (a 100k USDC
                # transfer has ``raw=10**11``, far below the default
                # ``10**16`` ETH threshold). Apply the threshold ONLY
                # to native-asset transfers; token transfers pass
                # through and downstream USD-priced thresholds are
                # deferred to Phase 2.
                #
                # Per-asset threshold (asset.chain may differ from tx.chain
                # when a cross-chain decoder fires; for plain transfers the
                # chains match). Default to 0 so unknown chains don't block.
                # PB-003.1: same ONWARD deep-floor override at the per-transfer
                # site — a native sub-frame surfaced as a transfer has the sink as
                # its economic source even when ``from_addr`` is an intermediary
                # contract (mirrors the internal-tx branch; ~2680 direct sends
                # already have ``from_addr == expanding_address``). A transfer
                # back TO the sink (``transfer.to_addr == expanding_address``)
                # keeps the global floor. Empty set → global fallback.
                _deep_transfer = self._onward_deep_floor(
                    transfer.asset.chain, expanding_address, transfer.to_addr
                )
                transfer_threshold = (
                    _deep_transfer
                    if _deep_transfer is not None
                    else self._policy.min_value_native.get(transfer.asset.chain, 0)
                )
                if transfer.asset.contract is None and transfer.amount.raw < transfer_threshold:
                    # Round 27 codex P2 fix: only count POSITIVE transfers
                    # below threshold (zero-amount events are not "movement
                    # pruned by policy" — they're not movement at all).
                    if transfer.amount.raw > 0:
                        self._sub_threshold_drops += 1
                    continue
                edge = FlowEdge(
                    source=source,
                    target=transfer.to_addr,
                    kind=EdgeKind.TRANSFER,
                    value_minor=transfer.amount.raw,
                    asset_symbol=transfer.asset.symbol,
                    decimals=transfer.asset.decimals,
                    # True token identity (scan #16 Lens B). ``None`` for BTC vouts
                    # (native asset). Synthesized ERC-20 edges keep the placeholder
                    # ``asset_symbol`` above but carry the real contract here.
                    asset_contract=transfer.asset.contract,
                    tx_hash=tx.tx_hash,
                    block=tx.block,
                    decoder=decoder_label,
                )
                child = (
                    transfer.to_addr
                    if _addr_key(transfer.to_addr) != _addr_key(expanding_address)
                    else None
                )
                results.append((edge, child))

        return results

    async def _fetch_internal_txs_for_tx(
        self,
        *,
        tx: NormalizedTransaction,
        expanding_address: Address,
    ) -> tuple[NormalizedTransaction, ...] | None:
        """Round 12 codex P2-3: shared internal-tx fetch helper.

        Returns the adapter's internal txs for ``tx.tx_hash``, or ``None``
        if the chain is not EVM, the adapter is missing, or the call
        raised. ``None`` lets the caller distinguish "no internal txs" from
        "we couldn't ask"; both ``_has_outgoing_internal_tx`` and the
        edge-deriving caller can act on the distinction.

        The fetch is bookkept as one ``adapter_calls`` increment regardless
        of how many callers consume the result — the helper is intentionally
        non-memoising because a tx may be fetched at most once per address
        expansion in practice (the seed-vs-incoming gating in
        ``_process_tx`` is single-shot).
        """
        if not tx.chain.is_evm:
            return None
        try:
            adapter = self._adapters.get(tx.chain)
        except KeyError as exc:
            self._record_expansion_error(expanding_address, tx.tx_hash, str(exc))
            return None
        try:
            self._adapter_calls[tx.chain] = self._adapter_calls.get(tx.chain, 0) + 1
            return await adapter.get_internal_txs(tx.tx_hash)
        except Exception as exc:
            self._record_expansion_error(expanding_address, tx.tx_hash, f"get_internal_txs: {exc}")
            return None

    @staticmethod
    def _internal_has_actor_as_sender(
        internal_txs: tuple[NormalizedTransaction, ...],
        actor_address: Address,
    ) -> bool:
        """Return ``True`` iff any internal tx is a successful outbound
        value transfer with ``actor_address`` as ``from_addr``."""
        actor_key = _addr_key(actor_address)
        for itx in internal_txs:
            if itx.from_addr is None:
                continue
            if _addr_key(itx.from_addr) != actor_key:
                continue
            if itx.status == 0:
                continue
            if itx.value_native.raw <= 0:
                continue
            return True
        return False

    @staticmethod
    def _is_clearly_outgoing_no_io(
        tx: NormalizedTransaction,
        node_address: Address,
    ) -> bool:
        """Cheap, IO-free direction check used by the round-15 cap pre-filter.

        Returns ``True`` only when the TX can be classified as outgoing
        WITHOUT an adapter call. The full direction filter at
        ``_process_tx`` is richer — it falls back to ``get_internal_txs``
        for EVM contract-as-sender patterns — but the cap pre-filter
        cannot afford an extra adapter round-trip per skipped TX, and
        ambiguous TXs never reach this helper because they fall through
        to the per-TX path (we keep them in ``items``).

        The helper mirrors the cheap branches of ``_process_tx``:

        * EVM: ``tx.from_addr == node_address`` is unambiguously
          outgoing. ``from_addr != node_address`` is ambiguous (could be
          a contract-call payout pattern) and we conservatively return
          ``False`` so the cap pre-filter does NOT promote post-window
          ambiguous TXs to ``TIME_WINDOW``. Such TXs are forward-walking
          on EVM (Etherscan ``startblock`` keeps them in
          chronological order), so cap-starvation by post-window
          ambiguous TXs is not a realistic adapter pattern.

        * BTC: outgoing iff the address is ``vin[0]`` OR is not
          exclusively a vout (multi-input ``vin[1+]`` case). Mirrors the
          round-11 BTC heuristic in ``_process_tx`` line-for-line. The
          niche change-to-self false-reject is consistent across the two
          paths (the per-TX path makes the same trade-off).
        """
        node_key = _addr_key(node_address)
        chain = node_address.chain
        if chain == ChainId.BITCOIN:
            if tx.from_addr is not None and _addr_key(tx.from_addr) == node_key:
                return True
            # Address appears as a vout AND not vin[0] → incoming. The
            # negated form (``not any``) reads as "address is NOT
            # exclusively a vout" which is the round-11 outgoing
            # heuristic; ruff SIM103 prefers this inline form over a
            # split if/return.
            return not any(
                t.to_addr is not None and _addr_key(t.to_addr) == node_key for t in tx.transfers
            )
        # EVM (and any future non-BTC chain): only ``from_addr == node``
        # is unambiguously outgoing without an adapter call. Contract
        # payout patterns are intentionally classified as "not clearly
        # outgoing" so they do not count toward TIME_WINDOW promotion at
        # the cap pre-filter; they reach ``_process_tx`` via the
        # ``items`` path when in-window, and never starve the cap when
        # out-of-window because forward-walking EVM adapters return
        # in-window history first.
        return tx.from_addr is not None and _addr_key(tx.from_addr) == node_key

    @staticmethod
    def _is_clearly_incoming_no_io(
        tx: NormalizedTransaction,
        node_address: Address,
    ) -> bool:
        """Round 38 codex P2 helper: classify TXs that are unambiguously
        incoming WITHOUT an adapter call, so the cap pre-filter can skip
        them and keep slots free for outgoing rows.

        Returns ``True`` only when the TX is definitively incoming
        (cannot disguise an outgoing internal payout). This is the
        complement of :meth:`_is_clearly_outgoing_no_io` — together they
        partition TXs into {clearly outgoing, clearly incoming,
        ambiguous}. Pre-filter callers want to skip clearly-incoming
        rows; ambiguous rows MUST stay in ``items`` so ``_process_tx``
        can resolve them via ``get_internal_txs``.

        * BTC: clearly incoming iff the node appears in ``transfers``
          (vouts) AND is NOT ``vin[0]``. Mirrors the negated form of
          :meth:`_is_clearly_outgoing_no_io`. BTC has no internal-tx
          surface, so the IO-free direction signal is exhaustive.
        * EVM: ALWAYS returns ``False``. An EVM TX with
          ``to_addr == node_address`` (top-level direction TO the node)
          can still be the round-12 P2-3 contract-as-sender pattern:
          the node is a contract that receives an external call and
          pays out via internal subcalls. Without an
          ``adapter.get_internal_txs`` round-trip we cannot distinguish
          "pure receive" from "contract receives + internal payout",
          so the cap pre-filter must keep these TXs in ``items`` so
          ``_process_tx`` can resolve them via the internal-tx fetch.
          Codex round 38 P2 surfaced an EOA-receive case the cap-fill
          regression affects; tightening that without calling
          ``get_internal_txs`` would re-break the round-12 contract
          payout path. The EVM cap-fill issue is therefore left to
          P1-018 (HeuristicLabelerService) which can pre-classify
          contract-vs-EOA via the labeler cache.
        """
        node_key = _addr_key(node_address)
        chain = node_address.chain
        if chain == ChainId.BITCOIN:
            if tx.from_addr is not None and _addr_key(tx.from_addr) == node_key:
                return False  # vin[0] is node → outgoing
            return any(
                t.to_addr is not None and _addr_key(t.to_addr) == node_key for t in tx.transfers
            )
        # EVM: ambiguous without an adapter call — keep in items.
        return False

    async def _derive_internal_tx_edge_pairs(
        self,
        tx: NormalizedTransaction,
        *,
        expanding_address: Address,
        prefetched_internal_txs: tuple[NormalizedTransaction, ...] | None = None,
    ) -> list[tuple[FlowEdge, Address | None]]:
        """Fetch + emit ``EdgeKind.INTERNAL`` edges from EVM internal-tx traces.

        Round 4 codex P2-2: contract-withdrawal / fallback-receive flows hide
        their value movement in CALL / CREATE sub-frames that the
        ``account/txlistinternal`` Etherscan endpoint surfaces. The tracer
        previously ignored this surface; this helper bridges the gap.

        Caller (``_expand_tx``) gates on ``tx.chain.is_evm`` so this method
        never runs against BTC, whose adapter returns ``()`` for
        ``get_internal_txs`` regardless. A fetch failure is recorded as an
        expansion error and treated as "no internal txs" — the trace must
        not abort because the optional internal surface is unavailable.

        Round 12 codex P2-3: ``prefetched_internal_txs`` lets the caller
        thread already-fetched internal txs through (avoiding a second
        adapter call when ``_process_tx`` had to peek at internals to
        decide whether to direction-reject an EVM TX).

        Per-internal-tx filters:
        * Skip rows with missing endpoints (``from_addr`` / ``to_addr``).
        * Skip rows with ``value_native <= 0`` (fee/state-only sub-frames).
        * Apply the chain's ``min_value_native`` threshold the same way
          plain native transfers are gated.
        """
        if prefetched_internal_txs is not None:
            internal_txs = prefetched_internal_txs
        else:
            try:
                adapter = self._adapters.get(tx.chain)
            except KeyError as exc:
                self._record_expansion_error(expanding_address, tx.tx_hash, str(exc))
                return []

            try:
                self._adapter_calls[tx.chain] = self._adapter_calls.get(tx.chain, 0) + 1
                internal_txs = await adapter.get_internal_txs(tx.tx_hash)
            except Exception as exc:
                self._record_expansion_error(
                    expanding_address, tx.tx_hash, f"get_internal_txs: {exc}"
                )
                return []

        if not internal_txs:
            return []

        # PB-003.1: a deep-expand sink's ONWARD internal edges clear the lower
        # deep floor, keyed on the EXPANDING sink (the causal/economic source),
        # NOT ``internal_tx.from_addr``. An EOA sink's onward value routinely
        # moves as an internal sub-frame whose mechanical sender is the router /
        # contract it called — keying on that mechanical sender would drop the
        # dominant EOA→contract onward leg (the sub-frame IS the sink's
        # re-dispersal; its recipient, ``internal_tx.to_addr``, is the enqueued
        # child, never the router). An INBOUND sub-frame (``pool → sink``: a
        # borrow / withdrawal / refund) keeps the global floor via
        # ``_onward_deep_floor`` (per-row, since ``to_addr`` varies). Empty set →
        # global fallback.
        global_threshold = self._policy.min_value_native.get(tx.chain, 0)
        results: list[tuple[FlowEdge, Address | None]] = []
        for internal_tx in internal_txs:
            if internal_tx.from_addr is None or internal_tx.to_addr is None:
                continue
            # Round 5 codex P2-2 fix: skip failed internal subcalls.
            # ``normalize_internal_tx`` encodes Etherscan ``isError="1"`` as
            # ``status == 0`` (P1-002 / `_etherscan_v2.py:539`); a reverted
            # subcall moved no value on-chain even when the outer TX
            # succeeded (sibling subcalls still settled), so emitting an
            # INTERNAL edge for it would create a phantom transfer. The
            # strict ``== 0`` check leaves status-None / status-1 rows
            # untouched.
            if internal_tx.status == 0:
                continue
            if internal_tx.value_native.raw <= 0:
                continue
            _deep = self._onward_deep_floor(tx.chain, expanding_address, internal_tx.to_addr)
            row_threshold = _deep if _deep is not None else global_threshold
            if internal_tx.value_native.raw < row_threshold:
                # Round 27 codex P2 fix: instrument the internal-tx
                # threshold drop the same way the top-level transfer
                # pipeline does, so the seed precedence ladder can
                # promote NO_OUTGOING -> VALUE_SUB_THRESHOLD when the
                # only seed-derived flow was a sub-threshold internal
                # transfer.
                self._sub_threshold_drops += 1
                continue
            edge = FlowEdge(
                source=internal_tx.from_addr,
                target=internal_tx.to_addr,
                kind=EdgeKind.INTERNAL,
                value_minor=internal_tx.value_native.raw,
                asset_symbol=tx.chain.native_symbol,
                decimals=tx.chain.native_decimals,
                tx_hash=tx.tx_hash,
                block=internal_tx.block,
            )
            child = (
                internal_tx.to_addr
                if _addr_key(internal_tx.to_addr) != _addr_key(expanding_address)
                else None
            )
            results.append((edge, child))
        return results

    def _upsert_node(
        self,
        *,
        address: Address,
        depth: int,
        first_seen_tx: TxRef,
        first_seen_at: datetime,
    ) -> tuple[GraphNode, bool]:
        """Insert a node if it does not yet exist.

        Returns ``(node, was_new)`` so callers can distinguish a fresh
        enqueue from a no-op upsert against an already-known address. Round
        7 codex P2: ``_expand_address`` uses ``was_new`` to count only newly
        enqueued children toward ``expandable_children`` so cycle / duplicate
        destinations do not mask the BRANCHING_LIMIT terminal reason.

        Round 10 codex P2-2: when an address that was previously inserted at
        a deeper depth is re-upserted at a shallower depth (e.g. address
        first inserted as a depth-2 child, then later observed as a depth-1
        edge source within the same TX), update the stored depth and
        re-prioritise the frontier entry. Pre-fix: this method early-returned
        and preserved the deeper depth, leading to incorrect graph metrics
        (the node would be reported at depth 2 even though it was a direct
        child of the seed) and incorrect frontier ordering. The shallower
        depth wins because BFS semantics define a node's depth as the
        SHORTEST path length from the seed. Already-popped nodes (i.e.
        nodes whose expansion has already started) do not get an updated
        depth — the BFS has already committed to the stored depth for that
        node, and reverting it would risk re-expanding through a node that
        was already terminated.

        Round 17 codex P1 fix: when the existing record is at the SAME
        depth, the earliest ``first_seen_at`` wins. Pre-fix: the same-depth
        branch returned the existing node without comparing timestamps, so
        if two depth-N parents reached the same child and the later-arriving
        path was processed first, the child kept the later timestamp; its
        own expansion's ``forward_walk`` filter then incorrectly rejected
        legitimate spends that happened between the earlier and later
        arrivals. Post-fix: ``first_seen_at`` (and ``first_seen_tx``) are
        replaced with the earlier observation. The ``Frontier`` ordering
        rule does NOT depend on ``first_seen_at`` (depth ASC → key ASC),
        so no re-prioritisation is needed; we still attempt
        ``update_priority`` so the queue entry mirrors the updated node
        record (and silently honours the popped-already case).
        """
        # Round 11 codex P2 fix: chain-aware canonical key preserves BTC
        # Base58Check case (case-sensitive) so two distinct base58 addresses
        # differing only by case do NOT collide in ``self._nodes``.
        key = canonical_address_key(address)
        existing = self._nodes.get(key)
        if existing is not None:
            if depth < existing.depth:
                # Round 10 codex P2-2: re-prioritise iff the existing node is
                # still in the frontier. ``Frontier.update_priority`` returns
                # ``False`` when the node has already been popped, in which
                # case mutating ``self._nodes[key]`` to the shallower depth
                # would create an inconsistency with the BFS expansion the
                # frontier already performed at the deeper depth. Only
                # reprioritise when we can ALSO update the queue position.
                # Round 17 codex P1: when promoting depth, also adopt the
                # incoming ``first_seen_at`` / ``first_seen_tx`` if they are
                # earlier — the shallower-depth observation typically arrives
                # via the seed path with the seed timestamp, which is by
                # definition <= any later first-seen attribution.
                update_fields: dict[str, Any] = {"depth": depth}
                if first_seen_at < existing.first_seen_at:
                    update_fields["first_seen_at"] = first_seen_at
                    update_fields["first_seen_tx"] = first_seen_tx
                updated = existing.model_copy(update=update_fields)
                if self._frontier.update_priority(updated):
                    self._nodes[key] = updated
                    return updated, False
            elif depth == existing.depth and first_seen_at < existing.first_seen_at:
                # Round 17 codex P1: same depth, earlier arrival wins. The
                # frontier ordering (depth ASC → key ASC) does not depend on
                # ``first_seen_at``, but if the node is still queued we
                # still call ``update_priority`` to keep the queued entry
                # in sync with ``self._nodes[key]``. If the node has
                # already been popped (``update_priority`` returns False)
                # we still update ``self._nodes[key]`` because subsequent
                # operations — most notably ``_process_tx``'s
                # ``forward_walk`` filter (``tx.block.timestamp <
                # node.first_seen_at``) — read the timestamp directly from
                # ``self._nodes`` rather than the queue entry; a stale
                # later-arrival timestamp would falsely reject in-window
                # spends between the earlier and later arrivals.
                updated = existing.model_copy(
                    update={
                        "first_seen_at": first_seen_at,
                        "first_seen_tx": first_seen_tx,
                    }
                )
                self._frontier.update_priority(updated)
                self._nodes[key] = updated
                return updated, False
            return existing, False
        node = GraphNode(
            address=address,
            depth=depth,
            label=None,
            first_seen_tx=first_seen_tx,
            first_seen_at=first_seen_at,
            terminal=False,
        )
        self._nodes[key] = node
        self._frontier.push(node)
        return node, True

    def _mark_terminal(self, node: GraphNode, reason: TerminationReason) -> None:
        self._terminal_reasons.setdefault(node.canonical_key, reason)

    async def _fetch_label_cached(self, node: GraphNode) -> Any:
        key = node.canonical_key
        if key in self._label_cache:
            return self._label_cache[key]
        try:
            label = await self._labeler.fetch_label(node.address)
        except Exception as exc:
            # Round 34 codex P1 fix (extended): labeler implementations
            # may consult external services (Etherscan label endpoint,
            # OFAC list mirrors, etc.) whose httpx exceptions embed the
            # request URL with embedded API keys. Apply
            # :func:`_redact_secrets` so credentials cannot leak into
            # application logs via this warning.
            logger.warning(
                "labeler_service.fetch_label raised on addr=%s: %s",
                node.address.value,
                _redact_secrets(str(exc)),
            )
            label = None
        self._label_cache[key] = label
        return label

    async def _fetch_logs_safe(
        self, address: Address, tx: NormalizedTransaction
    ) -> tuple[NormalizedLog, ...] | None:
        try:
            adapter = self._adapters.get(tx.chain)
            self._adapter_calls[tx.chain] = self._adapter_calls.get(tx.chain, 0) + 1
            return await adapter.get_logs(tx.tx_hash)
        except Exception as exc:
            self._record_expansion_error(address, tx.tx_hash, str(exc))
            return None

    def _record_expansion_error(self, address: Address, tx_hash: str | None, error: str) -> None:
        if len(self._expansion_errors) >= _EXPANSION_ERRORS_CAP:
            self._expansion_errors_overflow += 1
            return
        # Round 30 codex P1 fix: redact API keys / bearer tokens before
        # the error string lands in ``CaseGraph.metadata['expansion_errors']``.
        # Adapter exceptions raised by ``httpx`` typically include the
        # full request URL in ``str(exc)``, so any caller that does
        # ``self._record_expansion_error(addr, hash, str(exc))`` would
        # otherwise leak the Etherscan ``apikey`` query parameter into
        # exported trace artifacts.
        self._expansion_errors.append(
            {
                "address": str(address),
                "error": _redact_secrets(error),
                "tx_hash": tx_hash,
            }
        )

    def _make_cross_chain_edge(
        self,
        *,
        actor: Address,
        tx: NormalizedTransaction,
        hop: CrossChainHop,
        decoder_name: str,
    ) -> FlowEdge:
        # P2-002.2: ``CrossChainHop`` has no ``extras`` field (see
        # ``normalized.py:972`` model definition); cross-chain semantic
        # intent is fully captured in hop fields (via/memo/asset_in/
        # asset_out). Symmetry with ``_make_defi_edge`` does NOT require
        # adding an ``extras`` field to ``CrossChainHop`` in this slice —
        # that is a Phase 3 horizontal-expansion concern when new
        # cross-chain bridges introduce non-hop metadata.
        return FlowEdge(
            source=actor,
            target=hop.dst_address,
            kind=EdgeKind.CROSS_CHAIN,
            value_minor=hop.amount_in.raw,
            asset_symbol=hop.asset_in.symbol,
            decimals=hop.asset_in.decimals,
            # SOURCE-side token identity (mirrors the source-side asset_symbol /
            # decimals above); ``None`` when the bridged-in asset is native.
            asset_contract=hop.asset_in.contract,
            tx_hash=tx.tx_hash,
            block=tx.block,
            decoder=decoder_name,
            hop=hop,
        )

    @staticmethod
    def _defi_edge_endpoints(action: DefiAction, actor: Address) -> tuple[Address, Address]:
        """Direction-aware ``(source, target)`` for a DeFi action's FlowEdge.

        Round 22 codex P2-2: the FlowEdge direction must follow the actual
        value-flow, not always ``actor → pool``. BORROW / COLLATERAL_WITHDRAW
        disburse ``pool → actor``; COLLATERAL_SUPPLY / REPAY move ``actor →
        pool``. See ``DefiActionKind`` in :mod:`vca.decoders.base` — the closed
        4-member vocabulary keeps this membership dispatch exhaustive (the
        ``else`` is defence-in-depth for a future kind).

        Shared by :meth:`_make_defi_edge` and the decoder value-gate so the
        PB-003.1 deep-floor source-gate can be computed from the DIRECTION-AWARE
        source WITHOUT constructing the FlowEdge — preserving the original
        threshold-BEFORE-validation ordering (a sub-threshold action must be
        dropped, not built into an edge that could raise a validation error).
        """
        action_actor = action.actor if action.actor is not None else actor
        action_pool = action.pool if action.pool is not None else action_actor
        if action.kind in (DefiActionKind.BORROW, DefiActionKind.COLLATERAL_WITHDRAW):
            return action_pool, action_actor
        return action_actor, action_pool

    def _make_defi_edge(
        self,
        *,
        actor: Address,
        tx: NormalizedTransaction,
        action: DefiAction,
        decoder_name: str,
    ) -> FlowEdge:
        source, target = self._defi_edge_endpoints(action, actor)
        # P2-002.2: propagate ``DefiAction.extras`` → ``FlowEdge.extras``
        # (P2-002.0 R-7 deferred). Frozen extras pass through
        # ``FlowEdge._freeze_extras`` idempotently — see
        # :mod:`vca.types._extras_freeze` round-trip tests.
        return FlowEdge(
            source=source,
            target=target,
            kind=EdgeKind.DEFI,
            value_minor=action.amount.raw,
            asset_symbol=action.asset.symbol,
            decimals=action.asset.decimals,
            # True token identity of the DeFi action's asset (scan #16 Lens B);
            # ``None`` when the action moved a native coin.
            asset_contract=action.asset.contract,
            tx_hash=tx.tx_hash,
            block=tx.block,
            decoder=decoder_name,
            extras=action.extras,
        )

    def _handle_unregistered_dst_chain(
        self,
        dst_address: Address,
        tx: NormalizedTransaction,
        *,
        source_addr: Address,
        depth: int,
    ) -> None:
        """Soft-fail: the destination chain has no registered adapter.

        Per WBS R-CROSS-CHAIN-SOFT-FAIL: emit a terminal node + EXPANSION_ERROR
        and continue. ``depth`` is the actual graph depth of the unreachable
        node — the parent's ``depth + 1`` — *not* a sentinel; the original
        ``999`` value misled downstream consumers (P1-014 codex round 1).
        """
        del source_addr
        node, _ = self._upsert_node(
            address=dst_address,
            depth=depth,
            first_seen_tx=TxRef(chain=tx.chain, tx_hash=tx.tx_hash),
            first_seen_at=tx.block.timestamp,
        )
        self._record_expansion_error(
            dst_address,
            tx.tx_hash,
            f"destination chain {dst_address.chain.value} not registered",
        )
        self._mark_terminal(node, TerminationReason.EXPANSION_ERROR)

    @staticmethod
    def _is_boundary_edge(edge: FlowEdge) -> str | None:
        """Inspect ``edge.extras`` for a Stage 8 boundary marker.

        Returns the matched ``stage_label`` string when the edge is a
        recognised boundary; ``None`` otherwise. The four gates that
        must hold (parity with the rank-5 classifier predicate
        :func:`vca.tracer.stage_classifier._heuristics._out_of_scope_boundary_problem`,
        codex pre-emptions F-B / F-C):

            1. ``edge.kind == EdgeKind.DEFI`` (R-KIND-OVERRIDE-DEFI-ONLY).
            2. ``edge.extras["kind_override"]`` is a string equal to
               :data:`_BRIDGE_OUT_BOUNDARY_KIND_OVERRIDE`.
            3. ``edge.extras["stage_label"]`` is a string.
            4. The stage label is in
               :data:`_KNOWN_OUT_OF_SCOPE_STAGE_LABELS_TRACER`
               (R-OUT-OF-SCOPE-BOUNDARY-FROZENSET — unknown future
               chains defer to fallback rather than terminate).

        Pure function so the call-site hook in :meth:`_expand_tx`
        compiles to a single short-circuit branch.
        """
        if edge.kind != EdgeKind.DEFI:
            return None
        override = edge.extras.get("kind_override")
        if not isinstance(override, str):
            return None
        if override != _BRIDGE_OUT_BOUNDARY_KIND_OVERRIDE:
            return None
        stage_label_value = edge.extras.get("stage_label")
        if not isinstance(stage_label_value, str):
            return None
        if stage_label_value not in _KNOWN_OUT_OF_SCOPE_STAGE_LABELS_TRACER:
            return None
        return stage_label_value

    def _record_boundary_exit(
        self,
        *,
        edge: FlowEdge,
        tx: NormalizedTransaction,
        stage_label_value: str,
        depth: int,
    ) -> None:
        """P2-008.3 — Upsert boundary target, mark terminal, stamp metadata.

        Architectural twin of :meth:`_handle_unregistered_dst_chain`:
        upsert the target node + mark it terminal so the BFS frontier
        never expands it. The semantic difference is the
        :class:`TerminationReason` — boundary exits use
        :attr:`TerminationReason.TERMINAL_LABEL` (off-chain account
        behaves like a CEX / MIXER terminal) while unregistered chains
        use :attr:`TerminationReason.EXPANSION_ERROR`.

        Side-effects:

            1. Upserts ``edge.target`` at ``depth`` (parent ``depth + 1``
               for follow-on TXs; depth-1 for the seed expansion path).
            2. Marks the upserted node
               :attr:`TerminationReason.TERMINAL_LABEL`.
            3. Appends a 5-key dict (``stage_label``, ``bridge``,
               ``destination_chain``, ``edge_id``, ``target_canonical_key``)
               to ``self._pending_boundary_exits`` for the final
               :meth:`execute` merge into
               ``CaseGraph.metadata["boundary_exits"]``
               (R-BOUNDARY-METADATA-PROVENANCE — provenance keys held
               constant for downstream P2-008.4 reporter consumption).

        The caller (the ``_expand_tx`` BFS hook) is responsible for
        coercing ``child=None`` in ``edge_child_pairs`` so the boundary
        target is never enqueued (R-BOUNDARY-CHILD-COERCION).
        """
        target = edge.target
        node, _ = self._upsert_node(
            address=target,
            depth=depth,
            first_seen_tx=TxRef(chain=tx.chain, tx_hash=tx.tx_hash),
            first_seen_at=tx.block.timestamp,
        )
        self._mark_terminal(node, TerminationReason.TERMINAL_LABEL)
        # Tracer-local edge_id — deterministic per-edge string suitable
        # for the metadata side-channel. Mirrors the structural fields
        # used by the classifier's edge_id but stays decoupled from the
        # classifier module (R-PURE — tracer MUST NOT import classifier).
        # The metadata is consumed by P2-008.4 reporter rendering; the
        # exact format is held stable so the reporter (and downstream
        # JSON exporters) can key on it without re-deriving.
        bridge_value = edge.extras.get("bridge")
        destination_chain_value = edge.extras.get("destination_chain")
        edge_id_value = (
            f"{canonical_address_key(edge.source)}->{canonical_address_key(target)}"
            f"|{edge.tx_hash or ''}|{edge.kind.value}|{edge.decoder or ''}"
            f"|{stage_label_value}"
        )
        self._pending_boundary_exits.append(
            {
                "stage_label": stage_label_value,
                "bridge": str(bridge_value) if isinstance(bridge_value, str) else "",
                "destination_chain": (
                    str(destination_chain_value) if isinstance(destination_chain_value, str) else ""
                ),
                "edge_id": edge_id_value,
                "target_canonical_key": canonical_address_key(target),
            }
        )


__all__ = ["_TraceRun"]
