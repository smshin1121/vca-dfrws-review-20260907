"""StageLabel closed vocabulary + module-level regex constants (P1-015).

Splitting per WBS R-FILE-CAP §10. The 13-member vocabulary is verbatim
from ``docs/source/03_KelpDAO_rsETH_Exploit_분석.md`` lines 77-89.
Adding a member is a public-API change.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from enum import StrEnum
from types import MappingProxyType
from typing import Final

from pydantic import ConfigDict


class StageLabel(StrEnum):
    """13-member closed vocabulary — verbatim from source-doc lines 77-89."""

    STAGE_1 = "Stage 1"
    STAGE_2 = "Stage 2"
    STAGE_3_A = "Stage 3-A"
    STAGE_3_B = "Stage 3-B"
    STAGE_4 = "Stage 4"
    STAGE_5 = "Stage 5"
    STAGE_6 = "Stage 6"
    STAGE_7 = "Stage 7"
    STAGE_8_BTC_L1 = "Stage 8 / BTC L1"
    STAGE_8_BTC_L2 = "Stage 8 / BTC L2"
    STAGE_8_BTC_L3 = "Stage 8 / BTC L3"
    STAGE_8_BTC_L4 = "Stage 8 / BTC L4"
    TRACE_TERMINATED = "추적 종료"


FROZEN_CONFIG: Final[ConfigDict] = ConfigDict(frozen=True, strict=True, extra="forbid")
DECODER_NAME_RE = re.compile(r"[a-z0-9_.-]+")
CASE_ID_RE = re.compile(r"[a-zA-Z0-9_-]+")
# Rationale: heuristic-name prefix (lowercase identifier) + ":" + ASCII payload.
RATIONALE_RE = re.compile(r"[a-z][a-z0-9_]*:[\x20-\x7e]+")

# P2-002.3 — known ``edge.extras["kind_override"]`` values consumed by the
# rank-4 ``is_kind_override`` heuristic. Adding a value here is part of
# extending the classifier to recognise a new DEFI-decoder family.
# Currently:
#   * ``"swap"`` — direct sells (KyberSwap, CoW Protocol, Sky LitePSM)
#   * ``"bridge_send"`` — LayerZero v2 OFT (LZMultiCall)
_KNOWN_KIND_OVERRIDES: Final[frozenset[str]] = frozenset({"swap", "bridge_send"})

# Sentinel value emitted by Stage 8 boundary recognizers (Polygon PoS Bridge,
# Mayan Forwarder). Consumed by the rank-5 ``is_out_of_scope_boundary``
# heuristic (P2-008.3) to drive boundary-aware ``TRACE_TERMINATED`` rationale
# disambiguation. The rank-4 ``is_kind_override`` heuristic explicitly defers
# this value so rank 5 can claim it without colliding with the swap /
# bridge_send mapping rules.
_BRIDGE_OUT_BOUNDARY: Final[str] = "bridge_out_boundary"

# P2-008.3 — known ``edge.extras["stage_label"]`` values consumed by the
# rank-5 ``is_out_of_scope_boundary`` heuristic. The frozenset enumerates
# the two boundary stage labels emitted by Phase 2 boundary recognizers:
#
#   * ``"OUT_OF_SCOPE_POLYGON"`` — Polygon PoS Bridge ``depositFor``
#     (P2-008.0d). Bridges to Polygon; the Polygon-side flow is
#     explicitly out of scope per supplement PDF page 40-41.
#   * ``"OUT_OF_SCOPE_SOLANA_MAYAN"`` — Mayan Forwarder ``forwardERC20``
#     (P2-008.0e). Bridges to Solana via Mayan Swift; the Solana-side
#     flow is explicitly out of scope.
#
# R-OUT-OF-SCOPE-BOUNDARY-FROZENSET: unknown values DEFER to fallback
# (forward-compatibility for future boundary chains; adding a value here
# is part of extending the Phase-2 boundary recognizer fleet).
_KNOWN_OUT_OF_SCOPE_STAGE_LABELS: Final[frozenset[str]] = frozenset(
    {
        "OUT_OF_SCOPE_POLYGON",
        "OUT_OF_SCOPE_SOLANA_MAYAN",
    }
)

# P2-005.3 — known ``AddressLabel.extras["attribution_role"]`` values consumed
# by the rank-5 ``is_address_label_anchor`` heuristic.
#
# CONV-1 correction: this roster is the CONSUMED set, which is NOT the same as
# the EMITTED set. More roles are emitted than are listed here, and the excess
# is deliberate — a role absent from this frozenset simply never promotes to a
# StageLabel. In particular ``"branch_convergence_point"``
# (:class:`~vca.labeler.attribution.ConvergenceLabeler`, wired onto the KelpDAO
# roster by CONV-1) IS emitted and IS rendered by the reporter's separate
# same-named ``_KNOWN_ATTRIBUTION_ROLES`` (``reporting/_context.py``), but is
# intentionally excluded here so it flips zero stages. Do not "fix" the count
# by adding emitted-but-unconsumed roles — that would change stage assignment
# and force a golden re-bless.
#
# The 6 values below are the consumed ones, emitted by:
#
#   * ``SmurfingSweepLabeler`` (P2-005.0)        → ``"smurfing_residual_sweep"``
#   * ``EthBtcRatioDetector``  (P2-006.0)        → ``"eth_btc_ratio_attribution"``
#   * ``PeelingChainLabeler``  (P2-007.0)        → ``"btc_peeling_chain_origin"``
#   * ``CoinJoinPoolEntryLabeler`` (P2-007.0)    → ``"btc_coinjoin_pool_entry"``
#   * ``VaultLabeler`` (P2-007.0)                → ``"btc_vault_address"``
#   * ``BtcAddressReuseDetector`` (P3-XVAL3)     → ``"btc_address_reuse_attribution"``
#
# R-ATTRIBUTION-ROLE-WHITELIST-CLASSIFIER — unknown roles DEFER to fallback
# (forward-compatibility for future attribution labelers; adding a value
# here is part of extending the rank-5 consumption surface to recognise a
# new labeler's marker). The frozenset MUST match
# ``_ATTRIBUTION_ROLE_TO_STAGE.keys()`` exactly (import-time tripwire below).
_KNOWN_ATTRIBUTION_ROLES: Final[frozenset[str]] = frozenset(
    {
        "smurfing_residual_sweep",
        "eth_btc_ratio_attribution",
        "btc_peeling_chain_origin",
        "btc_coinjoin_pool_entry",
        "btc_vault_address",
        "btc_address_reuse_attribution",
    }
)

# P2-005.3 — closed mapping from attribution role → StageLabel consumed by
# the rank-5 ``is_address_label_anchor`` heuristic. The 5 base entries close
# P2-005.3 (smurfing) + P2-006.3 (eth_btc_ratio) + P2-007.3 (BTC pattern
# trio); the 6th (P3-XVAL3) registers the BTC recipient-address reuse role:
#
#   * ``smurfing_residual_sweep``    → ``STAGE_6`` (Stage 6 smurfing sweep)
#   * ``eth_btc_ratio_attribution``  → ``STAGE_7`` (Stage 7 THORChain swap)
#   * ``btc_peeling_chain_origin``   → ``STAGE_8_BTC_L1`` (Stage 8 layered)
#   * ``btc_coinjoin_pool_entry``    → ``STAGE_8_BTC_L1`` (Stage 8 layered)
#   * ``btc_vault_address``          → ``STAGE_8_BTC_L1`` (Stage 8 layered)
#   * ``btc_address_reuse_attribution`` → ``STAGE_8_BTC_L1`` (Stage 8 layered)
#
# ``MappingProxyType`` wrapping makes the mapping read-only at module level.
# Why ``btc_address_reuse_attribution`` → ``STAGE_8_BTC_L1`` (NOT ``STAGE_7``
# like its ``eth_btc_ratio_attribution`` twin): the twin anchors on the EVM
# SOURCE wallet — a cross-chain-relative ETH→BTC swap relationship that
# belongs to the Stage 7 THORChain swap layer. ``BtcAddressReuseDetector``
# (``src/vca/labeler/btc_address_reuse.py``) instead labels the BITCOIN
# RECIPIENT address itself (it enforces ``target_btc_address.chain is
# ChainId.BITCOIN``), reused across ≥2 deposits — a BTC-chain
# re-consolidation address from which Stage 8 BTC layering fans OUT (per the
# detector docstring + supplement PDF "(2) BTC 주소 재사용 패턴": "스머핑으로
# 분신되었던 ETH를 BTC 체인에서 단일 주소로 재통합"). It therefore stages with
# the other 3 BTC-chain roles at the layered-mixing canonical
# ``STAGE_8_BTC_L1`` (per supplement PDF §3.가.3 (5)); finer-grained L2/L3/L4
# disambiguation stays under the rank-10 ``is_btc_layered`` depth-based rule.
_ATTRIBUTION_ROLE_TO_STAGE: Final[Mapping[str, StageLabel]] = MappingProxyType(
    {
        "smurfing_residual_sweep": StageLabel.STAGE_6,
        "eth_btc_ratio_attribution": StageLabel.STAGE_7,
        "btc_peeling_chain_origin": StageLabel.STAGE_8_BTC_L1,
        "btc_coinjoin_pool_entry": StageLabel.STAGE_8_BTC_L1,
        "btc_vault_address": StageLabel.STAGE_8_BTC_L1,
        "btc_address_reuse_attribution": StageLabel.STAGE_8_BTC_L1,
    }
)

# Import-time tripwire — keys MUST match the whitelist frozenset exactly.
# Catches drift if either constant is amended in isolation.
assert _ATTRIBUTION_ROLE_TO_STAGE.keys() == _KNOWN_ATTRIBUTION_ROLES, (
    "_ATTRIBUTION_ROLE_TO_STAGE.keys() must match _KNOWN_ATTRIBUTION_ROLES"
)


__all__ = [
    "CASE_ID_RE",
    "DECODER_NAME_RE",
    "FROZEN_CONFIG",
    "RATIONALE_RE",
    "_ATTRIBUTION_ROLE_TO_STAGE",
    "_BRIDGE_OUT_BOUNDARY",
    "_KNOWN_ATTRIBUTION_ROLES",
    "_KNOWN_KIND_OVERRIDES",
    "_KNOWN_OUT_OF_SCOPE_STAGE_LABELS",
    "StageLabel",
]
