"""Frontier-based BFS orchestrator (P1-014).

Single-threaded async BFS over the transaction graph. SOLE public
entrypoint: :meth:`Tracer.trace`. Returns a fully-frozen
:class:`vca.tracer.CaseGraph`.

Per-call mutable state lives in :class:`vca.tracer._run._TraceRun` so a
single :class:`Tracer` instance can run multiple concurrent ``trace()``
calls without sharing intermediate caches.

Design constraints (cross-cut):

* No persistence (DoD-23): no imports from :mod:`vca.persistence` /
  :mod:`vca.http`; no ``httpx`` / ``sqlalchemy`` / ``aiolimiter``.
* No concurrency primitives (DoD-26 / R-VISITED-CONCURRENCY): no
  ``asyncio.gather``, ``asyncio.create_task``, ``asyncio.run``.
* Monotonic-time metrics (R-METRICS-MONOTONIC):
  ``metrics.duration_seconds`` from ``time.monotonic`` deltas; the
  ``started_at`` / ``finished_at`` wall-clock fields are diagnostic only.
* Deterministic ordering (R-DETERMINISM): node order = depth ASC then
  canonical_key ASC; edge order = ``(source.canonical_key,
  target.canonical_key, tx_hash or "", kind.value)`` ASC; iteration over
  ``terminal_reasons`` is canonical_key ASC.
* Cross-chain soft-fail (R-CROSS-CHAIN-SOFT-FAIL): unregistered
  destination chain emits a terminal node + EXPANSION_ERROR; trace
  continues. Seed-chain unregistered raises hard.
"""

from __future__ import annotations

import inspect
from collections.abc import Callable
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from vca.adapters import AdapterRegistry
from vca.decoders import DecoderRegistry
from vca.tracer._run import _TraceRun
from vca.tracer.graph import CaseGraph, TxRef
from vca.tracer.labeler_service import LabelerService
from vca.tracer.policy import TracePolicy

if TYPE_CHECKING:  # pragma: no cover - import-time only, kept off the runtime path
    # See ``vca.tracer._run`` for the rationale: abi_fallback transitively
    # imports ``httpx`` and is only referenced here as an optional parameter
    # type hint.
    from vca.decoders.abi_fallback import AbiFallbackResolver


def _default_clock() -> datetime:
    """Default ``clock`` — wall-clock UTC ``now()``."""
    return datetime.now(UTC)


class Tracer:
    """Frontier-based BFS orchestrator. SOLE entrypoint: :meth:`trace`.

    Per WBS DoD-14 the constructor is keyword-only. The ``clock`` argument
    enables deterministic-time tests (R-CLOCK-INJECTABLE); production
    callers omit it and get wall-clock UTC.
    """

    def __init__(
        self,
        *,
        adapter_registry: AdapterRegistry,
        decoder_registry: DecoderRegistry,
        labeler_service: LabelerService,
        policy: TracePolicy,
        abi_fallback: AbiFallbackResolver | None = None,
        clock: Callable[[], datetime] = _default_clock,
    ) -> None:
        if not isinstance(labeler_service, LabelerService):
            raise TypeError(
                f"labeler_service must implement LabelerService Protocol "
                f"(missing async fetch_label), got {type(labeler_service).__name__}"
            )
        # Round 8 codex P2-3 fix: ``runtime_checkable`` Protocols only check
        # attribute presence, not coroutine semantics. A class that defines
        # ``fetch_label`` synchronously passes the ``isinstance`` check above
        # but produces a non-awaitable return, which the (now-removed)
        # ``try/except TypeError`` around ``await`` in ``_TraceRun._fetch_label_cached``
        # silently swallowed. Enforce async at construction so the bug surfaces
        # immediately instead of corrupting label resolution at runtime.
        if not inspect.iscoroutinefunction(labeler_service.fetch_label):
            raise TypeError(
                "labeler_service.fetch_label must be an async coroutine function "
                f"(runtime_checkable Protocols don't enforce async signatures); "
                f"got {type(labeler_service.fetch_label).__name__} "
                f"on {type(labeler_service).__name__}"
            )
        self._adapters = adapter_registry
        self._decoders = decoder_registry
        self._labeler = labeler_service
        self._policy = policy
        self._abi_fallback = abi_fallback
        self._clock = clock

    async def trace(self, *, case_id: str, seed_tx: TxRef) -> CaseGraph:
        """Walk the transaction graph by BFS and return a frozen ``CaseGraph``.

        Raises :class:`vca.tracer.TracerExpansionError` on unrecoverable
        failures (seed-chain adapter not registered, seed-TX fetch
        failure). Per-address recoverable failures are recorded in
        ``CaseGraph.metadata["expansion_errors"]`` and do NOT abort.
        """
        run = _TraceRun(
            case_id=case_id,
            seed_tx=seed_tx,
            adapters=self._adapters,
            decoders=self._decoders,
            labeler=self._labeler,
            policy=self._policy,
            abi_fallback=self._abi_fallback,
            clock=self._clock,
        )
        return await run.execute()


__all__ = ["Tracer"]
