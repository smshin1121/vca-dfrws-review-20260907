"""StagePolicy frozen DTO (P1-015 DoD-5)."""

from __future__ import annotations

from collections.abc import Mapping
from datetime import timedelta
from types import MappingProxyType
from typing import Self

from pydantic import BaseModel, Field, field_serializer, model_validator

from vca.tracer.stage_classifier._vocab import (
    DECODER_NAME_RE,
    FROZEN_CONFIG,
    StageLabel,
)

# Codex P1-015 R8 finding #2 — decoder names are bounded so the rationale
# strings produced by ``cross_chain_outcome`` / ``defi_outcome`` (which
# embed the decoder verbatim) cannot exceed the ``StageAssignment.rationale``
# 256-char limit. Real decoder identifiers are short (``aave_v3``,
# ``thorchain.v1``, ``layerzero_v2``), so 64 chars is generous; failing at
# policy construction time is the right place to reject pathological inputs.
_DECODER_NAME_MAX_LENGTH = 64

_DEFAULT_DEFI_DECODERS: frozenset[str] = frozenset({"aave_v3", "compound_v3", "euler_v2"})
_DEFAULT_CROSS_CHAIN_MAP: Mapping[str, StageLabel] = MappingProxyType(
    {
        "layerzero_v2": StageLabel.STAGE_3_B,
        "thorchain.v1": StageLabel.STAGE_7,
    }
)
_DEFAULT_BTC_DEPTHS: Mapping[int, StageLabel] = MappingProxyType(
    {
        0: StageLabel.STAGE_8_BTC_L1,
        1: StageLabel.STAGE_8_BTC_L2,
        2: StageLabel.STAGE_8_BTC_L3,
        3: StageLabel.STAGE_8_BTC_L4,
    }
)


def _default_cross_chain_map() -> Mapping[str, StageLabel]:
    return MappingProxyType(dict(_DEFAULT_CROSS_CHAIN_MAP))


def _default_btc_depths() -> Mapping[int, StageLabel]:
    return MappingProxyType(dict(_DEFAULT_BTC_DEPTHS))


class StagePolicy(BaseModel):
    """Frozen tuning knobs for :func:`classify_stages`."""

    model_config = FROZEN_CONFIG

    fan_window: timedelta = Field(default=timedelta(seconds=600))
    fan_threshold: int = Field(default=3, ge=2, le=10000)
    smurf_threshold: int = Field(default=3, ge=2, le=10000)
    smurf_value_tolerance_bps: int = Field(default=50, ge=0, le=10000)
    defi_decoder_names: frozenset[str] = Field(default_factory=lambda: _DEFAULT_DEFI_DECODERS)
    cross_chain_decoder_stage_map: Mapping[str, StageLabel] = Field(
        default_factory=_default_cross_chain_map
    )
    btc_layer_depths: Mapping[int, StageLabel] = Field(default_factory=_default_btc_depths)

    @model_validator(mode="after")
    def _validate_fan_window(self) -> Self:
        if self.fan_window <= timedelta(0):
            raise ValueError(f"StagePolicy.fan_window must be positive, got {self.fan_window}")
        return self

    @model_validator(mode="after")
    def _validate_defi_decoders(self) -> Self:
        for name in self.defi_decoder_names:
            # Codex P1-015 R8 finding #2 — bound the decoder name so the
            # ``defi_collateral:decoder=<name>`` rationale string fits the
            # 256-char limit on ``StageAssignment.rationale`` values.
            if len(name) < 1 or len(name) > _DECODER_NAME_MAX_LENGTH:
                raise ValueError(
                    f"StagePolicy.defi_decoder_names entry length must be in "
                    f"[1, {_DECODER_NAME_MAX_LENGTH}], got: {len(name)} "
                    f"(name={name!r})"
                )
            if not DECODER_NAME_RE.fullmatch(name):
                raise ValueError(
                    f"StagePolicy.defi_decoder_names entry must match [a-z0-9_.-]+, got: {name!r}"
                )
        return self

    @model_validator(mode="after")
    def _validate_cross_chain_map(self) -> Self:
        # Pydantic strict mode already enforces ``Mapping[str, StageLabel]``
        # types; this validator only adds the decoder-name charset check
        # and the MappingProxy wrap.
        for key in self.cross_chain_decoder_stage_map:
            # Codex P1-015 R8 finding #2 — same length bound as
            # ``defi_decoder_names`` so ``cross_chain_hop:decoder=<key>``
            # rationale strings cannot overflow the 256-char rationale cap.
            if len(key) < 1 or len(key) > _DECODER_NAME_MAX_LENGTH:
                raise ValueError(
                    f"StagePolicy.cross_chain_decoder_stage_map key length must be in "
                    f"[1, {_DECODER_NAME_MAX_LENGTH}], got: {len(key)} (key={key!r})"
                )
            if not DECODER_NAME_RE.fullmatch(key):
                raise ValueError(
                    f"StagePolicy.cross_chain_decoder_stage_map key must match "
                    f"[a-z0-9_.-]+, got: {key!r}"
                )
        object.__setattr__(
            self,
            "cross_chain_decoder_stage_map",
            MappingProxyType(dict(self.cross_chain_decoder_stage_map)),
        )
        return self

    @model_validator(mode="after")
    def _validate_btc_layer_depths(self) -> Self:
        # Pydantic strict mode already enforces ``Mapping[int, StageLabel]``;
        # this validator only checks the non-negative key invariant + wrap.
        for key in self.btc_layer_depths:
            if key < 0:
                raise ValueError(f"StagePolicy.btc_layer_depths key must be >= 0, got: {key}")
        object.__setattr__(
            self,
            "btc_layer_depths",
            MappingProxyType(dict(self.btc_layer_depths)),
        )
        return self

    @field_serializer("cross_chain_decoder_stage_map")
    def _serialize_cross_chain_map(self, value: Mapping[str, StageLabel]) -> dict[str, str]:
        return {k: v.value for k, v in sorted(value.items())}

    @field_serializer("btc_layer_depths")
    def _serialize_btc_depths(self, value: Mapping[int, StageLabel]) -> dict[str, str]:
        return {str(k): v.value for k, v in sorted(value.items())}

    @field_serializer("defi_decoder_names")
    def _serialize_defi_decoders(self, value: frozenset[str]) -> list[str]:
        return sorted(value)


__all__ = ["StagePolicy"]
