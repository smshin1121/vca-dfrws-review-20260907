"""Internal BFS queue with depth-first ordering and dedup-by-canonical-key.

The :class:`Frontier` is **not** part of the public surface — not exported
by :mod:`vca.tracer`. Tests access it directly via
``vca.tracer.frontier``. The class is intentionally policy-free: the
tracer enforces ``max_depth`` itself; ``Frontier`` is just a deterministic
ordered queue with a permanent dedupe set.

Ordering (R-DETERMINISM): depth ASC → ``(chain.value, addr.value.lower())``
ASC. The dedupe set is permanent — re-pushing an already-visited address
is a no-op even after the first visit has been popped.
"""

from __future__ import annotations

from collections import deque

from vca.tracer.graph import GraphNode
from vca.tracer.policy import TracePolicy


class Frontier:
    """Internal BFS queue with depth-first ordering and dedup-by-canonical-key.

    Methods:
        push: enqueue a node; no-op when the node's ``canonical_key`` has
            already been seen.
        pop: dequeue the next node by ordering rule; returns ``None`` on
            empty.
        update_priority: re-prioritise an already-enqueued node when its
            depth is reduced (shallower depth discovered). No-op when the
            node has already been popped.
        __len__: live queue size (unvisited count).
        peek_max_size: historical max queue length (for ``TraceMetrics``).
        visited_count: total dedup set size.
    """

    __slots__ = ("_max_size", "_queue", "_visited_keys")

    def __init__(self, *, policy: TracePolicy) -> None:
        self._queue: deque[GraphNode] = deque()
        self._visited_keys: set[str] = set()
        self._max_size: int = 0
        # ``policy`` is accepted for forward-compat (Phase 2 priority by
        # value) but not stored — the Frontier stays policy-free today.
        del policy

    def push(self, node: GraphNode) -> None:
        """Enqueue ``node``; no-op when its ``canonical_key`` is already seen.

        Insertion preserves the deterministic ordering rule: depth ASC,
        then canonical_key ASC. Same-depth same-key ties are impossible
        (the dedupe rejects them).
        """
        key = node.canonical_key
        if key in self._visited_keys:
            return
        self._visited_keys.add(key)
        # Linear scan to find the insertion slot. Frontiers are bounded
        # by ``policy.max_total_addresses`` (default 5,000) — O(N) per
        # push is acceptable. If that ever bites, switch to ``heapq``.
        idx = 0
        for existing in self._queue:
            if existing.depth > node.depth:
                break
            if existing.depth == node.depth and existing.canonical_key > key:
                break
            idx += 1
        self._queue.insert(idx, node)
        if len(self._queue) > self._max_size:
            self._max_size = len(self._queue)

    def pop(self) -> GraphNode | None:
        """Return the next node in ordering rule, or ``None`` on empty."""
        if not self._queue:
            return None
        return self._queue.popleft()

    def update_priority(self, node: GraphNode) -> bool:
        """Re-prioritise an already-enqueued node by removing and re-inserting.

        Round 10 codex P2-2: when ``_upsert_node`` is called with a depth
        shallower than the existing node's recorded depth (e.g. address X
        first appears as a child at depth 2, then later appears as an edge
        source at depth 1), the in-flight queue position must follow the
        new (shallower) depth so the deterministic ordering rule (depth
        ASC → key ASC) remains consistent with the node's stored depth.
        Without this re-sort, the BFS would still expand X at the correct
        ``depth=1`` value (the tracer reads depth from ``self._nodes``
        rather than the queue entry), but the queue's ordering would be
        wrong relative to other nodes inserted between the original push
        and the priority update.

        Returns ``True`` when the node was found in the queue and
        re-inserted, ``False`` when the node has already been popped (and
        therefore the priority update is moot — the BFS already processed
        it). Same-key duplicates already cannot exist (push deduplicates
        permanently against ``_visited_keys``).
        """
        key = node.canonical_key
        for idx, existing in enumerate(self._queue):
            if existing.canonical_key == key:
                # Remove the stale entry. Insertion preserves the
                # deterministic ordering rule using the same logic ``push``
                # applies; bypass the dedup set because the key is already
                # marked visited (re-pushing through ``push`` would no-op).
                del self._queue[idx]
                insert_at = 0
                for other in self._queue:
                    if other.depth > node.depth:
                        break
                    if other.depth == node.depth and other.canonical_key > key:
                        break
                    insert_at += 1
                self._queue.insert(insert_at, node)
                return True
        return False

    def __len__(self) -> int:
        return len(self._queue)

    def peek_max_size(self) -> int:
        """Historical maximum queue length — used by ``TraceMetrics``."""
        return self._max_size

    def visited_count(self) -> int:
        """Dedup set size — addresses ever enqueued (including popped)."""
        return len(self._visited_keys)


__all__ = ["Frontier"]
