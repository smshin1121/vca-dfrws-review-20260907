"""Fallback table (P1-015 DoD-10) — every unclaimed edge gets a label."""

from __future__ import annotations

from collections.abc import Mapping

from vca.tracer.graph import CaseGraph, EdgeKind, FlowEdge, canonical_address_key
from vca.tracer.stage_classifier._priority import ClassifierContext
from vca.tracer.stage_classifier._vocab import StageLabel
from vca.types import ChainId


def fallback_outcome(
    graph: CaseGraph,
    edge: FlowEdge,
    ctx: ClassifierContext,
    edge_label_cache: Mapping[str, StageLabel],
    outgoing_label_cache: Mapping[str, StageLabel] | None = None,
    incoming_label_cache: Mapping[str, StageLabel] | None = None,
) -> tuple[StageLabel, str]:
    """First-match fallback per WBS §6 (F1..F8).

    Codex P1-015 R9 finding #1 — F1 ABRIDGED inheritance now consults
    TWO caches with strict precedence: ``outgoing_label_cache`` (label of
    the first non-ABRIDGED edge whose ``source`` is the ABRIDGED source)
    BEFORE ``incoming_label_cache`` (label of the first non-ABRIDGED edge
    whose ``target`` is the ABRIDGED source). The OUTGOING signal answers
    "what stage was the source acting in when it emitted the ABRIDGED
    branch?" — its actions as a sender — which is the right inheritance
    direction. INCOMING is only consulted when the source has no prior
    outgoing classification (this preserves the R4 finding #2 fix:
    ABRIDGED off a node that was only ever a target still inherits via
    F1 instead of falling through to F2/F7/F8).

    Codex P1-015 R4 finding #2 — the original single ``node_label_cache``
    conflated incoming and outgoing labels and had no precedence rule;
    pollution by an unrelated incoming label could overwrite the
    semantically-correct outgoing label depending on sort order. The
    R9 split fixes that.
    """
    del graph
    src_node = ctx.nodes_by_key.get(canonical_address_key(edge.source))
    tgt_node = ctx.nodes_by_key.get(canonical_address_key(edge.target))
    src_depth = 0 if src_node is None else src_node.depth
    tgt_depth = 0 if tgt_node is None else tgt_node.depth

    # F1: ABRIDGED inherits source's classification (or recurse to F2..).
    if edge.kind == EdgeKind.ABRIDGED:
        src_key = canonical_address_key(edge.source)
        # Codex P1-015 R9 finding #1 — outgoing precedence over incoming.
        # The ABRIDGED edge is a synthetic breadcrumb of the source's
        # branching as a sender, so an OUTGOING label (what the source
        # did) better reflects its acting-stage than an INCOMING label
        # (what reached the source). When no outgoing label exists,
        # incoming is the R4 finding #2 fallback.
        if outgoing_label_cache is not None and src_key in outgoing_label_cache:
            return (
                outgoing_label_cache[src_key],
                f"fallback_f1:abridged_inherits_from={src_key}",
            )
        if incoming_label_cache is not None and src_key in incoming_label_cache:
            return (
                incoming_label_cache[src_key],
                f"fallback_f1:abridged_inherits_from={src_key}",
            )
        # Defensive backward-compatibility walk for callers that pass
        # only ``edge_label_cache`` (no per-node caches). The current
        # ``classify_stages`` always populates both per-node caches, so
        # this loop is unreachable from production code paths but
        # preserves the original F1 contract for any external caller.
        for prior_id, prior_label in edge_label_cache.items():
            if prior_id.startswith(f"{src_key}->"):
                return prior_label, f"fallback_f1:abridged_inherits_from={src_key}"
        # Drop through to F2-F8 if no prior label exists.

    # F5-CROSSCHAIN (codex P1-015 R4 finding #3) — ANY ``EdgeKind.CROSS_CHAIN``
    # whose decoder is unknown is routed through F5 BEFORE F2. Without this
    # ordering an unknown ``BTC → ETH/ARB`` cross-chain hop is caught by the
    # F2 BTC endpoint catch-all and mis-labelled as a generic BTC layer hop
    # instead of receiving the F5 target-chain mapping. F5's target-chain
    # mapping: BTC → ``STAGE_7`` (the bridge-into-BTC carve-out from R3
    # finding #1), ARB → ``STAGE_3_B``, else (ETH or otherwise) → ``STAGE_5``.
    if edge.kind == EdgeKind.CROSS_CHAIN:
        if edge.target.chain == ChainId.BITCOIN:
            return StageLabel.STAGE_7, "fallback_f5:cross_chain_to_btc"
        if edge.target.chain == ChainId.ARBITRUM:
            return StageLabel.STAGE_3_B, "fallback_f5:cross_chain_to_arb"
        # target.chain == ETHEREUM or any other non-BTC, non-ARB chain.
        return StageLabel.STAGE_5, "fallback_f5:cross_chain_to_eth"

    # F2: BTC chain catch-all for non-CROSS_CHAIN BTC edges (TRANSFER /
    # DEFI / etc.). Cross-chain edges are handled by F5 above.
    if edge.source.chain == ChainId.BITCOIN or edge.target.chain == ChainId.BITCOIN:
        # P3.2-008 — key on SOURCE depth (lockstep with
        # ``_heuristics.btc_layered_outcome``): a BTC laundering layer is
        # defined by where the funds depart FROM, so the entry receiver's
        # redistribution is L1 (relative 0). Target-depth was off-by-one
        # (first BTC->BTC hop targets entry+1 => L1 unreachable).
        base = 0 if ctx.btc_entry_depth is None else ctx.btc_entry_depth
        layer = max(0, min(3, src_depth - base))
        label = ctx.policy.btc_layer_depths.get(layer, StageLabel.STAGE_8_BTC_L1)
        return label, f"fallback_f2:btc_layer={layer}"

    # F4 BEFORE F3 (codex P1-015 R5 finding #1) — F4 is strictly more
    # specific than F3 (F4 ⊂ F3 because F4 requires F3's predicate plus
    # ``target.depth == 1``). With F3 listed first, F4 was dead code: a
    # depth-0 source emitting a single TRANSFER to a depth-1 target without
    # meeting any rank or fan threshold should be ``STAGE_2`` per WBS §6,
    # but F3 caught it as ``STAGE_1``. Order the more-specific row first
    # so the WBS §6 contract holds.
    if src_depth == 0 and tgt_depth == 1:
        return StageLabel.STAGE_2, f"fallback_f4:src_depth=0,tgt_depth=1,kind={edge.kind.value}"

    # F3: source depth 0 (target NOT depth 1 — that case is F4 above).
    if src_depth == 0:
        return StageLabel.STAGE_1, f"fallback_f3:src_depth=0,kind={edge.kind.value}"

    # F6: DEFI with unknown decoder. F2 has filtered out BTC endpoints so
    # the source chain is ETHEREUM or ARBITRUM here.
    if edge.kind == EdgeKind.DEFI:
        if edge.source.chain == ChainId.ETHEREUM:
            return StageLabel.STAGE_3_A, "fallback_f6:defi_eth"
        # source.chain == ARBITRUM.
        return StageLabel.STAGE_3_B, "fallback_f6:defi_arb"

    # F7: target depth >= 2 → STAGE_5.
    if tgt_depth >= 2:
        return StageLabel.STAGE_5, f"fallback_f7:tgt_depth={tgt_depth}"

    # F8: catch-all.
    return StageLabel.STAGE_5, f"fallback_f8:catch_all,kind={edge.kind.value}"


__all__ = ["fallback_outcome"]
