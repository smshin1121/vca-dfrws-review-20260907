"""Tracer DTOs (P1-014).

Defines TxRef, EdgeKind, TerminationReason, GraphNode, FlowEdge,
CaseGraph, and TraceMetrics — the SOLE shape crossing the public boundary.

All models are frozen Pydantic v2 with strict mode and forbid-extras. The
tracer is an in-memory orchestrator only — these DTOs are the SOLE shape
crossing the public boundary into P1-016 (persistence) and P1-015 (Stage
classifier). See ``_workspace/P1-014_architect_wbs.md`` §3 for the full
field manifest and cross-field rules.

Design notes
------------
* ``EdgeKind`` is **transport** kind (TRANSFER / INTERNAL / BRIDGE / DEFI
  / CROSS_CHAIN / ABRIDGED) — how the edge was decoded, not its stage
  role. P1-015 (Stage classifier) maps these to ARCH §4.1 stage labels.
* ``TerminationReason`` is the closed vocabulary of why a node stopped
  expanding. Adding a member is a public-API change.
* ``CaseGraph.metadata`` and ``FlowEdge.extras`` use the recursive-freeze
  pipeline at :mod:`vca.types._extras_freeze` — the 6th and 7th callers
  per WBS R-NO-LIFT.
* ``CaseGraph`` enforces referential integrity at construction time:
  every edge endpoint must appear in ``nodes``; every key in
  ``terminal_reasons`` must appear in ``nodes``; node ``canonical_key``
  values are unique.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from datetime import datetime
from enum import StrEnum
from types import MappingProxyType
from typing import Any, Final, Self

from pydantic import BaseModel, ConfigDict, Field, field_serializer, model_validator

from vca.labeler import AddressLabel
from vca.tracer._types import _ensure_utc, _validate_chain_tx_hash
from vca.types import Address, BlockRef, ChainId, CrossChainHop
from vca.types._extras_freeze import (
    freeze_extras_value,
    thaw_extras_value,
)

# ---------------------------------------------------------------------------
# Shared model config — strict, frozen, extras forbidden.
# ---------------------------------------------------------------------------

_FROZEN_CONFIG: Final[ConfigDict] = ConfigDict(frozen=True, strict=True, extra="forbid")

# Validation regex constants.
_CASE_ID_RE = re.compile(r"[a-zA-Z0-9_-]+")
# Asset.symbol has no upstream charset validator (just ``str``), but real
# token symbols include mixed case (``rsETH``, ``stETH``, ``wBTC``) and
# bridged-token suffixes that contain a dot (``USDC.e`` on Arbitrum,
# ``USDC.b`` variants on other chains, ``WETH.e``, ...). Round 25 codex
# P2: the previous regex ``[A-Za-z0-9_-]+`` rejected those legitimate
# symbols even though :class:`vca.types.Asset` accepts them. The
# FlowEdge charset must be no narrower than the upstream Asset charset,
# so we add ``.`` to the allowlist while still rejecting whitespace,
# slashes, and other punctuation that would break downstream rendering.
_ASSET_SYMBOL_RE = re.compile(r"[A-Za-z0-9_.-]+")
_DECODER_NAME_RE = re.compile(r"[a-z0-9_.-]+")


def canonical_address_key(address: Address) -> str:
    """Compute the canonical dedup key for an :class:`Address`.

    Round 11 codex P2 fix — chain-aware case handling:

    * EVM chains: addresses are stored EIP-55 (mixed case via
      ``to_checksum_address``) but on-chain semantics are case-insensitive,
      so we lowercase the hex payload to dedup ``0xAbC...`` vs ``0xabc...``.
    * BTC: ``vca.types._bech32.normalize_btc_address`` already lowercases
      bech32 (``bc1...``) and preserves case for Base58Check (``1...``,
      ``3...``). Base58Check is intentionally case-sensitive — two strings
      differing only by case decode to different bytes (different
      addresses). Lowercasing them would either produce an invalid key or
      merge two distinct BTC addresses, so the BTC value is used verbatim.

    Single source of truth used by :class:`GraphNode.canonical_key`,
    :class:`CaseGraph._validate_referential_integrity`, ``_TraceRun``'s
    direction / dedup helpers, and the deterministic edge sort.
    """
    if address.chain.is_evm:
        return f"{address.chain.value}:{address.value.lower()}"
    return f"{address.chain.value}:{address.value}"


# ---------------------------------------------------------------------------
# 1) EdgeKind / TerminationReason — closed vocabularies
# ---------------------------------------------------------------------------


class EdgeKind(StrEnum):
    """Transport kind of a :class:`FlowEdge`.

    "How the edge was decoded", not "stage role". The Stage classifier
    (P1-015) maps these to ARCH §4.1 stage labels in a follow-up pass.
    Adding a member is a public-API change.
    """

    TRANSFER = "transfer"
    INTERNAL = "internal"
    BRIDGE = "bridge"
    DEFI = "defi"
    CROSS_CHAIN = "cross_chain"
    ABRIDGED = "abridged"


class TerminationReason(StrEnum):
    """Why a node stopped being expanded.

    Per-address rationale lives in :attr:`CaseGraph.terminal_reasons`.
    Priority order (DoD-18) decides which reason wins when several apply.
    Adding a member is a public-API change.

    Round 16 codex P2-4 fix: ``SEED_REVERTED`` was removed from the closed
    public vocabulary; reverted seeds now reuse :attr:`EXPANSION_ERROR`
    and emit a per-anchor expansion-error record whose ``error`` field
    carries the ``"seed_reverted"`` marker — surfaced via
    ``CaseGraph.metadata['expansion_errors']`` — so downstream consumers
    can still distinguish the case without relying on a non-public enum
    member. Pre-fix the round-9 fix expanded the closed vocabulary
    without coordinating persistence/classifier consumers built against
    the original set.
    """

    MAX_DEPTH = "max_depth"
    TERMINAL_LABEL = "terminal_label"
    TIME_WINDOW = "time_window"
    BRANCHING_LIMIT = "branching_limit"
    NO_OUTGOING = "no_outgoing"
    VALUE_SUB_THRESHOLD = "value_sub_threshold"
    EXPANSION_ERROR = "expansion_error"


# ---------------------------------------------------------------------------
# 2) TxRef — frozen seed-tx reference
# ---------------------------------------------------------------------------


class TxRef(BaseModel):
    """Frozen seed-TX reference. Hashable on ``(chain, tx_hash)``.

    ``canonical()`` returns the same shape as
    :attr:`vca.types.NormalizedTransaction.tx_id` (``"<chain>:<hash>"``)
    so reporters can join on the string form without per-chain branching.
    """

    model_config = _FROZEN_CONFIG

    chain: ChainId
    tx_hash: str

    @model_validator(mode="after")
    def _validate_tx_hash(self) -> Self:
        normalised = _validate_chain_tx_hash(self.chain, self.tx_hash, field="TxRef.tx_hash")
        if normalised != self.tx_hash:
            object.__setattr__(self, "tx_hash", normalised)
        return self

    def canonical(self) -> str:
        return f"{self.chain.value}:{self.tx_hash}"

    def __hash__(self) -> int:
        return hash((self.chain.value, self.tx_hash))


# ---------------------------------------------------------------------------
# 3) GraphNode — one address visited or anchored
# ---------------------------------------------------------------------------


class GraphNode(BaseModel):
    """One address visited (or anchored) by the tracer.

    Hashable on ``(chain, address.value.lower())`` so a
    ``dict[(chain, addr)] -> GraphNode`` is the canonical visited-set
    keying (R-VISITED-KEY).
    """

    model_config = _FROZEN_CONFIG

    address: Address
    depth: int = Field(ge=0)
    label: AddressLabel | None = None
    first_seen_tx: TxRef
    first_seen_at: datetime
    terminal: bool = False

    @model_validator(mode="after")
    def _validate_first_seen_at(self) -> Self:
        normalised = _ensure_utc(self.first_seen_at)
        if normalised is not self.first_seen_at:
            object.__setattr__(self, "first_seen_at", normalised)
        return self

    @property
    def canonical_key(self) -> str:
        """Chain-scoped dedup key — see :func:`canonical_address_key`.

        Round 11 codex P2 fix preserves BTC Base58Check case (case-sensitive
        encoding) while still lowercasing EVM hex (case-insensitive).
        """
        return canonical_address_key(self.address)

    def __hash__(self) -> int:
        # Mirror ``canonical_key``'s chain-aware case handling so the
        # hashing identity (used by ``set[GraphNode]`` and equality)
        # agrees with the dedup key used by ``Frontier`` / ``CaseGraph``.
        if self.address.chain.is_evm:
            return hash((self.address.chain.value, self.address.value.lower()))
        return hash((self.address.chain.value, self.address.value))


# ---------------------------------------------------------------------------
# 4) FlowEdge — one directed edge between two addresses
# ---------------------------------------------------------------------------


class FlowEdge(BaseModel):
    """One directed edge between two addresses.

    Cross-field rules (DoD-9):

    * ``kind == CROSS_CHAIN`` ↔ ``hop is not None`` AND
      ``source.chain != target.chain``; otherwise ``hop is None`` AND
      ``source.chain == target.chain``.
    * ``kind == ABRIDGED`` ⇒ ``value_minor is None`` AND
      ``tx_hash is None``.
    * ``tx_hash`` (when set) matches the source chain's tx-hash regex.
    * ``decoder`` (when set) matches ``[a-z0-9_.-]+``.
    * ``asset_symbol`` matches ``[A-Za-z0-9_.-]+`` length 1-32 (mixed
      case to admit real-world tokens such as ``rsETH``, ``stETH``,
      ``wBTC``; the dot is allowed for bridged-token suffixes such as
      Arbitrum's ``USDC.e`` — round 25 codex P2 alignment with the
      upstream :class:`vca.types.Asset.symbol` charset).
    """

    model_config = _FROZEN_CONFIG

    source: Address
    target: Address
    kind: EdgeKind
    value_minor: int | None = Field(default=None, ge=0)
    asset_symbol: str = Field(min_length=1, max_length=32)
    decimals: int = Field(ge=0, le=36)
    # The token's on-chain contract address — the TRUE ``(chain, contract)``
    # identity of a moved ERC-20/DeFi/cross-chain asset (scan #16 Lens B). Native
    # coins and self-loop markers leave it ``None``. Distinct from
    # ``asset_symbol``: synthesized ERC-20 edges all share the placeholder
    # ``"ERC20"`` symbol (which feeds ``edge_id`` + smurf-clustering keys, so it
    # is deliberately UNCHANGED), whereas ``asset_contract`` disambiguates them so
    # web-side aggregation keys on the real token, not the placeholder symbol.
    asset_contract: Address | None = None
    tx_hash: str | None = None
    block: BlockRef | None = None
    decoder: str | None = None
    hop: CrossChainHop | None = None
    extras: Mapping[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_asset_symbol_charset(self) -> Self:
        if not _ASSET_SYMBOL_RE.fullmatch(self.asset_symbol):
            raise ValueError(
                f"FlowEdge.asset_symbol must match [A-Za-z0-9_.-]+, got: {self.asset_symbol!r}"
            )
        return self

    @model_validator(mode="after")
    def _validate_kind_invariants(self) -> Self:
        # CROSS_CHAIN ↔ hop is not None ↔ source.chain != target.chain
        if self.kind == EdgeKind.CROSS_CHAIN:
            if self.hop is None:
                raise ValueError("FlowEdge.kind=CROSS_CHAIN requires hop")
            if self.source.chain == self.target.chain:
                raise ValueError(
                    "FlowEdge.kind=CROSS_CHAIN requires source.chain != target.chain, "
                    f"got source={self.source.chain.value}, target={self.target.chain.value}"
                )
        else:
            if self.hop is not None:
                raise ValueError(
                    f"FlowEdge.hop is exclusive to kind=CROSS_CHAIN, got kind={self.kind.value}"
                )
            if self.source.chain != self.target.chain:
                raise ValueError(
                    f"FlowEdge non-cross-chain edge requires source.chain == target.chain, "
                    f"got source={self.source.chain.value}, target={self.target.chain.value}"
                )
        # ABRIDGED markers carry no per-edge data
        if self.kind == EdgeKind.ABRIDGED:
            if self.value_minor is not None:
                raise ValueError("FlowEdge.kind=ABRIDGED requires value_minor=None")
            if self.tx_hash is not None:
                raise ValueError("FlowEdge.kind=ABRIDGED requires tx_hash=None")
        return self

    @model_validator(mode="after")
    def _validate_cross_chain_hop_consistency(self) -> Self:
        """Round 14 codex P2 fix: pin the edge's endpoints / tx_hash to
        the underlying ``CrossChainHop`` route data.

        The previous ``_validate_kind_invariants`` check only enforced the
        coarse rule "kind=CROSS_CHAIN ⇒ hop set AND source.chain !=
        target.chain". A decoder or caller could still construct an edge
        whose ``target`` differed from ``hop.dst_address``, whose
        ``source.chain`` differed from ``hop.src_chain``, or whose
        ``tx_hash`` differed from ``hop.src_tx`` — the resulting model was
        internally contradictory yet accepted, and downstream consumers
        (visualiser cluster joins, reporter route summaries) would silently
        render mismatched routes.

        Pin every cross-chain field that has an authoritative counterpart
        on the hop:

        * ``source.chain == hop.src_chain``
        * ``target.chain == hop.dst_chain``
        * ``target == hop.dst_address``
        * ``tx_hash == hop.src_tx`` (when ``tx_hash`` is set; ``tx_hash``
          can be None for synthetic / abridged-style cross-chain markers
          that the kind invariants don't forbid).

        Skip non-CROSS_CHAIN edges — ``_validate_kind_invariants`` has
        already enforced ``hop is None`` for those.
        """
        if self.kind != EdgeKind.CROSS_CHAIN:
            return self
        # ``_validate_kind_invariants`` runs before this validator and
        # raises when ``self.hop is None``, so by the time we get here
        # ``self.hop`` is guaranteed to be set. Asserting None here would
        # mask the earlier error message, so we use a defensive guard
        # instead of an ``assert`` and skip the consistency check if a
        # later refactor ever reorders the validators.
        hop = self.hop
        if hop is None:  # pragma: no cover - defensive; ordering guarantee
            return self
        if self.source.chain != hop.src_chain:
            raise ValueError(
                f"FlowEdge.source.chain ({self.source.chain.value}) "
                f"!= hop.src_chain ({hop.src_chain.value})"
            )
        if self.target.chain != hop.dst_chain:
            raise ValueError(
                f"FlowEdge.target.chain ({self.target.chain.value}) "
                f"!= hop.dst_chain ({hop.dst_chain.value})"
            )
        if self.target != hop.dst_address:
            raise ValueError(
                f"FlowEdge.target ({self.target.value}) "
                f"!= hop.dst_address ({hop.dst_address.value})"
            )
        if self.tx_hash is not None and self.tx_hash.lower() != hop.src_tx.lower():
            # Round 15 codex P2 fix: compare tx hashes case-insensitively.
            # ``CrossChainHop._validate_src_tx`` already canonicalises
            # ``hop.src_tx`` to lowercase, but ``FlowEdge._validate_tx_hash``
            # — which performs the same lowercase normalisation on
            # ``self.tx_hash`` — runs AFTER this consistency validator
            # because Pydantic executes ``model_validator(mode="after")``
            # in declaration order. Comparing the raw values therefore
            # rejected an otherwise-valid edge whose caller supplied an
            # uppercase-hex EVM tx hash. ``.lower()`` on both sides keeps
            # the pin semantically identical (the canonicalisation is
            # idempotent on already-lowercase strings) while staying
            # robust to validator-ordering changes.
            raise ValueError(f"FlowEdge.tx_hash ({self.tx_hash}) != hop.src_tx ({hop.src_tx})")
        # Round 35 codex P2 fix: pin the duplicated ``value_minor`` /
        # ``asset_symbol`` / ``decimals`` fields to ``hop.amount_in`` /
        # ``hop.asset_in``. Pre-fix the validator only enforced endpoint
        # consistency, so a caller could construct
        # ``FlowEdge(kind=CROSS_CHAIN, value_minor=1, asset_symbol="BOGUS",
        # decimals=0, hop=...)`` whose hop describes 1 ETH while the edge
        # surface advertises 1 wei of "BOGUS" — downstream consumers
        # (Reporter, Mermaid timeline) read the edge fields directly and
        # would render the wrong route amount. The internal
        # ``_make_cross_chain_edge`` factory already populates these
        # fields from the hop, so this validator only catches misuse
        # from external constructors / future refactors.
        if self.value_minor != hop.amount_in.raw:
            raise ValueError(
                f"FlowEdge.value_minor ({self.value_minor}) "
                f"!= hop.amount_in.raw ({hop.amount_in.raw})"
            )
        if self.asset_symbol != hop.asset_in.symbol:
            raise ValueError(
                f"FlowEdge.asset_symbol ({self.asset_symbol!r}) "
                f"!= hop.asset_in.symbol ({hop.asset_in.symbol!r})"
            )
        if self.decimals != hop.asset_in.decimals:
            raise ValueError(
                f"FlowEdge.decimals ({self.decimals}) "
                f"!= hop.asset_in.decimals ({hop.asset_in.decimals})"
            )
        return self

    @model_validator(mode="after")
    def _validate_asset_contract(self) -> Self:
        """scan #16 Lens B codex P2-B fix: pin a non-null ``asset_contract`` to a
        consistent token identity.

        :class:`vca.types.Asset` already rejects a non-EVM / chain-mismatched
        contract, but ``FlowEdge.asset_contract`` is a raw :class:`Address` that
        bypasses that check on reconstruction (a corrupt persisted row or a bad
        external caller). WHEN it is set:

        * (a) the token lives on the SOURCE chain
          (``asset_contract.chain == source.chain``); and
        * (b) the token lives on an EVM chain (``asset_contract.chain.is_evm``) —
          token contracts are an EVM-only concept, so a BTC edge whose
          ``asset_contract`` is a BTC address passes (a) yet is still invalid
          (mirrors ``Asset._validate_contract_chain``); and
        * (c) for a CROSS_CHAIN edge with a hop, the flat field must NOT disagree
          with the authoritative hop identity
          (``asset_contract == hop.asset_in.contract``).

        Native coins / self-loop markers leave ``asset_contract=None`` and skip
        this check. Consistent with ``_validate_cross_chain_hop_consistency``
        (which already pins asset_symbol/decimals/value to ``hop.asset_in``).
        Byte-neutral: every golden edge is consistent (direct token contracts sit
        on the source EVM chain; cross-chain / BTC goldens are native so
        ``asset_contract=None``).
        """
        contract = self.asset_contract
        if contract is None:
            return self
        if contract.chain != self.source.chain:
            raise ValueError(
                f"FlowEdge.asset_contract.chain ({contract.chain.value}) "
                f"!= source.chain ({self.source.chain.value})"
            )
        if not contract.chain.is_evm:
            # Token contracts are EVM-only (R-SECRET-SAFE: chain value only, no
            # address echoed).
            raise ValueError(
                f"FlowEdge.asset_contract must be on an EVM chain, got: {contract.chain.value}"
            )
        if self.kind == EdgeKind.CROSS_CHAIN and self.hop is not None:
            hop_contract = self.hop.asset_in.contract
            if contract != hop_contract:
                hop_repr = hop_contract.value if hop_contract is not None else "None"
                raise ValueError(
                    f"FlowEdge.asset_contract ({contract.value}) "
                    f"!= hop.asset_in.contract ({hop_repr})"
                )
        return self

    @model_validator(mode="after")
    def _validate_tx_hash(self) -> Self:
        if self.tx_hash is None:
            return self
        normalised = _validate_chain_tx_hash(
            self.source.chain, self.tx_hash, field="FlowEdge.tx_hash"
        )
        if normalised != self.tx_hash:
            object.__setattr__(self, "tx_hash", normalised)
        return self

    @model_validator(mode="after")
    def _validate_block_chain(self) -> Self:
        """Round 23 codex P2 fix: pin ``block.chain`` to ``source.chain``.

        Pre-fix the model never checked that ``block.chain`` matched the
        edge's source/transaction chain. A caller could supply a BTC
        ``BlockRef`` to an ETH→ETH ``TRANSFER`` edge — the model accepted
        it, and downstream consumers (visualiser, reporter) would render
        a contradictory route. For ``CROSS_CHAIN`` edges the block lives
        on the source chain (where the bridging TX was mined); the
        round-14 cross-chain consistency validator already pins
        ``source.chain == hop.src_chain``, so ``block.chain ==
        source.chain`` is the right rule for both same-chain and
        cross-chain edges.
        """
        if self.block is None:
            return self
        if self.block.chain != self.source.chain:
            raise ValueError(
                f"FlowEdge.block.chain ({self.block.chain.value}) "
                f"!= source.chain ({self.source.chain.value})"
            )
        return self

    @model_validator(mode="after")
    def _validate_decoder_charset(self) -> Self:
        if self.decoder is None:
            return self
        if not _DECODER_NAME_RE.fullmatch(self.decoder):
            raise ValueError(f"FlowEdge.decoder must match [a-z0-9_.-]+, got: {self.decoder!r}")
        return self

    @model_validator(mode="after")
    def _freeze_extras(self) -> Self:
        frozen = freeze_extras_value(dict(self.extras), label="FlowEdge.extras")
        object.__setattr__(self, "extras", frozen)
        return self

    @field_serializer("extras")
    def _serialize_extras(self, value: Mapping[str, Any]) -> dict[str, Any]:
        thawed = thaw_extras_value(value)
        if not isinstance(thawed, dict):  # pragma: no cover - structural guarantee
            raise TypeError("FlowEdge.extras must serialise to a dict")
        return thawed

    @field_serializer("kind")
    def _serialize_kind(self, value: EdgeKind) -> str:
        return value.value


# ---------------------------------------------------------------------------
# 5) TraceMetrics — diagnostic counters captured during a Tracer.trace run
# ---------------------------------------------------------------------------


class TraceMetrics(BaseModel):
    """Diagnostic counters captured during a :meth:`Tracer.trace` run.

    Cross-field rule (DoD-11): ``(finished_at - started_at).total_seconds()
    ≈ duration_seconds`` within 1ms tolerance — the timer is monotonic and
    the wall-clock fields are diagnostic only (R-METRICS-MONOTONIC).
    """

    model_config = _FROZEN_CONFIG

    started_at: datetime
    finished_at: datetime
    duration_seconds: float = Field(ge=0.0)
    nodes_count: int = Field(ge=0)
    edges_count: int = Field(ge=0)
    frontier_max_size: int = Field(ge=0)
    adapter_calls: Mapping[ChainId, int] = Field(default_factory=dict)
    decoder_matches: int = Field(default=0, ge=0)
    abi_fallback_resolutions: int = Field(default=0, ge=0)
    abridged_emissions: int = Field(default=0, ge=0)

    @model_validator(mode="after")
    def _validate_started_finished(self) -> Self:
        normalised_start = _ensure_utc(self.started_at)
        if normalised_start is not self.started_at:
            object.__setattr__(self, "started_at", normalised_start)
        normalised_end = _ensure_utc(self.finished_at)
        if normalised_end is not self.finished_at:
            object.__setattr__(self, "finished_at", normalised_end)
        if self.started_at > self.finished_at:
            raise ValueError(
                f"TraceMetrics.started_at must be <= finished_at, got "
                f"started_at={self.started_at}, finished_at={self.finished_at}"
            )
        return self

    @model_validator(mode="after")
    def _freeze_adapter_calls(self) -> Self:
        """Round 23 codex P3 fix: validate adapter-call counts are
        non-negative ints (and not ``bool`` — Python's ``bool`` subclasses
        ``int`` so ``isinstance(True, int)`` is True; counters need
        the genuine int domain). Every other counter field on
        :class:`TraceMetrics` (``nodes_count``, ``edges_count``,
        ``frontier_max_size``, ``decoder_matches``,
        ``abi_fallback_resolutions``, ``abridged_emissions``) carries
        ``ge=0``; ``adapter_calls`` is the same diagnostic counter shape
        and must obey the same lower bound.
        """
        for chain, count in self.adapter_calls.items():
            if not isinstance(chain, ChainId):
                raise ValueError(  # noqa: TRY004 - pydantic value-domain validator
                    f"TraceMetrics.adapter_calls key must be ChainId, got {type(chain).__name__}"
                )
            # ``bool`` is a subclass of ``int`` in Python; reject it so
            # ``True`` / ``False`` cannot masquerade as 1 / 0 counts.
            if not isinstance(count, int) or isinstance(count, bool):
                raise ValueError(  # noqa: TRY004 - pydantic value-domain validator
                    f"TraceMetrics.adapter_calls[{chain.value}] must be int, "
                    f"got {type(count).__name__}"
                )
            if count < 0:
                raise ValueError(
                    f"TraceMetrics.adapter_calls[{chain.value}] must be >= 0, got {count}"
                )
        object.__setattr__(self, "adapter_calls", MappingProxyType(dict(self.adapter_calls)))
        return self

    @field_serializer("adapter_calls")
    def _serialize_adapter_calls(self, value: Mapping[ChainId, int]) -> dict[str, int]:
        return {k.value: v for k, v in value.items()}


# ---------------------------------------------------------------------------
# 6) CaseGraph — frozen, deterministic, persistence-ready BFS output
# ---------------------------------------------------------------------------


class CaseGraph(BaseModel):
    """In-memory BFS output. Frozen, deterministic, persistence-ready.

    Cross-field rules (DoD-10):

    * Every node's ``canonical_key`` is unique within ``nodes``.
    * Every edge's ``source.canonical_key`` and ``target.canonical_key``
      MUST appear in ``nodes`` (referential integrity).
    * Every key in ``terminal_reasons`` MUST appear in ``nodes``.

    ``metadata`` is recursively frozen via
    :func:`vca.types._extras_freeze.freeze_extras_value` (the 7th caller).
    """

    model_config = _FROZEN_CONFIG

    case_id: str = Field(min_length=1, max_length=128)
    seed_tx: TxRef
    nodes: tuple[GraphNode, ...] = ()
    edges: tuple[FlowEdge, ...] = ()
    terminal_reasons: Mapping[str, TerminationReason] = Field(default_factory=dict)
    metrics: TraceMetrics
    metadata: Mapping[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_case_id(self) -> Self:
        if not _CASE_ID_RE.fullmatch(self.case_id):
            raise ValueError(f"CaseGraph.case_id must match [a-zA-Z0-9_-]+, got: {self.case_id!r}")
        return self

    @model_validator(mode="after")
    def _validate_referential_integrity(self) -> Self:
        node_keys = {n.canonical_key for n in self.nodes}
        if len(node_keys) != len(self.nodes):
            raise ValueError("CaseGraph.nodes contains duplicate canonical_key entries")
        for idx, edge in enumerate(self.edges):
            # Round 11 codex P2 fix: route through ``canonical_address_key``
            # so BTC Base58Check addresses (intentionally case-sensitive)
            # match the same dedup key the corresponding ``GraphNode``
            # entries use. The pre-fix ``.value.lower()`` short-circuit
            # produced an invalid lowercased base58 key that never appeared
            # in ``node_keys``, false-failing the integrity check (and, for
            # two distinct BTC addresses differing only by case, would have
            # silently merged them — see node-side fix).
            src_key = canonical_address_key(edge.source)
            tgt_key = canonical_address_key(edge.target)
            if src_key not in node_keys:
                raise ValueError(f"CaseGraph.edges[{idx}].source not in nodes: {src_key}")
            if tgt_key not in node_keys:
                raise ValueError(f"CaseGraph.edges[{idx}].target not in nodes: {tgt_key}")
        for key in self.terminal_reasons:
            if key not in node_keys:
                raise ValueError(f"CaseGraph.terminal_reasons key not in nodes: {key}")
        return self

    @model_validator(mode="after")
    def _freeze_collections(self) -> Self:
        frozen_metadata = freeze_extras_value(dict(self.metadata), label="CaseGraph.metadata")
        object.__setattr__(self, "metadata", frozen_metadata)
        object.__setattr__(self, "terminal_reasons", MappingProxyType(dict(self.terminal_reasons)))
        return self

    @field_serializer("metadata")
    def _serialize_metadata(self, value: Mapping[str, Any]) -> dict[str, Any]:
        thawed = thaw_extras_value(value)
        if not isinstance(thawed, dict):  # pragma: no cover - structural guarantee
            raise TypeError("CaseGraph.metadata must serialise to a dict")
        return thawed

    @field_serializer("terminal_reasons")
    def _serialize_terminal_reasons(self, value: Mapping[str, TerminationReason]) -> dict[str, str]:
        return {k: v.value for k, v in sorted(value.items())}


__all__ = [
    "CaseGraph",
    "EdgeKind",
    "FlowEdge",
    "GraphNode",
    "TerminationReason",
    "TraceMetrics",
    "TxRef",
]
