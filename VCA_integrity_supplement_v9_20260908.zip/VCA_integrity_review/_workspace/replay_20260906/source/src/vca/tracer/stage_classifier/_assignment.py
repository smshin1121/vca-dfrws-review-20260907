"""StageAssignment frozen DTO (P1-015 DoD-6)."""

from __future__ import annotations

from collections.abc import Mapping
from types import MappingProxyType
from typing import Self

from pydantic import BaseModel, Field, field_serializer, model_validator

from vca.tracer.stage_classifier._vocab import (
    CASE_ID_RE,
    FROZEN_CONFIG,
    RATIONALE_RE,
    StageLabel,
)


class StageAssignment(BaseModel):
    """Frozen output: every edge ID → ``StageLabel`` + rationale."""

    model_config = FROZEN_CONFIG

    case_id: str = Field(min_length=1, max_length=128)
    edge_labels: Mapping[str, StageLabel]
    rationale: Mapping[str, str]

    @model_validator(mode="after")
    def _validate_case_id(self) -> Self:
        if not CASE_ID_RE.fullmatch(self.case_id):
            raise ValueError(
                f"StageAssignment.case_id must match [a-zA-Z0-9_-]+, got: {self.case_id!r}"
            )
        return self

    @model_validator(mode="after")
    def _validate_rationale_charset(self) -> Self:
        for key, value in self.rationale.items():
            # Pydantic strict mode already enforces ``str`` value type.
            if len(value) < 1 or len(value) > 256:
                raise ValueError(
                    f"StageAssignment.rationale[{key!r}] length must be in "
                    f"[1, 256], got: {len(value)}"
                )
            if not RATIONALE_RE.fullmatch(value):
                raise ValueError(
                    f"StageAssignment.rationale[{key!r}] must match "
                    f"^[a-z][a-z0-9_]*:[\\x20-\\x7e]+$, got: {value!r}"
                )
        return self

    @model_validator(mode="after")
    def _validate_referential_integrity(self) -> Self:
        if set(self.edge_labels.keys()) != set(self.rationale.keys()):
            raise ValueError("StageAssignment.edge_labels and rationale keys must match")
        return self

    @model_validator(mode="after")
    def _freeze_mappings(self) -> Self:
        object.__setattr__(self, "edge_labels", MappingProxyType(dict(self.edge_labels)))
        object.__setattr__(self, "rationale", MappingProxyType(dict(self.rationale)))
        return self

    @field_serializer("edge_labels")
    def _serialize_edge_labels(self, value: Mapping[str, StageLabel]) -> dict[str, str]:
        return {k: v.value for k, v in sorted(value.items())}

    @field_serializer("rationale")
    def _serialize_rationale(self, value: Mapping[str, str]) -> dict[str, str]:
        return dict(sorted(value.items()))


__all__ = ["StageAssignment"]
