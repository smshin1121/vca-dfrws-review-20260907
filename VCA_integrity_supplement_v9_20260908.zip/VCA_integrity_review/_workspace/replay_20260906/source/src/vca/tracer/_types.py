"""Private re-declared validators for tracer-side DTOs (P1-014 R-NO-PRIVATE-IMPORT).

The tracer needs ``_ensure_utc`` (datetime tz-aware UTC validator) and
``_validate_chain_tx_hash`` (chain-aware tx-hash format check). Those
helpers exist in :mod:`vca.types.normalized` but are underscore-prefixed
(private). Per WBS R-NO-PRIVATE-IMPORT, the tracer re-declares them here
identical-by-byte to the type module's versions rather than reaching
across the encapsulation boundary.

Tests in :mod:`tests.unit.tracer.test_types` pin equivalence: both helpers
must reject the same inputs as their source-of-truth counterparts.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime
from typing import Final

from vca.types import ChainId

# ---------------------------------------------------------------------------
# Tx-hash regex constants — identical to vca.types.normalized.
# ---------------------------------------------------------------------------

_EVM_TX_HASH_RE: Final[re.Pattern[str]] = re.compile(r"0x[0-9a-fA-F]{64}")
_BTC_TX_HASH_RE: Final[re.Pattern[str]] = re.compile(r"[0-9a-fA-F]{64}")


def _ensure_utc(value: datetime) -> datetime:
    """Tz-aware UTC enforcement. Raises ValueError on naive datetime."""
    if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
        raise ValueError("datetime must be timezone-aware (UTC)")
    return value.astimezone(UTC)


def _validate_chain_tx_hash(chain: ChainId, value: str, *, field: str = "tx_hash") -> str:
    """Validate a chain-aware tx hash and return its canonical lowercase form.

    EVM (Ethereum/Arbitrum): ``0x`` + 64 lowercase hex.
    BTC: 64 lowercase hex (no ``0x`` prefix per Bitcoin convention).

    Re-declared per WBS R-NO-PRIVATE-IMPORT — must stay byte-identical to
    :func:`vca.types.normalized._validate_chain_tx_hash`.
    """
    if not isinstance(value, str):
        raise ValueError(  # noqa: TRY004 - value-domain validator path
            f"{field} must be str, got {type(value).__name__}"
        )
    if chain.is_evm:
        if not _EVM_TX_HASH_RE.fullmatch(value):
            raise ValueError(
                f"{field} must be 0x + 64 lowercase hex for chain={chain.value}, got: {value}"
            )
        return value.lower()
    if not _BTC_TX_HASH_RE.fullmatch(value):
        raise ValueError(
            f"{field} must be 64 lowercase hex (BTC: no 0x) for chain={chain.value}, got: {value}"
        )
    return value.lower()


__all__ = [
    "_ensure_utc",
    "_validate_chain_tx_hash",
]
