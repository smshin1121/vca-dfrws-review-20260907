"""LabelerService Protocol seam for tracer-side label resolution (P1-014).

The tracer never imports concrete detectors (P1-013 ``SingleUseDetector``
etc.) directly — the Protocol is the SOLE seam. Concrete service
implementations live OUTSIDE this PR (P1-018 ``HeuristicLabelerService``,
future Etherscan label fetcher).

Per WBS R-LABELER-SERVICE: P1-014 ships only this Protocol surface plus a
:class:`NullLabelerService` default for tests / lightweight bootstrap. The
heuristic-running service implementation is deferred to P1-018 because it
requires building :class:`vca.labeler.AddressActivity` from
``adapter.get_address_txs`` calls, which entangles balance fetching and
cospend-group enumeration — concerns the tracer does not need.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from vca.labeler import AddressLabel
from vca.types import Address


@runtime_checkable
class LabelerService(Protocol):
    """Tracer-side seam for label resolution.

    Implementations MUST be async. The tracer awaits this method at most
    once per address (cached on :attr:`GraphNode.label`).
    """

    async def fetch_label(self, address: Address) -> AddressLabel | None: ...


class NullLabelerService:
    """Default no-op service: every address gets ``None``.

    Useful for tests that exercise the tracer without label plumbing and
    for early-bootstrap callers that have not yet wired a heuristic
    service. Real callers (P1-019 CLI) wire a heuristic-running service.
    """

    async def fetch_label(self, address: Address) -> AddressLabel | None:
        # ``address`` is intentionally unused — the null service ignores all input.
        del address
        return None


__all__ = ["LabelerService", "NullLabelerService"]
