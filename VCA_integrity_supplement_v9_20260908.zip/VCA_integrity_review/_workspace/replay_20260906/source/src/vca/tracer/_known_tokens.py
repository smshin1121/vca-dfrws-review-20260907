"""Static decimals table for well-known ERC-20 tokens (scan #15 true-decimals).

:func:`vca.tracer._run._synthesize_erc20_transfers_from_logs` recovers token
movement from raw ``Transfer`` logs but cannot fetch a token's on-chain
``decimals()`` without an extra API round-trip, so it stamps a placeholder ``18``.
That UNDERSTATES the human-unit value — and the scan #13 DEC-1 branching-trim
ranking — of LOW-decimal tokens (USDC/USDT = 6, WBTC = 8): a 1,000-USDC transfer
(raw ``1_000_000_000``) reads as ``1e-9`` under 18 decimals instead of ``1,000``.
This table resolves the decimals of a curated set of canonical, high-liquidity
tokens with NO extra API call.

DECIMALS-ONLY by design (user decision, scan #15). The caller keeps the
placeholder SYMBOL (``"ERC20"``); only the value-critical ``decimals`` is
corrected. Because every token that appears in the current golden fixtures is an
18-decimal token, resolving decimals is a no-op there (``18 == 18``) so the
KelpDAO / Bybit goldens stay byte-identical (no INV-2 re-bless); the correction
only bites future captures that move a low-decimal token.

PROVENANCE. These are the canonical Ethereum-mainnet / Arbitrum-One deployment
addresses of universally-known tokens — protocol constants in the same spirit as
the ERC-20 ``Transfer`` event topic hash in ``_run.py``, each verifiable on
Etherscan / Arbiscan. A wrong or typo'd key simply fails to match and falls back
to the placeholder ``18`` (safe-by-omission — a miss never fabricates a value).
The table is deliberately SMALL and stablecoin/wrapped-asset focused (the DPRK
laundering vehicles); niche tokens stay on the placeholder.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from types import MappingProxyType
from typing import Final

from vca.types import Address, ChainId

# The placeholder SYMBOL stamped on every synthesized ERC-20 edge —
# :func:`vca.tracer._run._synthesize_erc20_transfers_from_logs` cannot recover a
# token's real symbol from a raw ``Transfer`` log without an extra API round-trip.
# It feeds ``edge_id`` + smurf-clustering keys, so it is deliberately STABLE
# (changing it is golden-affecting). Promoted here (out of ``_run.py``) as the
# shared SSOT so the WEB builders can recognise a legacy pre-0007 synthesized
# token — one whose ``(chain, contract)`` identity was never persisted
# (``asset_contract IS NULL``) yet still carries this placeholder symbol — and
# treat it as UNRESOLVED (ambiguous) rather than silently merging two DISTINCT
# such tokens under the shared placeholder key.
ERC20_PLACEHOLDER_SYMBOL: Final[str] = "ERC20"

# (chain, lowercased contract hex) -> ERC-20 ``decimals``. Keyed on the same
# lowercased-hex form :func:`vca.tracer.graph.canonical_address_key` produces for
# EVM addresses, so a checksummed (EIP-55) contract still matches.
_KNOWN_TOKEN_DECIMALS: Final[Mapping[tuple[ChainId, str], int]] = MappingProxyType(
    {
        # --- Ethereum mainnet ---
        (ChainId.ETHEREUM, "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"): 6,  # USDC
        (ChainId.ETHEREUM, "0xdac17f958d2ee523a2206206994597c13d831ec7"): 6,  # USDT
        (ChainId.ETHEREUM, "0x6b175474e89094c44da98b954eedeac495271d0f"): 18,  # DAI
        (ChainId.ETHEREUM, "0x2260fac5e5542a773aa44fbcfedf7c193bc2c599"): 8,  # WBTC
        (ChainId.ETHEREUM, "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"): 18,  # WETH
        # Liquid-staking / restaking tokens (all 18-dec) — the DPRK laundering
        # vehicles in the KelpDAO / Bybit cases. Present here so decimals resolve
        # alongside the symbol table below; being 18-dec they are byte-neutral in
        # the goldens (18 == 18 placeholder).
        (ChainId.ETHEREUM, "0xa1290d69c65a6fe4df752f95823fae25cb99e5a7"): 18,  # rsETH
        (ChainId.ETHEREUM, "0x7f39c581f595b53c5cb19bd0b3f8da6c935e2ca0"): 18,  # wstETH
        (ChainId.ETHEREUM, "0xae7ab96520de3a18e5e111b5eaab095312d7fe84"): 18,  # stETH
        (ChainId.ETHEREUM, "0xe6829d9a7ee3040e1276fa75293bde931859e8fa"): 18,  # cmETH
        (ChainId.ETHEREUM, "0xd5f7838f5c461feff7fe49ea5ebaf7728bb0adfa"): 18,  # mETH
        # --- Arbitrum One ---
        (ChainId.ARBITRUM, "0xaf88d065e77c8cc2239327c5edb3a432268e5831"): 6,  # USDC (native)
        (ChainId.ARBITRUM, "0xff970a61a04b1ca14834a43f5de4533ebddb5cc8"): 6,  # USDC.e (bridged)
        (ChainId.ARBITRUM, "0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9"): 6,  # USDT
        (ChainId.ARBITRUM, "0x2f2a2543b76a4166549f7aab2e75bef0aefc5b0f"): 8,  # WBTC
        (ChainId.ARBITRUM, "0x82af49447d8a07e3bd95bd0d56f35241523fbab1"): 18,  # WETH
    }
)


# (chain, lowercased contract hex) -> real ERC-20 SYMBOL. This is the DISPLAY-side
# companion to ``_KNOWN_TOKEN_DECIMALS`` (scan #16 Lens B contract-identity fix).
# The tracer keeps stamping the placeholder ``"ERC20"`` symbol on synthesized
# edges (that placeholder feeds ``edge_id`` + smurf-clustering keys, so changing
# it is golden-affecting); this table lets the WEB builders resolve a human symbol
# for DISPLAY ONLY once they have already keyed aggregation on the true
# ``(chain, contract)`` identity. A miss falls back to the stored ``asset_symbol``
# (safe-by-omission — a miss never fabricates a symbol). Every key MUST also
# appear in ``_KNOWN_TOKEN_DECIMALS`` so decimals resolve for the same token.
_KNOWN_TOKEN_SYMBOLS: Final[Mapping[tuple[ChainId, str], str]] = MappingProxyType(
    {
        (ChainId.ETHEREUM, "0xa1290d69c65a6fe4df752f95823fae25cb99e5a7"): "rsETH",
        (ChainId.ETHEREUM, "0x7f39c581f595b53c5cb19bd0b3f8da6c935e2ca0"): "wstETH",
        (ChainId.ETHEREUM, "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"): "WETH",
        (ChainId.ETHEREUM, "0xae7ab96520de3a18e5e111b5eaab095312d7fe84"): "stETH",
        (ChainId.ETHEREUM, "0xe6829d9a7ee3040e1276fa75293bde931859e8fa"): "cmETH",
        (ChainId.ETHEREUM, "0xd5f7838f5c461feff7fe49ea5ebaf7728bb0adfa"): "mETH",
    }
)


def resolve_known_token_decimals(contract: Address) -> int | None:
    """Return the canonical ``decimals`` for a known ERC-20 ``contract``, else ``None``.

    ``None`` means "not in the curated table" — the caller keeps the placeholder
    ``18``. EVM contract addresses are matched case-insensitively (the on-chain
    address semantics are case-insensitive; :class:`Address` stores EIP-55 mixed
    case).
    """
    return _KNOWN_TOKEN_DECIMALS.get((contract.chain, contract.value.lower()))


def resolve_known_token_symbol(contract: Address) -> str | None:
    """Return the canonical SYMBOL for a known ERC-20 ``contract``, else ``None``.

    DISPLAY-ONLY companion to :func:`resolve_known_token_decimals`. ``None`` means
    "not in the curated table" — the caller falls back to the stored placeholder
    ``asset_symbol``. Matched case-insensitively (the on-chain address semantics
    are case-insensitive; :class:`Address` stores EIP-55 mixed case).
    """
    return _KNOWN_TOKEN_SYMBOLS.get((contract.chain, contract.value.lower()))


def resolve_display_symbol(contract: Address | None, candidate_symbols: Iterable[str]) -> str:
    """Deterministic DISPLAY symbol for one token identity (codex R5 P2).

    The curated :func:`resolve_known_token_symbol` (contract-keyed, order-independent)
    wins when known. Otherwise pick from the edges' STORED symbols FAVORING a real
    symbol over the ``ERC20_PLACEHOLDER_SYMBOL`` (a decoder-produced ``"USDC"`` beats a
    synthesized ``"ERC20"`` for the SAME contract), breaking ties by sort order — so
    permuting equal edges of one contract can never flip the label. Empty candidates
    resolve to the placeholder.
    """
    if contract is not None:
        known = resolve_known_token_symbol(contract)
        if known is not None:
            return known
    symbols = set(candidate_symbols)
    real = sorted(symbol for symbol in symbols if symbol != ERC20_PLACEHOLDER_SYMBOL)
    if real:
        return real[0]
    return min(symbols) if symbols else ERC20_PLACEHOLDER_SYMBOL


__all__ = [
    "ERC20_PLACEHOLDER_SYMBOL",
    "resolve_display_symbol",
    "resolve_known_token_decimals",
    "resolve_known_token_symbol",
]
