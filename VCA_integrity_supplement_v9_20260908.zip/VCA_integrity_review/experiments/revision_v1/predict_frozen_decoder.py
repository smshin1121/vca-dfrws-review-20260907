"""Run frozen VCA decoders before reading any held-out payout labels."""

import ast
import hashlib
import json
import sys
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
from types import MappingProxyType

from vca.adapters.evm._normalizers import (
    normalize_block_ref,
    normalize_log,
    normalize_tx_from_proxy,
)
from vca.decoders.thorchain import ThorchainDecoder
from vca.decoders.thorchain_vault import ThorchainVaultDecoder, ThorchainVaultDecoderConfig
from vca.types import Address, ChainId

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "_workspace/replay_20260906/source"
CAPTURE = ROOT / "captures/revision_v1_external"
SELECTED = ROOT / "experiments/revision_v1/selection/selected_inputs.json"
OUT = ROOT / "experiments/revision_v1/results/first_predictions.json"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not OUT.exists(), "First predictions are immutable"
    OUT.parent.mkdir(parents=True, exist_ok=True)
    statepath = CAPTURE / "capture_state.json"
    state = json.loads(statepath.read_text(encoding="utf-8"))
    assert all(key.startswith("eth_") for key in state["requests"]), (
        "Prediction must precede Midgard collection"
    )
    selected = json.loads(SELECTED.read_text(encoding="utf-8"))
    assert len(selected) == 96
    assert state["selected_inputs_sha256"] == sha(SELECTED)
    bybitfile = SOURCE / "src/vca/cases/bybit_seed.py"
    constants = {
        node.target.id: node.value.value
        for node in ast.walk(ast.parse(bybitfile.read_text(encoding="utf-8")))
        if isinstance(node, ast.AnnAssign)
        and isinstance(node.target, ast.Name)
        and isinstance(node.value, ast.Constant)
    }
    extra = Address.from_str(constants["BYBIT_THORCHAIN_VAULT"], ChainId.ETHEREUM)
    decoders = [
        ThorchainDecoder(),
        ThorchainVaultDecoder(),
        ThorchainVaultDecoder(
            config=ThorchainVaultDecoderConfig(vaults=MappingProxyType({ChainId.ETHEREUM: extra}))
        ),
    ]
    allowed = {Path(__file__).resolve(), statepath.resolve(), SELECTED.resolve(), OUT.resolve()}
    consumed = {
        statepath.relative_to(ROOT).as_posix(): sha(statepath),
        SELECTED.relative_to(ROOT).as_posix(): sha(SELECTED),
    }
    for entry in state["requests"].values():
        if entry["status"] == "available":
            path = CAPTURE / entry["response_file"]
            assert sha(path) == entry["response_sha256"]
            allowed.add(path.resolve())
            consumed[path.relative_to(ROOT).as_posix()] = sha(path)
    reads = set()

    def audit(event, args):
        if event.startswith("socket.") and event in {"socket.connect", "socket.getaddrinfo"}:
            raise PermissionError("Prediction uses no network")
        if event == "open" and isinstance(args[0], (str, bytes)):
            path = Path(args[0]).resolve()
            if (
                path in allowed
                or path.is_relative_to(SOURCE / "src")
                or path.is_relative_to(Path(sys.prefix))
                or path.is_relative_to(Path(sys.base_prefix))
            ):
                reads.add(str(path))
            else:
                raise PermissionError("File outside prediction inputs: " + str(path))

    sys.addaudithook(audit)

    def payload(key):
        entry = state["requests"].get(key)
        if entry and entry["status"] == "available":
            return json.loads((CAPTURE / entry["response_file"]).read_text(encoding="utf-8"))[
                "result"
            ]
        return None

    rows = []
    for item in selected:
        identifier = item["txid"]
        row = {**item, "status": "input_unavailable", "hops": []}
        record = state["records"].get(identifier, {})
        tx, receipt, block = [payload(record.get(k)) for k in ("transaction", "receipt", "block")]
        if not all(isinstance(x, dict) for x in (tx, receipt, block)):
            rows.append(row)
            continue
        try:
            assert tx["hash"].lower() == receipt["transactionHash"].lower() == identifier
            assert tx["blockHash"].lower() == receipt["blockHash"].lower() == block["hash"].lower()
            assert (
                int(tx["blockNumber"], 16)
                == int(receipt["blockNumber"], 16)
                == int(block["number"], 16)
            )
            row.update(
                {
                    "eth_timestamp": datetime.fromtimestamp(
                        int(block["timestamp"], 16), UTC
                    ).isoformat(),
                    "eth_block": int(block["number"], 16),
                    "to": tx["to"],
                    "from": tx["from"],
                    "value_wei": int(tx["value"], 16),
                    "calldata": tx["input"],
                    "receipt_status": int(receipt["status"], 16),
                }
            )
            if row["receipt_status"] != 1:
                row["status"] = "eth_execution_failed"
            else:
                ref = normalize_block_ref(raw_block=block, chain=ChainId.ETHEREUM)
                normalized = normalize_tx_from_proxy(
                    raw_tx=tx,
                    block=ref,
                    chain=ChainId.ETHEREUM,
                    raw_uri=state["requests"][record["transaction"]]["url"],
                )
                logs = tuple(
                    normalize_log(raw_log=log, block=ref, chain=ChainId.ETHEREUM)
                    for log in receipt["logs"]
                )
                assert all(log.tx_hash == normalized.tx_hash for log in logs)
                matched = [decoder for decoder in decoders if decoder.matches(normalized)]
                row["matched_decoders"] = [decoder.name for decoder in matched]
                row["status"] = (
                    "transport_not_supported" if not matched else "memo_or_asset_not_supported"
                )
                for decoder in matched:
                    row["hops"].extend(
                        hop.model_dump(mode="json") for hop in decoder.decode(normalized, logs)
                    )
                if row["hops"]:
                    row["status"] = "decoded" if len(row["hops"]) == 1 else "multiple_decoded_hops"
        except (AssertionError, KeyError, TypeError, ValueError) as exc:
            row["status"] = "input_binding_or_decoder_error"
            row["error"] = f"{type(exc).__name__}: {exc}"
        rows.append(row)
    source_files = [
        SOURCE / "src/vca/adapters/evm/_normalizers.py",
        SOURCE / "src/vca/decoders/thorchain.py",
        SOURCE / "src/vca/decoders/thorchain_vault.py",
        bybitfile,
    ]
    result = {
        "status": "FIRST_PREDICTIONS_RECORDED",
        "created_utc": datetime.now(UTC).isoformat(),
        "selected_inputs_sha256": sha(SELECTED),
        "rows": rows,
        "counts": dict(Counter(row["status"] for row in rows)),
        "capture_state_before_labels_sha256": sha(statepath),
        "consumed_inputs_sha256": consumed,
        "frozen_code_sha256": {
            path.relative_to(SOURCE).as_posix(): sha(path) for path in source_files
        },
        "predictor_sha256": sha(Path(__file__)),
        "label_files_read": [],
        "file_reads_observed": sorted(reads),
        "network_requests": 0,
        "scope": "Existing router decoder and two existing vault settings; no new transport "
        "or grammar; all selected rows retained",
    }
    OUT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"status": result["status"], "n": len(rows), "counts": result["counts"]}))


if __name__ == "__main__":
    main()
