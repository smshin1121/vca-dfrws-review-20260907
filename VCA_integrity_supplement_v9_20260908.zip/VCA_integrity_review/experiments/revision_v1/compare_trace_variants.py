"""Measure full-replay variants from their graph files, preserving each run."""
import hashlib
import json
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / "_workspace/replay_20260906/source"
HUB = "0xdd90071d52f20e85c89802e5dc1ec0a7b6475f92"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def key(address):
    value = address["value"].lower() if address["chain"] in ("eth", "arb") else address["value"]
    return address["chain"] + ":" + value


def measure(graph, roster):
    nodes = {key(n["address"]): n for n in graph["nodes"]}
    assert len(nodes) == len(graph["nodes"])
    assert all(key(e["source"]) in nodes and key(e["target"]) in nodes for e in graph["edges"])
    markers = {key(n["address"]) for n in graph["nodes"] if n["terminal"]}
    reasons = {k.lower() if k.startswith(("eth:", "arb:")) else k: v for k, v in graph["terminal_reasons"].items()}
    assert markers == reasons.keys()
    return {"nodes": len(nodes), "edges": len(graph["edges"]), "terminal": len(markers), "stop_reasons": dict(Counter(reasons.values())),
        "thorchain_hops": sum(bool(e.get("hop")) and e["hop"]["via"].startswith("thorchain") for e in graph["edges"]),
        "fbi_addresses_present": sorted({k[4:] for k in nodes if k.startswith("eth:")} & roster),
        "hub_outgoing_edges": sum(key(e["source"]) == "eth:" + HUB for e in graph["edges"]),
        "hub_stop": reasons.get("eth:" + HUB), "node_keys": sorted(nodes)}


def run():
    roster = {v.lower() for v in read(SOURCE / "tests/fixtures/bybit/fbi_psa_250226.json")["addresses"]}
    basefile = SOURCE / "tests/golden/expected/bybit_graph.json"
    base = read(basefile)["graph"]
    baseline = measure(base, roster)
    assert (baseline["nodes"], baseline["edges"], baseline["terminal"], baseline["stop_reasons"]) == (1991, 3127, 1919, {"expansion_error": 1894, "time_window": 25})
    base_edges = {json.dumps(e, sort_keys=True, separators=(",", ":")) for e in base["edges"]}
    rows = [{"variant": "baseline", "measurements": baseline, "graph_sha256": sha(basefile)}]
    for variant in ("cap20", "threshold50", "window7", "no_exceptions", "hub_completion"):
        directory = ROOT / "_workspace/revision_v1" / ("hub_completion" if variant == "hub_completion" else "sensitivity/" + variant)
        summary = read(directory / "summary.json")
        assert summary["status"] == "PASS" and summary["cli_exit_code"] == 0
        assert all(r["blocked"] for r in summary["guard_probes"])
        path = directory / "out/bybit/graph.json"
        graph = read(path)["graph"]
        values = measure(graph, roster)
        edges = {json.dumps(e, sort_keys=True, separators=(",", ":")) for e in graph["edges"]}
        added = [json.loads(e) for e in sorted(edges - base_edges)]
        row = {"variant": variant, "measurements": values, "graph_sha256": sha(path), "graph_path": path.relative_to(ROOT).as_posix(),
            "summary_sha256": sha(directory / "summary.json"), "elapsed_seconds": summary["elapsed_seconds"],
            "network_guard": summary["network_guard"], "added_nodes": sorted(set(values["node_keys"]) - set(baseline["node_keys"])),
            "removed_nodes": sorted(set(baseline["node_keys"]) - set(values["node_keys"])),
            "added_edges": len(added), "removed_edges": len(base_edges - edges),
            "newly_present_fbi": sorted(set(values["fbi_addresses_present"]) - set(baseline["fbi_addresses_present"]))}
        if variant == "hub_completion":
            row["added_hub_edges"] = [e for e in added if key(e["source"]) == "eth:" + HUB]
            used = [json.loads(s) for s in (directory / "hub_response_use.jsonl").read_text().splitlines()]
            assert len(used) == 1 and used[0]["rows"] == 162
            row["injected_response"] = used[0]
            captured = []
            for source in used[0]["sources"]:
                file = ROOT / "captures/revision_v1_payer_hub" / source["response_file"]
                assert sha(file) == source["sha256"]
                captured.extend(read(file)["result"])
            by_id = {t["hash"].lower(): t for t in captured}
            for edge in row["added_hub_edges"]:
                raw = by_id[edge["tx_hash"].lower()]
                assert raw["from"].lower() == edge["source"]["value"].lower()
                assert raw["to"].lower() == edge["target"]["value"].lower()
                assert int(raw["value"]) == edge["value_minor"]
                assert edge["asset_symbol"] == "ETH" and edge["decimals"] == 18
                assert datetime.fromtimestamp(int(raw["timeStamp"]), UTC) == datetime.fromisoformat(edge["block"]["timestamp"].replace("Z", "+00:00"))
            row["all_added_hub_edges_bound_to_raw_records"] = True
        else:
            policy = read(directory / "policy_change.json")
            row["changed_policy_fields"] = [k for k in policy["before"] if policy["before"][k] != policy["after"][k]]
        rows.append(row)
    return {"status": "MEASURED_AND_CHECKED", "created_utc": datetime.now(UTC).isoformat(), "rows": rows,
        "scope": "Fixed-input policy comparisons plus one targeted new-history experiment; not a new incident or global collection-completeness estimate",
        "script_sha256": sha(Path(__file__))}


if __name__ == "__main__":
    out = HERE / "trace_variant_results.json"
    assert not out.exists()
    result = run()
    out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    for row in result["rows"]:
        values = {k: v for k, v in row["measurements"].items() if k not in ("node_keys", "fbi_addresses_present")}
        print(json.dumps({"variant": row["variant"], **values, "FBI_present": len(row["measurements"]["fbi_addresses_present"]), "added_edges": row.get("added_edges"), "removed_edges": row.get("removed_edges")}))
