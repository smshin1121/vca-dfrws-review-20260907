"""Capture the fixed 96-swap sample using bounded, unauthenticated read requests."""

import argparse
import hashlib
import json
import re
import time
from datetime import UTC, datetime
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener

ROOT = Path(__file__).resolve().parents[2]
SELECTION = ROOT / "experiments/revision_v1/selection"
DEST = ROOT / "captures/revision_v1_external"
PREDICTIONS = ROOT / "experiments/revision_v1/results/first_predictions.json"
RPC = ("https://ethereum-rpc.publicnode.com", "https://eth.llamarpc.com")
MIDGARD = ("https://gateway.liquify.com/chain/thorchain_midgard",) * 2
BITCOIN = ("https://blockstream.info", "https://mempool.space")
MAX_HTTP = 960
MAX_LOGICAL = 480
MAX_BYTES = 10_000_000


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.now(UTC).isoformat()


def validate_response(raw, attempt, rpc_method, serial):
    if len(raw) > MAX_BYTES:
        raise ValueError("Response exceeded limit and is incomplete")
    data = json.loads(raw)
    if attempt.get("http_status") != 200:
        raise ValueError("Non-200 response")
    if rpc_method:
        if data.get("id") != serial or data.get("jsonrpc") != "2.0":
            raise ValueError("RPC envelope does not bind response to request")
        if data.get("error") or not isinstance(data.get("result"), dict):
            raise ValueError("RPC error or missing result: " + str(data.get("error", "null")))
    elif not isinstance(data, dict):
        raise ValueError("Expected JSON object")


class RestrictedRedirect(HTTPRedirectHandler):
    def __init__(self, hosts):
        super().__init__()
        self.hosts = hosts

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urlparse(newurl)
        if parsed.scheme != "https" or parsed.hostname not in self.hosts:
            raise ValueError("Redirect outside the specified HTTPS service")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class Capture:
    def __init__(self):
        DEST.mkdir(parents=True, exist_ok=True)
        (DEST / "raw").mkdir(exist_ok=True)
        self.path = DEST / "capture_state.json"
        self.state = (
            read(self.path)
            if self.path.exists()
            else {
                "started_utc": now(),
                "requests": {},
                "records": {},
                "http_attempts": 0,
                "selected_inputs_sha256": sha(SELECTION / "selected_inputs.json"),
                "protocol_sha256": sha(ROOT / "experiments/revision_v1/EXTERNAL_PROTOCOL.md"),
                "source_commit": "247784d5354cb2766b52502eb1687d916f03383f",
                "network_scope": "Unauthenticated read-only RPC and explorer requests; "
                "TLS verification enabled",
            }
        )
        assert self.state["selected_inputs_sha256"] == sha(SELECTION / "selected_inputs.json")
        self.last_request = 0.0

    def save(self):
        self.state["updated_utc"] = now()
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(self.state, indent=2) + "\n", encoding="utf-8", newline="\n")
        for retry in range(8):
            try:
                temp.replace(self.path)
                break
            except PermissionError:
                if retry == 7:
                    raise
                time.sleep(0.25 * (retry + 1))

    def payload(self, key):
        entry = self.state["requests"].get(key)
        if entry and entry["status"] == "available":
            path = DEST / entry["response_file"]
            assert sha(path) == entry["response_sha256"]
            data = read(path)
            return data["result"] if entry["rpc_method"] else data
        return None

    def fetch(self, key, endpoints, path="", rpc_method=None, params=None):
        if key in self.state["requests"]:
            entry = self.state["requests"][key]
            if entry["status"] == "available" or any(
                a["url"] in {e + path for e in endpoints} for a in entry["attempts"]
            ):
                return self.payload(key)
        else:
            if len(self.state["requests"]) >= MAX_LOGICAL:
                self.state.setdefault("budget_omissions", []).append(key)
                self.save()
                return None
            entry = {
                "key": key,
                "rpc_method": rpc_method,
                "params": params,
                "status": "unavailable",
                "attempts": [],
            }
            self.state["requests"][key] = entry
        opener = build_opener(RestrictedRedirect({urlparse(e).hostname for e in endpoints}))
        for endpoint in endpoints:
            if self.state["http_attempts"] >= MAX_HTTP:
                entry["reason"] = "http_budget_exhausted"
                self.save()
                return None
            time.sleep(max(0, 0.5 - (time.monotonic() - self.last_request)))
            self.last_request = time.monotonic()
            serial = self.state["http_attempts"] + 1
            self.state["http_attempts"] = serial
            url = endpoint + path
            body = None
            if rpc_method:
                assert rpc_method in {
                    "eth_getTransactionByHash",
                    "eth_getTransactionReceipt",
                    "eth_getBlockByHash",
                }
                body = json.dumps(
                    {"jsonrpc": "2.0", "id": serial, "method": rpc_method, "params": params}
                ).encode()
            attempt = {
                "started_utc": now(),
                "url": url,
                "http_method": "POST" if body else "GET",
                "serial": serial,
                "tls_verified": True,
            }
            entry["attempts"].append(attempt)
            if body:
                request_file = DEST / "raw" / f"{serial:06d}.request.json"
                with request_file.open("xb") as stream:
                    stream.write(body)
                attempt["request_file"] = request_file.relative_to(DEST).as_posix()
                attempt["request_sha256"] = sha(request_file)
            self.save()
            raw = None
            start = time.monotonic()
            try:
                request = Request(
                    url,
                    data=body,
                    headers={
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "User-Agent": "VCA-academic-validation/1.0",
                        "x-client-id": "vca-academic-validation",
                    },
                )
                with opener.open(request, timeout=25) as response:
                    attempt["http_status"] = response.status
                    attempt["final_url"] = response.url
                    raw = response.read(MAX_BYTES + 1)
            except HTTPError as exc:
                attempt["http_status"] = exc.code
                raw = exc.read(MAX_BYTES + 1)
                attempt["error"] = f"HTTP {exc.code}"
                if exc.code in (429, 503):
                    delay = exc.headers.get("Retry-After", "2")
                    seconds = int(delay) if delay.isdigit() else 60
                    attempt["retry_after_seconds"] = seconds
                    if seconds > 60:
                        attempt["retry_abandoned"] = "server_wait_exceeds_task_limit"
                    else:
                        time.sleep(max(2, seconds))
            except (URLError, TimeoutError, OSError, ValueError) as exc:
                attempt["error"] = f"{type(exc).__name__}: {exc}"
            attempt["elapsed_seconds"] = round(time.monotonic() - start, 3)
            attempt["finished_utc"] = now()
            if raw is not None:
                response_file = DEST / "raw" / f"{serial:06d}.response.json"
                with response_file.open("xb") as stream:
                    stream.write(raw)
                attempt["response_file"] = response_file.relative_to(DEST).as_posix()
                attempt["response_sha256"] = sha(response_file)
                attempt["response_bytes"] = len(raw)
                try:
                    validate_response(raw, attempt, rpc_method, serial)
                    entry.update(
                        {
                            "status": "available",
                            "response_file": attempt["response_file"],
                            "response_sha256": attempt["response_sha256"],
                            "url": url,
                        }
                    )
                except (ValueError, AttributeError) as exc:
                    attempt["content_error"] = str(exc)
            self.save()
            if entry["status"] == "available":
                return self.payload(key)
            if attempt.get("retry_abandoned"):
                break
        return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=["eth", "midgard", "btc"], required=True)
    parser.add_argument("--limit", choices=[3, 96], type=int, default=3)
    args = parser.parse_args()
    selected = read(SELECTION / "selected_inputs.json")
    assert len(selected) == 96
    capture = Capture()
    if args.stage != "eth":
        predictions = read(PREDICTIONS)
        assert len(predictions["rows"]) == 96
        assert predictions["selected_inputs_sha256"] == sha(SELECTION / "selected_inputs.json")
        capture.state["first_predictions_sha256"] = sha(PREDICTIONS)
        capture.state["endpoint_amendment_sha256"] = sha(
            ROOT / "experiments/holdout/ENDPOINT_AMENDMENT_20260907.md"
        )
    for item in selected[: args.limit]:
        identifier = item["txid"]
        record = capture.state["records"].setdefault(identifier, {"rank": item["rank"]})
        if args.stage == "eth":
            record["transaction"] = "eth_tx:" + identifier
            tx = capture.fetch(
                record["transaction"],
                RPC,
                rpc_method="eth_getTransactionByHash",
                params=[identifier],
            )
            if tx:
                if str(tx.get("hash", "")).lower() != identifier or not tx.get("blockHash"):
                    record["binding_error"] = (
                        "Ethereum transaction identity or confirmation missing"
                    )
                else:
                    record["receipt"] = "eth_receipt:" + identifier
                    capture.fetch(
                        record["receipt"],
                        RPC,
                        rpc_method="eth_getTransactionReceipt",
                        params=[identifier],
                    )
                    blockhash = tx["blockHash"].lower()
                    record["block"] = "eth_block:" + blockhash
                    capture.fetch(
                        record["block"],
                        RPC,
                        rpc_method="eth_getBlockByHash",
                        params=[blockhash, False],
                    )
        elif args.stage == "midgard":
            record["midgard"] = "midgard:" + identifier
            capture.fetch(
                record["midgard"],
                MIDGARD,
                path="/v2/actions?" + urlencode({"txid": identifier[2:], "limit": 50}),
            )
        else:
            data = capture.payload(record.get("midgard", ""))
            record.setdefault("bitcoin", {})
            for action in (data or {}).get("actions", []):
                bound = any(
                    str(leg.get("txID", "")).lower().removeprefix("0x") == identifier[2:]
                    for leg in action.get("in", [])
                )
                if not bound:
                    continue
                for leg in action.get("out", []):
                    if not any(coin.get("asset") == "BTC.BTC" for coin in leg.get("coins", [])):
                        continue
                    txid = str(leg.get("txID", "")).lower()
                    if not re.fullmatch(r"[0-9a-f]{64}", txid):
                        continue
                    key = "btc_tx:" + txid
                    record["bitcoin"][txid] = key
                    capture.fetch(key, BITCOIN, path="/api/tx/" + txid)
        capture.save()
        print(
            json.dumps(
                {
                    "rank": item["rank"],
                    "stage": args.stage,
                    "http_attempts": capture.state["http_attempts"],
                }
            ),
            flush=True,
        )
    stages = capture.state.setdefault("stage_runs", [])
    stages.append(
        {
            "stage": args.stage,
            "limit": args.limit,
            "finished_utc": now(),
            "script_sha256": sha(Path(__file__)),
        }
    )
    capture.save()
    snapshot = DEST / f"state_after_{len(stages):02d}_{args.stage}_{args.limit}.json"
    with snapshot.open("xb") as stream:
        stream.write(capture.path.read_bytes())
    print(
        json.dumps(
            {
                "status": "CAPTURE_ATTEMPT_COMPLETED",
                "http_attempts": capture.state["http_attempts"],
                "available": sum(
                    r["status"] == "available" for r in capture.state["requests"].values()
                ),
                "logical_requests": len(capture.state["requests"]),
            }
        )
    )


if __name__ == "__main__":
    main()
