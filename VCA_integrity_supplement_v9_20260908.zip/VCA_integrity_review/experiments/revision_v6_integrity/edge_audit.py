"""Audit frozen graph-row counts without rerunning or modifying VCA.

The producer uses Counters of complete serialized edge records. The checker
reopens the files and independently cancels sorted record lists, preserving
their multiplicities. Matching records is a graph-report operation, not proof
that two records denote one on-chain event.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

RESULTS = "experiments/revision_v1/trace_variant_results.json"
RESULTS_SHA = "4b0062c85bb88a825075e57b4f24dba9e568746cfb3a2eae3acb5f8d6f9345fa"
LEGACY_SCRIPT = "experiments/revision_v1/compare_trace_variants.py"
LEGACY_SCRIPT_SHA = "1d91f3eb8c7c839ca467f8f4bcfcf081074471117199df380ffe66143d855989"
BASELINE = "_workspace/replay_20260906/source/tests/golden/expected/bybit_graph.json"
VARIANTS = ("baseline", "cap20", "threshold50", "window7", "no_exceptions", "hub_completion")


class AuditError(Exception):
    """The preserved data or a count claim did not satisfy the audit."""


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_under(root: Path, relative: str) -> bytes:
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise AuditError(f"Input is outside --root: {relative}")
    return path.read_bytes()


def canonical(row: dict[str, Any]) -> str:
    return json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)


def graph_rows(blob: bytes) -> list[dict[str, Any]]:
    rows = json.loads(blob)["graph"]["edges"]
    if not isinstance(rows, list) or not all(isinstance(row, dict) for row in rows):
        raise AuditError("graph.edges must be a list of record objects")
    return rows


def measures(old: Counter[str], new: Counter[str]) -> dict[str, int | bool]:
    old_count, new_count = sum(old.values()), sum(new.values())
    common = sum((old & new).values())
    removed, added = sum((old - new).values()), sum((new - old).values())
    return {
        "old": old_count,
        "new": new_count,
        "common": common,
        "removed": removed,
        "added": added,
        "old_equals_common_plus_removed": old_count == common + removed,
        "new_equals_common_plus_added": new_count == common + added,
        "new_equals_old_minus_removed_plus_added": new_count == old_count - removed + added,
    }


def check_pair(
    old_rows: list[dict[str, Any]], new_rows: list[dict[str, Any]], claim: dict[str, Any]
) -> list[str]:
    """Separate implementation: sorted-list cancellation, not Counter arithmetic."""
    # The documented complete-record serialization is the common input contract;
    # the checker neither calls canonical()/measures() nor imports the old script.
    old = sorted(json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False) for row in old_rows)
    new = sorted(json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False) for row in new_rows)
    errors = []
    for basis, before, after in (
        ("row_multiset", old, new),
        ("distinct_records", sorted(set(old)), sorted(set(new))),
    ):
        i = j = common = removed = added = 0
        while i < len(before) and j < len(after):
            if before[i] == after[j]:
                common += 1
                i += 1
                j += 1
            elif before[i] < after[j]:
                removed += 1
                i += 1
            else:
                added += 1
                j += 1
        removed += len(before) - i
        added += len(after) - j
        expected = {"old": len(before), "new": len(after), "common": common, "removed": removed, "added": added}
        observed = claim.get(basis, {})
        for field, number in expected.items():
            if type(observed.get(field)) is not int or observed[field] != number:
                errors.append(f"{basis}.{field}: expected {number}, got {observed.get(field)!r}")
        if any(observed.get(field) is not True for field in (
            "old_equals_common_plus_removed", "new_equals_common_plus_added",
            "new_equals_old_minus_removed_plus_added",
        )):
            errors.append(f"{basis}: missing true accounting identities")
    return errors


def describe_graph(path: str, blob: bytes, rows: list[dict[str, Any]]) -> dict[str, Any]:
    positions: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(rows):
        positions[canonical(row)].append(index)
    duplicates = [
        {"canonical_record_sha256": sha256(key.encode("utf-8")), "multiplicity": len(indices),
         "zero_based_row_indices": indices, "record": json.loads(key)}
        for key, indices in sorted(positions.items()) if len(indices) > 1
    ]
    return {
        "path": path, "bytes": len(blob), "sha256": sha256(blob),
        "edge_rows": len(rows), "distinct_edge_records": len(positions),
        "duplicate_excess_rows": len(rows) - len(positions), "duplicates": duplicates,
    }


def build(root: Path) -> dict[str, Any]:
    legacy_blob = read_under(root, RESULTS)
    if sha256(legacy_blob) != RESULTS_SHA:
        raise AuditError("Frozen trace_variant_results.json digest mismatch")
    if sha256(read_under(root, LEGACY_SCRIPT)) != LEGACY_SCRIPT_SHA:
        raise AuditError("Frozen compare_trace_variants.py digest mismatch")
    legacy = json.loads(legacy_blob)
    if tuple(row["variant"] for row in legacy["rows"]) != VARIANTS:
        raise AuditError("Unexpected frozen variant roster/order")
    graphs, records, preserved = {}, {}, {}
    for entry in legacy["rows"]:
        name = entry["variant"]
        path = BASELINE if name == "baseline" else entry["graph_path"]
        blob = read_under(root, path)
        if sha256(blob) != entry["graph_sha256"]:
            raise AuditError(f"Frozen graph digest mismatch: {name}")
        rows = graph_rows(blob)
        if len(rows) != entry["measurements"]["edges"]:
            raise AuditError(f"Legacy table total disagrees with preserved graph rows: {name}")
        graphs[name] = describe_graph(path, blob, rows)
        records[name] = rows
        preserved[path] = sha256(blob)

    old = Counter(canonical(row) for row in records["baseline"])
    comparisons = []
    for entry in legacy["rows"][1:]:
        name = entry["variant"]
        new = Counter(canonical(row) for row in records[name])
        row_counts = measures(old, new)
        distinct_counts = measures(Counter(set(old)), Counter(set(new)))
        if (entry["removed_edges"], entry["added_edges"]) != (distinct_counts["removed"], distinct_counts["added"]):
            raise AuditError(f"Legacy difference no longer equals distinct-record difference: {name}")
        comparisons.append({
            "variant": name, "row_multiset": row_counts, "distinct_records": distinct_counts,
            "legacy_report": {"old_total_basis": "edge_rows", "new_total_basis": "edge_rows",
                              "removed_edges": entry["removed_edges"], "added_edges": entry["added_edges"],
                              "difference_basis": "distinct_complete_edge_records"},
            "legacy_difference_matches_row_difference": (entry["removed_edges"], entry["added_edges"]) == (row_counts["removed"], row_counts["added"]),
        })

    # Checker reopens the graph files after constructing the report. No captured
    # response, graph output, or legacy result is rewritten by this audit.
    fresh = {name: graph_rows(read_under(root, entry["path"])) for name, entry in graphs.items()}
    duplicate = next((entry for entry in graphs["baseline"]["duplicates"]), None)
    if duplicate is None:
        raise AuditError("No preserved duplicate available for the dropped-duplicate control")
    drop_index = duplicate["zero_based_row_indices"][-1]
    dropped = fresh["baseline"][:drop_index] + fresh["baseline"][drop_index + 1:]
    if len({canonical(row) for row in dropped}) != graphs["baseline"]["distinct_edge_records"]:
        raise AuditError("Dropped-duplicate control changed the distinct-record set")
    controls = []
    for claim in comparisons:
        name = claim["variant"]
        errors = check_pair(fresh["baseline"], fresh[name], claim)
        if errors:
            raise AuditError(f"Independent count check failed for {name}: {errors}")
        controls.append({"variant": name, "control": "unaltered_graphs_and_claim", "expected": "accept", "observed": "accept"})
        altered = copy.deepcopy(claim)
        altered["row_multiset"]["new"] += 1
        errors = check_pair(fresh["baseline"], fresh[name], altered)
        if not any(error.startswith("row_multiset.new:") for error in errors):
            raise AuditError(f"Altered-total control was not rejected for its changed new total: {name}")
        controls.append({"variant": name, "control": "reported_new_total_plus_one", "expected": "reject", "observed": "reject", "errors": errors})
        errors = check_pair(dropped, fresh[name], claim)
        if not any(error.startswith("row_multiset.old:") for error in errors) or any(error.startswith("distinct_records") for error in errors):
            raise AuditError(f"Dropped-duplicate control did not isolate multiplicity: {name}")
        controls.append({"variant": name, "control": "one_baseline_duplicate_removed_in_memory", "expected": "reject", "observed": "reject", "distinct_record_set_unchanged": True, "errors": errors})

    preserved[RESULTS] = RESULTS_SHA
    preserved[LEGACY_SCRIPT] = LEGACY_SCRIPT_SHA
    if any(sha256(read_under(root, path)) != digest for path, digest in preserved.items()):
        raise AuditError("An input changed during the audit")
    corrected = next(row for row in comparisons if row["variant"] == "no_exceptions")
    return {
        "schema_version": 1, "status": "PASS", "created_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Recount of preserved graph output records; no VCA replay, capture, deduplication of saved graphs, or inference that identical records denote the same on-chain event.",
        "canonical_key_definition": "Complete edge object serialized with Python json.dumps(row, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False), encoded as UTF-8. No fields are omitted; no address normalization is applied. Position within graph.edges is not part of the key; array-valued fields retain their order. Repeated rows retain multiplicity in row_multiset.",
        "row_identity": "new = old - removed + added; common matches the minimum multiplicity for each complete record.",
        "distinct_identity": "new = old - removed + added after collapsing only identical complete records. This is not a transaction or output identifier.",
        "legacy_sources": {"report": {"path": RESULTS, "sha256": RESULTS_SHA}, "script": {"path": LEGACY_SCRIPT, "sha256": LEGACY_SCRIPT_SHA}},
        "graphs": graphs, "comparisons": comparisons,
        "correction": {
            "affected_variant": "no_exceptions", "corrected_row_removed": corrected["row_multiset"]["removed"],
            "legacy_distinct_removed": corrected["distinct_records"]["removed"],
            "explanation": "The previous text combined graph array lengths with set differences of serialized records. Baseline contains one additional occurrence of a complete record (two identical rows), both occurrences absent after removing the overrides. The row-based removal is 985; 984 is the distinct-record removal. The original 3127 and new 2148 table totals remain unchanged.",
            "other_variant_difference_counts_unchanged": all(row["legacy_difference_matches_row_difference"] for row in comparisons if row["variant"] != "no_exceptions"),
            "baseline_duplicate_has_thorchain_hop": duplicate["record"]["hop"] is not None,
        },
        "checker": {"algorithm": "Fresh disk reads; sorted-list cancellation independent of Counter producer", "normal_controls_passed": 5, "adverse_controls_rejected": 10, "controls": controls},
        "all_preserved_input_hashes_unchanged": True,
        "script_sha256": sha256(Path(__file__).read_bytes()),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2], help="Root containing the preserved root-relative evidence paths")
    parser.add_argument("--output", type=Path, help="New report path; relative paths are resolved under --root; existing files are never overwritten")
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output or Path("experiments/revision_v6_integrity/edge_audit.json")
    output = (root / output).resolve()
    if not output.is_relative_to(root):
        raise AuditError("Report output must remain inside --root")
    if output.exists():
        raise AuditError("Report already exists; use a new --output path")
    result = build(root)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(result, indent=2, ensure_ascii=True, allow_nan=False) + "\n")
    print(json.dumps({"status": result["status"], "comparisons": len(result["comparisons"]),
                      "normal_controls": result["checker"]["normal_controls_passed"],
                      "adverse_controls": result["checker"]["adverse_controls_rejected"],
                      "no_exceptions": next(row["row_multiset"] for row in result["comparisons"] if row["variant"] == "no_exceptions")}))


if __name__ == "__main__":
    main()
