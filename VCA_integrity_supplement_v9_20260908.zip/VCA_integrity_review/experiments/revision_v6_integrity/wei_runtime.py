"""Repeat the preserved VCA normalization path and the one native amount guard.

Requires the original frozen VCA environment (already supplied with revision 5).
This is separate from the dependency-free wei_audit.py, and performs no capture,
prediction-file overwrite, decoder change, or full-incident trace.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sys
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    source = root / "_workspace/replay_20260906/source"
    capture = root / "captures/revision_v1_external"
    inputs = {}

    def read(path):
        raw = path.read_bytes()
        inputs[path.relative_to(root).as_posix()] = hashlib.sha256(raw).hexdigest()
        return json.loads(raw)

    predictions = read(root / "experiments/revision_v1/results/first_predictions.json")
    state = read(capture / "capture_state.json")
    for name, digest in predictions["frozen_code_sha256"].items():
        path = source / name
        measured = hashlib.sha256(path.read_bytes()).hexdigest()
        require(measured == digest, "frozen source hash differs: " + name)
        inputs[path.relative_to(root).as_posix()] = measured
    sys.path.insert(0, str(source / "src"))
    from vca.adapters.evm._normalizers import normalize_block_ref, normalize_log, normalize_tx_from_proxy
    from vca.decoders.thorchain import ThorchainDecoder
    from vca.types import Amount, ChainId

    attempts = []

    def network_guard(event, arguments):
        if event in {"socket.connect", "socket.getaddrinfo"}:
            attempts.append(event)
            raise PermissionError("Frozen wei audit forbids outbound network use")

    sys.addaudithook(network_guard)

    def payload(key):
        entry = state["requests"][key]
        require(entry["status"] == "available", "missing frozen input")
        path = capture / entry["response_file"]
        envelope = read(path)
        require(inputs[path.relative_to(root).as_posix()] == entry["response_sha256"], "response hash differs")
        return envelope["result"]

    rows = []
    target = None
    for pred in predictions["rows"]:
        record = state["records"][pred["txid"]]
        transaction = payload(record["transaction"])
        block = payload(record["block"])
        normalized = normalize_tx_from_proxy(
            raw_tx=transaction,
            block=normalize_block_ref(raw_block=block, chain=ChainId.ETHEREUM),
            chain=ChainId.ETHEREUM,
            raw_uri=state["requests"][record["transaction"]]["url"],
        )
        require(type(normalized.value_native.raw) is int, "normalized amount is not int")
        require(normalized.value_native.raw == int(transaction["value"], 16) == pred["value_wei"],
                "normalized amount differs from raw/prediction")
        require(normalized.input == transaction["input"] == pred["calldata"],
                "normalized calldata differs from raw/prediction")
        rows.append({"rank": pred["rank"], "txid": pred["txid"],
                     "value_wei": normalized.value_native.raw,
                     "value_type": type(normalized.value_native.raw).__name__,
                     "value_and_calldata_unchanged": True})
        if pred["rank"] == 65:
            target = (transaction, block, payload(record["receipt"]), pred)
    require(len(rows) == 96 and target is not None, "runtime sample incomplete")
    transaction, block, receipt, pred = target
    require(pred["txid"] == "0xf384c26216f515b829843e4e9c008bc968195c6a5a4b11359e8bceee7daf4ec0", "wrong rank-65 case")
    decoder = ThorchainDecoder()

    def decode_copy(raw):
        trace = []

        def profile(frame, event, argument):
            if frame.f_code.co_name == "_decode_deposit_with_expiry_calldata" and event == "return" and argument is not None:
                trace.append({"event": "ABI return", "argument_wei": argument[2],
                              "argument_type": type(argument[2]).__name__})
            if frame.f_code.co_name == "_assert_native_amount_coherence" and event == "call":
                trace.append({"event": "native guard input",
                              "decoded_amount": frame.f_locals["decoded_amount"],
                              "value_native_raw": frame.f_locals["value_native_raw"],
                              "types": [type(frame.f_locals[name]).__name__ for name in ("decoded_amount", "value_native_raw")]})

        ref = normalize_block_ref(raw_block=block, chain=ChainId.ETHEREUM)
        norm = normalize_tx_from_proxy(raw_tx=raw, block=ref, chain=ChainId.ETHEREUM,
                                       raw_uri="archived:rank65")
        logs = tuple(normalize_log(raw_log=log, block=ref, chain=ChainId.ETHEREUM) for log in receipt["logs"])
        require(decoder.matches(norm), "rank-65 router not recognized")
        sys.setprofile(profile)
        try:
            hops = decoder.decode(norm, logs)
            result = {"outcome": "DECODED", "hops": len(hops),
                      "amounts_wei": [hop.amount_in.raw for hop in hops]}
        except ValueError as exc:
            result = {"outcome": "REJECTED", "exception_type": type(exc).__name__,
                      "exception_text": str(exc)}
        finally:
            sys.setprofile(None)
        result["trace"] = trace
        return result

    baseline = decode_copy(copy.deepcopy(transaction))
    require(baseline["outcome"] == "REJECTED" and baseline["exception_type"] == "ValidationError", "expected frozen guard rejection")
    require(baseline["trace"] == [
        {"event": "ABI return", "argument_wei": 26710257243351728, "argument_type": "int"},
        {"event": "native guard input", "decoded_amount": 26710257243351728,
         "value_native_raw": 26710257243351726, "types": ["int", "int"]}], "unexpected native guard call path")
    baseline_error = "ValidationError: " + baseline["exception_text"]
    require(baseline_error == pred["error"], "runtime rejection differs from preserved prediction")
    controls = [{"name": "unchanged raw transaction copy", **baseline}]
    adjusted_value = copy.deepcopy(transaction)
    adjusted_value["value"] = hex(26710257243351728)
    value_result = decode_copy(adjusted_value)
    require(value_result["outcome"] == "DECODED" and value_result["hops"] == 1
            and value_result["amounts_wei"] == [26710257243351728], "value equality control failed")
    controls.append({"name": "synthetic copy: value raised to calldata amount", **value_result})
    adjusted_calldata = copy.deepcopy(transaction)
    adjusted_calldata["input"] = transaction["input"][:138] + format(26710257243351726, "064x") + transaction["input"][202:]
    calldata_result = decode_copy(adjusted_calldata)
    require(calldata_result["outcome"] == "DECODED" and calldata_result["hops"] == 1
            and calldata_result["amounts_wei"] == [26710257243351726], "calldata equality control failed")
    controls.append({"name": "synthetic copy: calldata lowered to transaction value", **calldata_result})
    try:
        Amount(raw=float(26710257243351726), decimals=18)
    except ValueError as exc:
        require(type(exc).__name__ == "ValidationError", "wrong noninteger amount rejection")
        controls.append({"name": "synthetic float supplied to Amount.raw", "outcome": "REJECTED",
                         "exception_type": type(exc).__name__})
    else:
        raise ValueError("Amount unexpectedly accepts a float")

    loaded_modules = {}
    for name, module in sorted(sys.modules.items()):
        if name == "vca" or name.startswith("vca."):
            file = getattr(module, "__file__", None)
            if file:
                path = Path(file).resolve()
                require(path.is_relative_to(source / "src"), "VCA imported outside frozen source")
                loaded_modules[path.relative_to(root).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    require(not attempts, "network attempt observed")
    result = {
        "status": "PASS", "schema": "vca.wei-frozen-runtime.v1",
        "scope": "Existing frozen environment: 96 transaction normalizations and the rank-65 router guard, not a new decoder evaluation or independent-team reproduction.",
        "python_version": sys.version.split()[0],
        "normalizations": {"n": len(rows), "integer_values_equal_raw_and_prediction": len(rows),
                           "calldata_equal_raw_and_prediction": len(rows), "rows": rows},
        "case_rank": 65, "case_txid": pred["txid"],
        "unchanged_case": baseline, "controls": controls,
        "control_scope": "The two equality controls modify only in-memory copies. They do not alter the original transaction, frozen predictions, or 46/96 result.",
        "network_attempts": attempts, "frozen_inputs_modified": False,
        "inputs_sha256": dict(sorted(inputs.items())),
        "loaded_frozen_vca_modules_sha256": loaded_modules,
        "runtime_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    output = args.output.resolve()
    require(output.is_relative_to(root), "output must be within root")
    encoded = (json.dumps(result, indent=2, ensure_ascii=True) + "\n").encode()
    if output.exists():
        require(output.read_bytes() == encoded, "output exists with different bytes; choose a fresh path")
    else:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(encoded)
    print(json.dumps({"status": result["status"], "normalizations": len(rows),
                      "rank65_guard_outcome": baseline["outcome"], "controls": len(controls),
                      "network_attempts": len(attempts)}))


if __name__ == "__main__":
    main()
