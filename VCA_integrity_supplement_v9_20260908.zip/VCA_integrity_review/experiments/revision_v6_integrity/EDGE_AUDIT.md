# Preserved graph edge-count audit

The row-based change after removing all Bybit overrides is **985 removed rows and 6 added rows**, with 2,142 common rows. Thus **3,127 - 985 + 6 = 2,148**. The original graph totals in the manuscript table are correct. The earlier description used 984 removed *distinct complete records* alongside totals counted as array rows.

This audit reopens the preserved graph outputs. It does not run VCA, change graph records, or collect new data. Its result supersedes the interpretation of the earlier difference counts while preserving the earlier files as execution history.

## Recompute

Run from the artifact root containing the root-relative input paths recorded in `edge_audit.json`:

```text
python -B experiments/revision_v6_integrity/edge_audit.py --root . --output experiments/revision_v6_integrity/edge_audit_recomputed.json
```

The output must be a new path inside `--root`; existing files are not overwritten. Python standard-library modules suffice. The frozen legacy report, comparator, and all six graph files are checked against their preserved SHA-256 digests before calculation and checked again before writing the report. A package must retain the paths listed in the report; copying this script alone does not supply the graph evidence.

The report's timestamp changes on a new execution. Its graph measurements, comparisons, canonical-key definition, and control results are deterministic for these inputs.

## Same-basis counts

Each comparison uses the same baseline. “Rows” retains every entry in `graph.edges`, including identical entries. “Distinct records” collapses only identical complete serialized edge objects, with no omitted fields or address normalization.

| Variant | New rows | Common rows | Removed rows | Added rows | New distinct records | Common distinct records | Removed distinct records | Added distinct records |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Baseline | 3,127 | 3,127 | 0 | 0 | 3,126 | 3,126 | 0 | 0 |
| Per-address tx cap 20 | 3,148 | 3,127 | 0 | 21 | 3,147 | 3,126 | 0 | 21 |
| Threshold 50 ETH | 3,127 | 3,127 | 0 | 0 | 3,126 | 3,126 | 0 | 0 |
| Window 7 days | 2,287 | 2,287 | 840 | 0 | 2,286 | 2,286 | 840 | 0 |
| No overrides | 2,148 | 2,142 | 985 | 6 | 2,148 | 2,142 | 984 | 6 |
| Added hub history | 3,160 | 3,127 | 0 | 33 | 3,159 | 3,126 | 0 | 33 |

For every variant and both bases, the report checks:

```text
old = common + removed
new = common + added
new = old - removed + added
```

The row-based relation is multiset accounting: matching rows cancel one occurrence at a time. The distinct-record relation is set accounting. Neither relation permits mixing a row count on one side with a distinct-record difference on the other.

The only affected previous difference is the removed count for `no_exceptions`. All five previously reported final graph totals are unchanged. The other four added/removed counts are also unchanged under a row basis.

## Identical record occurrences

The baseline contains two identical complete edge records at zero-based indices **3006 and 3007**. Their canonical JSON SHA-256 is:

```text
a5b7613a8ae2284777908832024441745067fc48f8242c8cd39291761e6a4921
```

They record transaction `0xe0cfdf60734acc3fa956636281fcf0cbb34b192c60183dde163d92b1375a894e`, an Ethereum ERC20 transfer of 1,376,000,000,000,000,000 minor units, with 18 decimals and contract `0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2`. The `hop` field is null. The full fields and exact indices for every preserved variant are in `graphs.<variant>.duplicates` in the JSON report.

Both occurrences disappear when all overrides are removed. The other four variants retain both. This accounts for the one-row difference between 985 removed rows and 984 removed distinct records.

Identical graph records do **not** establish that the underlying chain contained a duplicated event. This edge record has no log index, and this audit does not consult raw receipt logs to decide whether the two occurrences represent one or two on-chain transfer events. Accordingly, the audit retains the graph's row multiplicity and does not deduplicate or rewrite any original graph. These records are not THORChain hops, and this correction does not change the 153-hop evaluation or its payment totals.

## Verification and controls

The producer counts complete serialized records with `collections.Counter`. The checker reopens the original graph files and independently traverses sorted record lists, cancelling matching occurrences one by one. It does not call the producer's counting function or import the old comparator.

- **5 normal controls:** all preserved baseline/variant pairs agree with their row and distinct-record reports.
- **5 changed-total controls:** adding one to each claimed new row total is rejected for the changed total.
- **5 dropped-duplicate controls:** removing one baseline duplicate occurrence in memory is rejected against the original row-based report, although the distinct-record set stays unchanged.

All 15 controls produced their expected decisions. The adverse controls operate on in-memory copies and leave the files untouched. This tests count reporting and multiplicity preservation; it does not validate the upstream graph's completeness or the causal meaning of its edges.

## Suggested manuscript wording

English:

> With all overrides removed, 2,142 edge rows remain common to the baseline, 985 are removed and six are added, giving 3,127 - 985 + 6 = 2,148 rows. The removed rows contain 984 distinct complete records because the baseline includes one record twice. We retain row multiplicity in the table; the audit package reports both counting bases.

Korean:

> 모든 예외를 제거한 그래프는 기준 그래프와 공통인 엣지 행 2,142개를 유지하고, 985개를 제거하며 6개를 추가해 총 2,148개가 된다(3,127 - 985 + 6 = 2,148). 제거된 행은 서로 다른 전체 레코드로 세면 984개이다. 기준 그래프에 같은 레코드가 두 번 들어 있기 때문이다. 표는 이 중복 행을 포함한 행 수를 유지하며, 감사 자료에 두 집계 기준을 함께 제시한다.

For a shorter correction, retain the first two English sentences and identify the table's “Edges” column as “Edge rows.” Do not change 2,148 to 2,149 or remove a graph row to force agreement.
