"""Audit the preserved 2-wei case with Python's standard library only.

Run from a Codex/artifact root with:
  python -B experiments/revision_v6_integrity/wei_audit.py --root . --output audit.json

This script reads preserved HTTP bytes and frozen prediction records. It does
not call VCA, eth_abi, a node, or an explorer. Separate runtime evidence is in
wei_runtime.json; neither audit authenticates a signed Ethereum transaction.
"""

from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

CASE = "0xf384c26216f515b829843e4e9c008bc968195c6a5a4b11359e8bceee7daf4ec0"
CAPTURE = "captures/revision_v1_external"
REVISION = "experiments/revision_v1"
SOURCE = "_workspace/replay_20260906/source"
SELECTOR = "0x44bc937b"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON key: " + key)
        result[key] = value
    return result


def parse_json(data):
    return json.loads(data, object_pairs_hook=unique_object)


def hex_quantity(value):
    require(type(value) is str, "quantity must be a hex string")
    require(re.fullmatch(r"0x(?:0|[1-9a-fA-F][0-9a-fA-F]*)", value) is not None,
            "invalid canonical hex quantity")
    return int(value, 16)


def calldata_fields(value):
    require(type(value) is str, "calldata must be a hex string")
    require(re.fullmatch(r"0x(?:[0-9a-fA-F]{2})+", value) is not None,
            "invalid calldata hex")
    require(value[:10].lower() == SELECTOR, "unexpected function selector")
    body = value[10:]
    require(len(body) >= 5 * 64 and len(body) % 64 == 0,
            "calldata ABI head/body length")
    # ABI uint256 argument 2, after a four-byte selector and two 32-byte words.
    word = body[2 * 64:3 * 64]
    require(body[64:128] == "0" * 64, "case is not a native-ETH deposit")
    memo_offset = int(body[3 * 64:4 * 64], 16)
    require(memo_offset % 32 == 0 and memo_offset >= 5 * 32,
            "invalid memo offset")
    length_start = memo_offset * 2
    require(length_start + 64 <= len(body), "memo length word unavailable")
    memo_length = int(body[length_start:length_start + 64], 16)
    memo_start = length_start + 64
    require(memo_start + memo_length * 2 <= len(body), "memo data unavailable")
    memo = bytes.fromhex(body[memo_start:memo_start + memo_length * 2]).decode("utf-8")
    return {
        "selector": value[:10],
        "signature": "depositWithExpiry(address,address,uint256,string,uint256)",
        "amount_argument_zero_based_index": 2,
        "amount_word_hex": word,
        "argument_wei": int(word, 16),
        "amount_calldata_byte_slice": [68, 100],
        "amount_hex_string_character_slice_including_0x": [138, 202],
        "asset_word_hex": body[64:128],
        "vault_address_hex": "0x" + body[24:64],
        "memo": memo,
    }


def case_values(transaction):
    require(transaction["hash"].lower() == CASE, "wrong case transaction")
    result = calldata_fields(transaction["input"])
    result["transaction_value_hex"] = transaction["value"]
    result["transaction_value_wei"] = hex_quantity(transaction["value"])
    result["difference_wei"] = result["argument_wei"] - result["transaction_value_wei"]
    return result


def compare_case(transaction, expected):
    result = case_values(transaction)
    for key in ("amount_word_hex", "argument_wei", "transaction_value_hex",
                "transaction_value_wei", "difference_wei"):
        require(result[key] == expected[key], "case content mismatch: " + key)
    return result


def source_function(text, name):
    nodes = [node for node in ast.walk(ast.parse(text))
             if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name]
    require(len(nodes) == 1, "source function not unique: " + name)
    node = nodes[0]
    calls = [ast.unparse(child.func) for child in ast.walk(node)
             if isinstance(child, ast.Call)]
    return {
        "function": name,
        "line_start": node.lineno,
        "line_end": node.end_lineno,
        "source": ast.get_source_segment(text, node),
        "explicit_float_calls": calls.count("float"),
    }


def run(root):
    files = {}

    def read_bytes(relative):
        path = (root / relative).resolve()
        require(path.is_relative_to(root), "input outside root")
        data = path.read_bytes()
        files[relative] = {"sha256": sha(data), "bytes": len(data)}
        return data

    def read(relative):
        return parse_json(read_bytes(relative))

    state = read(CAPTURE + "/capture_state.json")
    predictions = read(REVISION + "/results/first_predictions.json")
    evaluation = read(REVISION + "/results/evaluation.json")
    metadata = read(REVISION + "/selection/selected_metadata.json")
    selected = read(REVISION + "/selection/selected_inputs.json")
    old_audit = read(REVISION + "/independent_recalculation.json")
    require(state["first_predictions_sha256"] == files[REVISION + "/results/first_predictions.json"]["sha256"],
            "first prediction hash differs from capture pin")
    require(state["selected_inputs_sha256"] == files[REVISION + "/selection/selected_inputs.json"]["sha256"],
            "selection hash differs from capture pin")
    require([row["txid"] for row in selected] == [row["txid"] for row in predictions["rows"]]
            == [row["txid"] for row in evaluation["rows"]]
            == [row["txid"] for row in metadata], "row order/identity")
    require(len(selected) == len({row["txid"] for row in selected}) == 96, "96 unique rows required")

    normalized_records = []
    periods = {quarter: Counter() for quarter in ("Q1", "Q3", "Q4")}
    target = None
    target_binding = None
    target_raw = None
    for pred, result, meta in zip(predictions["rows"], evaluation["rows"], metadata, strict=True):
        entry = state["requests"][state["records"][pred["txid"]]["transaction"]]
        require(entry["status"] == "available", "transaction unavailable")
        response_path = CAPTURE + "/" + entry["response_file"]
        raw = read_bytes(response_path)
        require(sha(raw) == entry["response_sha256"], "response capture hash mismatch")
        require(predictions["consumed_inputs_sha256"][response_path] == sha(raw),
                "response differs from prediction-consumed bytes")
        attempts = [a for a in entry["attempts"] if a.get("response_file") == entry["response_file"]]
        require(len(attempts) == 1, "response attempt ambiguity")
        attempt = attempts[0]
        request_path = CAPTURE + "/" + attempt["request_file"]
        request_raw = read_bytes(request_path)
        require(sha(request_raw) == attempt["request_sha256"], "request hash mismatch")
        request = parse_json(request_raw)
        envelope = parse_json(raw)
        require(request["method"] == entry["rpc_method"] == "eth_getTransactionByHash",
                "wrong RPC method")
        require(request["params"] == entry["params"] == [pred["txid"]], "RPC request transaction mismatch")
        require(request["id"] == envelope["id"] == attempt["serial"], "RPC id mismatch")
        require(request["jsonrpc"] == envelope["jsonrpc"] == "2.0", "RPC version mismatch")
        transaction = envelope["result"]
        require(transaction["hash"].lower() == pred["txid"], "RPC result transaction mismatch")
        value = hex_quantity(transaction["value"])
        require(type(pred["value_wei"]) is int and pred["value_wei"] == value,
                "prediction value differs from direct hex integer")
        require(pred["calldata"] == transaction["input"], "prediction calldata differs from response")
        require(type(result["deposit_wei"]) is int and result["deposit_wei"] == value,
                "evaluation value differs from direct hex integer")
        require(type(result["midgard_eth_partition_1e8"]) is int, "partition must be integer")
        calculated_partition_status = "consistent" if value // 10**10 == result["midgard_eth_partition_1e8"] else "mismatch"
        require(calculated_partition_status == result["eth_partition_status"], "partition status mismatch")
        periods[meta["period"]][calculated_partition_status] += 1
        normalized_records.append({
            "rank": pred["rank"], "txid": pred["txid"], "period": meta["period"],
            "response_file": response_path, "response_sha256": sha(raw),
            "request_file": request_path, "request_sha256": sha(request_raw),
            "raw_value_hex": transaction["value"], "direct_value_wei": value,
            "prediction_value_equal": True, "prediction_calldata_equal": True,
            "evaluation_value_equal": True,
            "eth_partition_status": calculated_partition_status,
        })
        if pred["txid"] == CASE:
            target, target_raw = transaction, raw
            target_binding = {
                "rank": pred["rank"], "txid": CASE,
                "request_file": request_path, "response_file": response_path,
                "request_sha256": sha(request_raw), "response_sha256": sha(raw),
                "rpc_method": request["method"], "rpc_params": request["params"],
                "rpc_id": request["id"], "endpoint": attempt["url"],
                "recorded_http_status": attempt["http_status"],
                "recorded_tls_verified": attempt["tls_verified"],
                "captured_utc": attempt["finished_utc"],
                "original_prediction_status": pred["status"],
                "original_prediction_error": pred["error"],
                "original_end_to_end_status": result["end_to_end_status"],
            }
    require(target is not None and target_raw is not None and target_binding is not None, "case missing")
    values = case_values(target)
    prior = [row for row in old_audit["external"]["decoder_error_diagnosis"] if row["txid"] == CASE]
    require(len(prior) == 1, "original diagnosis missing")
    require(values["argument_wei"] == prior[0]["argument_wei"]
            and values["transaction_value_wei"] == prior[0]["transaction_value_wei"],
            "direct extraction differs from preserved ABI diagnosis")
    require(values["difference_wei"] == 2, "preserved difference is not 2 wei")
    for field in ("input", "value"):
        matches = list(re.finditer(rb'"' + field.encode() + rb'"\s*:\s*"([^"\\]*)"', target_raw))
        require(len(matches) == 1, "raw JSON field not unique: " + field)
        match = matches[0]
        require(match[1].decode() == target[field], "raw token differs from JSON field")
        values[field + "_raw_response_byte_slice"] = list(match.span(1))
        if field == "input":
            start = match.start(1)
            values["amount_word_raw_response_byte_slice"] = [start + 138, start + 202]
    values["raw_calldata_hex"] = target["input"]

    controls = []
    compare_case(copy.deepcopy(target), values)
    controls.append({"name": "unchanged in-memory copy", "outcome": "PASS"})
    for name, field in (("value +1 wei", "value"), ("calldata amount +1 wei", "input")):
        changed = copy.deepcopy(target)
        if field == "value":
            changed[field] = hex(values["transaction_value_wei"] + 1)
        else:
            changed[field] = changed[field][:138] + format(values["argument_wei"] + 1, "064x") + changed[field][202:]
        try:
            compare_case(changed, values)
        except ValueError as exc:
            expected_key = "transaction_value_hex" if field == "value" else "amount_word_hex"
            require(str(exc) == "case content mismatch: " + expected_key, "wrong tamper failure")
            controls.append({"name": name, "outcome": "REJECTED", "reason": str(exc)})
        else:
            raise ValueError("tampered case accepted: " + name)
    for name, field, bad, reason in (
        ("malformed value hex", "value", "0xGG", "invalid canonical hex quantity"),
        ("non-string value", "value", 26710257243351726, "quantity must be a hex string"),
        ("malformed calldata hex", "input", target["input"][:-1] + "G", "invalid calldata hex"),
    ):
        changed = copy.deepcopy(target)
        changed[field] = bad
        try:
            case_values(changed)
        except ValueError as exc:
            require(str(exc) == reason, "wrong invalid-input failure")
            controls.append({"name": name, "outcome": "REJECTED", "reason": str(exc)})
        else:
            raise ValueError("invalid input accepted: " + name)

    source_specs = [
        (REVISION + "/capture_public_records.py", ["fetch"]),
        (REVISION + "/predict_frozen_decoder.py", ["main"]),
        (SOURCE + "/src/vca/adapters/evm/_normalizers.py", ["normalize_tx_from_proxy", "_maybe_calldata"]),
        (SOURCE + "/src/vca/decoders/thorchain.py", ["_decode_deposit_with_expiry_calldata", "_assert_native_amount_coherence", "decode"]),
    ]
    source_path = []
    for relative, functions in source_specs:
        text = read_bytes(relative).decode("utf-8")
        if relative.startswith(SOURCE + "/"):
            require(files[relative]["sha256"] == predictions["frozen_code_sha256"][relative[len(SOURCE) + 1:]],
                    "frozen source differs from first predictions")
        elif relative.endswith("predict_frozen_decoder.py"):
            require(files[relative]["sha256"] == predictions["predictor_sha256"], "predictor changed")
        else:
            require(any(run["script_sha256"] == files[relative]["sha256"] for run in state["stage_runs"]),
                    "capture script not bound to execution record")
        for name in functions:
            info = source_function(text, name)
            require(info["explicit_float_calls"] == 0, "float() call in audited function")
            source_path.append({"path": relative, "sha256": files[relative]["sha256"], **info})

    return {
        "status": "PASS", "schema": "vca.wei-integrity.v1",
        "scope": "Direct integer extraction from preserved RPC HTTP response bytes and comparison with 96 recorded predictions; not transaction-signature, consensus, upstream implementation, or independent-team authentication.",
        "network_requests": 0, "frozen_inputs_modified": False,
        "case": {**target_binding, **values},
        "conclusion": "The two different hex values already occur in the archived eth_getTransactionByHash response. All 96 recorded values and calldata strings equal that response's integer value and calldata. No amount change is observed from those archived bytes to the predictions. The upstream cause of the 2-wei difference is not established.",
        "integer_conversion_path": [
            "Capture.fetch reads response.read(MAX_BYTES + 1) and writes the same raw bytes with stream.write(raw) before JSON validation.",
            "predict_frozen_decoder.py loads result with json.loads, records int(tx['value'], 16), and copies tx['input'].",
            "normalize_tx_from_proxy uses Amount(raw=int(value_hex, 16), ...) and _maybe_calldata passes the string through.",
            "Frozen router uses bytes.fromhex(input_hex[10:]) and ABI uint256 decoding, then int(amount). This separate audit reads the third 32-byte word directly with int(word, 16).",
            "A nonzero native calldata amount is compared by integer equality with tx.value_native.raw; the original rejection and 46/96 completion count are preserved.",
        ],
        "source_function_evidence": source_path,
        "normalization_record_check": {"n": 96, "raw_vs_prediction_value_equal": 96,
            "raw_vs_prediction_calldata_equal": 96, "raw_vs_evaluation_value_equal": 96,
            "scope": "Recorded predictor inputs, plus source inspection; actual frozen runtime calls are a separate wei_runtime.json result.",
            "rows": normalized_records},
        "eth_partition_by_period": {quarter: {"n": sum(counter.values()),
            "consistent": counter["consistent"], "mismatch": counter["mismatch"]}
            for quarter, counter in periods.items()},
        "eth_partition_scope": "Recomputes saved classification from direct RPC value // 10**10 and saved Midgard partition integers. It does not recollect or reauthenticate Midgard responses.",
        "controls": {"normal": 1, "content_tamper": 2, "invalid_input": 3,
            "all_expected_outcomes": True, "file_hashes_used_in_in_memory_controls": False,
            "rows": controls},
        "float_illustration": {"int_float_raw_value": int(float(values["transaction_value_wei"])),
            "same_as_amount_argument": int(float(values["transaction_value_wei"])) == values["argument_wei"],
            "scope": "Diagnostic illustration only; it does not establish whether any upstream transaction creator or RPC implementation used floating point."},
        "inputs": dict(sorted(files.items())),
        "auditor_sha256": sha(Path(__file__).read_bytes()),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    result = run(root)
    output = args.output.resolve()
    require(output.is_relative_to(root), "output must be within root")
    output.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(result, indent=2, ensure_ascii=True) + "\n").encode()
    if output.exists():
        require(output.read_bytes() == encoded, "output exists with different bytes; choose a fresh path")
    else:
        output.write_bytes(encoded)
    print(json.dumps({"status": result["status"], "case_difference_wei": result["case"]["difference_wei"],
        "recorded_predictions_checked": 96, "controls": len(result["controls"]["rows"]),
        "eth_partition_by_period": result["eth_partition_by_period"]}))


if __name__ == "__main__":
    main()
