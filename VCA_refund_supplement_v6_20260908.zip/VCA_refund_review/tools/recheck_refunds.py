"""Offline supplement entry point; preserve distributed evidence and create new results."""

import hashlib
import importlib
import json
import shutil
import socket
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_files():
    manifest = json.loads((ROOT / "BUNDLE_MANIFEST.json").read_bytes())
    actual_files = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file()
                    and "_checks" not in p.relative_to(ROOT).parts and p.name != "BUNDLE_MANIFEST.json"}
    assert actual_files == set(manifest["files"]), "Missing or unexpected distributed file"
    for relative, record in manifest["files"].items():
        path = ROOT / relative
        assert path.is_file() and path.stat().st_size == record["bytes"] and sha(path) == record["sha256"], relative
    return len(manifest["files"])


def main():
    sys.dont_write_bytecode = True
    before = check_files()
    version = json.loads((ROOT / "VERSION_MANIFEST.json").read_bytes())
    destination = ROOT / "_checks"
    destination.mkdir(exist_ok=False)
    attempts = []

    def denied(*args, **kwargs):
        attempts.append("Python socket operation")
        raise RuntimeError("Network access is disabled for the offline refund check")

    socket.socket.connect = denied
    socket.socket.connect_ex = denied
    socket.create_connection = denied
    socket.getaddrinfo = denied
    import vca.types._bech32 as bech32

    assert sha(Path(bech32.__file__)) == version["frozen_bech32_sha256"], "Use the frozen revision-5 source environment"
    work = destination / "workspace"
    for folder in ("experiments", "captures"):
        shutil.copytree(ROOT / folder, work / folder)
    sys.path.insert(0, str(work / "experiments/revision_v2"))
    expected = json.loads((work / "experiments/revision_v2/evaluation.json").read_bytes())
    measured = importlib.import_module("evaluate_refunds").evaluate()
    for key in ("summary", "rows", "controls"):
        assert measured[key] == expected[key], key
    separate = importlib.import_module("verify_refunds").check_all()
    assert separate["status"] == "PASS"
    assert not attempts
    after = check_files()
    report = {"status": "PASS", "completed_utc": datetime.now(UTC).isoformat(),
        "files_checked_before": before, "files_checked_after": after,
        "summary": measured["summary"], "controls": len(measured["controls"]),
        "separate_recalculation": separate["status"], "python_socket_attempts": len(attempts),
        "scope": "New offline calculation in the supplied environment; no new acquisition or independent-team assertion."}
    (destination / "evaluation.json").write_bytes((json.dumps(measured, indent=2) + "\n").encode())
    (destination / "separate_recalculation.json").write_bytes((json.dumps(separate, indent=2) + "\n").encode())
    (destination / "RESULT.json").write_bytes((json.dumps(report, indent=2) + "\n").encode())
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
