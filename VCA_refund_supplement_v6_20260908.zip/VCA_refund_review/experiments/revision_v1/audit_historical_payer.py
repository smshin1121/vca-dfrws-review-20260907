"""Corroborate historical payout dispatch with THORNode and Bitcoin inputs.

The API observations remain a protocol source, not independent consensus
verification. No current active-vault list is substituted for historical data.
"""
import copy
import hashlib
import json
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

import yaml
from vca.types._bech32 import _convert_bits, _decode_bech32

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CAPTURE = ROOT / "captures/revision_v1_payer_hub"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def witness_script(public_key):
    decoded = _decode_bech32(public_key)
    if decoded is None or decoded[0] != "thorpub" or decoded[2] != 1:
        raise ValueError("Unsupported vault key encoding")
    data = _convert_bits(decoded[1], 5, 8, pad=False)
    if data is None:
        raise ValueError("Invalid vault key bit encoding")
    raw = bytes(data)
    if len(raw) != 38 or raw[:5].hex() != "eb5ae98721" or raw[5] not in (2, 3):
        raise ValueError("Unsupported amino/secp256k1 public key")
    digest = hashlib.new("ripemd160", hashlib.sha256(raw[5:]).digest()).hexdigest()
    return "0014" + digest


def check(inbound, outbound, bitcoin, source_id, output_id, recipient, amount):
    if inbound is None or outbound is None:
        return "protocol_unavailable", {}
    try:
        observed = outbound["tx"]
        payout = observed["tx"]
        historical = inbound["tx"]
        planned = [a for a in inbound["actions"] if a.get("chain") == "BTC" and a.get("to_address") == recipient and a.get("in_hash", "").lower() == source_id]
        emitted = [t for t in inbound["out_txs"] if t.get("id", "").lower() == output_id]
        checks = {
            "inbound_identity": inbound["tx_id"].lower() == historical["tx"]["id"].lower() == source_id,
            "outbound_identity": outbound["tx_id"].lower() == payout["id"].lower() == bitcoin["txid"].lower() == output_id,
            "protocol_chain": payout["chain"] == "BTC",
            "inbound_out_hash": output_id in {v.lower() for v in historical["out_hashes"]},
            "dispatch_record": len(emitted) == 1 and emitted[0] == payout,
            "recipient": payout["to_address"] == recipient,
            "amount": sum(int(c["amount"]) for c in payout["coins"] if c["asset"] == "BTC.BTC") == amount,
            "historical_vault_key": bool(observed["observed_pub_key"]) and any(a.get("vault_pub_key") == observed["observed_pub_key"] for a in planned),
            "memo_reference": payout["memo"].upper() == "OUT:" + source_id.upper(),
            "confirmed_bitcoin": bitcoin["status"]["confirmed"] is True,
            "input_payer_addresses": bool(bitcoin["vin"]) and all(v.get("prevout", {}).get("scriptpubkey_address") == payout["from_address"] for v in bitcoin["vin"]),
            "unique_recipient_output": [v["value"] for v in bitcoin["vout"] if v.get("scriptpubkey_address") == recipient] == [amount],
        }
        try:
            expected_script = witness_script(observed["observed_pub_key"])
        except ValueError:
            return "vault_key_encoding_unsupported", checks
        checks["input_scripts_from_historical_key"] = all(v.get("prevout", {}).get("scriptpubkey") == expected_script for v in bitcoin["vin"])
    except (KeyError, TypeError, ValueError) as error:
        return "protocol_fields_unavailable", {"error_type": type(error).__name__}
    return "corroborated" if all(checks.values()) else "mismatch", checks


def run():
    manifest = json.loads((CAPTURE / "manifest.json").read_text())
    requests = {r["name"].removeprefix("tx_"): r for r in manifest["requests"] if r["name"].startswith("tx_")}
    for request in manifest["requests"]:
        for attempt in request["attempts"]:
            if "response_file" in attempt:
                assert sha(CAPTURE / attempt["response_file"]) == attempt["sha256"]

    def protocol(identifier):
        entry = requests[identifier]
        if entry["status"] != "available":
            return None
        return json.loads((CAPTURE / entry["response_file"]).read_text())

    rows = []
    normal = None
    population = json.loads((HERE / "accounting_results.json").read_text())["rows"]
    for row in population:
        if row["raw_output_reference_satoshis"] is None:
            rows.append({"case": row["case"], "inbound": row["inbound_txid"], "status": "original_bitcoin_unavailable"})
            continue
        assert len(row["reference_outputs"]) == 1
        reference = row["reference_outputs"][0]
        source_id = row["inbound_txid"].removeprefix("0x")
        output_id = reference["txid"]
        origin = reference["origins"][0]
        cassette = yaml.load((ROOT / origin["file"]).read_text(encoding="utf-8"), Loader=yaml.CSafeLoader)
        payload = json.loads(cassette["interactions"][origin["interaction"]]["response"]["body"]["string"])
        bitcoin = next(t for t in (payload if isinstance(payload, list) else [payload]) if t["txid"] == output_id)
        args = (protocol(source_id), protocol(output_id), bitcoin, source_id, output_id, row["recipient"], reference["satoshis"])
        status, assertions = check(*args)
        rows.append({"case": row["case"], "inbound": source_id, "outbound": output_id, "status": status, "checks": assertions})
        if normal is None and status == "corroborated":
            normal = args
    assert normal is not None, "Need a positive control before interpreting negative results"
    controls = []

    def control(name, args, expected):
        actual, _ = check(*args)
        assert actual == expected, (name, actual)
        controls.append({"name": name, "expected": expected, "actual": actual})

    control("unchanged_deep_copy", copy.deepcopy(normal), "corroborated")
    modified = copy.deepcopy(normal)
    modified[2]["vin"][0]["prevout"]["scriptpubkey_address"] = "unrelated-payer"
    control("correct_reference_recipient_wrong_payer", modified, "mismatch")
    modified = copy.deepcopy(normal)
    for action in modified[0]["actions"]:
        if action.get("chain") == "BTC":
            action["vault_pub_key"] = "different-historical-vault"
    control("different_dispatch_vault", modified, "mismatch")
    modified = copy.deepcopy(normal)
    modified[0]["tx"]["out_hashes"] = []
    control("missing_inbound_payout_link", modified, "mismatch")
    modified = list(copy.deepcopy(normal))
    modified[0] = None
    control("protocol_unavailable_not_match", modified, "protocol_unavailable")
    modified = copy.deepcopy(normal)
    modified[2]["vout"][0]["value"] += 1
    control("one_satoshi_changed", modified, "mismatch")
    modified = copy.deepcopy(normal)
    modified[2]["vin"][0]["prevout"]["scriptpubkey"] = "0014" + "00" * 20
    control("same_address_label_wrong_locking_script", modified, "mismatch")
    return {"status": "MEASURED", "created_utc": datetime.now(UTC).isoformat(), "counts": dict(Counter(r["status"] for r in rows)),
        "rows": rows, "controls": controls, "scope": "Historical protocol dispatch corroboration, dependent on THORNode and saved explorer responses. No full-node or independent-consensus verification.",
        "source_manifest_sha256": sha(CAPTURE / "manifest.json"), "script_sha256": sha(Path(__file__))}


if __name__ == "__main__":
    out = HERE / "historical_payer_results.json"
    assert not out.exists()
    result = run()
    out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"counts": result["counts"], "controls": len(result["controls"])}))
