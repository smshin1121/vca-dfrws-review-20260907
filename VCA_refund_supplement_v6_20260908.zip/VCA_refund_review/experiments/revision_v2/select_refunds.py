"""Select a fixed external accounting set from preserved refund frame pages."""

import re
from collections import Counter

from capture_refunds import DEST, HERE, ROOT, epoch, now, read, sha, write_new


def select():
    paths = [HERE / "REFUND_PROTOCOL.md", HERE / "frame_capture.json",
             ROOT / "experiments/revision_v1/selection/exclusions.json",
             ROOT / "experiments/revision_v1/selection/sealed_labels.json"]
    hashes = {p.relative_to(ROOT).as_posix(): sha(p.read_bytes()) for p in paths}
    exclusion = read(paths[2])
    old_ids = set(exclusion["identifiers"])
    old_senders = set(exclusion["evm_senders"])
    old_recipients = set(exclusion["btc_recipients"])
    for label in read(paths[3]):
        old_ids.add(label["txid"].lower())
        old_senders.update(leg["address"].lower() for leg in label["record"]["in"])
        old_recipients.update(leg["address"] for leg in label["record"]["out"])
    frame = read(paths[1])
    assert frame["protocol_sha256"] == hashes[paths[0].relative_to(ROOT).as_posix()]
    eligible, exclusions, selected, frame_counts = [], [], [], []
    seen = set()
    for period in frame["periods"]:
        local = []
        for page in period["pages"]:
            request_path = DEST / "requests" / (page["key"] + ".json")
            request = read(request_path)
            response_path = DEST / request["response_file"]
            assert sha(response_path.read_bytes()) == request["response_sha256"]
            hashes[request_path.relative_to(ROOT).as_posix()] = sha(request_path.read_bytes())
            hashes[response_path.relative_to(ROOT).as_posix()] = request["response_sha256"]
            for index, action in enumerate(read(response_path)["actions"]):
                origin = {"period": period["period"], "page_key": page["key"], "action_index": index}
                date = int(action["date"])
                reason = None
                if not epoch(period["lower"]) * 10**9 <= date < epoch(period["upper"]) * 10**9:
                    reason = "outside_period"
                elif action.get("type") != "refund":
                    reason = "non_refund_action"
                elif len(action.get("in", [])) != 1:
                    reason = "inbound_cardinality"
                else:
                    leg = action["in"][0]
                    coins = leg.get("coins", [])
                    identifier = "0x" + leg.get("txID", "").lower().removeprefix("0x")
                    memo = action.get("metadata", {}).get("refund", {}).get("memo", "")
                    fields = memo.split(":")
                    if not coins or any(c.get("asset") != "ETH.ETH" for c in coins):
                        reason = "non_native_eth_input"
                    elif not re.fullmatch(r"0x[0-9a-f]{64}", identifier):
                        reason = "invalid_inbound_id"
                    elif len(fields) < 3 or fields[0].upper() not in {"SWAP", "S", "=", "=<"} or fields[1].upper() not in {"BTC.BTC", "BTC", "B"} or not fields[2]:
                        reason = "outside_literal_btc_memo_forms"
                    else:
                        recipient = fields[2].split("/", 1)[0]
                        sender = leg.get("address", "").lower()
                        if identifier in old_ids or sender in old_senders or recipient in old_recipients:
                            reason = "prior_sample_or_development_overlap"
                        elif identifier in seen:
                            reason = "duplicate_inbound"
                        else:
                            seen.add(identifier)
                            btc_claims = [c for out in action.get("out", []) for c in out.get("coins", []) if c.get("asset") == "BTC.BTC"]
                            row = {**origin, "txid": identifier, "timestamp_ns": str(date),
                                   "sender": sender, "memo": memo, "memo_recipient": recipient,
                                   "frame_stratum": "btc_claim" if btc_claims else "no_btc_claim",
                                   "rank_sha256": sha(("VCA-REFUND2-20260908|" + identifier).encode())}
                            eligible.append(row)
                            local.append(row)
                if reason:
                    exclusions.append({**origin, "reason": reason})
        for stratum in ("btc_claim", "no_btc_claim"):
            rows = sorted((r for r in local if r["frame_stratum"] == stratum), key=lambda r: (r["rank_sha256"], r["txid"]))
            selected.extend(rows[:8])
        frame_counts.append({"period": period["period"], "frame_stop": period["stop"],
            "eligible": len(local), "strata": dict(Counter(r["frame_stratum"] for r in local))})
    result = {"created_utc": now(), "inputs_sha256": hashes, "frame_counts": frame_counts,
        "exclusion_counts": dict(Counter(x["reason"] for x in exclusions)),
        "eligible": eligible, "exclusions": exclusions, "selected": selected,
        "n": len(selected), "scope": "Refund-exposed case study; not decoder accuracy or population prevalence."}
    write_new(HERE / "selection.json", result)
    print({"n": result["n"], "frame_counts": frame_counts, "excluded": result["exclusion_counts"]})


if __name__ == "__main__":
    select()
