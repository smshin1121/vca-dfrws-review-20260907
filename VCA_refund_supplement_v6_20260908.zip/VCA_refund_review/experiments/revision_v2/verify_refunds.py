"""Separate raw-byte recalculation; imports no selector, evaluator or VCA code."""

import hashlib
import json
import re
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CAPTURES = ROOT / "captures/revision_v2_refunds"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def response(key):
    entry = read(CAPTURES / "requests" / (key + ".json"))
    if entry["status"] != "available":
        return None
    path = CAPTURES / entry["response_file"]
    assert digest(path) == entry["response_sha256"]
    data = read(path)
    return data["result"] if entry["rpc_method"] else data


def normal(identifier):
    return identifier.lower().removeprefix("0x")


def check_all():
    expected = read(HERE / "evaluation.json")
    selection = read(HERE / "selection.json")
    frame = read(HERE / "frame_capture.json")
    captures = read(HERE / "selected_capture.json")
    for name, wanted in expected["inputs_sha256"].items():
        assert digest(ROOT / name) == wanted, name
    # Check failed attempts too; all source records and byte hashes are retained.
    requests = [read(p) for p in sorted((CAPTURES / "requests").glob("*.json"))]
    for entry in requests:
        assert entry["protocol_sha256"] == digest(HERE / "REFUND_PROTOCOL.md")
        for attempt in entry["attempts"]:
            for kind in ("request", "response"):
                if kind + "_file" in attempt:
                    assert digest(CAPTURES / attempt[kind + "_file"]) == attempt[kind + "_sha256"]
            assert attempt["tls_verified"] is True and attempt["authorization_sent"] is False
    assert len(requests) <= 400 and sum(len(r["attempts"]) for r in requests) <= 800
    exclusions = read(ROOT / "experiments/revision_v1/selection/exclusions.json")
    ids = {normal(x) for x in exclusions["identifiers"]}
    senders = {x.lower() for x in exclusions["evm_senders"]}
    recipients = set(exclusions["btc_recipients"])
    for old in read(ROOT / "experiments/revision_v1/selection/sealed_labels.json"):
        ids.add(normal(old["txid"]))
        senders.update(leg["address"].lower() for leg in old["record"]["in"])
        recipients.update(leg["address"] for leg in old["record"]["out"])
    candidates, seen, period_counts = {}, set(), {}
    for period in frame["periods"]:
        lower = int(datetime.fromisoformat(period["lower"]).replace(tzinfo=UTC).timestamp()) * 10**9
        upper = int(datetime.fromisoformat(period["upper"]).replace(tzinfo=UTC).timestamp()) * 10**9
        for page in period["pages"]:
            for row in response(page["key"])["actions"]:
                if not lower <= int(row["date"]) < upper or row["type"] != "refund" or len(row["in"]) != 1:
                    continue
                incoming = row["in"][0]
                if not incoming["coins"] or {c["asset"] for c in incoming["coins"]} != {"ETH.ETH"}:
                    continue
                txid = normal(incoming["txID"])
                fields = row["metadata"]["refund"]["memo"].split(":")
                if not re.fullmatch("[0-9a-f]{64}", txid) or len(fields) < 3 or fields[0].upper() not in ("SWAP", "S", "=", "=<") or fields[1].upper() not in ("BTC.BTC", "BTC", "B") or not fields[2]:
                    continue
                if txid in ids or incoming["address"].lower() in senders or fields[2].split("/")[0] in recipients or txid in seen:
                    continue
                seen.add(txid)
                shape = "btc_claim" if any(c["asset"] == "BTC.BTC" for out in row["out"] for c in out["coins"]) else "no_btc_claim"
                key = (period["period"], shape)
                ranking = hashlib.sha256(("VCA-REFUND2-20260908|0x" + txid).encode()).hexdigest()
                candidates.setdefault(key, []).append((ranking, "0x" + txid))
        period_counts[period["period"]] = {kind: len(candidates.get((period["period"], kind), [])) for kind in ("btc_claim", "no_btc_claim")}
    regenerated = [identifier for period in frame["periods"] for kind in ("btc_claim", "no_btc_claim")
                   for _, identifier in sorted(candidates.get((period["period"], kind), []))[:8]]
    assert regenerated == [x["txid"] for x in selection["selected"]]
    findings = []
    for chosen, capture, result in zip(selection["selected"], captures["rows"], expected["rows"], strict=True):
        inbound = normal(chosen["txid"])
        assert datetime.fromisoformat(selection["created_utc"]) < datetime.fromisoformat(capture["started_utc"])
        actions = [a for key in capture["action_pages"] for a in response(key)["actions"]]
        assert actions and all({normal(i["txID"]) for i in a["in"]} == {inbound} for a in actions)
        assert capture["action_stop"] == "short_final_page"
        btc_claims = [(normal(o["txID"]), o["address"], int(c["amount"])) for a in actions for o in a["out"] for c in o["coins"] if c["asset"] == "BTC.BTC"]
        native = {(normal(o["txID"]), o["address"].lower(), int(c["amount"])) for a in actions for o in a["out"] for c in o["coins"] if c["asset"] == "ETH.ETH"}
        total, output_ids = 0, []
        for txid in sorted({c[0] for c in btc_claims}):
            transaction = response(capture["btc"][txid])
            assert transaction["txid"] == txid and transaction["status"]["confirmed"] is True
            for index, out in enumerate(transaction["vout"]):
                if out.get("scriptpubkey_address") == chosen["memo_recipient"]:
                    total += out["value"]
                    output_ids.append(["BTC", txid, index])
        assert result["reference_btc_satoshis"] == (total if output_ids else None)
        assert result["naive_btc_satoshis"] == sum(c[2] for c in btc_claims)
        assert result["frozen_btc_satoshis"] == sum(c[2] for c in set(btc_claims))
        assert output_ids == [r["output_id"] for r in result["reference_outputs"]]
        inbound_protocol = response(capture["thor"][inbound])
        assert normal(inbound_protocol["tx_id"]) == inbound
        native_checks = []
        for txid, recipient, amount in sorted(native):
            keys = capture["eth_refunds"][txid]
            tx, receipt = response(keys["tx"]), response(keys["receipt"])
            assert normal(tx["hash"]) == normal(receipt["transactionHash"]) == txid
            assert tx["blockHash"] == receipt["blockHash"] and receipt["status"] == "0x1"
            matches = []
            for log in receipt["logs"]:
                if log["topics"][0] != "0xa9cd03aa3c1b4515114539cd53d22085129d495cb9e9f9af77864526240f1bf7":
                    continue
                assert len(log["topics"]) == 3 and all(t[2:26] == "0" * 24 for t in log["topics"][1:])
                if log["topics"][2][-40:].lower() != recipient[2:]:
                    continue
                assert log["address"].lower() == tx["to"].lower()
                assert log["removed"] is False and log["blockHash"] == receipt["blockHash"] and normal(log["transactionHash"]) == txid
                assert log["topics"][1][-40:].lower() == tx["from"][2:].lower()
                data = bytes.fromhex(log["data"][2:])
                word = lambda offset: int.from_bytes(data[offset:offset + 32], "big")
                assert word(0) == 0
                value, memo_offset = word(32), word(64)
                assert memo_offset == 96 and len(data) >= memo_offset + 32
                size = word(memo_offset)
                assert len(data) >= memo_offset + 32 + size
                memo = data[memo_offset + 32:memo_offset + 32 + size].decode()
                if memo.upper() != "REFUND:" + inbound.upper():
                    continue
                assert value == amount * 10**10 == int(tx["value"], 16)
                matches.append(["ETH", txid, int(log["logIndex"], 16)])
            assert len(matches) == 1
            recorded = [out for out in inbound_protocol["out_txs"] if normal(out["id"]) == txid]
            assert len(recorded) == 1
            dispatch = recorded[0]
            assert dispatch["chain"] == "ETH" and dispatch["to_address"].lower() == recipient
            assert dispatch["from_address"].lower() == tx["from"].lower() and dispatch["memo"].upper() == "REFUND:" + inbound.upper()
            assert sum(int(c["amount"]) for c in dispatch["coins"] if c["asset"] == "ETH.ETH") == amount
            native_checks.append(matches[0])
        assert native_checks == [r["output_id"] for r in result["eth_refund_checks"]]
        source_tx = response(capture["input_tx"])
        actual_input = int(source_tx["value"], 16) // 10**10
        parts = sum(int(c["amount"]) for a in actions for i in a["in"] for c in i["coins"] if c["asset"] == "ETH.ETH")
        swap = sum(int(c["amount"]) for a in actions if a["type"] == "swap" for i in a["in"] for c in i["coins"] if c["asset"] == "ETH.ETH")
        fee = sum(int(c["amount"]) for a in actions if a["type"] == "refund" for c in a["metadata"]["refund"]["networkFees"] if c["asset"] == "ETH.ETH")
        assert actual_input == parts == swap + sum(c[2] for c in native) + fee
        findings.append({"inbound": chosen["txid"], "btc_output_ids": output_ids,
                         "eth_output_ids": native_checks, "eth_dispatch_correspondence": True})
    return {"status": "PASS", "created_utc": datetime.now(UTC).isoformat(),
        "scope": "Separate implementation in the same research workflow; not independent-team reproduction.",
        "selection_reconstructed": regenerated, "eligible_by_period": period_counts,
        "requests": len(requests), "http_attempts": sum(len(r["attempts"]) for r in requests),
        "request_statuses": dict(Counter(r["status"] for r in requests)),
        "evaluation_sha256": digest(HERE / "evaluation.json"), "findings": findings,
        "summary_checked": expected["summary"], "source_sha256": digest(Path(__file__))}


if __name__ == "__main__":
    report = check_all()
    with (HERE / "independent_recalculation.json").open("xb") as stream:
        stream.write((json.dumps(report, indent=2) + "\n").encode())
    print({k: report[k] for k in ("status", "requests", "http_attempts", "request_statuses")})
