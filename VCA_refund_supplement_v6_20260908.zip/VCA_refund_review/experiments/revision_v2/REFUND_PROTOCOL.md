# External refund accounting probe, revision 2

Recorded before collecting candidate actions or selecting transactions on
2026-09-08 (Korea). Revision 5, its frozen decoder, the initial 40 swaps and
the additional 96 swaps remain unchanged. This is a locally prospective
protocol, not public preregistration.

## Question and scope

Does repeated BTC payout reporting across Midgard swap/refund actions also
occur outside the two development incidents? Compare raw action summation,
the frozen four-field accounting key, an amount-independent enumeration of
actual recipient outputs in the referenced Bitcoin transactions, and the
existing supplemental output-index audit. This is an external accounting
case study selected for refund exposure, not a population prevalence estimate,
an unseen-decoder accuracy test, or independent payout discovery.

## Fixed frame and selection

Collect up to ten pages of 50 Midgard `type=refund&asset=ETH.ETH` actions in
each of two UTC periods: January 2025 and August 2026. Start just before the
following month's first second (`timestamp`); follow `nextPageToken` backwards.
Stop at the lower date boundary, an empty/short final page, a repeated token,
a failed response, or the ten-page ceiling. Do not infer completeness from a
failed page or a count of -1. Preserve every page and its stopping reason.
Client-side time filtering enforces the periods even if an endpoint ignores
query parameters. Report a truncated frame if the ceiling is reached.

Eligibility requires one inbound leg containing only native ETH.ETH, a
64-hex inbound identifier, and a refund memo explicitly requesting BTC:
command SWAP, S, =, or =<; target BTC.BTC, BTC, or B (case-insensitive).
Aliases, invalid memos and other assets outside these literal forms are
recorded as exclusions. Require a nonempty destination field, retaining it
verbatim for later validation. These criteria inspect the protocol record,
not the frozen decoder's ability to handle it.

Exclude inbound identifiers and participant addresses in the saved development
and initial-40 exclusion set, plus the selected additional 96 swaps. Preserve
the earlier exclusion policy's public-infrastructure exceptions. Deduplicate
inbound IDs by first captured occurrence. Within each period create two
descriptive strata from the refund action: at least one BTC output claim, or
no BTC output claim. The latter does not by itself prove that no BTC payment
exists. Sort by SHA256("VCA-REFUND2-20260908|" + lowercase-0x-inbound-ID)
and select up to eight per stratum (maximum 32). No replacement for later
unavailable, inconsistent, unsupported, pending or ambiguous observations.
Strata are not labelled partial/full refund until the complete bound action
response has been checked.

## Collection and checks

Save selection before querying selected inbound IDs. Fetch each selected ID's
Midgard actions, Ethereum transaction and receipt, native-ETH refund transaction
and receipt when an ETH output is claimed, and every claimed BTC transaction.
Follow bounded action pagination (up to four pages per selected ID); missing
pages mean action coverage is incomplete. Collect THORNode transaction details
for each selected inbound and claimed BTC outbound as protocol corroboration.
No reference amount is used when enumerating raw Bitcoin outputs to the memo
recipient; the referenced transaction IDs still come from Midgard.

Report BTC claims, unique indexed outputs, missing/ambiguous/mismatched cases,
naive and deduplicated totals, and the actually enumerable reference totals.
Do not assign a verified BTC total of zero merely because the captured actions
contain no BTC claim. Native ETH refund amounts must be checked against actual
transaction value or an explicitly decoded router transfer event; unsupported
contracts remain unresolved. Distinguish cross-asset outputs (BTC payout plus
ETH refund) from multiple distinct BTC outputs and from duplicate action rows.
Do not claim this probe validates distinct equal-valued BTC outputs unless
such real outputs are actually found.

Use the existing output-index audit unchanged, including its conservative
unresolved result for empty BTC claims. Keep any new no-BTC classification as
a separate descriptive field. Recompute results with a separate implementation
and meaningful positive/negative evidence controls before editing the paper.
Failures stay in all relevant denominators. New findings can change conclusions;
they cannot justify silently revising this protocol or old predictions.

## Access and preservation

Unauthenticated HTTPS only: gateway.liquify.com (Midgard/THORNode),
ethereum-rpc.publicnode.com or eth.llamarpc.com (eth_getTransactionByHash and
eth_getTransactionReceipt), blockstream.info or mempool.space (Bitcoin JSON).
At most 400 logical requests, two attempts each, one in flight, 0.5-second
minimum start spacing, 25-second timeout, 10 MB maximum response, verified TLS.
Public documentation may additionally be archived from GitLab and the official
Midgard Swagger endpoint. No payments, credentials or blockchain writes.
Preserve raw bytes, request parameters, capture times, failed attempts,
selection and protocol hashes. Every new result belongs to revision 2;
the published revision-5 package remains immutable.

API specification consulted before collection:
https://midgard.thorchain.network/v2/doc
https://gitlab.com/thorchain/midgard/-/raw/develop/internal/timeseries/actions.go
`timestamp` uses seconds; action dates use nanoseconds; backward tokens must
not be combined with `timestamp`. The source's count may be unavailable.
