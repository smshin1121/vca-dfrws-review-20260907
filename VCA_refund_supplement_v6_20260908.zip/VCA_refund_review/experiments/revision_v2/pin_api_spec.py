"""Preserve the exact public API and event schema used for the refund audit."""

import json
import re

from capture_refunds import Capture, HERE, MIDGARD, now, write_new

capture = Capture()
swagger = capture.fetch("reference_midgard_swagger", [MIDGARD + "/v2/swagger.json"])
commit = capture.fetch("reference_router_commit", [
    "https://gitlab.com/api/v4/projects/thorchain%2Fthornode/repository/commits/v1.109.2"])
assert commit is not None
revision = commit["id"]
path = "bifrost/pkg/chainclients/ethereum/smart_contract.go"
source_url = f"https://gitlab.com/thorchain/thornode/-/raw/{revision}/{path}"
raw = capture.fetch("reference_router_abi", [source_url], json_expected=False)
assert raw is not None
match = re.search(r'routerContractABI\s*=\s*("(?:\\.|[^"\\])*")', raw.decode())
assert match
abi = json.loads(json.loads(match[1]))
event = next(x for x in abi if x.get("type") == "event" and x.get("name") == "TransferOut")
assert [(x["type"], x["indexed"]) for x in event["inputs"]] == [
    ("address", True), ("address", True), ("address", False), ("uint256", False), ("string", False)]
write_new(HERE / "api_spec.json", {"created_utc": now(), "midgard_swagger_available": swagger is not None,
    "router_commit": revision, "router_source_url": source_url, "transfer_out_event": event,
    "scope": "Pins the stable event schema; not proof of a deployed contract's bytecode or historical version."})
print({"router_commit": revision, "midgard_swagger_available": swagger is not None})
