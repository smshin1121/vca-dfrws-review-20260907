"""Acquire selected refund observations without replacing any failed case."""

import re
from urllib.parse import urlencode

from capture_refunds import Capture, HERE, MIDGARD, THOR, now, read, sha, write_new

RPC = ("https://ethereum-rpc.publicnode.com", "https://eth.llamarpc.com")


def identifier(value):
    value = value.lower().removeprefix("0x")
    return value if re.fullmatch(r"[0-9a-f]{64}", value) else None


def run():
    capture = Capture()
    selected_path = HERE / "selection.json"
    selected_hash = sha(selected_path.read_bytes())
    selected = read(selected_path)["selected"]
    rows = []
    for index, item in enumerate(selected, 1):
        report_path = HERE / "cases" / f"{index:02}_capture.json"
        if report_path.exists():
            row = read(report_path)
            assert row["selection_sha256"] == selected_hash and row["txid"] == item["txid"]
            rows.append(row)
            continue
        inbound = identifier(item["txid"])
        assert inbound
        row = {"index": index, "txid": item["txid"], "selection_sha256": selected_hash,
            "started_utc": now(), "action_pages": [], "btc": {}, "eth_refunds": {}, "thor": {},
            "invalid_output_identifiers": []}
        for suffix, method in (("tx", "eth_getTransactionByHash"), ("receipt", "eth_getTransactionReceipt")):
            key = "eth_" + inbound + "_" + suffix
            capture.fetch(key, RPC, method=method, params=["0x" + inbound])
            row["input_" + suffix] = key
        actions = []
        token = None
        tokens = set()
        row["action_stop"] = "page_ceiling"
        for page in range(4):
            params = {"txid": inbound, "limit": 50}
            if token:
                params["nextPageToken"] = token
            key = f"selected_{index:02}_actions_{page + 1}"
            url = MIDGARD + "/v2/actions?" + urlencode(params)
            data = capture.fetch(key, [url, url])
            row["action_pages"].append(key)
            if data is None or not isinstance(data.get("actions"), list):
                row["action_stop"] = "unavailable_page"
                break
            actions.extend(data["actions"])
            if len(data["actions"]) < 50:
                row["action_stop"] = "short_final_page"
                break
            token = data.get("meta", {}).get("nextPageToken")
            if not token or token in tokens:
                row["action_stop"] = "missing_or_repeated_token"
                break
            tokens.add(token)
        bound = [a for a in actions if {identifier(x.get("txID", "")) for x in a.get("in", [])} == {inbound}]
        row["bound_actions"] = len(bound)
        row["other_actions"] = len(actions) - len(bound)
        for action in bound:
            for leg in action.get("out", []):
                assets = {coin.get("asset") for coin in leg.get("coins", [])}
                output = identifier(leg.get("txID", ""))
                if not output:
                    row["invalid_output_identifiers"].append(leg)
                    continue
                if "BTC.BTC" in assets and output not in row["btc"]:
                    key = "btc_" + output
                    capture.fetch(key, ["https://blockstream.info/api/tx/" + output,
                        "https://mempool.space/api/tx/" + output])
                    row["btc"][output] = key
                if "ETH.ETH" in assets and output not in row["eth_refunds"]:
                    record = {}
                    for suffix, method in (("tx", "eth_getTransactionByHash"), ("receipt", "eth_getTransactionReceipt")):
                        key = "eth_" + output + "_" + suffix
                        capture.fetch(key, RPC, method=method, params=["0x" + output])
                        record[suffix] = key
                    row["eth_refunds"][output] = record
        for txid in [inbound] + sorted(row["btc"]):
            key = "thor_" + txid
            url = THOR + "/thorchain/tx/details/" + txid.upper()
            capture.fetch(key, [url, url])
            row["thor"][txid] = key
        row["ended_utc"] = now()
        write_new(report_path, row)
        rows.append(row)
        print({"completed_case": index, "of": len(selected)}, flush=True)
    write_new(HERE / "selected_capture.json", {"ended_utc": now(), "selection_sha256": selected_hash, "rows": rows})


if __name__ == "__main__":
    run()
