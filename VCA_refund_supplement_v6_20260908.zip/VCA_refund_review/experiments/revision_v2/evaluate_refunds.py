"""Evaluate saved external refund actions; never treat missing BTC claims as proof of zero."""

import copy
import sys
from collections import Counter

from eth_abi import decode
from eth_utils import keccak

from capture_refunds import DEST, HERE, ROOT, now, read, sha, write_new

sys.path.insert(0, str(HERE.parent / "revision_v1"))
from audit_historical_payer import check as payer_check  # noqa: E402
from output_audit import audit_outputs, bitcoin_claims, frozen_four_field_total  # noqa: E402

ZERO = "0x" + "00" * 20
EVENT_TOPIC = "0x" + keccak(text="TransferOut(address,address,address,uint256,string)").hex()


def norm(identifier):
    return identifier.lower().removeprefix("0x")


class Evidence:
    def __init__(self):
        self.hashes = {}

    def file(self, path):
        self.hashes[path.relative_to(ROOT).as_posix()] = sha(path.read_bytes())
        return read(path)

    def payload(self, key):
        record = self.file(DEST / "requests" / (key + ".json"))
        for attempt in record["attempts"]:
            for prefix in ("request", "response"):
                if prefix + "_file" in attempt:
                    path = DEST / attempt[prefix + "_file"]
                    actual = sha(path.read_bytes())
                    assert actual == attempt[prefix + "_sha256"]
                    self.hashes[path.relative_to(ROOT).as_posix()] = actual
        if record["status"] != "available":
            return None
        data = self.file(DEST / record["response_file"])
        return data["result"] if record["rpc_method"] else data


def eth_refund_check(tx, receipt, inbound, txid, recipient, e8_amount):
    if tx is None or receipt is None:
        return {"status": "transaction_or_receipt_unavailable"}
    if norm(tx["hash"]) != txid or norm(receipt["transactionHash"]) != txid or tx.get("blockHash") != receipt.get("blockHash"):
        return {"status": "identity_mismatch"}
    if receipt.get("status") != "0x1" or tx.get("blockHash") is None:
        return {"status": "unsuccessful_or_unconfirmed"}
    candidates = []
    for log in receipt.get("logs", []):
        topics = log.get("topics", [])
        if len(topics) != 3 or topics[0].lower() != EVENT_TOPIC or log.get("address", "").lower() != tx.get("to", "").lower():
            continue
        if log.get("removed") is not False or norm(log.get("transactionHash", "")) != txid or log.get("blockHash") != tx.get("blockHash"):
            continue
        try:
            asset, amount, memo = decode(["address", "uint256", "string"], bytes.fromhex(log["data"][2:]))
            vault = "0x" + topics[1][-40:].lower()
            destination = "0x" + topics[2][-40:].lower()
            index = int(log["logIndex"], 16)
        except (ValueError, KeyError):
            continue
        if asset != ZERO or memo.upper() != "REFUND:" + inbound.upper() or destination != recipient.lower() or vault != tx["from"].lower() or index < 0:
            continue
        candidates.append({"output_id": ["ETH", txid, index], "recipient": destination,
                           "wei": amount, "memo": memo, "vault": vault, "router": log["address"].lower()})
    if len(candidates) != 1:
        return {"status": "ambiguous_refund_event" if candidates else "refund_event_unresolved", "candidates": candidates}
    candidate = candidates[0]
    if candidate["wei"] != e8_amount * 10**10:
        return {"status": "refund_amount_mismatch", "candidate": candidate}
    return {"status": "resolved_router_event", **candidate,
            "top_level_value_matches_event": int(tx["value"], 16) == candidate["wei"]}


def evaluate():
    evidence = Evidence()
    selection = evidence.file(HERE / "selection.json")
    captured = evidence.file(HERE / "selected_capture.json")
    assert captured["selection_sha256"] == sha((HERE / "selection.json").read_bytes())
    evidence.file(HERE / "api_spec.json")
    for relative, expected in selection["inputs_sha256"].items():
        assert sha((ROOT / relative).read_bytes()) == expected
        evidence.hashes[relative] = expected
    rows, normal_btc, normal_eth = [], None, None
    for selected, case in zip(selection["selected"], captured["rows"], strict=True):
        assert selected["txid"] == case["txid"]
        assert selection["created_utc"] < case["started_utc"]
        source_id = norm(case["txid"])
        actions, missing_pages = [], []
        for key in case["action_pages"]:
            response = evidence.payload(key)
            if response is None:
                missing_pages.append(key)
            else:
                actions.extend(response["actions"])
        bound = [a for a in actions if {norm(x.get("txID", "")) for x in a.get("in", [])} == {source_id}]
        action_complete = case["action_stop"] == "short_final_page" and not missing_pages and len(actions) == len(bound)
        tx = evidence.payload(case["input_tx"])
        receipt = evidence.payload(case["input_receipt"])
        btc = {txid: evidence.payload(key) for txid, key in case["btc"].items()}
        btc = {key: value for key, value in btc.items() if value is not None}
        claims = bitcoin_claims(bound)
        audit = audit_outputs(bound, btc)
        # Independent reference calculation enumerates every output to the memo
        # recipient in unique named transactions, without using claim amounts.
        referenced = {c["txid"] for c in claims}
        ref_outputs = []
        missing_btc = []
        for txid in sorted(referenced):
            transaction = btc.get(txid)
            if transaction is None or norm(transaction.get("txid", "")) != txid or transaction.get("status", {}).get("confirmed") is not True:
                missing_btc.append(txid)
                continue
            for vout, output in enumerate(transaction["vout"]):
                if output.get("scriptpubkey_address") == selected["memo_recipient"]:
                    ref_outputs.append({"output_id": ["BTC", txid, vout], "satoshis": output["value"]})
        reference_total = sum(o["satoshis"] for o in ref_outputs) if ref_outputs and not missing_btc and action_complete else None
        native_claims = {(norm(o["txID"]), o["address"].lower(), int(c["amount"]))
            for a in bound for o in a.get("out", []) for c in o.get("coins", []) if c["asset"] == "ETH.ETH"}
        refunds = []
        for txid, recipient, amount in sorted(native_claims):
            keys = case["eth_refunds"].get(txid)
            args = (evidence.payload(keys["tx"]) if keys else None,
                    evidence.payload(keys["receipt"]) if keys else None,
                    source_id, txid, recipient, amount)
            result = eth_refund_check(*args)
            refunds.append({"claimed_e8": amount, **result})
            if normal_eth is None and result["status"] == "resolved_router_event":
                normal_eth = args
        protocol = {txid: evidence.payload(key) for txid, key in case["thor"].items()}
        payer = []
        for ref in ref_outputs:
            txid = ref["output_id"][1]
            status, checks = payer_check(protocol.get(source_id), protocol.get(txid), btc[txid],
                source_id, txid, selected["memo_recipient"], ref["satoshis"])
            payer.append({"txid": txid, "status": status, "checks": checks})
        native_inputs = sum(int(c["amount"]) for a in bound for leg in a.get("in", []) for c in leg.get("coins", []) if c["asset"] == "ETH.ETH")
        swap_inputs = sum(int(c["amount"]) for a in bound if a["type"] == "swap" for leg in a.get("in", []) for c in leg.get("coins", []) if c["asset"] == "ETH.ETH")
        refund_fees = sum(int(c["amount"]) for a in bound if a["type"] == "refund" for c in a.get("metadata", {}).get("refund", {}).get("networkFees", []) if c["asset"] == "ETH.ETH")
        source_bound = tx is not None and receipt is not None and norm(tx["hash"]) == source_id == norm(receipt["transactionHash"]) and tx.get("blockHash") == receipt.get("blockHash") and receipt.get("status") == "0x1"
        full_source_e8 = int(tx["value"], 16) // 10**10 if source_bound else None
        refund_e8 = sum(c[2] for c in native_claims)
        row = {"index": case["index"], "inbound": case["txid"], "period": selected["period"],
            "frame_stratum": selected["frame_stratum"], "sender": selected["sender"], "recipient": selected["memo_recipient"],
            "action_types": dict(Counter(a["type"] for a in bound)), "action_statuses": dict(Counter(a["status"] for a in bound)),
            "action_coverage_complete": action_complete, "bound_actions": len(bound), "missing_pages": missing_pages,
            "naive_btc_satoshis": sum(c["satoshis"] for c in claims), "frozen_btc_satoshis": frozen_four_field_total(bound),
            "reference_btc_satoshis": reference_total, "reference_outputs": ref_outputs,
            "btc_output_audit": audit, "payer": payer, "missing_btc": missing_btc, "eth_refund_checks": refunds,
            "input_transaction_bound": source_bound, "input_value_e8": full_source_e8,
            "input_value_wei_remainder": int(tx["value"], 16) % 10**10 if source_bound else None,
            "midgard_partition_input_e8": native_inputs, "swap_input_e8": swap_inputs,
            "refund_e8": refund_e8, "refund_fee_e8": refund_fees,
            "input_partition_matches_top_value": full_source_e8 == native_inputs if source_bound else None,
            "refund_balance_matches_top_value": full_source_e8 == swap_inputs + refund_e8 + refund_fees if source_bound else None,
            "description": "BTC payout and ETH refund recorded" if claims and native_claims else "ETH refund recorded; no BTC claim in captured actions",
            "refund_reasons": [a.get("metadata", {}).get("refund", {}).get("reason") for a in bound if a["type"] == "refund"]}
        rows.append(row)
        if normal_btc is None and audit["status"] == "resolved":
            normal_btc = (bound, btc)
    assert len(rows) == selection["n"]
    assert normal_btc is not None and normal_eth is not None, "Positive controls required"
    controls = []

    def btc_control(name, arguments, expected):
        actual = audit_outputs(*arguments)["status"]
        assert actual == expected, (name, actual)
        controls.append({"name": name, "expected": expected, "actual": actual})

    btc_control("unchanged_real_btc_copy", copy.deepcopy(normal_btc), "resolved")
    changed = copy.deepcopy(normal_btc)
    for transaction in changed[1].values():
        for output in transaction["vout"]:
            output["value"] += 1
    btc_control("one_satoshi_changed_outputs", changed, "unresolved")
    btc_control("missing_named_bitcoin", (normal_btc[0], {}), "unresolved")
    btc_control("no_btc_claims_do_not_verify_zero", ([], {}), "unresolved")
    for name, arguments, expected in [
        ("unchanged_real_eth_copy", copy.deepcopy(normal_eth), "resolved_router_event"),
        ("one_e8_changed_refund", (*normal_eth[:-1], normal_eth[-1] + 1), "refund_amount_mismatch"),
        ("missing_refund_receipt", (normal_eth[0], None, *normal_eth[2:]), "transaction_or_receipt_unavailable")]:
        actual = eth_refund_check(*arguments)["status"]
        assert actual == expected, (name, actual)
        controls.append({"name": name, "expected": expected, "actual": actual})
    modified = list(copy.deepcopy(normal_eth))
    modified[1]["logs"][0]["removed"] = True
    actual = eth_refund_check(*modified)["status"]
    assert actual == "refund_event_unresolved"
    controls.append({"name": "removed_log_not_evidence", "expected": "refund_event_unresolved", "actual": actual})
    covered = [r for r in rows if r["reference_btc_satoshis"] is not None]
    summary = {"selected": len(rows), "with_btc_reference": len(covered), "without_btc_claim": sum(not r["btc_output_audit"]["claims"] for r in rows),
        "naive_btc_satoshis_covered": sum(r["naive_btc_satoshis"] for r in covered),
        "frozen_btc_satoshis_covered": sum(r["frozen_btc_satoshis"] for r in covered),
        "reference_btc_satoshis_covered": sum(r["reference_btc_satoshis"] for r in covered),
        "naive_excess_satoshis_covered": sum(r["naive_btc_satoshis"] - r["reference_btc_satoshis"] for r in covered),
        "btc_output_audit": dict(Counter(r["btc_output_audit"]["status"] for r in rows)),
        "eth_refund_checks": dict(Counter(c["status"] for r in rows for c in r["eth_refund_checks"])),
        "payer_checks": dict(Counter(c["status"] for r in rows for c in r["payer"])),
        "unique_senders": len({r["sender"] for r in rows}), "unique_recipients": len({r["recipient"] for r in rows}),
        "input_partition_matches": sum(r["input_partition_matches_top_value"] is True for r in rows),
        "refund_balance_matches": sum(r["refund_balance_matches_top_value"] is True for r in rows)}
    return {"status": "MEASURED", "created_utc": now(), "summary": summary, "rows": rows, "controls": controls,
        "inputs_sha256": evidence.hashes, "scripts_sha256": {p.relative_to(ROOT).as_posix(): sha(p.read_bytes()) for p in
            (HERE / "evaluate_refunds.py", HERE.parent / "revision_v1/output_audit.py", HERE.parent / "revision_v1/audit_historical_payer.py")},
        "scope": "Refund-selected external accounting cases; BTC transaction IDs are protocol supplied. No proof of zero BTC payout for empty claims; no incidence or decoder-coverage estimate."}


if __name__ == "__main__":
    result = evaluate()
    write_new(HERE / "evaluation.json", result)
    print(result["summary"])
