"""Bounded read-only refund probe; requests and their raw bytes are append-only."""

import argparse
import hashlib
import json
import re
import time
from datetime import UTC, datetime
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
DEST = ROOT / "captures/revision_v2_refunds"
MIDGARD = "https://gateway.liquify.com/chain/thorchain_midgard"
THOR = "https://gateway.liquify.com/chain/thorchain_api"
PERIODS = (("2025-01", "2025-01-01", "2025-02-01"),
           ("2026-08", "2026-08-01", "2026-09-01"))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def now():
    return datetime.now(UTC).isoformat()


def write_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write((json.dumps(value, indent=2) + "\n").encode())


class Redirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urlparse(newurl)
        if parsed.scheme != "https" or parsed.hostname != urlparse(req.full_url).hostname:
            raise ValueError("Cross-host/non-HTTPS redirect refused")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class Capture:
    def __init__(self):
        DEST.mkdir(parents=True, exist_ok=True)
        (DEST / "requests").mkdir(exist_ok=True)
        self.protocol_hash = sha((HERE / "REFUND_PROTOCOL.md").read_bytes())
        self.last_request = 0.0

    def fetch(self, key, urls, method=None, params=None, json_expected=True):
        assert re.fullmatch(r"[a-zA-Z0-9_-]+", key)
        record_path = DEST / "requests" / (key + ".json")
        if record_path.exists():
            record = read(record_path)
            assert record["protocol_sha256"] == self.protocol_hash
            assert record["urls"] == list(urls) and record["rpc_method"] == method and record["params"] == params
            if record["status"] != "available":
                return None
            raw = (DEST / record["response_file"]).read_bytes()
            assert sha(raw) == record["response_sha256"]
            data = json.loads(raw) if json_expected else raw
            return data["result"] if method else data
        assert len(list((DEST / "requests").glob("*.json"))) < 400
        assert method in {None, "eth_getTransactionByHash", "eth_getTransactionReceipt"}
        record = {"key": key, "urls": list(urls), "rpc_method": method,
                  "params": params, "started_utc": now(), "status": "unavailable",
                  "protocol_sha256": self.protocol_hash, "script_sha256": sha(Path(__file__).read_bytes()),
                  "attempts": []}
        for attempt_number, url in enumerate(urls[:2], 1):
            host = urlparse(url).hostname
            assert url.startswith("https://") and host in {
                "gateway.liquify.com", "ethereum-rpc.publicnode.com", "eth.llamarpc.com",
                "blockstream.info", "mempool.space", "gitlab.com"}
            time.sleep(max(0, .5 - (time.monotonic() - self.last_request)))
            self.last_request = time.monotonic()
            body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}).encode() if method else None
            stem = key + f"_attempt{attempt_number}"
            attempt = {"url": url, "started_utc": now(), "method": "POST" if body else "GET",
                       "tls_verified": True, "authorization_sent": False, "cookie_sent": False}
            if body:
                request_path = DEST / (stem + ".request.json")
                with request_path.open("xb") as stream:
                    stream.write(body)
                attempt.update(request_file=request_path.name, request_sha256=sha(body))
            raw = None
            try:
                request = Request(url, data=body, headers={"Accept": "application/json",
                    "Content-Type": "application/json", "User-Agent": "VCA-academic-validation/2.0"})
                try:
                    response = build_opener(Redirects()).open(request, timeout=25)
                except HTTPError as error:
                    response = error
                with response:
                    attempt["http_status"] = response.status
                    attempt["final_url"] = response.geturl()
                    raw = response.read(10_000_001)
                raw_path = DEST / (stem + ".response.bin")
                with raw_path.open("xb") as stream:
                    stream.write(raw)
                attempt.update(response_file=raw_path.name, response_sha256=sha(raw), bytes=len(raw))
                assert len(raw) <= 10_000_000, "Response-size ceiling"
                assert attempt["http_status"] == 200, "HTTP failure"
                data = json.loads(raw) if json_expected else raw
                if method:
                    assert data.get("id") == 1 and data.get("jsonrpc") == "2.0"
                    assert isinstance(data.get("result"), dict) and not data.get("error"), "Missing RPC result"
                if json_expected:
                    assert isinstance(data, (dict, list)), "Unexpected JSON shape"
                record.update(status="available", response_file=raw_path.name, response_sha256=sha(raw))
            except (HTTPError, URLError, TimeoutError, OSError, ValueError, AssertionError) as error:
                attempt["error"] = type(error).__name__ + ": " + str(error)
            attempt["ended_utc"] = now()
            record["attempts"].append(attempt)
            if record["status"] == "available":
                break
        record["ended_utc"] = now()
        write_new(record_path, record)
        print(json.dumps({"request": key, "status": record["status"]}), flush=True)
        if record["status"] != "available":
            return None
        data = json.loads(raw) if json_expected else raw
        return data["result"] if method else data


def epoch(day):
    return int(datetime.fromisoformat(day).replace(tzinfo=UTC).timestamp())


def collect_frame():
    capture = Capture()
    result = {"created_utc": now(), "protocol_sha256": capture.protocol_hash, "periods": []}
    for period, lower, upper in PERIODS:
        report = {"period": period, "lower": lower, "upper": upper, "pages": [], "stop": "page_ceiling"}
        token = None
        tokens = set()
        for page in range(10):
            params = {"type": "refund", "asset": "ETH.ETH", "limit": 50}
            if token:
                params["nextPageToken"] = token
            else:
                params["timestamp"] = epoch(upper)
            key = f"frame_{period.replace('-', '')}_{page + 1:02}"
            url = MIDGARD + "/v2/actions?" + urlencode(params)
            data = capture.fetch(key, [url, url])
            if data is None or not isinstance(data.get("actions"), list):
                report["stop"] = "unavailable_page"
                break
            actions = data["actions"]
            dates = [int(a["date"]) for a in actions]
            report["pages"].append({"key": key, "actions": len(actions),
                "reported_count": data.get("count"), "meta": data.get("meta"),
                "min_date_ns": min(dates) if dates else None, "max_date_ns": max(dates) if dates else None})
            if any(d >= epoch(upper) * 10**9 for d in dates):
                report["stop"] = "upper_bound_not_respected"
                break
            if dates and min(dates) < epoch(lower) * 10**9:
                report["stop"] = "lower_bound_reached"
                break
            if len(actions) < 50:
                report["stop"] = "short_final_page"
                break
            token = data.get("meta", {}).get("nextPageToken")
            if not token or token in tokens:
                report["stop"] = "missing_or_repeated_token"
                break
            tokens.add(token)
        result["periods"].append(report)
    write_new(HERE / "frame_capture.json", result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=["frame"])
    parser.parse_args()
    collect_frame()
