# External refund accounting supplement

This supplement extends the revision-5 review artifact with a separate external
refund experiment. It does not overwrite revision 5 or change the frozen VCA
decoder, initial 40 swaps, additional 96 swaps, or their first predictions.

## Run from a new extraction

First install revision 5's locked environment using its README. Extract this
supplement into a **different, new directory**, such as `C:/vca-refund-review`.
Keep the independently supplied ZIP checksum and verify it before extraction.
From the supplement's extracted root, use that already installed environment:

```powershell
C:/vca-review/source/.venv/Scripts/python.exe -X utf8 -B tools/recheck_refunds.py
```

Adjust only the Python path to the actual revision-5 extraction. The command
requires Python 3.12 and its frozen VCA, eth-abi and eth-utils dependencies. It
verifies the frozen Bech32 helper, checks all distributed file hashes, creates a
new `_checks` workspace, recalculates the selected cases, runs eight controls,
reconstructs selection with separate code, and checks original hashes again.
`_checks/RESULT.json` must report `PASS`. Existing `_checks` directories are
refused; use a new extraction for a repeat. Do not run `capture_*.py` or
`pin_api_spec.py`: those are preserved acquisition code, not replay commands.

The checker blocks Python socket operations and records attempts; this is not an
OS firewall. Its successful execution is a fresh calculation using supplied data,
not an independent-team or fresh-installation claim. Record operator affiliation,
actual machine details and any author assistance when reporting another run.

## Observed findings

- The prospective local protocol queried January 2025 and August 2026. The first
  January page timed out twice and remains unavailable. August's five pages
  reached the beginning-of-month boundary: 242 in-period actions, 87 eligible
  native-ETH/literal-BTC refund actions, comprising 3 with BTC claims and 84
  without. Salted hashing selected all 3 and 8 of the latter; no replacements.
- The 3 partial refunds repeat BTC outputs across swap and refund actions.
  Naive sum: **9.49019624 BTC**. Frozen-key, indexed-output and amount-independent
  recipient-output reference sums: **4.74509812 BTC**. Excess: **4.74509812 BTC**.
- All 11 ETH refunds agree with transaction receipts and protocol outbounds.
  All 3 BTC payers have corroborating historical protocol/input-script records.
  No BTC claim in the other 8 observations is **not proof of zero BTC payment**;
  the conservative output audit intentionally reports those totals unresolved.
- There are only 4 senders and 4 BTC recipients; the 3 partial refunds use 2 of
  each. This targeted sample demonstrates external recurrence, not prevalence,
  full-incident accuracy, new decoder coverage, or independent payout discovery.
- The sample includes BTC payout plus ETH refund, but contains no real case of
  multiple distinct BTC payouts for one deposit. Equal-output boundary evidence
  remains synthetic in revision 5.

## Evidence and dependencies

`experiments/revision_v2/` preserves the pre-collection plan, frame, selection,
executed scripts, case records, primary result, eight controls, and separate
recalculation. `captures/revision_v2_refunds/` contains raw public responses,
request metadata, times and digests, including failed attempts. `VERSION_MANIFEST`
binds the base ZIP and original support inputs. The few copied revision-1 support
files retain their original bytes and are private to this separate extraction;
do not use them to replace metadata projected in revision 5.

Raw THORNode ABI source is distributed under the included MIT license. Its pinned
event schema documents parsing; it does not prove a contract's deployed bytecode.
Public protocol data are compared with public Ethereum/Bitcoin responses, not
independently replayed consensus or state transitions.
